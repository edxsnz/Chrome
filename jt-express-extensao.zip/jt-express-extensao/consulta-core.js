// consulta-core.js
// Motor das consultas longas (abas Lote e Expedido): rede, login, fila de
// requisições e os laços que consultam lote por lote / grupo por grupo.
// Não mexe na tela: é carregado pelo popup (que usa as configurações e as
// funções puras) e pelo background.js (que roda as consultas mesmo com o
// popup fechado). Tudo aqui precisa funcionar sem DOM.
//
// Como a consulta é feita: o fetch roda DENTRO da aba do JMS (chrome.scripting),
// igual ao que o próprio site faz — assim a requisição sai com a origem e o
// Referer reais do sistema (chamadas vindas direto da extensão costumam ser
// recusadas por gateways). O token vem do cookie YL_TOKEN, lido na hora de
// cada consulta; ele nunca é guardado nem exibido.

// ---------- ABA LOTE (motor) ----------
const LOTE_API = {
  hostPreferido: "jmsbr.jtjms-br.com",
  // Qualquer endereço do JMS (jmsbr, outro subdomínio...) — o mesmo padrão
  // do host_permissions do manifest.
  padraoAba: "https://*.jtjms-br.com/*",
  url: "https://gw.jtjms-br.com/operatingplatform/packScanList/waybillIdsByPackageNumber",
  cookie: "YL_TOKEN",
};

const LOTE_CFG = {
  concorrencia: 1, // uma consulta por vez: carga leve no JMS
  tentativas: 4, // por lote
  backoffBaseMs: 2000,
  backoffMaxMs: 20000,
  timeoutMs: 25000,
  // Rajada (igual ao Expedido): um lote logo depois do outro, só com uma folga
  // mínima, até o sistema bloquear; o bloqueio é o mesmo do Expedido (ritmo do JMS abaixo).
  espacoMinMs: 10,
  espacoMaxMs: 30,
  // Memória dos lotes (só na sessão do navegador): no Continuar/Criar lote,
  // um lote conferido há menos disso não é consultado de novo (o escolhido,
  // o atual e os abertos no Criar lote são sempre consultados). Antes de dizer
  // "tudo em lote", os que vieram da memória são conferidos de novo.
  memoriaValidadeMs: 10 * 60 * 1000,
  // Lote terminado (LOTE_TAMANHO ou mais) quase não muda: fica na memória o
  // turno todo. A conferência final (sempre de verdade) continua valendo.
  memoriaCheioValidadeMs: 12 * 60 * 60 * 1000,
};

// Pacotes que cabem num lote (popup e background usam o mesmo número)
const LOTE_TAMANHO = 150;


const LOTE_MSG = {
  semAba: "Não encontrei o sistema JMS aberto. Abra o JMS em uma aba deste navegador, entre na sua conta e tente de novo.",
  recarregar: "A extensão foi atualizada e precisa ser recarregada para acessar o JMS. Depois de recarregar, cole as listas de novo.",
  permitir: "A extensão está sem permissão para acessar o sistema JMS. Clique abaixo e confirme.",
  semToken: "Não achei o seu login do sistema. Atualize a página do JMS (F5), confira se está logado e tente de novo.",
  tokenEstranho: "O login do sistema veio em um formato inesperado. Saia e entre de novo no JMS.",
  auth: "O sistema recusou o login (sessão expirada?). Entre de novo no JMS e tente outra vez.",
  abaPerdida: "A aba do sistema foi fechada ou recarregada durante a consulta. Deixe-a aberta e tente de novo.",
  generico: "Não foi possível consultar os lotes. Tente novamente.",
  semFundo: "Não foi possível iniciar a consulta. Feche e abra a extensão de novo; se continuar, recarregue a extensão.",
};

class ErroLote extends Error {
  constructor(tipo, mensagem) {
    super(mensagem);
    this.tipo = tipo;
  }
}

// ATENÇÃO: esta função roda DENTRO da aba do sistema (o chrome.scripting
// serializa o código dela), então NÃO pode usar nenhuma variável deste
// arquivo — só o que chega pelos argumentos e as APIs do navegador.
async function consultarLoteNaPagina(url, cabecalhos, corpoJson, timeoutMs) {
  const controle = new AbortController();
  const relogio = setTimeout(() => controle.abort(), timeoutMs);
  try {
    const resposta = await fetch(url, {
      method: corpoJson == null ? "GET" : "POST", // sem corpo = GET
      headers: cabecalhos,
      body: corpoJson == null ? undefined : corpoJson,
      credentials: "omit",
      redirect: "error", // se o sistema redirecionar, não manda o token pra outro lugar
      signal: controle.signal,
    });
    let json = null;
    try {
      json = await resposta.json();
    } catch (e) {
      json = null;
    }
    return {
      status: resposta.status,
      ok: resposta.ok,
      retryAfter: resposta.headers.get("retry-after"),
      json,
    };
  } catch (e) {
    return { status: 0, ok: false, erro: e && e.name === "AbortError" ? "timeout" : "rede" };
  } finally {
    clearTimeout(relogio);
  }
}

function montarCabecalhosLote(token) {
  return {
    accept: "application/json, text/plain, */*",
    "accept-language": "pt-BR,pt;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
    authtoken: token,
    "cache-control": "max-age=2, must-revalidate",
    "content-type": "application/json;charset=UTF-8",
    lang: "PT",
    langtype: "PT",
    routename: "trackingExpress",
    routernamelist:
      "%E6%93%8D%E4%BD%9C%E5%B9%B3%E5%8F%B0%3E%E5%BF%AB%E4%BB%B6%E6%9F%A5%E8%AF%A2%3E%E5%BF%AB%E4%BB%B6%E8%B7%9F%E8%B8%AA",
    timezone: "GMT-0300",
  };
}

const dormir = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const aleatorioEntre = (min, max) => min + Math.random() * (max - min);

function esperaBackoff(tentativa) {
  return Math.min(LOTE_CFG.backoffBaseMs * 2 ** (tentativa - 1), LOTE_CFG.backoffMaxMs) + Math.random() * 250;
}

function esperaDoRetryAfter(valor, tentativa) {
  const segundos = Number(valor);
  if (valor != null && valor !== "" && Number.isFinite(segundos) && segundos >= 0) {
    return Math.min(segundos * 1000, LOTE_CFG.backoffMaxMs * 2);
  }
  return esperaBackoff(tentativa);
}

// ---------- Ritmo do JMS (Lote e Expedido juntos) ----------
// O gateway do JMS aceita ~64 consultas e depois recusa tudo (HTTP 405, que
// chega como "sem conexão") por ~1 min; a contagem dele só zera depois do
// bloqueio. Por padrão as duas abas consultam o mais rápido possível até
// bloquear e, no bloqueio, esperam ~1 min (cada motor cuida do seu).
// Opcional (EXP_CFG.rajadaCota > 0): orçamento COMUM às duas abas, com pausa
// de 1 min a cada N consultas; se bloquear antes, a rajada diminui.
const rajadaJms = { cota: 0, enviadas: 0, inicio: 0 };
function cotaRajadaJms() {
  if (!rajadaJms.cota) {
    const c = Math.floor(EXP_CFG.rajadaCota);
    rajadaJms.cota = c > 0 ? c : Infinity;
  }
  return rajadaJms.cota;
}
function contarEnvioJms() {
  if (!rajadaJms.enviadas) rajadaJms.inicio = Date.now();
  rajadaJms.enviadas++;
}
// O sistema voltou depois de um bloqueio: a consulta que passou abre uma rajada nova
function recomecarRajadaJms() {
  rajadaJms.enviadas = 1;
  rajadaJms.inicio = Date.now();
}
// Bloqueou depois de "aceitas": a rajada fica menor (com folga e uma mínima).
// Devolve a cota nova, ou null se não mudou.
function baixarCotaJms(aceitas) {
  const cota = cotaRajadaJms();
  if (cota === Infinity) return null;
  const nova = Math.max(EXP_CFG.rajadaMinima, Math.min(cota, aceitas - EXP_CFG.rajadaFolga));
  if (nova >= cota) return null;
  rajadaJms.cota = nova;
  return nova;
}
// Antes de cada consulta: se a rajada completou, espera o minuto dela acabar.
// Devolve false se a consulta foi cancelada durante a pausa.
async function respeitarRajadaJms(ativo, aoAguardar = () => {}, aoRegistro = () => {}) {
  while (rajadaJms.enviadas >= cotaRajadaJms()) {
    const falta = rajadaJms.inicio + EXP_CFG.janelaMs + EXP_CFG.janelaMargemMs - Date.now();
    if (falta > 0) {
      aoRegistro({ t: Date.now(), tipo: "rajada", enviadas: rajadaJms.enviadas, duracaoMs: Date.now() - rajadaJms.inicio, esperaMs: falta, cota: rajadaJms.cota });
      const ate = Date.now() + falta;
      aoAguardar(ate, "rajada");
      while (ativo() && Date.now() < ate) await dormir(Math.min(1000, ate - Date.now()));
      aoAguardar(0, "");
      if (!ativo()) return false;
    }
    // (outra consulta pode ter recomeçado a rajada enquanto esta esperava)
    if (rajadaJms.enviadas >= cotaRajadaJms() && rajadaJms.inicio + EXP_CFG.janelaMs + EXP_CFG.janelaMargemMs <= Date.now()) rajadaJms.enviadas = 0;
  }
  return ativo();
}

// O login do JMS (cookie YL_TOKEN) só é aceito de jtjms-br.com ou subdomínios.
const LOTE_DOMINIO = "jtjms-br.com";
function ehDominioJms(dominio) {
  const d = String(dominio || "").replace(/^\./, "").toLowerCase();
  return d === LOTE_DOMINIO || d.endsWith("." + LOTE_DOMINIO);
}

function hostDaAba(aba) {
  try {
    return new URL(aba && aba.url).hostname.toLowerCase();
  } catch (e) {
    return "";
  }
}

// Limpa o valor lido (aspas, %xx) sem nunca mostrar ou guardar o token.
function limparToken(valor) {
  let v = String(valor == null ? "" : valor).trim().replace(/^"(.*)"$/, "$1").trim();
  if (/%[0-9A-Fa-f]{2}/.test(v)) {
    try {
      v = decodeURIComponent(v).trim();
    } catch (e) {
      /* deixa como veio */
    }
  }
  // O JMS às vezes guarda o login como JSON: {"value": "..."} / {"data": ...} / {"token": ...}
  if (v.startsWith("{")) {
    try {
      const j = JSON.parse(v);
      const t = j && (j.value || j.data || j.token);
      if (typeof t === "string") v = t.trim();
    } catch (e) {
      /* não era JSON: deixa como veio (a validação recusa) */
    }
  }
  return v;
}

// Roda DENTRO da aba do JMS (precisa ser autocontida). Plano B para quando o
// login não aparece pela API de cookies: lê do próprio site.
function lerTokenNaPagina(nome) {
  const alvo = String(nome).toLowerCase();
  try {
    for (const parte of document.cookie.split(";")) {
      const k = parte.indexOf("=");
      if (k > 0 && parte.slice(0, k).trim().toLowerCase() === alvo) return parte.slice(k + 1).trim();
    }
  } catch (e) {
    /* sem acesso a document.cookie */
  }
  for (const area of ["localStorage", "sessionStorage"]) {
    try {
      const st = window[area];
      for (let n = 0; n < st.length; n++) {
        const chave = st.key(n);
        if (chave && chave.toLowerCase() === alvo) return st.getItem(chave) || "";
      }
    } catch (e) {
      /* armazenamento indisponível */
    }
  }
  return "";
}

// Junta todos os cookies YL_TOKEN do domínio do JMS: normais e particionados
// (o Chrome novo guarda alguns cookies "por site", e a busca simples não os vê),
// no mesmo perfil/janela da aba do sistema.
async function cookiesDoLogin(aba) {
  if (!chrome.cookies || !chrome.cookies.getAll) return [];
  let storeId;
  try {
    const lojas = chrome.cookies.getAllCookieStores ? await chrome.cookies.getAllCookieStores() : [];
    const loja = (lojas || []).find((l) => (l.tabIds || []).includes(aba && aba.id));
    if (loja) storeId = loja.id;
  } catch (e) {
    storeId = undefined;
  }
  const base = storeId ? { domain: LOTE_DOMINIO, storeId } : { domain: LOTE_DOMINIO };
  const achados = [];
  for (const filtro of [base, { ...base, partitionKey: {} }]) {
    try {
      const lista = await chrome.cookies.getAll(filtro);
      if (Array.isArray(lista)) achados.push(...lista);
    } catch (e) {
      /* Chrome antigo sem suporte a partitionKey: segue com o que tiver */
    }
  }
  const alvo = LOTE_API.cookie.toLowerCase();
  return achados.filter((c) => c && String(c.name).toLowerCase() === alvo && ehDominioJms(c.domain) && c.value);
}

// Confere se a extensão consegue falar com o JMS antes de procurar a aba.
// "recarregar": arquivos novos, mas o Chrome ainda roda o manifest antigo
//   (sem as permissões de cookies/scripting) — só recarregar resolve.
// "permitir": manifest certo, mas o acesso ao site foi negado/restrito.
async function verificarAcessoLote() {
  if (!chrome.cookies || !chrome.cookies.getAll || !chrome.scripting || !chrome.scripting.executeScript) return "recarregar";
  if (!chrome.permissions || !chrome.permissions.contains) return "ok"; // sem como checar: segue e deixa a consulta dizer
  try {
    const ok = await chrome.permissions.contains({ origins: [LOTE_API.padraoAba] });
    return ok ? "ok" : "permitir";
  } catch (e) {
    return "permitir";
  }
}

async function obterTokenLote(aba) {
  const host = hostDaAba(aba);
  const valido = (v) => /^[A-Za-z0-9._-]{8,300}$/.test(v);
  const cookies = await cookiesDoLogin(aba);
  // Prioridade: cookie do próprio endereço da aba > do domínio pai > qualquer outro do JMS
  const peso = (c) => {
    const d = String(c.domain).replace(/^\./, "").toLowerCase();
    if (d === host) return 0;
    if (host.endsWith("." + d)) return 1;
    return 2;
  };
  cookies.sort((a, b) => peso(a) - peso(b));
  const candidatos = cookies.map((c) => limparToken(c.value)).filter(Boolean);

  if (!candidatos.length && aba && aba.id != null && chrome.scripting) {
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId: aba.id }, func: lerTokenNaPagina, args: [LOTE_API.cookie] });
      const v = limparToken(r && r.result);
      if (v) candidatos.push(v);
    } catch (e) {
      /* aba indisponível: cai no aviso de login abaixo */
    }
  }

  if (!candidatos.length) throw new ErroLote("token", LOTE_MSG.semToken);
  const bom = candidatos.find(valido);
  if (!bom) throw new ErroLote("token", LOTE_MSG.tokenEstranho);
  return bom;
}

async function acharAbaSistema() {
  const acesso = await verificarAcessoLote();
  if (acesso !== "ok") throw new ErroLote(acesso, LOTE_MSG[acesso]);
  let abas = [];
  try {
    abas = await chrome.tabs.query({ url: LOTE_API.padraoAba });
  } catch (e) {
    abas = [];
  }
  // Prioridade: aba ativa do jmsbr > qualquer jmsbr > ativa de outro endereço do JMS > qualquer outra
  const vivas = (abas || []).filter((a) => a && !a.discarded && a.id != null);
  const preferidas = vivas.filter((a) => hostDaAba(a) === LOTE_API.hostPreferido);
  const aba =
    preferidas.find((a) => a.active) || preferidas[0] || vivas.find((a) => a.active) || vivas[0];
  if (!aba || aba.id == null) throw new ErroLote("aba", LOTE_MSG.semAba);
  return aba;
}

async function pedirLote(tabId, token, lote) {
  const [execucao] = await chrome.scripting.executeScript({
    target: { tabId },
    func: consultarLoteNaPagina,
    args: [LOTE_API.url, montarCabecalhosLote(token), JSON.stringify([lote]), LOTE_CFG.timeoutMs],
  });
  return execucao && execucao.result ? execucao.result : { status: 0, ok: false, erro: "rede" };
}

// Decide o que fazer com a resposta de UM lote.
function classificarRespostaLote(r, lote) {
  if (r.erro === "aba") return { tipo: "fatal", motivo: LOTE_MSG.abaPerdida };
  if (r.erro === "timeout") return { tipo: "tentar", motivo: "demorou demais" };
  // Recusa na hora (o 405 do bloqueio chega como "sem conexão"): é o bloqueio
  if (r.erro) return { tipo: "limite", retryAfter: null, motivo: "bloqueio do minuto (HTTP 405 / sem conexão)" };
  if (r.status === 401 || r.status === 403) return { tipo: "auth" };
  if (r.status === 429) return { tipo: "limite", retryAfter: r.retryAfter, motivo: "limite de requisições do servidor" };
  if (r.status === 405) return { tipo: "limite", retryAfter: r.retryAfter, motivo: "bloqueio do minuto (HTTP 405)" };
  if (r.status >= 500) return { tipo: "tentar", motivo: `erro ${r.status} do servidor` };
  if (!r.ok) return { tipo: "falha", motivo: `erro HTTP ${r.status}` };

  const j = r.json;
  if (!j || typeof j !== "object") return { tipo: "tentar", motivo: "resposta inesperada (sessão expirada?)" };

  const sucesso = (j.succ === true || j.code === 1) && j.fail !== true;
  if (!sucesso) {
    const msg = String(j.msg || "").slice(0, 80);
    if (/token|login|sess[aã]o|expir|autent|unauthor/i.test(msg)) return { tipo: "auth" };
    return { tipo: "falha", motivo: msg || "o sistema recusou a consulta" };
  }
  if (!Array.isArray(j.data)) return { tipo: "tentar", motivo: "resposta sem dados" };

  // Pedimos 1 lote por vez. Se veio 1 item, é ele (mesmo que o código volte
  // formatado diferente); se vierem vários, só vale o que bate com o lote.
  // Regra nº 1: só confirma o que é do lote pedido. Um item só vale se o
  // packageNumber bater (ou não vier); item de OUTRO lote é falha deste lote.
  const itens = j.data.filter((i) => i && typeof i === "object");
  const numero = (i) => String(i.packageNumber == null ? "" : i.packageNumber).trim().toUpperCase();
  const alvo = itens.length === 1 && !numero(itens[0]) ? itens : itens.filter((i) => numero(i) === lote);
  if (itens.length && !alvo.length) return { tipo: "falha", motivo: "o sistema respondeu com outro lote" };
  const ids = new Set();
  for (const item of alvo) {
    if (Array.isArray(item.waybillIds)) item.waybillIds.forEach((id) => ids.add(String(id).trim().toUpperCase()));
  }
  return { tipo: "ok", ids, vazio: ids.size === 0 };
}

// Vagas de requisição ao JMS valem para TODAS as execuções: as de uma
// consulta cancelada continuam no ar até responder, e uma consulta nova
// não pode somar com elas (nunca mais que LOTE_CFG.concorrencia ao mesmo tempo).
// Bloqueio do JMS visto por QUALQUER motor (Lote ou Expedido rodando juntos):
// o limite é do mesmo sistema; quando um toma bloqueio, o outro também espera
// em vez de levar outro 405 e alongar o bloqueio.
let jmsBloqueadoAte = 0;
function avisarBloqueioJms(ate) {
  jmsBloqueadoAte = Math.max(jmsBloqueadoAte, ate);
}

let loteNoAr = 0;
const loteEsperandoVaga = [];
async function pegarVagaLote() {
  while (loteNoAr >= LOTE_CFG.concorrencia) await new Promise((r) => loteEsperandoVaga.push(r));
  loteNoAr++;
}
function soltarVagaLote() {
  loteNoAr--;
  const proximo = loteEsperandoVaga.shift();
  if (proximo) proximo();
}

// Leitura defensiva do que volta da sessão (retomada depois de o Chrome
// encerrar o background no meio de uma consulta).
const listaDeTextos = (v) => (Array.isArray(v) ? v.filter((x) => typeof x === "string") : []);
const listaDePares = (v) => (Array.isArray(v) ? v.filter((p) => Array.isArray(p) && p.length === 2 && typeof p[0] === "string") : []);

// ativo(): quem chamou ainda quer esta consulta (falso = cancelada/substituída).
// retomar: fotografia salva por aoProgresso — continua de onde parou, sem
// repetir lote já consultado e sem perder o que já foi achado.
// aoProgresso(feitos, total, fotografia) é chamado depois de CADA lote.
// prontos: Map lote -> lista de códigos (da memória): entra no resultado sem
//   consultar e fica marcado em daMemoria (para a conferência final).
// aoLote(lote, ids): cada lote consultado de verdade (para guardar na memória).
async function executarConsultaLotes({ lotes, coletaSet, tabId, token, ativo: continuar = () => true, aoProgresso = () => {}, retomar = null, prontos = null, aoLote = () => {}, aoAguardar = () => {} }) {
  const salvo = retomar && typeof retomar === "object" && Array.isArray(retomar.fila) ? retomar : null;
  const fila = salvo ? listaDeTextos(salvo.fila) : [...lotes];
  const encontrados = new Set(salvo ? listaDeTextos(salvo.encontrados) : []);
  const falhas = new Map(salvo ? listaDePares(salvo.falhas).map(([l, m]) => [l, String(m)]) : []);
  const vazios = new Set(salvo ? listaDeTextos(salvo.vazios) : []);
  // lote -> quantos pacotes ele já tem (todos, não só os da coleta)
  const contagem = new Map(salvo ? listaDePares(salvo.contagem).filter((p) => Number.isFinite(p[1])) : []);
  let concluidos = salvo && Number.isInteger(salvo.concluidos) ? salvo.concluidos : 0;
  // lote -> códigos da coleta achados nele (a conferência final troca os da memória)
  const porLote = new Map(salvo ? listaDePares(salvo.porLote).map(([l, ids]) => [l, listaDeTextos(ids)]) : []);
  const daMemoria = new Set(salvo ? listaDeTextos(salvo.daMemoria) : []);
  const emCurso = new Set(); // lotes pedidos e ainda sem resposta: voltam para a fila numa retomada
  let fatal = null;
  let pausaGlobal = Promise.resolve(); // 429 de qualquer um segura TODOS os trabalhadores
  // Bloqueio do JMS: quando começou (0 = livre) e quantos o sistema aceitou desde que liberou
  let travouEm = 0;
  let aceitasDesde = 0;
  let bloqueioAte = 0; // ninguém consulta antes disso (vale para todos os trabalhadores)

  const ativo = () => continuar() && !fatal;
  const fotografia = () => ({
    fila: [...emCurso, ...fila],
    encontrados: [...encontrados],
    falhas: [...falhas],
    vazios: [...vazios],
    contagem: [...contagem],
    concluidos,
    porLote: [...porLote],
    daMemoria: [...daMemoria],
  });

  function anotarOk(lote, ids) {
    const achados = [];
    ids.forEach((id) => {
      if (coletaSet.has(id)) {
        encontrados.add(id);
        achados.push(id);
      }
    });
    porLote.set(lote, achados);
    if (ids.size === 0) vazios.add(lote);
    else vazios.delete(lote);
    contagem.set(lote, ids.size);
  }

  // Da memória: sem consultar (só os que ainda estão na fila)
  if (prontos instanceof Map && prontos.size) {
    let usou = 0;
    for (let i = fila.length - 1; i >= 0; i--) {
      const lote = fila[i];
      const ids = prontos.get(lote);
      if (!Array.isArray(ids)) continue;
      fila.splice(i, 1);
      anotarOk(lote, new Set(listaDeTextos(ids).map((id) => id.trim().toUpperCase())));
      daMemoria.add(lote);
      concluidos++;
      usou++;
    }
    if (usou && continuar()) aoProgresso(concluidos, lotes.length, fotografia());
  }

  async function consultarUm(lote) {
    let ultimoMotivo = LOTE_MSG.generico;
    const inicioLote = Date.now();
    for (let tentativa = 1; tentativa <= LOTE_CFG.tentativas; tentativa++) {
      await pausaGlobal;
      if (!ativo()) return null;
      bloqueioAte = Math.max(bloqueioAte, jmsBloqueadoAte);
      if (bloqueioAte > Date.now()) {
        while (ativo() && Date.now() < bloqueioAte) await dormir(Math.min(1000, bloqueioAte - Date.now()));
        aoAguardar(0, "");
        if (!ativo()) return null;
      }
      if (!(await respeitarRajadaJms(ativo, aoAguardar))) return null;

      await pegarVagaLote();
      if (!ativo()) {
        soltarVagaLote();
        return null;
      }
      let resposta;
      try {
        contarEnvioJms();
        resposta = await pedirLote(tabId, token, lote);
      } catch (e) {
        resposta = { erro: "aba" };
      } finally {
        soltarVagaLote();
      }
      if (!ativo()) return null;

      const c = classificarRespostaLote(resposta, lote);
      if (c.tipo !== "limite" && c.tipo !== "fatal" && c.tipo !== "auth" && !(c.tipo === "tentar" && resposta && resposta.erro)) {
        // O sistema respondeu: se estava bloqueado, liberou (rajada nova)
        if (travouEm) {
          travouEm = 0;
          aceitasDesde = 0;
          recomecarRajadaJms();
        }
        aceitasDesde++;
      }
      if (c.tipo === "ok") return c;
      if (c.tipo === "auth") {
        fatal = new ErroLote("auth", LOTE_MSG.auth);
        return null;
      }
      if (c.tipo === "fatal") {
        fatal = new ErroLote("aba", c.motivo);
        return null;
      }
      if (c.tipo === "falha") return c;

      ultimoMotivo = c.motivo;
      if (c.tipo === "limite") {
        // Bloqueio: não gasta tentativa. Espera os 62 s desde a recusa, testa o
        // MESMO lote e, se ainda recusar, espera mais 62 s (EXP_CFG.sondaMs).
        if (!travouEm) {
          travouEm = Date.now();
          baixarCotaJms(aceitasDesde);
        }
        const desde = Date.now() - travouEm;
        const passo = desde < EXP_CFG.janelaMs ? EXP_CFG.janelaMs + EXP_CFG.janelaMargemMs - desde : EXP_CFG.sondaMs;
        const pedido = c.retryAfter != null ? esperaDoRetryAfter(c.retryAfter, Math.min(tentativa, 5)) : 0;
        const espera = Math.max(passo, pedido);
        if (Date.now() + espera - inicioLote > EXP_CFG.limiteTetoMs) return { tipo: "falha", motivo: "o sistema não liberou a consulta" };
        bloqueioAte = Math.max(bloqueioAte, Date.now() + espera);
        avisarBloqueioJms(bloqueioAte);
        aoAguardar(bloqueioAte, "limite");
        tentativa--;
      } else if (tentativa < LOTE_CFG.tentativas) {
        await dormir(esperaBackoff(tentativa));
      }
    }
    return { tipo: "falha", motivo: ultimoMotivo };
  }

  async function trabalhador() {
    while (ativo()) {
      const lote = fila.shift(); // atômico: JS roda uma coisa por vez, dois trabalhadores nunca pegam o mesmo lote
      if (lote === undefined) return;
      emCurso.add(lote);

      const r = await consultarUm(lote);
      if (r === null) return; // cancelado ou erro fatal
      if (!continuar()) return;

      if (r.tipo === "ok") {
        anotarOk(lote, r.ids);
        aoLote(lote, [...r.ids]);
      } else {
        falhas.set(lote, r.motivo);
      }
      emCurso.delete(lote);

      concluidos++;
      aoProgresso(concluidos, lotes.length, fotografia());
      if (fila.length) await dormir(aleatorioEntre(LOTE_CFG.espacoMinMs, LOTE_CFG.espacoMaxMs));
    }
  }

  const quantos = Math.min(LOTE_CFG.concorrencia, fila.length);
  await Promise.all(Array.from({ length: quantos }, trabalhador));
  return { encontrados, falhas, vazios, contagem, fatal, porLote, daMemoria };
}

// ---------- RASTREIO (usado pelo raio e pelo painel do JMS) ----------
// O fetch roda dentro da aba do JMS e o token é lido na hora (nunca guardado
// nem exibido). Ritmo decidido pelo Edson: "consulte tudo muito rápido até
// bloquear; bloqueando, espera 1 minuto" — vale para Lote, raio e painel.

const EXP_API = {
  url: "https://gw.jtjms-br.com/operatingplatform/podTracking/inner/query/keywordList",
};

const EXP_CFG = {
  // Rajada: uma consulta logo depois da outra, o mais rápido possível (folga mínima).
  pausaMinMs: 10,
  pausaMaxMs: 30,
  // Bloqueio do JMS (HTTP 405, que chega como "sem conexão", ou 429): dura ~1 min.
  // Decisão do Edson: a cada recusa, espera 62 s INTEIROS e testa o mesmo
  // código (tentar antes só piora). Vale para Lote, raio e painel.
  janelaMs: 62 * 1000,
  janelaMargemMs: 0,
  sondaMs: 62 * 1000,
  // Parar antes do bloqueio NÃO funciona no JMS real: a contagem dele só zera
  // depois de um bloqueio. Por isso a rajada vai até bloquear (0 = sem cota).
  rajadaCota: 0,
  rajadaMinima: 20,
  rajadaFolga: 4, // depois de um bloqueio: cota = o que o sistema aceitou − folga
  limiteTetoMs: 30 * 60 * 1000, // 30 min no mesmo código → aí sim vira erro
  // Resposta vazia/recusada (o limite às vezes vem assim): espera e tenta o
  // mesmo código; depois disso vira "não consultado" (nunca "sem rastreio").
  esperasSuspeitaMs: [5000, 10000, 20000, 30000, 60000],
  suspeitasMax: 6,
};

// Texto do motivo no sistema: "Encomenda.expedida.mas.não.chegou.有发未到件"
function normalizarTextoExp(texto) {
  return String(texto == null ? "" : texto)
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[._\s]+/g, " ");
}

function ehExpedidoNaoChegou(evento) {
  if (!evento || typeof evento !== "object") return false;
  const bruto = [evento.remark1, evento.waybillTrackingContent].map((v) => String(v == null ? "" : v)).join(" ");
  if (bruto.includes("有发未到件")) return true;
  return /expedid[ao] mas nao chegou/.test(normalizarTextoExp(bruto));
}

// "2026-10-20 05:16:17" → número comparável (ou null)
function horaDoEvento(evento) {
  const v = String((evento && (evento.scanTime || evento.uploadTime)) || "").trim();
  const m = v.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?/);
  if (!m) return null;
  return Number(m[1] + m[2] + m[3] + m[4] + m[5] + (m[6] || "00"));
}

// Último evento = o de horário mais recente; empate ou sem horário: o que
// vem primeiro na lista (o sistema manda do mais novo para o mais antigo).
// Função pura.
function ultimoEventoExp(detalhes) {
  if (!Array.isArray(detalhes)) return null;
  const eventos = detalhes.filter((d) => d && typeof d === "object");
  if (!eventos.length) return null;
  let melhor = eventos[0];
  let melhorHora = horaDoEvento(melhor);
  for (const ev of eventos.slice(1)) {
    const h = horaDoEvento(ev);
    if (h != null && (melhorHora == null || h > melhorHora)) {
      melhor = ev;
      melhorHora = h;
    }
  }
  return melhor;
}

// Mensagens do sistema que indicam excesso de consultas (português, inglês, chinês)
function pareceLimiteExp(msg) {
  const t = normalizarTextoExp(msg);
  return /frequen|muitas (solicita|requisi|consulta)|limite|too many|rate|throttl|aguarde|tente (novamente )?mais tarde/.test(t) || /频繁|过多|限流|稍后/.test(String(msg || ""));
}

// Decide o que fazer com a resposta de um GRUPO de códigos.
// ok → { tipo: "ok", porCodigo: Map(código → { exp, semRastreio }), faltando: [códigos sem item na resposta] }
// Um código só é classificado pelo item DELE (keyword igual). Num grupo, o
// código que não veio na resposta volta para ser consultado sozinho.
function classificarRespostaExp(r, codigos) {
  if (r.erro === "aba") return { tipo: "fatal", motivo: LOTE_MSG.abaPerdida };
  if (r.erro === "timeout") return { tipo: "tentar", motivo: "demorou demais" };
  // Recusa na hora (o 405 do bloqueio chega sem cabeçalhos e o navegador mostra
  // como "sem conexão"): é o bloqueio, nunca pula o código.
  if (r.erro) return { tipo: "limite", retryAfter: null, motivo: "bloqueio do minuto (HTTP 405 / sem conexão)" };
  if (r.status === 401 || r.status === 403) return { tipo: "auth" };
  if (r.status === 429) return { tipo: "limite", retryAfter: r.retryAfter, motivo: "limite de requisições do servidor" };
  // 405: o JMS recusa assim depois de ~60 consultas e segue recusando por ~1 min
  if (r.status === 405) return { tipo: "limite", retryAfter: r.retryAfter, motivo: "bloqueio do minuto (HTTP 405)" };
  if (r.status >= 500) return { tipo: "tentar", motivo: `erro ${r.status} do servidor` };
  // Qualquer outro status: pode ser o limite com outro código HTTP — insiste
  if (!r.ok) return { tipo: "suspeito", motivo: `erro HTTP ${r.status}` };

  const j = r.json;
  if (!j || typeof j !== "object") return { tipo: "suspeito", motivo: "resposta inesperada" };
  const sucesso = (j.succ === true || j.code === 1) && j.fail !== true;
  if (!sucesso) {
    const msg = String(j.msg || "").slice(0, 80);
    if (/token|login|sess[aã]o|expir|autent|unauthor/i.test(msg)) return { tipo: "auth" };
    // Limite avisado na mensagem (sem 429): freia como um 429
    if (pareceLimiteExp(msg)) return { tipo: "limite", retryAfter: null, motivo: "limite de requisições do servidor" };
    return { tipo: "suspeito", motivo: msg || "o sistema recusou a consulta" };
  }
  if (!Array.isArray(j.data)) return { tipo: "suspeito", motivo: "resposta sem dados" };

  const itens = j.data.filter((i) => i && typeof i === "object");
  const chave = (i) => String(i.keyword == null ? "" : i.keyword).trim().toUpperCase();
  const porCodigo = new Map();
  const faltando = [];
  const classificar = (item) => {
    const ultimo = item ? ultimoEventoExp(item.details) : null;
    return ultimo ? { exp: ehExpedidoNaoChegou(ultimo), semRastreio: false } : { exp: false, semRastreio: true };
  };
  if (codigos.length === 1) {
    // Sozinho: 1 item sem "keyword" é dele. Item de OUTRO código ou resposta
    // sem nenhum evento é SUSPEITA (o limite do JMS pode vir assim): nunca
    // classifica nem pula — espera e tenta de novo o mesmo código.
    const codigo = codigos[0];
    const alvo = itens.length === 1 && !chave(itens[0]) ? itens[0] : itens.find((i) => chave(i) === codigo);
    if (!alvo && itens.length) return { tipo: "suspeito", motivo: "o sistema respondeu com outro código" };
    if (!alvo || !ultimoEventoExp(alvo.details)) return { tipo: "suspeito", motivo: "resposta vazia", vazio: true };
    porCodigo.set(codigo, classificar(alvo));
    return { tipo: "ok", porCodigo, faltando };
  }
  for (const codigo of codigos) {
    const alvo = itens.find((i) => chave(i) === codigo);
    if (alvo) porCodigo.set(codigo, classificar(alvo));
    else faltando.push(codigo);
  }
  return { tipo: "ok", porCodigo, faltando };
}

// ---------- Consulta em segundo plano (contrato popup ↔ background.js) ----------
// O background.js roda a consulta e guarda o andamento em storage.session
// (nunca o token). O popup só mostra: progresso enquanto "rodando" e, quando
// termina, o mesmo resultado de sempre.
const FUNDO_CHAVE = { lote: "fundo_lote" };

// ---------- PREENCHER A OCORRÊNCIA PELO RASTREIO (motor) ----------
// Botão "Preencher" da Ocorrência: 3 consultas ao JMS para UM rastreio, uma
// depois da outra, feitas pelo background.js (que conhece o bloqueio do JMS
// visto pelo Lote/Expedido). Os dados da cliente voltam só na resposta da
// mensagem: nunca vão para o diagnóstico, para registro nem para log.
const PREENCHER_API = {
  pedido: "https://gw.jtjms-br.com/operatingplatform/order/getOrderDetail",
  // O mesmo que o "olhinho" do JMS (dados sem máscara): só por clique da pessoa
  telefone: "https://gw.jtjms-br.com/operatingplatform/order/getPhoneByWaybillNo",
};

const PREENCHER_MSG = {
  invalido: "Rastreio inválido: use o código J&T de 15 dígitos (888… ou 999…).",
  generico: "Não foi possível buscar os dados no JMS. Tente novamente.",
};

// Código J&T: 15 dígitos começando com 888 ou 999 (sem espaços nem
// caracteres invisíveis de cópia). Devolve o código limpo ou "".
function rastreioJtValido(valor) {
  const cod = String(valor == null ? "" : valor).replace(/[\s\p{Cf}]+/gu, "");
  return /^(?:888|999)\d{12}$/.test(cod) ? cod : "";
}

// UMA consulta dentro da aba do JMS (mesmo caminho do Lote). corpo null = GET.
async function pedirJmsUnico(tabId, token, url, corpo) {
  const [execucao] = await chrome.scripting.executeScript({
    target: { tabId },
    func: consultarLoteNaPagina,
    args: [url, montarCabecalhosLote(token), corpo == null ? null : JSON.stringify(corpo), LOTE_CFG.timeoutMs],
  });
  return execucao && execucao.result ? execucao.result : { status: 0, ok: false, erro: "rede" };
}

// Mesmas regras de classificarRespostaExp, para uma resposta { code, msg, data }.
// ok → { tipo: "ok", data }
function classificarRespostaUnica(r) {
  if (!r || typeof r !== "object") return { tipo: "tentar" };
  if (r.erro === "aba") return { tipo: "fatal", motivo: LOTE_MSG.abaPerdida };
  if (r.erro === "timeout") return { tipo: "tentar" };
  if (r.erro) return { tipo: "limite" }; // o 405 do bloqueio chega como "sem conexão"
  if (r.status === 401 || r.status === 403) return { tipo: "auth" };
  if (r.status === 429 || r.status === 405) return { tipo: "limite" };
  if (r.status >= 500) return { tipo: "tentar" };
  if (!r.ok) return { tipo: "falha", motivo: `O sistema respondeu com erro (HTTP ${r.status}).` };
  const j = r.json;
  if (!j || typeof j !== "object") return { tipo: "falha", motivo: "O sistema mandou uma resposta inesperada." };
  const sucesso = (j.succ === true || j.code === 1) && j.fail !== true;
  if (!sucesso) {
    const msg = String(j.msg || "").slice(0, 120);
    if (/token|login|sess[aã]o|expir|autent|unauthor/i.test(msg)) return { tipo: "auth" };
    if (pareceLimiteExp(msg)) return { tipo: "limite" };
    return { tipo: "falha", motivo: msg ? `O sistema respondeu: ${msg}` : "O sistema recusou a consulta." };
  }
  return { tipo: "ok", data: j.data };
}

// "--", "—" ou só espaços = vazio (o JMS mostra assim quando não tem)
function valorJms(valor) {
  const v = String(valor == null ? "" : valor).replace(/\p{Cf}/gu, "").trim();
  return /^[-–—\s*]*$/.test(v) ? "" : v;
}

// "(+55)11987654321" → "11987654321". Só aceita DDD + número (10 ou 11 dígitos).
function telefoneDoJms(valor) {
  let d = String(valor == null ? "" : valor).replace(/\(\s*\+?\s*55\s*\)|^\s*\+\s*55/, "").replace(/\D/g, "");
  if ((d.length === 12 || d.length === 13) && d.startsWith("55")) d = d.slice(2);
  d = d.replace(/^0+/, "");
  return d.length === 10 || d.length === 11 ? d : "";
}

// A "assinatura de encomenda" mais recente (ignora "assinatura de devolução").
// Um "Concluído" depois dela não muda nada: a data da entrega é a da baixa.
function assinaturaMaisRecente(detalhes) {
  if (!Array.isArray(detalhes)) return null;
  const assinaturas = detalhes.filter((ev) => ev && typeof ev === "object" && normalizarTextoExp(ev.scanTypeName).trim() === "assinatura de encomenda");
  return ultimoEventoExp(assinaturas);
}

// scanTime da assinatura mais recente. Sem assinatura → "".
function dataAssinatura(detalhes) {
  const ultimo = assinaturaMaisRecente(detalhes);
  return ultimo ? valorJms(ultimo.scanTime) : "";
}

// ---- Dados de cada embarcador (levantamento de 157 rastreios, 20/11/2026) ----
// Base de quem atende: assinatura em outra rede = "pacote de outra base".
const MINHA_BASE = "F MAT-SP";

// Só para calibrar em desenvolvimento (Shopee, Via Varejo, remetente): com
// true, a resposta traz o FORMATO mascarado dos campos (nunca o valor), que o
// popup mostra no console dele. No release fica SEMPRE false.
const INSPECIONAR_CAMPOS = false;

// O código do cliente é procurado pelo FORMATO nestes campos, nesta ordem.
// "Número de rastreamento do cliente" do sistema = customerWaybillNo.
const CANDIDATOS_CODIGO = ["customerWaybillNo", "customerOrderId", "originalWaybillNo", "mainOrderId"];
const PADRAO_KW = /^KW[0-9A-Z]{8,}BR$/; // Kwai: KW + 13 dígitos + BR
const PADRAO_CNBR = /^CNBR[0-9A-Z]{6,}$/; // Cainiao
const PADRAO_BR26 = /^BR\d{2}[0-9A-Z]{6,}$/; // Shopee (hoje BR26…)
const PADRAO_CHAVE_NFE = /^\d{44}$/;

// Razão social de plataforma/operador: não é a loja que a cliente conhece.
const RAZOES_PLATAFORMA = ["BYTEDANCE", "EBAZAR", "JOYO", "FLOGISTICS", "ANJUN", "CAINIAO", "IN GLOW", "MELHOR ENVIO", "MANDAE", "TUCCI LOG", "KYRIOS LOG"];
const CATEGORIAS_GENERICAS = ["OTHER", "OTHERS", "OUTROS", "OUTRO", "OUTRAS"];

function semAcentoMaiusculo(texto) {
  return String(texto == null ? "" : texto)
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, " ")
    .trim();
}

// Código sem espaço nem caractere invisível, em maiúsculas
function codigoLimpo(valor) {
  return valorJms(valor).replace(/[\s\p{Cf}]+/gu, "").toUpperCase();
}

// Chave da NF-e (44 dígitos): cUF2 + AAMM4 + CNPJ14 + modelo2 + série3 + nNF9.
// Devolve o número da nota sem zeros à esquerda ("" se não for chave).
function numeroDaChaveNfe(chave) {
  const c = codigoLimpo(chave);
  if (!PADRAO_CHAVE_NFE.test(c)) return "";
  const n = String(Number(c.slice(25, 34)));
  return n === "0" ? "" : n;
}

// "LOJAS RIACHUELO SA" → "Lojas Riachuelo"
const PALAVRAS_MINUSCULAS = ["de", "da", "do", "das", "dos", "e"];
function lojaLimpa(nome) {
  let t = valorJms(nome).replace(/\s+/g, " ");
  const sufixo = /[\s,.-]+(?:LTDA|S\.?\s?\/?A|EIRELI|ME|EPP)\.?$/i;
  for (let i = 0; i < 3 && sufixo.test(t); i++) t = t.replace(sufixo, "");
  t = t.replace(/[\s,.-]+$/, "").trim();
  if (!t) return "";
  if (t === t.toUpperCase() && /\p{L}/u.test(t)) {
    t = t
      .toLowerCase()
      .split(" ")
      .map((p, i) => (i > 0 && PALAVRAS_MINUSCULAS.includes(p) ? p : p.replace(/\p{L}/u, (l) => l.toUpperCase())))
      .join(" ");
  }
  return t.slice(0, 60);
}

function ehRazaoPlataforma(nome) {
  const n = semAcentoMaiusculo(nome);
  return RAZOES_PLATAFORMA.some((r) => n.includes(r));
}

// Loja que a cliente reconhece: storeName; senão o cliente contratante, se
// não for a própria plataforma (nos intermediadores ele é a loja de verdade).
function lojaDoPedido(det) {
  const loja = lojaLimpa(det.storeName);
  if (loja) return loja;
  const cliente = valorJms(det.customerName);
  return cliente && !ehRazaoPlataforma(cliente) ? lojaLimpa(cliente) : "";
}

// Conteúdo: código de barras (EAN) não vai para a cliente como "Produto"; sem
// nome, usa a categoria do sistema (menos "Outros"), avisando.
function conteudoDoPedido(det) {
  const nome = valorJms(det.goodsName).replace(/\s+/g, " ");
  if (/^\d{8,14}$/.test(nome.replace(/\s/g, ""))) return { conteudo: "", conteudoMotivo: "ean" };
  if (nome) return { conteudo: nome, conteudoMotivo: "" };
  const categoria = valorJms(det.goodsTypeName);
  if (categoria && !CATEGORIAS_GENERICAS.includes(semAcentoMaiusculo(categoria))) {
    return { conteudo: categoria, conteudoMotivo: "generico" };
  }
  return { conteudo: "", conteudoMotivo: "vazio" };
}

// Códigos de cada embarcador, pelo formato. Função pura.
function extrairCamposEmbarcador(det) {
  const d = det && typeof det === "object" ? det : {};
  const valores = CANDIDATOS_CODIGO.map((k) => codigoLimpo(d[k]));
  const achar = (re) => valores.find((v) => re.test(v)) || "";
  const rastreioCliente = achar(PADRAO_KW) || achar(PADRAO_CNBR);
  const nf = numeroDaChaveNfe(achar(PADRAO_CHAVE_NFE));
  // Pedido: o customerOrderId, menos quando ele é a chave da NF-e
  let pedido = valorJms(d.customerOrderId).replace(/\s+/g, "");
  if (PADRAO_CHAVE_NFE.test(codigoLimpo(pedido))) pedido = "";
  // "Número de rastreamento do cliente" que veio num formato que não é KW/CNBR
  // (ex.: APF0… da Cainiao3PL): nunca vai para o campo, só vira aviso.
  const cw = valores[0];
  const rastreioClienteOutro = !!cw && !rastreioCliente && cw !== codigoLimpo(pedido);
  return { rastreioCliente, rastreioClienteOutro, nf, pedido, br26: achar(PADRAO_BR26), loja: lojaDoPedido(d) };
}

// Nomes de remetente/loja/cliente contratante, só para a regra "só física"
// (Arezzo, ZZAB, Motorola…). Conteúdo e dados da destinatária ficam de fora:
// "Capa Motorola" no produto não pode travar nada.
function remetentesDoPedido(pedidoData, det) {
  const vistos = new Set();
  const lista = [];
  const add = (v) => {
    const t = typeof v === "string" || typeof v === "number" ? valorJms(v).slice(0, 80) : "";
    if (t && !vistos.has(t)) {
      vistos.add(t);
      lista.push(t);
    }
  };
  add(det.customerName);
  add(det.storeName);
  for (const fonte of [det, pedidoData]) {
    if (!fonte || typeof fonte !== "object") continue;
    for (const [k, v] of Object.entries(fonte)) {
      if (!/sender|send|shipper/i.test(k)) continue;
      if (/phone|mobile|tel|cpf|cnpj|doc|addr|cep|zip|post|city|prov|area|street|district|id$|code|time|date|no$/i.test(k)) continue;
      add(v);
    }
  }
  return lista.slice(0, 8);
}

// Quem recebeu, da assinatura: "Assinar pelo próprio", "vizinho", "porteiro"…
function recebedorDaAssinatura(ass) {
  if (!ass) return "";
  const r = normalizarTextoExp(valorJms(ass.remark1)).trim();
  if (r) return r.slice(0, 60);
  const m = normalizarTextoExp(ass.waybillTrackingContent).match(/destinatario e \[?([^\],]+)/);
  return m ? m[1].trim().slice(0, 60) : "";
}

function tipoRecebedor(recebedor) {
  const r = normalizarTextoExp(recebedor);
  if (/porteir|portaria|recep|seguranc|zelador/.test(r)) return "portaria";
  if (/vizinh/.test(r)) return "vizinho";
  return "";
}

// "2026-07-30 13:28:12" → "30/07 13:28"
function dataCurtaJms(valor) {
  const m = valorJms(valor).match(/^\d{4}-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})/);
  return m ? `${m[2]}/${m[1]} ${m[3]}:${m[4]}` : "";
}

// Linha curta só para a tela: último evento · hora · base · entregador
function linhaStatus(detalhes, ass) {
  const ultimo = ultimoEventoExp(detalhes);
  if (!ultimo) return "";
  const tipo = valorJms(ultimo.scanTypeName);
  const fonte = ass || ultimo;
  const partes = [
    tipo ? tipo.charAt(0).toUpperCase() + tipo.slice(1) : "",
    dataCurtaJms(ultimo.scanTime),
    valorJms(fonte.scanNetworkName || ultimo.scanNetworkName),
    valorJms(fonte.staffName || ultimo.staffName),
  ].filter(Boolean);
  return partes.join(" · ").slice(0, 160);
}

// Formato do valor sem o valor: dígito vira 9, letra vira A. Só para calibrar.
function formatoMascarado(valor, mostrarPrefixo) {
  const s = String(valor == null ? "" : valor);
  if (!s) return "";
  const prefixo = mostrarPrefixo && /[A-Za-z]/.test(s.slice(0, 4)) ? s.slice(0, 4) : "";
  const resto = s
    .slice(prefixo.length)
    .replace(/\d/g, "9")
    .replace(/\p{L}/gu, "A")
    .replace(/9{3,}/g, (m) => `[9×${m.length}]`)
    .replace(/A{3,}/g, (m) => `[A×${m.length}]`);
  return `${prefixo}${resto} (${s.length})`;
}

function inspecionarPedido(pedidoData, det) {
  const campos = {};
  for (const k of [...CANDIDATOS_CODIGO, "orderSourceName", "orderSourceCode"]) campos[k] = formatoMascarado(det[k], true);
  const chaves = [];
  for (const [nome, fonte] of [["details", det], ["data", pedidoData]]) {
    if (!fonte || typeof fonte !== "object") continue;
    for (const [k, v] of Object.entries(fonte)) {
      if (fonte === pedidoData && k === "details") continue;
      const tipo = Array.isArray(v) ? "lista" : v === null ? "null" : typeof v;
      chaves.push(`${nome}.${k}: ${tipo}${typeof v === "string" ? ` ${formatoMascarado(v, false)}` : ""}`);
    }
  }
  return { campos, chaves: chaves.slice(0, 200) };
}

// Junta as 3 respostas no que vai para a tela. Nome e telefone vêm SÓ do
// getPhoneByWaybillNo (no getOrderDetail eles vêm mascarados).
function dadosPreencher(pedidoData, telefoneData, rastreioData) {
  const det = pedidoData && typeof pedidoData === "object" ? pedidoData.details || pedidoData : {};
  const tel = telefoneData && typeof telefoneData === "object" ? telefoneData : {};
  const item = Array.isArray(rastreioData) ? rastreioData.find((i) => i && typeof i === "object") : null;
  const eventos = item && Array.isArray(item.details) ? item.details : [];
  const ass = assinaturaMaisRecente(eventos);
  const campos = extrairCamposEmbarcador(det);
  const telefone = telefoneDoJms(tel.receiverMobilePhone);
  const dados = {
    telefone,
    telefoneEstranho: !telefone && !!valorJms(tel.receiverMobilePhone),
    nome: valorJms(tel.receiverName),
    origem: valorJms(det.orderSourceName),
    origemCodigo: valorJms(det.orderSourceCode).toUpperCase().slice(0, 12),
    pedido: campos.pedido,
    br26: campos.br26,
    data: ass ? valorJms(ass.scanTime) : "",
    ...conteudoDoPedido(det),
    rastreioCliente: campos.rastreioCliente,
    rastreioClienteOutro: campos.rastreioClienteOutro,
    nf: campos.nf,
    loja: campos.loja,
    remetentes: remetentesDoPedido(pedidoData, det),
    recebedor: recebedorDaAssinatura(ass),
    podInvalido: !!ass && String(ass.invalidPictureFlag) === "1",
    redeAssinatura: ass ? valorJms(ass.scanNetworkName) : "",
    status: linhaStatus(eventos, ass),
  };
  if (INSPECIONAR_CAMPOS) dados.inspecao = inspecionarPedido(pedidoData, det);
  return dados;
}

// O código do cliente só entra se combinar com o embarcador: KW no Kwai,
// CNBR na Cainiao (KW num pacote Cainiao não entra).
function codigoClienteDoEmbarcador(codigo, e) {
  if (!e || !e.rastreioCliente) return "";
  const c = codigoLimpo(codigo);
  if (e.id === "kwai") return PADRAO_KW.test(c) ? c : "";
  if (e.id === "cainiao") return PADRAO_CNBR.test(c) ? c : "";
  return PADRAO_KW.test(c) || PADRAO_CNBR.test(c) ? c : "";
}

// Avisos do preenchimento, do mais importante para o menos: o que reprova a
// acareação, código do embarcador faltando, conteúdo e o resto. Nenhum
// bloqueia: são para quem atende decidir antes de mandar. Função pura.
// endereco: só os avisos que fazem sentido na mensagem de endereço incorreto.
function avisosPreencher(d, e, endereco = false) {
  const ml = !!e && e.id === "mercadolivre";
  const reprova = [];
  const codigo = [];
  const conteudo = [];
  const resto = [];
  if (!endereco) {
    const tipo = tipoRecebedor(d.recebedor);
    if (tipo === "portaria") reprova.push(ml ? "recebedor genérico (portaria): o Mercado Livre não aceita, risco de extravio" : "recebido na portaria");
    if (tipo === "vizinho") reprova.push(ml ? "entregue a vizinho: o Mercado Livre não aceita terceiros" : "entregue a vizinho");
    if (d.podInvalido) reprova.push("POD marcado como inválido no sistema");
    if (d.redeAssinatura && semAcentoMaiusculo(d.redeAssinatura) !== semAcentoMaiusculo(MINHA_BASE)) {
      reprova.push(`assinado por outra base (${d.redeAssinatura})`);
    }
    if (e && e.id === "tiktok" && !d.telefone) reprova.push("TikTok: telefone do sistema inválido → acareação física permitida");
    if (e && e.rastreioCliente && !codigoClienteDoEmbarcador(d.rastreioCliente, e)) {
      const rotulo = e.rastreioCliente.rotulo || "Código do cliente";
      codigo.push(d.rastreioClienteOutro ? `${rotulo} não veio do sistema (veio outro código): copie do ticket` : `${rotulo} não veio do sistema: copie do ticket`);
    }
    if (e && e.nf && !d.nf) codigo.push(e.id === "infracommerce" ? "NF não vem do sistema: copie do ticket (6 dígitos)" : "NF não veio do sistema: copie do ticket");
  }
  if (d.conteudoMotivo === "ean") conteudo.push("conteúdo veio como código de barras (EAN): copie o nome do produto do ticket");
  else if (d.conteudoMotivo === "generico") conteudo.push("conteúdo genérico (categoria do sistema): confirme o produto com a cliente ou no ticket");
  else if (d.conteudoMotivo === "vazio") conteudo.push("conteúdo não veio do sistema");
  if (!endereco && !d.data) resto.push("pacote ainda não foi assinado no sistema");
  if (!d.telefone && !(e && e.id === "tiktok" && !endereco)) resto.push(d.telefoneEstranho ? "telefone veio num formato estranho" : "telefone não veio do sistema");
  if (!endereco && !d.nome) resto.push("nome não veio do sistema");
  return [...reprova, ...codigo, ...conteudo, ...resto];
}
