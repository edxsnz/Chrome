// consulta-core.js
// Motor das consultas longas (abas Lote e Expedido): rede, login, fila de
// requisições e os laços que consultam lote por lote / grupo por grupo.
// Não mexe na tela: é carregado pelo popup (que usa as configurações e as
// funções puras) e pelo background.js (que roda as consultas mesmo com o
// popup fechado). Tudo aqui precisa funcionar sem DOM.
//
// Como a consulta é feita: o fetch roda DENTRO da aba do JMS (chrome.scripting),
// igual ao que o próprio site faz — assim a requisição sai com a origem e o
// Referer reais do sistema (chamadas vindas direto da extensão costumam ser
// recusadas por gateways). O token vem do cookie YL_TOKEN, lido na hora de
// cada consulta; ele nunca é guardado nem exibido.

// ---------- ABA LOTE (motor) ----------
const LOTE_API = {
  hostPreferido: "jmsbr.jtjms-br.com",
  // Qualquer endereço do JMS (jmsbr, outro subdomínio...) — o mesmo padrão
  // do host_permissions do manifest.
  padraoAba: "https://*.jtjms-br.com/*",
  url: "https://gw.jtjms-br.com/operatingplatform/packScanList/waybillIdsByPackageNumber",
  cookie: "YL_TOKEN",
};

const LOTE_CFG = {
  concorrencia: 1, // uma consulta por vez: carga leve no JMS
  tentativas: 4, // por lote
  backoffBaseMs: 2000,
  backoffMaxMs: 20000,
  timeoutMs: 25000,
  espacoMinMs: 700, // pausa entre uma consulta e outra
  espacoMaxMs: 1300,
};


const LOTE_MSG = {
  semAba: "Não encontrei o sistema JMS aberto. Abra o JMS em uma aba deste navegador, entre na sua conta e tente de novo.",
  recarregar: "A extensão foi atualizada e precisa ser recarregada para acessar o JMS. Depois de recarregar, cole as listas de novo.",
  permitir: "A extensão está sem permissão para acessar o sistema JMS. Clique abaixo e confirme.",
  semToken: "Não achei o seu login do sistema. Atualize a página do JMS (F5), confira se está logado e tente de novo.",
  tokenEstranho: "O login do sistema veio em um formato inesperado. Saia e entre de novo no JMS.",
  auth: "O sistema recusou o login (sessão expirada?). Entre de novo no JMS e tente outra vez.",
  abaPerdida: "A aba do sistema foi fechada ou recarregada durante a consulta. Deixe-a aberta e tente de novo.",
  generico: "Não foi possível consultar os lotes. Tente novamente.",
  semFundo: "Não foi possível iniciar a consulta. Feche e abra a extensão de novo; se continuar, recarregue a extensão.",
};

class ErroLote extends Error {
  constructor(tipo, mensagem) {
    super(mensagem);
    this.tipo = tipo;
  }
}

// ATENÇÃO: esta função roda DENTRO da aba do sistema (o chrome.scripting
// serializa o código dela), então NÃO pode usar nenhuma variável deste
// arquivo — só o que chega pelos argumentos e as APIs do navegador.
async function consultarLoteNaPagina(url, cabecalhos, corpoJson, timeoutMs) {
  const controle = new AbortController();
  const relogio = setTimeout(() => controle.abort(), timeoutMs);
  try {
    const resposta = await fetch(url, {
      method: "POST",
      headers: cabecalhos,
      body: corpoJson,
      credentials: "omit",
      redirect: "error", // se o sistema redirecionar, não manda o token pra outro lugar
      signal: controle.signal,
    });
    let json = null;
    try {
      json = await resposta.json();
    } catch (e) {
      json = null;
    }
    return {
      status: resposta.status,
      ok: resposta.ok,
      retryAfter: resposta.headers.get("retry-after"),
      json,
    };
  } catch (e) {
    return { status: 0, ok: false, erro: e && e.name === "AbortError" ? "timeout" : "rede" };
  } finally {
    clearTimeout(relogio);
  }
}

function montarCabecalhosLote(token) {
  return {
    accept: "application/json, text/plain, */*",
    "accept-language": "pt-BR,pt;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
    authtoken: token,
    "cache-control": "max-age=2, must-revalidate",
    "content-type": "application/json;charset=UTF-8",
    lang: "PT",
    langtype: "PT",
    routename: "trackingExpress",
    routernamelist:
      "%E6%93%8D%E4%BD%9C%E5%B9%B3%E5%8F%B0%3E%E5%BF%AB%E4%BB%B6%E6%9F%A5%E8%AF%A2%3E%E5%BF%AB%E4%BB%B6%E8%B7%9F%E8%B8%AA",
    timezone: "GMT-0300",
  };
}

const dormir = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const aleatorioEntre = (min, max) => min + Math.random() * (max - min);

function esperaBackoff(tentativa) {
  return Math.min(LOTE_CFG.backoffBaseMs * 2 ** (tentativa - 1), LOTE_CFG.backoffMaxMs) + Math.random() * 250;
}

function esperaDoRetryAfter(valor, tentativa) {
  const segundos = Number(valor);
  if (valor != null && valor !== "" && Number.isFinite(segundos) && segundos >= 0) {
    return Math.min(segundos * 1000, LOTE_CFG.backoffMaxMs * 2);
  }
  return esperaBackoff(tentativa);
}

// O login do JMS (cookie YL_TOKEN) só é aceito de jtjms-br.com ou subdomínios.
const LOTE_DOMINIO = "jtjms-br.com";
function ehDominioJms(dominio) {
  const d = String(dominio || "").replace(/^\./, "").toLowerCase();
  return d === LOTE_DOMINIO || d.endsWith("." + LOTE_DOMINIO);
}

function hostDaAba(aba) {
  try {
    return new URL(aba && aba.url).hostname.toLowerCase();
  } catch (e) {
    return "";
  }
}

// Limpa o valor lido (aspas, %xx) sem nunca mostrar ou guardar o token.
function limparToken(valor) {
  let v = String(valor == null ? "" : valor).trim().replace(/^"(.*)"$/, "$1").trim();
  if (/%[0-9A-Fa-f]{2}/.test(v)) {
    try {
      v = decodeURIComponent(v).trim();
    } catch (e) {
      /* deixa como veio */
    }
  }
  return v;
}

// Roda DENTRO da aba do JMS (precisa ser autocontida). Plano B para quando o
// login não aparece pela API de cookies: lê do próprio site.
function lerTokenNaPagina(nome) {
  const alvo = String(nome).toLowerCase();
  try {
    for (const parte of document.cookie.split(";")) {
      const k = parte.indexOf("=");
      if (k > 0 && parte.slice(0, k).trim().toLowerCase() === alvo) return parte.slice(k + 1).trim();
    }
  } catch (e) {
    /* sem acesso a document.cookie */
  }
  for (const area of ["localStorage", "sessionStorage"]) {
    try {
      const st = window[area];
      for (let n = 0; n < st.length; n++) {
        const chave = st.key(n);
        if (chave && chave.toLowerCase() === alvo) return st.getItem(chave) || "";
      }
    } catch (e) {
      /* armazenamento indisponível */
    }
  }
  return "";
}

// Junta todos os cookies YL_TOKEN do domínio do JMS: normais e particionados
// (o Chrome novo guarda alguns cookies "por site", e a busca simples não os vê),
// no mesmo perfil/janela da aba do sistema.
async function cookiesDoLogin(aba) {
  if (!chrome.cookies || !chrome.cookies.getAll) return [];
  let storeId;
  try {
    const lojas = chrome.cookies.getAllCookieStores ? await chrome.cookies.getAllCookieStores() : [];
    const loja = (lojas || []).find((l) => (l.tabIds || []).includes(aba && aba.id));
    if (loja) storeId = loja.id;
  } catch (e) {
    storeId = undefined;
  }
  const base = storeId ? { domain: LOTE_DOMINIO, storeId } : { domain: LOTE_DOMINIO };
  const achados = [];
  for (const filtro of [base, { ...base, partitionKey: {} }]) {
    try {
      const lista = await chrome.cookies.getAll(filtro);
      if (Array.isArray(lista)) achados.push(...lista);
    } catch (e) {
      /* Chrome antigo sem suporte a partitionKey: segue com o que tiver */
    }
  }
  const alvo = LOTE_API.cookie.toLowerCase();
  return achados.filter((c) => c && String(c.name).toLowerCase() === alvo && ehDominioJms(c.domain) && c.value);
}

// Confere se a extensão consegue falar com o JMS antes de procurar a aba.
// "recarregar": arquivos novos, mas o Chrome ainda roda o manifest antigo
//   (sem as permissões de cookies/scripting) — só recarregar resolve.
// "permitir": manifest certo, mas o acesso ao site foi negado/restrito.
async function verificarAcessoLote() {
  if (!chrome.cookies || !chrome.cookies.getAll || !chrome.scripting || !chrome.scripting.executeScript) return "recarregar";
  if (!chrome.permissions || !chrome.permissions.contains) return "ok"; // sem como checar: segue e deixa a consulta dizer
  try {
    const ok = await chrome.permissions.contains({ origins: [LOTE_API.padraoAba] });
    return ok ? "ok" : "permitir";
  } catch (e) {
    return "permitir";
  }
}

async function obterTokenLote(aba) {
  const host = hostDaAba(aba);
  const valido = (v) => /^[A-Za-z0-9._-]{8,300}$/.test(v);
  const cookies = await cookiesDoLogin(aba);
  // Prioridade: cookie do próprio endereço da aba > do domínio pai > qualquer outro do JMS
  const peso = (c) => {
    const d = String(c.domain).replace(/^\./, "").toLowerCase();
    if (d === host) return 0;
    if (host.endsWith("." + d)) return 1;
    return 2;
  };
  cookies.sort((a, b) => peso(a) - peso(b));
  const candidatos = cookies.map((c) => limparToken(c.value)).filter(Boolean);

  if (!candidatos.length && aba && aba.id != null && chrome.scripting) {
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId: aba.id }, func: lerTokenNaPagina, args: [LOTE_API.cookie] });
      const v = limparToken(r && r.result);
      if (v) candidatos.push(v);
    } catch (e) {
      /* aba indisponível: cai no aviso de login abaixo */
    }
  }

  if (!candidatos.length) throw new ErroLote("token", LOTE_MSG.semToken);
  const bom = candidatos.find(valido);
  if (!bom) throw new ErroLote("token", LOTE_MSG.tokenEstranho);
  return bom;
}

async function acharAbaSistema() {
  const acesso = await verificarAcessoLote();
  if (acesso !== "ok") throw new ErroLote(acesso, LOTE_MSG[acesso]);
  let abas = [];
  try {
    abas = await chrome.tabs.query({ url: LOTE_API.padraoAba });
  } catch (e) {
    abas = [];
  }
  // Prioridade: aba ativa do jmsbr > qualquer jmsbr > ativa de outro endereço do JMS > qualquer outra
  const vivas = (abas || []).filter((a) => a && !a.discarded && a.id != null);
  const preferidas = vivas.filter((a) => hostDaAba(a) === LOTE_API.hostPreferido);
  const aba =
    preferidas.find((a) => a.active) || preferidas[0] || vivas.find((a) => a.active) || vivas[0];
  if (!aba || aba.id == null) throw new ErroLote("aba", LOTE_MSG.semAba);
  return aba;
}

async function pedirLote(tabId, token, lote) {
  const [execucao] = await chrome.scripting.executeScript({
    target: { tabId },
    func: consultarLoteNaPagina,
    args: [LOTE_API.url, montarCabecalhosLote(token), JSON.stringify([lote]), LOTE_CFG.timeoutMs],
  });
  return execucao && execucao.result ? execucao.result : { status: 0, ok: false, erro: "rede" };
}

// Decide o que fazer com a resposta de UM lote.
function classificarRespostaLote(r, lote) {
  if (r.erro === "aba") return { tipo: "fatal", motivo: LOTE_MSG.abaPerdida };
  if (r.erro) return { tipo: "tentar", motivo: r.erro === "timeout" ? "demorou demais" : "sem conexão" };
  if (r.status === 401 || r.status === 403) return { tipo: "auth" };
  if (r.status === 429) return { tipo: "limite", retryAfter: r.retryAfter, motivo: "limite de requisições do servidor" };
  if (r.status >= 500) return { tipo: "tentar", motivo: `erro ${r.status} do servidor` };
  if (!r.ok) return { tipo: "falha", motivo: `erro HTTP ${r.status}` };

  const j = r.json;
  if (!j || typeof j !== "object") return { tipo: "tentar", motivo: "resposta inesperada (sessão expirada?)" };

  const sucesso = (j.succ === true || j.code === 1) && j.fail !== true;
  if (!sucesso) {
    const msg = String(j.msg || "").slice(0, 80);
    if (/token|login|sess[aã]o|expir|autent|unauthor/i.test(msg)) return { tipo: "auth" };
    return { tipo: "falha", motivo: msg || "o sistema recusou a consulta" };
  }
  if (!Array.isArray(j.data)) return { tipo: "tentar", motivo: "resposta sem dados" };

  // Pedimos 1 lote por vez. Se veio 1 item, é ele (mesmo que o código volte
  // formatado diferente); se vierem vários, só vale o que bate com o lote.
  // Regra nº 1: só confirma o que é do lote pedido. Um item só vale se o
  // packageNumber bater (ou não vier); item de OUTRO lote é falha deste lote.
  const itens = j.data.filter((i) => i && typeof i === "object");
  const numero = (i) => String(i.packageNumber == null ? "" : i.packageNumber).trim().toUpperCase();
  const alvo = itens.length === 1 && !numero(itens[0]) ? itens : itens.filter((i) => numero(i) === lote);
  if (itens.length && !alvo.length) return { tipo: "falha", motivo: "o sistema respondeu com outro lote" };
  const ids = new Set();
  for (const item of alvo) {
    if (Array.isArray(item.waybillIds)) item.waybillIds.forEach((id) => ids.add(String(id).trim().toUpperCase()));
  }
  return { tipo: "ok", ids, vazio: ids.size === 0 };
}

// Vagas de requisição ao JMS valem para TODAS as execuções: as de uma
// consulta cancelada continuam no ar até responder, e uma consulta nova
// não pode somar com elas (nunca mais que LOTE_CFG.concorrencia ao mesmo tempo).
let loteNoAr = 0;
const loteEsperandoVaga = [];
async function pegarVagaLote() {
  while (loteNoAr >= LOTE_CFG.concorrencia) await new Promise((r) => loteEsperandoVaga.push(r));
  loteNoAr++;
}
function soltarVagaLote() {
  loteNoAr--;
  const proximo = loteEsperandoVaga.shift();
  if (proximo) proximo();
}

// Leitura defensiva do que volta da sessão (retomada depois de o Chrome
// encerrar o background no meio de uma consulta).
const listaDeTextos = (v) => (Array.isArray(v) ? v.filter((x) => typeof x === "string") : []);
const listaDePares = (v) => (Array.isArray(v) ? v.filter((p) => Array.isArray(p) && p.length === 2 && typeof p[0] === "string") : []);

// ativo(): quem chamou ainda quer esta consulta (falso = cancelada/substituída).
// retomar: fotografia salva por aoProgresso — continua de onde parou, sem
// repetir lote já consultado e sem perder o que já foi achado.
// aoProgresso(feitos, total, fotografia) é chamado depois de CADA lote.
async function executarConsultaLotes({ lotes, coletaSet, tabId, token, ativo: continuar = () => true, aoProgresso = () => {}, retomar = null }) {
  const salvo = retomar && typeof retomar === "object" && Array.isArray(retomar.fila) ? retomar : null;
  const fila = salvo ? listaDeTextos(salvo.fila) : [...lotes];
  const encontrados = new Set(salvo ? listaDeTextos(salvo.encontrados) : []);
  const falhas = new Map(salvo ? listaDePares(salvo.falhas).map(([l, m]) => [l, String(m)]) : []);
  const vazios = new Set(salvo ? listaDeTextos(salvo.vazios) : []);
  // lote -> quantos pacotes ele já tem (todos, não só os da coleta)
  const contagem = new Map(salvo ? listaDePares(salvo.contagem).filter((p) => Number.isFinite(p[1])) : []);
  let concluidos = salvo && Number.isInteger(salvo.concluidos) ? salvo.concluidos : 0;
  const emCurso = new Set(); // lotes pedidos e ainda sem resposta: voltam para a fila numa retomada
  let fatal = null;
  let pausaGlobal = Promise.resolve(); // 429 de qualquer um segura TODOS os trabalhadores

  const ativo = () => continuar() && !fatal;
  const fotografia = () => ({
    fila: [...emCurso, ...fila],
    encontrados: [...encontrados],
    falhas: [...falhas],
    vazios: [...vazios],
    contagem: [...contagem],
    concluidos,
  });

  async function consultarUm(lote) {
    let ultimoMotivo = LOTE_MSG.generico;
    for (let tentativa = 1; tentativa <= LOTE_CFG.tentativas; tentativa++) {
      await pausaGlobal;
      if (!ativo()) return null;

      await pegarVagaLote();
      if (!ativo()) {
        soltarVagaLote();
        return null;
      }
      let resposta;
      try {
        resposta = await pedirLote(tabId, token, lote);
      } catch (e) {
        resposta = { erro: "aba" };
      } finally {
        soltarVagaLote();
      }
      if (!ativo()) return null;

      const c = classificarRespostaLote(resposta, lote);
      if (c.tipo === "ok") return c;
      if (c.tipo === "auth") {
        fatal = new ErroLote("auth", LOTE_MSG.auth);
        return null;
      }
      if (c.tipo === "fatal") {
        fatal = new ErroLote("aba", c.motivo);
        return null;
      }
      if (c.tipo === "falha") return c;

      ultimoMotivo = c.motivo;
      if (c.tipo === "limite") {
        const pausa = dormir(esperaDoRetryAfter(c.retryAfter, tentativa));
        pausaGlobal = pausaGlobal.then(() => pausa);
      } else if (tentativa < LOTE_CFG.tentativas) {
        await dormir(esperaBackoff(tentativa));
      }
    }
    return { tipo: "falha", motivo: ultimoMotivo };
  }

  async function trabalhador() {
    while (ativo()) {
      const lote = fila.shift(); // atômico: JS roda uma coisa por vez, dois trabalhadores nunca pegam o mesmo lote
      if (lote === undefined) return;
      emCurso.add(lote);

      const r = await consultarUm(lote);
      if (r === null) return; // cancelado ou erro fatal
      if (!continuar()) return;

      if (r.tipo === "ok") {
        r.ids.forEach((id) => {
          if (coletaSet.has(id)) encontrados.add(id);
        });
        if (r.vazio) vazios.add(lote);
        contagem.set(lote, r.ids.size);
      } else {
        falhas.set(lote, r.motivo);
      }
      emCurso.delete(lote);

      concluidos++;
      aoProgresso(concluidos, lotes.length, fotografia());
      if (fila.length) await dormir(aleatorioEntre(LOTE_CFG.espacoMinMs, LOTE_CFG.espacoMaxMs));
    }
  }

  const quantos = Math.min(LOTE_CFG.concorrencia, fila.length);
  await Promise.all(Array.from({ length: quantos }, trabalhador));
  return { encontrados, falhas, vazios, contagem, fatal };
}

// ---------- ABA EXPEDIDO NÃO CHEGOU (motor) ----------
// Mesmas garantias da aba Lote: o fetch roda dentro da aba do JMS, o token é
// lido na hora (nunca guardado nem exibido) e as consultas usam a MESMA fila
// do Lote (uma por vez no total, com pausa entre elas), então as duas abas
// juntas nunca passam desse ritmo.

const EXP_API = {
  url: "https://gw.jtjms-br.com/operatingplatform/podTracking/inner/query/keywordList",
};

// O rastreio do JMS aceita 1 código por consulta. A velocidade vem de algumas
// consultas ao mesmo tempo, com ritmo ADAPTATIVO: começa com 2, sobe até 4 se
// tudo vai bem e, no primeiro sinal de limite (429) ou de servidor sobrecarregado,
// cai para 1, aumenta a pausa e respeita o Retry-After — depois volta a subir
// devagar. Só a aba Expedido usa este ritmo; o Lote continua no dele.
const EXP_CFG = {
  porConsulta: 1,
  concorrenciaInicial: 2,
  concorrenciaMax: 4,
  pausaMinMs: 100, // pausa de cada "trabalhador" entre uma consulta e a próxima
  pausaMaxMs: 250,
  acelerarACada: 25, // respostas boas seguidas para subir 1 na concorrência
  freioMax: 12, // a pausa pode ficar até 12× maior depois de limites seguidos
};

const EXP_MSG = {
  generico: "Não foi possível consultar os rastreios. Tente novamente.",
};

// Texto do motivo no sistema: "Encomenda.expedida.mas.não.chegou.有发未到件"
function normalizarTextoExp(texto) {
  return String(texto == null ? "" : texto)
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[._\s]+/g, " ");
}

function ehExpedidoNaoChegou(evento) {
  if (!evento || typeof evento !== "object") return false;
  const bruto = [evento.remark1, evento.waybillTrackingContent].map((v) => String(v == null ? "" : v)).join(" ");
  if (bruto.includes("有发未到件")) return true;
  return /expedid[ao] mas nao chegou/.test(normalizarTextoExp(bruto));
}

// "2026-10-20 05:16:17" → número comparável (ou null)
function horaDoEvento(evento) {
  const v = String((evento && (evento.scanTime || evento.uploadTime)) || "").trim();
  const m = v.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?/);
  if (!m) return null;
  return Number(m[1] + m[2] + m[3] + m[4] + m[5] + (m[6] || "00"));
}

// Último evento = o de horário mais recente; empate ou sem horário: o que
// vem primeiro na lista (o sistema manda do mais novo para o mais antigo).
// Função pura.
function ultimoEventoExp(detalhes) {
  if (!Array.isArray(detalhes)) return null;
  const eventos = detalhes.filter((d) => d && typeof d === "object");
  if (!eventos.length) return null;
  let melhor = eventos[0];
  let melhorHora = horaDoEvento(melhor);
  for (const ev of eventos.slice(1)) {
    const h = horaDoEvento(ev);
    if (h != null && (melhorHora == null || h > melhorHora)) {
      melhor = ev;
      melhorHora = h;
    }
  }
  return melhor;
}

async function pedirRastreio(tabId, token, codigos) {
  const corpo = JSON.stringify({ keywordList: codigos, trackingTypeEnum: "WAYBILL", countryId: "1" });
  const [execucao] = await chrome.scripting.executeScript({
    target: { tabId },
    func: consultarLoteNaPagina, // mesma função genérica de POST (roda na aba do JMS)
    args: [EXP_API.url, montarCabecalhosLote(token), corpo, LOTE_CFG.timeoutMs],
  });
  return execucao && execucao.result ? execucao.result : { status: 0, ok: false, erro: "rede" };
}

// Decide o que fazer com a resposta de um GRUPO de códigos.
// ok → { tipo: "ok", porCodigo: Map(código → { exp, semRastreio }), faltando: [códigos sem item na resposta] }
// Um código só é classificado pelo item DELE (keyword igual). Num grupo, o
// código que não veio na resposta volta para ser consultado sozinho.
function classificarRespostaExp(r, codigos) {
  if (r.erro === "aba") return { tipo: "fatal", motivo: LOTE_MSG.abaPerdida };
  if (r.erro) return { tipo: "tentar", motivo: r.erro === "timeout" ? "demorou demais" : "sem conexão" };
  if (r.status === 401 || r.status === 403) return { tipo: "auth" };
  if (r.status === 429) return { tipo: "limite", retryAfter: r.retryAfter, motivo: "limite de requisições do servidor" };
  if (r.status >= 500) return { tipo: "tentar", motivo: `erro ${r.status} do servidor` };
  if (!r.ok) return { tipo: "falha", motivo: `erro HTTP ${r.status}` };

  const j = r.json;
  if (!j || typeof j !== "object") return { tipo: "tentar", motivo: "resposta inesperada (sessão expirada?)" };
  const sucesso = (j.succ === true || j.code === 1) && j.fail !== true;
  if (!sucesso) {
    const msg = String(j.msg || "").slice(0, 80);
    if (/token|login|sess[aã]o|expir|autent|unauthor/i.test(msg)) return { tipo: "auth" };
    return { tipo: "falha", motivo: msg || "o sistema recusou a consulta" };
  }
  if (!Array.isArray(j.data)) return { tipo: "tentar", motivo: "resposta sem dados" };

  const itens = j.data.filter((i) => i && typeof i === "object");
  const chave = (i) => String(i.keyword == null ? "" : i.keyword).trim().toUpperCase();
  const porCodigo = new Map();
  const faltando = [];
  const classificar = (item) => {
    const ultimo = item ? ultimoEventoExp(item.details) : null;
    return ultimo ? { exp: ehExpedidoNaoChegou(ultimo), semRastreio: false } : { exp: false, semRastreio: true };
  };
  if (codigos.length === 1) {
    // Sozinho: 1 item sem "keyword" é dele; item de OUTRO código é falha
    // (nunca classificar um código pelo rastreio de outro); nada = sem rastreio.
    const codigo = codigos[0];
    const alvo = itens.length === 1 && !chave(itens[0]) ? itens[0] : itens.find((i) => chave(i) === codigo);
    if (!alvo && itens.length) return { tipo: "falha", motivo: "o sistema respondeu com outro código" };
    porCodigo.set(codigo, classificar(alvo));
    return { tipo: "ok", porCodigo, faltando };
  }
  for (const codigo of codigos) {
    const alvo = itens.find((i) => chave(i) === codigo);
    if (alvo) porCodigo.set(codigo, classificar(alvo));
    else faltando.push(codigo);
  }
  return { tipo: "ok", porCodigo, faltando };
}

// Vagas da aba Expedido (separadas das do Lote): o limite muda conforme o ritmo.
let expNoAr = 0;
const expEsperandoVaga = [];
async function pegarVagaExp(limite) {
  while (expNoAr >= limite()) await new Promise((r) => expEsperandoVaga.push(r));
  expNoAr++;
}
function acordarVagasExp() {
  const esperando = expEsperandoVaga.splice(0);
  esperando.forEach((r) => r());
}
function soltarVagaExp() {
  expNoAr--;
  acordarVagasExp();
}

// Ritmo adaptativo (puro, sem relógio): o motor chama ok()/limite()/instavel().
function criarRitmoExp(cfg = EXP_CFG) {
  const max = Math.max(1, Math.floor(cfg.concorrenciaMax) || 1);
  let conc = Math.min(max, Math.max(1, Math.floor(cfg.concorrenciaInicial) || 1));
  let freio = 1;
  let boasSeguidas = 0;
  return {
    get concorrencia() {
      return conc;
    },
    get freio() {
      return freio;
    },
    ok() {
      boasSeguidas++;
      if (boasSeguidas >= cfg.acelerarACada) {
        boasSeguidas = 0;
        if (freio > 1) freio = Math.max(1, freio / 2);
        else if (conc < max) conc++;
      }
    },
    limite() {
      boasSeguidas = 0;
      conc = 1;
      freio = Math.min(cfg.freioMax, freio * 2);
    },
    instavel() {
      boasSeguidas = 0;
      conc = Math.max(1, conc - 1);
    },
    pausa() {
      return aleatorioEntre(cfg.pausaMinMs, cfg.pausaMaxMs) * freio;
    },
  };
}

// Mesmo contrato do Lote: ativo() para cancelar, retomar = fotografia salva
// (grupos que faltam — inclusive os que estavam no ar — + o que já foi
// classificado), aoProgresso depois de cada grupo.
async function executarConsultaExp({ codigos, tabId, token, ativo: continuar = () => true, aoProgresso = () => {}, porConsulta = EXP_CFG.porConsulta, retomar = null }) {
  const salvo = retomar && typeof retomar === "object" && Array.isArray(retomar.fila) ? retomar : null;
  const expedidos = new Set(salvo ? listaDeTextos(salvo.expedidos) : []);
  const outros = new Set(salvo ? listaDeTextos(salvo.outros) : []);
  const semRastreio = new Set(salvo ? listaDeTextos(salvo.semRastreio) : []);
  const falhas = new Map(salvo ? listaDePares(salvo.falhas).map(([c, m]) => [c, String(m)]) : []);
  let fatal = null;
  let feitos = salvo && Number.isInteger(salvo.feitos) ? salvo.feitos : 0;
  const ativo = () => continuar() && !fatal;
  const tamanho = Math.max(1, Math.floor(porConsulta) || 1);
  const fila = [];
  if (salvo) salvo.fila.forEach((g) => { const grupo = listaDeTextos(g); if (grupo.length) fila.push(grupo); });
  else for (let i = 0; i < codigos.length; i += tamanho) fila.push(codigos.slice(i, i + tamanho));
  const noAr = new Set(); // grupos em consulta agora (entram na fotografia: retomada não os perde)
  const fotografia = () => ({
    fila: [...noAr, ...fila].map((g) => g.slice()),
    expedidos: [...expedidos],
    outros: [...outros],
    semRastreio: [...semRastreio],
    falhas: [...falhas],
    feitos,
  });
  const ritmo = criarRitmoExp();
  let pausaAte = 0; // 429 de qualquer trabalhador: ninguém manda nada antes disso

  const anotar = (codigo, c) => {
    if (c.semRastreio) semRastreio.add(codigo);
    else if (c.exp) expedidos.add(codigo);
    else outros.add(codigo);
    feitos++;
  };

  async function consultarGrupo(grupo) {
    let ultimoMotivo = EXP_MSG.generico;
    for (let tentativa = 1; tentativa <= LOTE_CFG.tentativas; tentativa++) {
      // Espera o fim de qualquer pausa pedida pelo sistema, pega a vaga e
      // confere de novo: um 429 pode ter chegado enquanto esperava a vaga.
      for (;;) {
        const falta = pausaAte - Date.now();
        if (falta > 0) await dormir(falta);
        if (!ativo()) return null;
        await pegarVagaExp(() => ritmo.concorrencia);
        if (!ativo()) {
          soltarVagaExp();
          return null;
        }
        if (pausaAte <= Date.now()) break;
        soltarVagaExp();
      }
      let resposta;
      try {
        resposta = await pedirRastreio(tabId, token, grupo);
      } catch (e) {
        resposta = { erro: "aba" };
      } finally {
        soltarVagaExp();
      }
      if (!ativo()) return null;
      const c = classificarRespostaExp(resposta, grupo);
      if (c.tipo === "ok" || c.tipo === "falha") {
        ritmo.ok();
        acordarVagasExp(); // a concorrência pode ter subido
        return c;
      }
      if (c.tipo === "auth") {
        fatal = new ErroLote("auth", LOTE_MSG.auth);
        return null;
      }
      if (c.tipo === "fatal") {
        fatal = new ErroLote("aba", c.motivo);
        return null;
      }
      ultimoMotivo = c.motivo;
      if (c.tipo === "limite") {
        ritmo.limite();
        pausaAte = Math.max(pausaAte, Date.now() + esperaDoRetryAfter(c.retryAfter, tentativa));
      } else {
        ritmo.instavel();
        if (tentativa < LOTE_CFG.tentativas) await dormir(esperaBackoff(tentativa));
      }
    }
    return { tipo: "falha", motivo: ultimoMotivo };
  }

  async function trabalhador(n) {
    // Os trabalhadores extras só entram quando a concorrência sobe
    while (ativo()) {
      while (n >= ritmo.concorrencia && ativo() && (fila.length || noAr.size)) await dormir(50);
      if (!ativo()) return;
      const grupo = fila.shift(); // atômico: dois trabalhadores nunca pegam o mesmo grupo
      if (grupo === undefined) {
        if (!noAr.size) return;
        await dormir(50); // outro trabalhador pode devolver códigos para a fila
        continue;
      }
      noAr.add(grupo);
      const resultado = await consultarGrupo(grupo);
      noAr.delete(grupo);
      if (resultado === null) {
        if (!fatal && !ativo()) fila.unshift(grupo); // cancelado: fica na fotografia
        return;
      }
      if (resultado.tipo === "ok") {
        resultado.porCodigo.forEach((c, codigo) => anotar(codigo, c));
        if (resultado.faltando.length) fila.unshift(...resultado.faltando.map((cod) => [cod]));
      } else if (grupo.length > 1) {
        fila.unshift(...grupo.map((cod) => [cod])); // grupo recusado: tenta cada código sozinho
      } else {
        falhas.set(grupo[0], resultado.motivo);
        feitos++;
      }
      aoProgresso(feitos, codigos.length, fotografia());
      if (fila.length) await dormir(ritmo.pausa());
    }
  }

  const max = Math.max(1, Math.floor(EXP_CFG.concorrenciaMax) || 1);
  await Promise.all(Array.from({ length: max }, (_, n) => trabalhador(n)));
  return { expedidos, outros, semRastreio, falhas, fatal };
}

// ---------- Consulta em segundo plano (contrato popup ↔ background.js) ----------
// O background.js roda a consulta e guarda o andamento em storage.session
// (nunca o token). O popup só mostra: progresso enquanto "rodando" e, quando
// termina, o mesmo resultado de sempre.
const FUNDO_CHAVE = { lote: "fundo_lote", exp: "fundo_exp" };
