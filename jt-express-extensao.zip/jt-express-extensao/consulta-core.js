// consulta-core.js
// Motor das consultas longas (abas Lote e Expedido): rede, login, fila de
// requisições e os laços que consultam lote por lote / grupo por grupo.
// Não mexe na tela: é carregado pelo popup (que usa as configurações e as
// funções puras) e pelo background.js (que roda as consultas mesmo com o
// popup fechado). Tudo aqui precisa funcionar sem DOM.
//
// Como a consulta é feita: o fetch roda DENTRO da aba do JMS (chrome.scripting),
// igual ao que o próprio site faz — assim a requisição sai com a origem e o
// Referer reais do sistema (chamadas vindas direto da extensão costumam ser
// recusadas por gateways). O token vem do cookie YL_TOKEN, lido na hora de
// cada consulta; ele nunca é guardado nem exibido.

// ---------- ABA LOTE (motor) ----------
const LOTE_API = {
  hostPreferido: "jmsbr.jtjms-br.com",
  // Qualquer endereço do JMS (jmsbr, outro subdomínio...) — o mesmo padrão
  // do host_permissions do manifest.
  padraoAba: "https://*.jtjms-br.com/*",
  url: "https://gw.jtjms-br.com/operatingplatform/packScanList/waybillIdsByPackageNumber",
  cookie: "YL_TOKEN",
};

const LOTE_CFG = {
  concorrencia: 1, // uma consulta por vez: carga leve no JMS
  tentativas: 4, // por lote
  backoffBaseMs: 2000,
  backoffMaxMs: 20000,
  timeoutMs: 25000,
  // Rajada (igual ao Expedido): um lote logo depois do outro, com folga de
  // milissegundos; o limite por minuto é o mesmo do Expedido (ritmo do JMS abaixo).
  espacoMinMs: 120,
  espacoMaxMs: 200,
  // Memória dos lotes (só na sessão do navegador): no Continuar/Criar lote,
  // um lote conferido há menos disso não é consultado de novo (o escolhido,
  // o atual e os abertos no Criar lote são sempre consultados). Antes de dizer
  // "tudo em lote", os que vieram da memória são conferidos de novo.
  memoriaValidadeMs: 10 * 60 * 1000,
  // Lote terminado (LOTE_TAMANHO ou mais) quase não muda: fica na memória o
  // turno todo. A conferência final (sempre de verdade) continua valendo.
  memoriaCheioValidadeMs: 12 * 60 * 60 * 1000,
};

// Pacotes que cabem num lote (popup e background usam o mesmo número)
const LOTE_TAMANHO = 150;


const LOTE_MSG = {
  semAba: "Não encontrei o sistema JMS aberto. Abra o JMS em uma aba deste navegador, entre na sua conta e tente de novo.",
  recarregar: "A extensão foi atualizada e precisa ser recarregada para acessar o JMS. Depois de recarregar, cole as listas de novo.",
  permitir: "A extensão está sem permissão para acessar o sistema JMS. Clique abaixo e confirme.",
  semToken: "Não achei o seu login do sistema. Atualize a página do JMS (F5), confira se está logado e tente de novo.",
  tokenEstranho: "O login do sistema veio em um formato inesperado. Saia e entre de novo no JMS.",
  auth: "O sistema recusou o login (sessão expirada?). Entre de novo no JMS e tente outra vez.",
  abaPerdida: "A aba do sistema foi fechada ou recarregada durante a consulta. Deixe-a aberta e tente de novo.",
  generico: "Não foi possível consultar os lotes. Tente novamente.",
  semFundo: "Não foi possível iniciar a consulta. Feche e abra a extensão de novo; se continuar, recarregue a extensão.",
};

class ErroLote extends Error {
  constructor(tipo, mensagem) {
    super(mensagem);
    this.tipo = tipo;
  }
}

// ATENÇÃO: esta função roda DENTRO da aba do sistema (o chrome.scripting
// serializa o código dela), então NÃO pode usar nenhuma variável deste
// arquivo — só o que chega pelos argumentos e as APIs do navegador.
async function consultarLoteNaPagina(url, cabecalhos, corpoJson, timeoutMs) {
  const controle = new AbortController();
  const relogio = setTimeout(() => controle.abort(), timeoutMs);
  try {
    const resposta = await fetch(url, {
      method: "POST",
      headers: cabecalhos,
      body: corpoJson,
      credentials: "omit",
      redirect: "error", // se o sistema redirecionar, não manda o token pra outro lugar
      signal: controle.signal,
    });
    let json = null;
    try {
      json = await resposta.json();
    } catch (e) {
      json = null;
    }
    return {
      status: resposta.status,
      ok: resposta.ok,
      retryAfter: resposta.headers.get("retry-after"),
      json,
    };
  } catch (e) {
    return { status: 0, ok: false, erro: e && e.name === "AbortError" ? "timeout" : "rede" };
  } finally {
    clearTimeout(relogio);
  }
}

function montarCabecalhosLote(token) {
  return {
    accept: "application/json, text/plain, */*",
    "accept-language": "pt-BR,pt;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
    authtoken: token,
    "cache-control": "max-age=2, must-revalidate",
    "content-type": "application/json;charset=UTF-8",
    lang: "PT",
    langtype: "PT",
    routename: "trackingExpress",
    routernamelist:
      "%E6%93%8D%E4%BD%9C%E5%B9%B3%E5%8F%B0%3E%E5%BF%AB%E4%BB%B6%E6%9F%A5%E8%AF%A2%3E%E5%BF%AB%E4%BB%B6%E8%B7%9F%E8%B8%AA",
    timezone: "GMT-0300",
  };
}

const dormir = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const aleatorioEntre = (min, max) => min + Math.random() * (max - min);

function esperaBackoff(tentativa) {
  return Math.min(LOTE_CFG.backoffBaseMs * 2 ** (tentativa - 1), LOTE_CFG.backoffMaxMs) + Math.random() * 250;
}

function esperaDoRetryAfter(valor, tentativa) {
  const segundos = Number(valor);
  if (valor != null && valor !== "" && Number.isFinite(segundos) && segundos >= 0) {
    return Math.min(segundos * 1000, LOTE_CFG.backoffMaxMs * 2);
  }
  return esperaBackoff(tentativa);
}

// O login do JMS (cookie YL_TOKEN) só é aceito de jtjms-br.com ou subdomínios.
// ---------- Ritmo do JMS (Lote e Expedido juntos) ----------
// O gateway do JMS aceita ~64 consultas e depois recusa tudo (HTTP 405, que
// chega como "sem conexão") por ~1 min. As duas abas usam o MESMO orçamento:
// rajadas de EXP_CFG.rajadaCota consultas e, ao completar, espera 1 min desde
// a 1ª da rajada. Se o sistema bloquear antes, a rajada diminui.
const rajadaJms = { cota: 0, enviadas: 0, inicio: 0 };
function cotaRajadaJms() {
  if (!rajadaJms.cota) {
    const c = Math.floor(EXP_CFG.rajadaCota);
    rajadaJms.cota = c > 0 ? c : Infinity;
  }
  return rajadaJms.cota;
}
function contarEnvioJms() {
  if (!rajadaJms.enviadas) rajadaJms.inicio = Date.now();
  rajadaJms.enviadas++;
}
// O sistema voltou depois de um bloqueio: a consulta que passou abre uma rajada nova
function recomecarRajadaJms() {
  rajadaJms.enviadas = 1;
  rajadaJms.inicio = Date.now();
}
// Bloqueou depois de "aceitas": a rajada fica menor (com folga e uma mínima).
// Devolve a cota nova, ou null se não mudou.
function baixarCotaJms(aceitas) {
  const cota = cotaRajadaJms();
  if (cota === Infinity) return null;
  const nova = Math.max(EXP_CFG.rajadaMinima, Math.min(cota, aceitas - EXP_CFG.rajadaFolga));
  if (nova >= cota) return null;
  rajadaJms.cota = nova;
  return nova;
}
// Antes de cada consulta: se a rajada completou, espera o minuto dela acabar.
// Devolve false se a consulta foi cancelada durante a pausa.
async function respeitarRajadaJms(ativo, aoAguardar = () => {}, aoRegistro = () => {}) {
  while (rajadaJms.enviadas >= cotaRajadaJms()) {
    const falta = rajadaJms.inicio + EXP_CFG.janelaMs + EXP_CFG.janelaMargemMs - Date.now();
    if (falta > 0) {
      aoRegistro({ t: Date.now(), tipo: "rajada", enviadas: rajadaJms.enviadas, duracaoMs: Date.now() - rajadaJms.inicio, esperaMs: falta, cota: rajadaJms.cota });
      const ate = Date.now() + falta;
      aoAguardar(ate, "rajada");
      while (ativo() && Date.now() < ate) await dormir(Math.min(1000, ate - Date.now()));
      aoAguardar(0, "");
      if (!ativo()) return false;
    }
    // (outra consulta pode ter recomeçado a rajada enquanto esta esperava)
    if (rajadaJms.enviadas >= cotaRajadaJms() && rajadaJms.inicio + EXP_CFG.janelaMs + EXP_CFG.janelaMargemMs <= Date.now()) rajadaJms.enviadas = 0;
  }
  return ativo();
}

const LOTE_DOMINIO = "jtjms-br.com";
function ehDominioJms(dominio) {
  const d = String(dominio || "").replace(/^\./, "").toLowerCase();
  return d === LOTE_DOMINIO || d.endsWith("." + LOTE_DOMINIO);
}

function hostDaAba(aba) {
  try {
    return new URL(aba && aba.url).hostname.toLowerCase();
  } catch (e) {
    return "";
  }
}

// Limpa o valor lido (aspas, %xx) sem nunca mostrar ou guardar o token.
function limparToken(valor) {
  let v = String(valor == null ? "" : valor).trim().replace(/^"(.*)"$/, "$1").trim();
  if (/%[0-9A-Fa-f]{2}/.test(v)) {
    try {
      v = decodeURIComponent(v).trim();
    } catch (e) {
      /* deixa como veio */
    }
  }
  return v;
}

// Roda DENTRO da aba do JMS (precisa ser autocontida). Plano B para quando o
// login não aparece pela API de cookies: lê do próprio site.
function lerTokenNaPagina(nome) {
  const alvo = String(nome).toLowerCase();
  try {
    for (const parte of document.cookie.split(";")) {
      const k = parte.indexOf("=");
      if (k > 0 && parte.slice(0, k).trim().toLowerCase() === alvo) return parte.slice(k + 1).trim();
    }
  } catch (e) {
    /* sem acesso a document.cookie */
  }
  for (const area of ["localStorage", "sessionStorage"]) {
    try {
      const st = window[area];
      for (let n = 0; n < st.length; n++) {
        const chave = st.key(n);
        if (chave && chave.toLowerCase() === alvo) return st.getItem(chave) || "";
      }
    } catch (e) {
      /* armazenamento indisponível */
    }
  }
  return "";
}

// Junta todos os cookies YL_TOKEN do domínio do JMS: normais e particionados
// (o Chrome novo guarda alguns cookies "por site", e a busca simples não os vê),
// no mesmo perfil/janela da aba do sistema.
async function cookiesDoLogin(aba) {
  if (!chrome.cookies || !chrome.cookies.getAll) return [];
  let storeId;
  try {
    const lojas = chrome.cookies.getAllCookieStores ? await chrome.cookies.getAllCookieStores() : [];
    const loja = (lojas || []).find((l) => (l.tabIds || []).includes(aba && aba.id));
    if (loja) storeId = loja.id;
  } catch (e) {
    storeId = undefined;
  }
  const base = storeId ? { domain: LOTE_DOMINIO, storeId } : { domain: LOTE_DOMINIO };
  const achados = [];
  for (const filtro of [base, { ...base, partitionKey: {} }]) {
    try {
      const lista = await chrome.cookies.getAll(filtro);
      if (Array.isArray(lista)) achados.push(...lista);
    } catch (e) {
      /* Chrome antigo sem suporte a partitionKey: segue com o que tiver */
    }
  }
  const alvo = LOTE_API.cookie.toLowerCase();
  return achados.filter((c) => c && String(c.name).toLowerCase() === alvo && ehDominioJms(c.domain) && c.value);
}

// Confere se a extensão consegue falar com o JMS antes de procurar a aba.
// "recarregar": arquivos novos, mas o Chrome ainda roda o manifest antigo
//   (sem as permissões de cookies/scripting) — só recarregar resolve.
// "permitir": manifest certo, mas o acesso ao site foi negado/restrito.
async function verificarAcessoLote() {
  if (!chrome.cookies || !chrome.cookies.getAll || !chrome.scripting || !chrome.scripting.executeScript) return "recarregar";
  if (!chrome.permissions || !chrome.permissions.contains) return "ok"; // sem como checar: segue e deixa a consulta dizer
  try {
    const ok = await chrome.permissions.contains({ origins: [LOTE_API.padraoAba] });
    return ok ? "ok" : "permitir";
  } catch (e) {
    return "permitir";
  }
}

async function obterTokenLote(aba) {
  const host = hostDaAba(aba);
  const valido = (v) => /^[A-Za-z0-9._-]{8,300}$/.test(v);
  const cookies = await cookiesDoLogin(aba);
  // Prioridade: cookie do próprio endereço da aba > do domínio pai > qualquer outro do JMS
  const peso = (c) => {
    const d = String(c.domain).replace(/^\./, "").toLowerCase();
    if (d === host) return 0;
    if (host.endsWith("." + d)) return 1;
    return 2;
  };
  cookies.sort((a, b) => peso(a) - peso(b));
  const candidatos = cookies.map((c) => limparToken(c.value)).filter(Boolean);

  if (!candidatos.length && aba && aba.id != null && chrome.scripting) {
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId: aba.id }, func: lerTokenNaPagina, args: [LOTE_API.cookie] });
      const v = limparToken(r && r.result);
      if (v) candidatos.push(v);
    } catch (e) {
      /* aba indisponível: cai no aviso de login abaixo */
    }
  }

  if (!candidatos.length) throw new ErroLote("token", LOTE_MSG.semToken);
  const bom = candidatos.find(valido);
  if (!bom) throw new ErroLote("token", LOTE_MSG.tokenEstranho);
  return bom;
}

async function acharAbaSistema() {
  const acesso = await verificarAcessoLote();
  if (acesso !== "ok") throw new ErroLote(acesso, LOTE_MSG[acesso]);
  let abas = [];
  try {
    abas = await chrome.tabs.query({ url: LOTE_API.padraoAba });
  } catch (e) {
    abas = [];
  }
  // Prioridade: aba ativa do jmsbr > qualquer jmsbr > ativa de outro endereço do JMS > qualquer outra
  const vivas = (abas || []).filter((a) => a && !a.discarded && a.id != null);
  const preferidas = vivas.filter((a) => hostDaAba(a) === LOTE_API.hostPreferido);
  const aba =
    preferidas.find((a) => a.active) || preferidas[0] || vivas.find((a) => a.active) || vivas[0];
  if (!aba || aba.id == null) throw new ErroLote("aba", LOTE_MSG.semAba);
  return aba;
}

async function pedirLote(tabId, token, lote) {
  const [execucao] = await chrome.scripting.executeScript({
    target: { tabId },
    func: consultarLoteNaPagina,
    args: [LOTE_API.url, montarCabecalhosLote(token), JSON.stringify([lote]), LOTE_CFG.timeoutMs],
  });
  return execucao && execucao.result ? execucao.result : { status: 0, ok: false, erro: "rede" };
}

// Decide o que fazer com a resposta de UM lote.
function classificarRespostaLote(r, lote) {
  if (r.erro === "aba") return { tipo: "fatal", motivo: LOTE_MSG.abaPerdida };
  if (r.erro === "timeout") return { tipo: "tentar", motivo: "demorou demais" };
  // Recusa na hora (o 405 do bloqueio chega como "sem conexão"): é o bloqueio
  if (r.erro) return { tipo: "limite", retryAfter: null, motivo: "bloqueio do minuto (HTTP 405 / sem conexão)" };
  if (r.status === 401 || r.status === 403) return { tipo: "auth" };
  if (r.status === 429) return { tipo: "limite", retryAfter: r.retryAfter, motivo: "limite de requisições do servidor" };
  if (r.status === 405) return { tipo: "limite", retryAfter: r.retryAfter, motivo: "bloqueio do minuto (HTTP 405)" };
  if (r.status >= 500) return { tipo: "tentar", motivo: `erro ${r.status} do servidor` };
  if (!r.ok) return { tipo: "falha", motivo: `erro HTTP ${r.status}` };

  const j = r.json;
  if (!j || typeof j !== "object") return { tipo: "tentar", motivo: "resposta inesperada (sessão expirada?)" };

  const sucesso = (j.succ === true || j.code === 1) && j.fail !== true;
  if (!sucesso) {
    const msg = String(j.msg || "").slice(0, 80);
    if (/token|login|sess[aã]o|expir|autent|unauthor/i.test(msg)) return { tipo: "auth" };
    return { tipo: "falha", motivo: msg || "o sistema recusou a consulta" };
  }
  if (!Array.isArray(j.data)) return { tipo: "tentar", motivo: "resposta sem dados" };

  // Pedimos 1 lote por vez. Se veio 1 item, é ele (mesmo que o código volte
  // formatado diferente); se vierem vários, só vale o que bate com o lote.
  // Regra nº 1: só confirma o que é do lote pedido. Um item só vale se o
  // packageNumber bater (ou não vier); item de OUTRO lote é falha deste lote.
  const itens = j.data.filter((i) => i && typeof i === "object");
  const numero = (i) => String(i.packageNumber == null ? "" : i.packageNumber).trim().toUpperCase();
  const alvo = itens.length === 1 && !numero(itens[0]) ? itens : itens.filter((i) => numero(i) === lote);
  if (itens.length && !alvo.length) return { tipo: "falha", motivo: "o sistema respondeu com outro lote" };
  const ids = new Set();
  for (const item of alvo) {
    if (Array.isArray(item.waybillIds)) item.waybillIds.forEach((id) => ids.add(String(id).trim().toUpperCase()));
  }
  return { tipo: "ok", ids, vazio: ids.size === 0 };
}

// Vagas de requisição ao JMS valem para TODAS as execuções: as de uma
// consulta cancelada continuam no ar até responder, e uma consulta nova
// não pode somar com elas (nunca mais que LOTE_CFG.concorrencia ao mesmo tempo).
let loteNoAr = 0;
const loteEsperandoVaga = [];
async function pegarVagaLote() {
  while (loteNoAr >= LOTE_CFG.concorrencia) await new Promise((r) => loteEsperandoVaga.push(r));
  loteNoAr++;
}
function soltarVagaLote() {
  loteNoAr--;
  const proximo = loteEsperandoVaga.shift();
  if (proximo) proximo();
}

// Leitura defensiva do que volta da sessão (retomada depois de o Chrome
// encerrar o background no meio de uma consulta).
const listaDeTextos = (v) => (Array.isArray(v) ? v.filter((x) => typeof x === "string") : []);
const listaDePares = (v) => (Array.isArray(v) ? v.filter((p) => Array.isArray(p) && p.length === 2 && typeof p[0] === "string") : []);

// ativo(): quem chamou ainda quer esta consulta (falso = cancelada/substituída).
// retomar: fotografia salva por aoProgresso — continua de onde parou, sem
// repetir lote já consultado e sem perder o que já foi achado.
// aoProgresso(feitos, total, fotografia) é chamado depois de CADA lote.
// prontos: Map lote -> lista de códigos (da memória): entra no resultado sem
//   consultar e fica marcado em daMemoria (para a conferência final).
// aoLote(lote, ids): cada lote consultado de verdade (para guardar na memória).
async function executarConsultaLotes({ lotes, coletaSet, tabId, token, ativo: continuar = () => true, aoProgresso = () => {}, retomar = null, prontos = null, aoLote = () => {}, aoAguardar = () => {} }) {
  const salvo = retomar && typeof retomar === "object" && Array.isArray(retomar.fila) ? retomar : null;
  const fila = salvo ? listaDeTextos(salvo.fila) : [...lotes];
  const encontrados = new Set(salvo ? listaDeTextos(salvo.encontrados) : []);
  const falhas = new Map(salvo ? listaDePares(salvo.falhas).map(([l, m]) => [l, String(m)]) : []);
  const vazios = new Set(salvo ? listaDeTextos(salvo.vazios) : []);
  // lote -> quantos pacotes ele já tem (todos, não só os da coleta)
  const contagem = new Map(salvo ? listaDePares(salvo.contagem).filter((p) => Number.isFinite(p[1])) : []);
  let concluidos = salvo && Number.isInteger(salvo.concluidos) ? salvo.concluidos : 0;
  // lote -> códigos da coleta achados nele (a conferência final troca os da memória)
  const porLote = new Map(salvo ? listaDePares(salvo.porLote).map(([l, ids]) => [l, listaDeTextos(ids)]) : []);
  const daMemoria = new Set(salvo ? listaDeTextos(salvo.daMemoria) : []);
  const emCurso = new Set(); // lotes pedidos e ainda sem resposta: voltam para a fila numa retomada
  let fatal = null;
  let pausaGlobal = Promise.resolve(); // 429 de qualquer um segura TODOS os trabalhadores
  // Bloqueio do JMS: quando começou (0 = livre) e quantos o sistema aceitou desde que liberou
  let travouEm = 0;
  let aceitasDesde = 0;
  let bloqueioAte = 0; // ninguém consulta antes disso (vale para todos os trabalhadores)

  const ativo = () => continuar() && !fatal;
  const fotografia = () => ({
    fila: [...emCurso, ...fila],
    encontrados: [...encontrados],
    falhas: [...falhas],
    vazios: [...vazios],
    contagem: [...contagem],
    concluidos,
    porLote: [...porLote],
    daMemoria: [...daMemoria],
  });

  function anotarOk(lote, ids) {
    const achados = [];
    ids.forEach((id) => {
      if (coletaSet.has(id)) {
        encontrados.add(id);
        achados.push(id);
      }
    });
    porLote.set(lote, achados);
    if (ids.size === 0) vazios.add(lote);
    else vazios.delete(lote);
    contagem.set(lote, ids.size);
  }

  // Da memória: sem consultar (só os que ainda estão na fila)
  if (prontos instanceof Map && prontos.size) {
    let usou = 0;
    for (let i = fila.length - 1; i >= 0; i--) {
      const lote = fila[i];
      const ids = prontos.get(lote);
      if (!Array.isArray(ids)) continue;
      fila.splice(i, 1);
      anotarOk(lote, new Set(listaDeTextos(ids).map((id) => id.trim().toUpperCase())));
      daMemoria.add(lote);
      concluidos++;
      usou++;
    }
    if (usou && continuar()) aoProgresso(concluidos, lotes.length, fotografia());
  }

  async function consultarUm(lote) {
    let ultimoMotivo = LOTE_MSG.generico;
    const inicioLote = Date.now();
    for (let tentativa = 1; tentativa <= LOTE_CFG.tentativas; tentativa++) {
      await pausaGlobal;
      if (!ativo()) return null;
      if (bloqueioAte > Date.now()) {
        while (ativo() && Date.now() < bloqueioAte) await dormir(Math.min(1000, bloqueioAte - Date.now()));
        aoAguardar(0, "");
        if (!ativo()) return null;
      }
      if (!(await respeitarRajadaJms(ativo, aoAguardar))) return null;

      await pegarVagaLote();
      if (!ativo()) {
        soltarVagaLote();
        return null;
      }
      let resposta;
      try {
        contarEnvioJms();
        resposta = await pedirLote(tabId, token, lote);
      } catch (e) {
        resposta = { erro: "aba" };
      } finally {
        soltarVagaLote();
      }
      if (!ativo()) return null;

      const c = classificarRespostaLote(resposta, lote);
      if (c.tipo !== "limite" && c.tipo !== "fatal" && c.tipo !== "auth" && !(c.tipo === "tentar" && resposta && resposta.erro)) {
        // O sistema respondeu: se estava bloqueado, liberou (rajada nova)
        if (travouEm) {
          travouEm = 0;
          aceitasDesde = 0;
          recomecarRajadaJms();
        }
        aceitasDesde++;
      }
      if (c.tipo === "ok") return c;
      if (c.tipo === "auth") {
        fatal = new ErroLote("auth", LOTE_MSG.auth);
        return null;
      }
      if (c.tipo === "fatal") {
        fatal = new ErroLote("aba", c.motivo);
        return null;
      }
      if (c.tipo === "falha") return c;

      ultimoMotivo = c.motivo;
      if (c.tipo === "limite") {
        // Bloqueio: não gasta tentativa. Espera completar 1 min desde a 1ª
        // recusa, testa o MESMO lote e, se ainda recusar, testa a cada poucos s.
        if (!travouEm) {
          travouEm = Date.now();
          baixarCotaJms(aceitasDesde);
        }
        const desde = Date.now() - travouEm;
        const passo = desde < EXP_CFG.janelaMs ? EXP_CFG.janelaMs + EXP_CFG.janelaMargemMs - desde : EXP_CFG.sondaMs;
        const pedido = c.retryAfter != null ? esperaDoRetryAfter(c.retryAfter, Math.min(tentativa, 5)) : 0;
        const espera = Math.max(passo, pedido);
        if (Date.now() + espera - inicioLote > EXP_CFG.limiteTetoMs) return { tipo: "falha", motivo: "o sistema não liberou a consulta" };
        bloqueioAte = Math.max(bloqueioAte, Date.now() + espera);
        aoAguardar(bloqueioAte, "limite");
        tentativa--;
      } else if (tentativa < LOTE_CFG.tentativas) {
        await dormir(esperaBackoff(tentativa));
      }
    }
    return { tipo: "falha", motivo: ultimoMotivo };
  }

  async function trabalhador() {
    while (ativo()) {
      const lote = fila.shift(); // atômico: JS roda uma coisa por vez, dois trabalhadores nunca pegam o mesmo lote
      if (lote === undefined) return;
      emCurso.add(lote);

      const r = await consultarUm(lote);
      if (r === null) return; // cancelado ou erro fatal
      if (!continuar()) return;

      if (r.tipo === "ok") {
        anotarOk(lote, r.ids);
        aoLote(lote, [...r.ids]);
      } else {
        falhas.set(lote, r.motivo);
      }
      emCurso.delete(lote);

      concluidos++;
      aoProgresso(concluidos, lotes.length, fotografia());
      if (fila.length) await dormir(aleatorioEntre(LOTE_CFG.espacoMinMs, LOTE_CFG.espacoMaxMs));
    }
  }

  const quantos = Math.min(LOTE_CFG.concorrencia, fila.length);
  await Promise.all(Array.from({ length: quantos }, trabalhador));
  return { encontrados, falhas, vazios, contagem, fatal, porLote, daMemoria };
}

// ---------- ABA EXPEDIDO NÃO CHEGOU (motor) ----------
// Mesmas garantias da aba Lote: o fetch roda dentro da aba do JMS, o token é
// lido na hora (nunca guardado nem exibido) e as consultas usam a MESMA fila
// do Lote (uma por vez no total, com pausa entre elas), então as duas abas
// juntas nunca passam desse ritmo.

const EXP_API = {
  url: "https://gw.jtjms-br.com/operatingplatform/podTracking/inner/query/keywordList",
};

// O rastreio do JMS aceita 1 código por consulta. A velocidade vem de até 2
// consultas ao mesmo tempo, com ritmo ADAPTATIVO: começa com 1, sobe até 2 se
// tudo vai bem e, no primeiro sinal de limite (429) ou de servidor sobrecarregado,
// cai para 1, aumenta a pausa e respeita o Retry-After — depois volta a subir
// devagar. Só a aba Expedido usa este ritmo; o Lote continua no dele.
const EXP_CFG = {
  porConsulta: 1,
  concorrenciaInicial: 1,
  concorrenciaMax: 1, // uma por vez: o JMS limita por volume (≈60 e bloqueia ~1 min)
  // Rajada: uma consulta logo depois da outra, só com uma folga de milissegundos.
  pausaMinMs: 120,
  pausaMaxMs: 200,
  acelerarACada: 60, // respostas boas seguidas para subir 1 na concorrência
  freioMax: 1, // sem freio: no bloqueio a espera é a janela de 1 minuto
  // Bloqueio do JMS (HTTP 405, que chega como "sem conexão", ou 429): ele dura
  // ~1 min a partir da 1ª recusa. Espera a janela, testa o MESMO código e, se
  // passar, solta a rajada de novo. Se ainda recusar, testa de novo em poucos s.
  janelaMs: 60 * 1000,
  janelaMargemMs: 1500,
  sondaMs: 4000,
  // Rajada por minuto: o JMS aceita ~64 consultas e bloqueia por ~1 min. Manda
  // 60 de uma vez e espera completar 1 min desde o início da rajada (+ margem):
  // assim nem chega a ser bloqueado. Se bloquear mesmo assim, a rajada diminui.
  rajadaCota: 60,
  rajadaMinima: 20,
  rajadaFolga: 4, // depois de um bloqueio: cota = o que o sistema aceitou − folga
  aprenderLimite: false, // pausa preventiva aprendida desligada (o bloqueio é por janela)
  limitesMax: 30, // avisos de limite seguidos que um código aguenta (não gastam tentativa)
  // Esperas quando o sistema segura (limite, resposta vazia ou recusa): insiste
  // no MESMO código até ir; depois de 60 s, repete 60 s até o teto por código.
  esperasLimiteMs: [5000, 10000, 20000, 30000, 60000],
  limiteTetoMs: 30 * 60 * 1000, // 30 min no mesmo código → aí sim vira erro (e volta no repasse)
  suspeitasMax: 6, // resposta vazia/recusada seguida: depois disso vira erro (nunca "pulado")
  // Aprende o limite: anota quantas consultas passaram até travar e quanto
  // tempo levou para liberar; depois para sozinha um pouco antes.
  aprenderMinimo: 10, // só aprende se passaram pelo menos 10 antes de travar
  aprenderMargem: 0.15, // para 15% antes do número aprendido
  pausaAprendidaMaxMs: 10 * 60 * 1000,
  repasses: 1, // no fim, refaz sozinha os que deram erro (antes de mostrar o resultado)
  repasseEsperaMs: 60000, // pausa antes de refazer
};

const EXP_MSG = {
  generico: "Não foi possível consultar os rastreios. Tente novamente.",
};

// Texto do motivo no sistema: "Encomenda.expedida.mas.não.chegou.有发未到件"
function normalizarTextoExp(texto) {
  return String(texto == null ? "" : texto)
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[._\s]+/g, " ");
}

function ehExpedidoNaoChegou(evento) {
  if (!evento || typeof evento !== "object") return false;
  const bruto = [evento.remark1, evento.waybillTrackingContent].map((v) => String(v == null ? "" : v)).join(" ");
  if (bruto.includes("有发未到件")) return true;
  return /expedid[ao] mas nao chegou/.test(normalizarTextoExp(bruto));
}

// "2026-10-20 05:16:17" → número comparável (ou null)
function horaDoEvento(evento) {
  const v = String((evento && (evento.scanTime || evento.uploadTime)) || "").trim();
  const m = v.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?/);
  if (!m) return null;
  return Number(m[1] + m[2] + m[3] + m[4] + m[5] + (m[6] || "00"));
}

// Último evento = o de horário mais recente; empate ou sem horário: o que
// vem primeiro na lista (o sistema manda do mais novo para o mais antigo).
// Função pura.
function ultimoEventoExp(detalhes) {
  if (!Array.isArray(detalhes)) return null;
  const eventos = detalhes.filter((d) => d && typeof d === "object");
  if (!eventos.length) return null;
  let melhor = eventos[0];
  let melhorHora = horaDoEvento(melhor);
  for (const ev of eventos.slice(1)) {
    const h = horaDoEvento(ev);
    if (h != null && (melhorHora == null || h > melhorHora)) {
      melhor = ev;
      melhorHora = h;
    }
  }
  return melhor;
}

async function pedirRastreio(tabId, token, codigos) {
  const corpo = JSON.stringify({ keywordList: codigos, trackingTypeEnum: "WAYBILL", countryId: "1" });
  const [execucao] = await chrome.scripting.executeScript({
    target: { tabId },
    func: consultarLoteNaPagina, // mesma função genérica de POST (roda na aba do JMS)
    args: [EXP_API.url, montarCabecalhosLote(token), corpo, LOTE_CFG.timeoutMs],
  });
  return execucao && execucao.result ? execucao.result : { status: 0, ok: false, erro: "rede" };
}

// Uma linha do diagnóstico (o que o JMS respondeu e o que a extensão entendeu).
// Nunca guarda o token nem os cabeçalhos — só o que ajuda a entender o limite.
function registroExp(codigos, r, c, t0) {
  const j = r && r.json && typeof r.json === "object" ? r.json : null;
  const itens = j && Array.isArray(j.data) ? j.data.filter((i) => i && typeof i === "object") : null;
  const eventos = itens && itens[0] && Array.isArray(itens[0].details) ? itens[0].details.length : null;
  const ultimo = itens && itens[0] ? ultimoEventoExp(itens[0].details) : null;
  return {
    t: Date.now(),
    ms: Date.now() - t0,
    cod: codigos.join("+"),
    http: r && r.erro ? r.erro : r ? r.status : null,
    msg: j ? String(j.msg == null ? "" : j.msg).slice(0, 80) : "",
    code: j && j.code != null ? String(j.code).slice(0, 12) : "",
    itens: itens ? itens.length : null,
    eventos,
    status: ultimo ? String(ultimo.scanTypeName || "").slice(0, 40) : "",
    retryAfter: r && r.retryAfter != null ? String(r.retryAfter).slice(0, 12) : "",
    tipo: c.tipo,
    exp: c.tipo === "ok" && c.porCodigo ? [...c.porCodigo.values()].some((v) => v.exp) : false,
    motivo: String(c.motivo || "").slice(0, 60),
  };
}

// Mensagens do sistema que indicam excesso de consultas (português, inglês, chinês)
function pareceLimiteExp(msg) {
  const t = normalizarTextoExp(msg);
  return /frequen|muitas (solicita|requisi|consulta)|limite|too many|rate|throttl|aguarde|tente (novamente )?mais tarde/.test(t) || /频繁|过多|限流|稍后/.test(String(msg || ""));
}

// Decide o que fazer com a resposta de um GRUPO de códigos.
// ok → { tipo: "ok", porCodigo: Map(código → { exp, semRastreio }), faltando: [códigos sem item na resposta] }
// Um código só é classificado pelo item DELE (keyword igual). Num grupo, o
// código que não veio na resposta volta para ser consultado sozinho.
function classificarRespostaExp(r, codigos) {
  if (r.erro === "aba") return { tipo: "fatal", motivo: LOTE_MSG.abaPerdida };
  if (r.erro === "timeout") return { tipo: "tentar", motivo: "demorou demais" };
  // Recusa na hora (o 405 do bloqueio chega sem cabeçalhos e o navegador mostra
  // como "sem conexão"): é o bloqueio, nunca pula o código.
  if (r.erro) return { tipo: "limite", retryAfter: null, motivo: "bloqueio do minuto (HTTP 405 / sem conexão)" };
  if (r.status === 401 || r.status === 403) return { tipo: "auth" };
  if (r.status === 429) return { tipo: "limite", retryAfter: r.retryAfter, motivo: "limite de requisições do servidor" };
  // 405: o JMS recusa assim depois de ~60 consultas e segue recusando por ~1 min
  if (r.status === 405) return { tipo: "limite", retryAfter: r.retryAfter, motivo: "bloqueio do minuto (HTTP 405)" };
  if (r.status >= 500) return { tipo: "tentar", motivo: `erro ${r.status} do servidor` };
  // Qualquer outro status: pode ser o limite com outro código HTTP — insiste
  if (!r.ok) return { tipo: "suspeito", motivo: `erro HTTP ${r.status}` };

  const j = r.json;
  if (!j || typeof j !== "object") return { tipo: "suspeito", motivo: "resposta inesperada" };
  const sucesso = (j.succ === true || j.code === 1) && j.fail !== true;
  if (!sucesso) {
    const msg = String(j.msg || "").slice(0, 80);
    if (/token|login|sess[aã]o|expir|autent|unauthor/i.test(msg)) return { tipo: "auth" };
    // Limite avisado na mensagem (sem 429): freia como um 429
    if (pareceLimiteExp(msg)) return { tipo: "limite", retryAfter: null, motivo: "limite de requisições do servidor" };
    return { tipo: "suspeito", motivo: msg || "o sistema recusou a consulta" };
  }
  if (!Array.isArray(j.data)) return { tipo: "suspeito", motivo: "resposta sem dados" };

  const itens = j.data.filter((i) => i && typeof i === "object");
  const chave = (i) => String(i.keyword == null ? "" : i.keyword).trim().toUpperCase();
  const porCodigo = new Map();
  const faltando = [];
  const classificar = (item) => {
    const ultimo = item ? ultimoEventoExp(item.details) : null;
    return ultimo ? { exp: ehExpedidoNaoChegou(ultimo), semRastreio: false } : { exp: false, semRastreio: true };
  };
  if (codigos.length === 1) {
    // Sozinho: 1 item sem "keyword" é dele. Item de OUTRO código ou resposta
    // sem nenhum evento é SUSPEITA (o limite do JMS pode vir assim): nunca
    // classifica nem pula — espera e tenta de novo o mesmo código.
    const codigo = codigos[0];
    const alvo = itens.length === 1 && !chave(itens[0]) ? itens[0] : itens.find((i) => chave(i) === codigo);
    if (!alvo && itens.length) return { tipo: "suspeito", motivo: "o sistema respondeu com outro código" };
    if (!alvo || !ultimoEventoExp(alvo.details)) return { tipo: "suspeito", motivo: "resposta vazia", vazio: true };
    porCodigo.set(codigo, classificar(alvo));
    return { tipo: "ok", porCodigo, faltando };
  }
  for (const codigo of codigos) {
    const alvo = itens.find((i) => chave(i) === codigo);
    if (alvo) porCodigo.set(codigo, classificar(alvo));
    else faltando.push(codigo);
  }
  return { tipo: "ok", porCodigo, faltando };
}

// Vagas da aba Expedido (separadas das do Lote): o limite muda conforme o ritmo.
let expNoAr = 0;
const expEsperandoVaga = [];
async function pegarVagaExp(limite) {
  while (expNoAr >= limite()) await new Promise((r) => expEsperandoVaga.push(r));
  expNoAr++;
}
function acordarVagasExp() {
  const esperando = expEsperandoVaga.splice(0);
  esperando.forEach((r) => r());
}
function soltarVagaExp() {
  expNoAr--;
  acordarVagasExp();
}

// Ritmo adaptativo (puro, sem relógio): o motor chama ok()/limite()/instavel().
function criarRitmoExp(cfg = EXP_CFG) {
  const max = Math.max(1, Math.floor(cfg.concorrenciaMax) || 1);
  let conc = Math.min(max, Math.max(1, Math.floor(cfg.concorrenciaInicial) || 1));
  let freio = 1;
  let boasSeguidas = 0;
  return {
    get concorrencia() {
      return conc;
    },
    get freio() {
      return freio;
    },
    ok() {
      boasSeguidas++;
      if (boasSeguidas >= cfg.acelerarACada) {
        boasSeguidas = 0;
        if (freio > 1) freio = Math.max(1, freio / 2);
        else if (conc < max) conc++;
      }
    },
    limite() {
      boasSeguidas = 0;
      conc = 1;
      freio = Math.min(cfg.freioMax, freio * 2);
    },
    instavel() {
      boasSeguidas = 0;
      conc = Math.max(1, conc - 1);
    },
    pausa() {
      return aleatorioEntre(cfg.pausaMinMs, cfg.pausaMaxMs) * freio;
    },
  };
}

// Mesmo contrato do Lote: ativo() para cancelar, retomar = fotografia salva
// (grupos que faltam — inclusive os que estavam no ar — + o que já foi
// classificado), aoProgresso depois de cada grupo.
async function executarConsultaExp({ codigos, tabId, token, ativo: continuar = () => true, aoProgresso = () => {}, aoAguardar = () => {}, porConsulta = EXP_CFG.porConsulta, retomar = null, aprendido: aprendidoInicial = null, aoAprender = () => {}, aoRegistro = () => {} }) {
  const salvo = retomar && typeof retomar === "object" && Array.isArray(retomar.fila) ? retomar : null;
  const expedidos = new Set(salvo ? listaDeTextos(salvo.expedidos) : []);
  const outros = new Set(salvo ? listaDeTextos(salvo.outros) : []);
  const semRastreio = new Set(salvo ? listaDeTextos(salvo.semRastreio) : []);
  const falhas = new Map(salvo ? listaDePares(salvo.falhas).map(([c, m]) => [c, String(m)]) : []);
  let fatal = null;
  let feitos = salvo && Number.isInteger(salvo.feitos) ? salvo.feitos : 0;
  let repasse = salvo && Number.isInteger(salvo.repasse) ? salvo.repasse : 0;
  const ativo = () => continuar() && !fatal;
  const tamanho = Math.max(1, Math.floor(porConsulta) || 1);
  const fila = [];
  if (salvo) salvo.fila.forEach((g) => { const grupo = listaDeTextos(g); if (grupo.length) fila.push(grupo); });
  else for (let i = 0; i < codigos.length; i += tamanho) fila.push(codigos.slice(i, i + tamanho));
  const noAr = new Set(); // grupos em consulta agora (entram na fotografia: retomada não os perde)
  const fotografia = () => ({
    fila: [...noAr, ...fila].map((g) => g.slice()),
    expedidos: [...expedidos],
    outros: [...outros],
    semRastreio: [...semRastreio],
    falhas: [...falhas],
    feitos,
    repasse,
  });
  const ritmo = criarRitmoExp();
  let pausaAte = 0; // 429 de qualquer trabalhador: ninguém manda nada antes disso
  // Aprendizado do limite: { cota, pausaMs } (vem de consultas anteriores, se houver)
  const aprendidoOk = (a) => a && Number.isFinite(a.cota) && a.cota >= EXP_CFG.aprenderMinimo && Number.isFinite(a.pausaMs) && a.pausaMs > 0;
  let aprendido = EXP_CFG.aprenderLimite && aprendidoOk(aprendidoInicial) ? { cota: aprendidoInicial.cota, pausaMs: Math.min(aprendidoInicial.pausaMs, EXP_CFG.pausaAprendidaMaxMs) } : null;
  let seguidasOk = 0; // consultas boas desde a última liberação/pausa
  let ultimoBom = null; // último código que respondeu com rastreio (usado como prova)
  let travouEm = 0; // quando o limite começou (0 = não está travado)
  let travouApos = 0;
  let travouAceitas = 0;
  let pausouPreventivo = false; // houve pausa preventiva desde a última trava
  // Janela: quantas consultas o sistema aceitou desde que liberou (diagnóstico)
  let janelaAceitas = 0;
  let janelaInicio = Date.now();
  // Rajada: o orçamento é o mesmo do Lote (ritmo do JMS, lá em cima)
  async function pedir(grupo) {
    contarEnvioJms();
    return pedirRastreio(tabId, token, grupo);
  }
  const respeitarRajada = () => respeitarRajadaJms(ativo, aoAguardar, aoRegistro);
  // O sistema voltou a responder: aprende quanto tempo levou para liberar e
  // depois de quantas consultas travou (usado pelos dois caminhos de "voltou").
  function liberou() {
    if (!travouEm) return;
    aoRegistro({ t: Date.now(), tipo: "janela", aceitas: travouAceitas, duracaoMs: travouEm - janelaInicio, bloqueioMs: Date.now() - travouEm });
    janelaAceitas = 0;
    janelaInicio = Date.now();
    // A consulta que acabou de passar abre uma rajada nova
    recomecarRajadaJms();
    if (!EXP_CFG.aprenderLimite) {
      travouEm = 0;
      seguidasOk = 0;
      return;
    }
    const medida = Math.min(Date.now() - travouEm, EXP_CFG.pausaAprendidaMaxMs);
    const limiteDaCota = aprendido ? Math.floor(aprendido.cota * (1 - EXP_CFG.aprenderMargem)) : 0;
    if (aprendido && pausouPreventivo && travouApos < limiteDaCota) {
      // Travou logo depois de uma pausa preventiva: a pausa foi curta
      // (o sistema não tinha "esquecido"). Mantém a cota e aumenta a pausa.
      aprendido = { cota: aprendido.cota, pausaMs: Math.min(Math.max(aprendido.pausaMs * 2, medida), EXP_CFG.pausaAprendidaMaxMs) };
      aoRegistro({ t: Date.now(), tipo: "aprendeu", cota: aprendido.cota, esperaMs: aprendido.pausaMs, motivo: "pausa curta: dobrou" });
      aoAprender({ ...aprendido });
    } else if (travouApos >= EXP_CFG.aprenderMinimo) {
      aprendido = { cota: travouApos, pausaMs: medida };
      aoRegistro({ t: Date.now(), tipo: "aprendeu", cota: aprendido.cota, esperaMs: aprendido.pausaMs });
      aoAprender({ ...aprendido });
    }
    pausouPreventivo = false;
    travouEm = 0;
    seguidasOk = 0;
  }

  async function esperar(ms, motivo) {
    const ate = Date.now() + ms;
    aoRegistro({ t: Date.now(), tipo: "pausa", motivo, esperaMs: ms, cota: aprendido ? aprendido.cota : null });
    aoAguardar(ate, motivo);
    while (ativo() && Date.now() < ate) await dormir(Math.min(1000, ate - Date.now()));
    aoAguardar(0, "");
  }

  const anotar = (codigo, c) => {
    if (c.semRastreio) semRastreio.add(codigo);
    else if (c.exp) expedidos.add(codigo);
    else outros.add(codigo);
    feitos++;
  };

  async function consultarGrupo(grupo) {
    let ultimoMotivo = EXP_MSG.generico;
    let limites = 0;
    let suspeitas = 0;
    const inicioCodigo = Date.now();
    // Pausa preventiva: perto do número que já travou antes, para pelo tempo aprendido
    if (EXP_CFG.aprenderLimite && aprendido && seguidasOk >= Math.max(1, Math.floor(aprendido.cota * (1 - EXP_CFG.aprenderMargem)))) {
      seguidasOk = 0;
      pausouPreventivo = true;
      await esperar(aprendido.pausaMs, "preventiva");
      if (!ativo()) return null;
    }
    for (let tentativa = 1; tentativa <= LOTE_CFG.tentativas; tentativa++) {
      // Espera o fim de qualquer pausa pedida pelo sistema, pega a vaga e
      // confere de novo: um 429 pode ter chegado enquanto esperava a vaga.
      for (;;) {
        const falta = pausaAte - Date.now();
        if (falta > 0) {
          while (ativo() && Date.now() < pausaAte) await dormir(Math.min(1000, pausaAte - Date.now()));
          aoAguardar(0, "");
        }
        if (!ativo()) return null;
        if (!(await respeitarRajada())) return null;
        await pegarVagaExp(() => ritmo.concorrencia);
        if (!ativo()) {
          soltarVagaExp();
          return null;
        }
        if (pausaAte <= Date.now()) break;
        soltarVagaExp();
      }
      let resposta;
      const t0 = Date.now();
      try {
        resposta = await pedir(grupo);
      } catch (e) {
        resposta = { erro: "aba" };
      } finally {
        soltarVagaExp();
      }
      if (!ativo()) return null;
      const c = classificarRespostaExp(resposta, grupo);
      aoRegistro(registroExp(grupo, resposta, c, t0));
      if (c.tipo === "ok" || c.tipo === "falha") {
        ritmo.ok();
        acordarVagasExp(); // a concorrência pode ter subido
        liberou();
        seguidasOk++;
        janelaAceitas++;
        if (c.tipo === "ok" && grupo.length === 1) {
          const v = c.porCodigo.get(grupo[0]);
          if (v && !v.semRastreio) ultimoBom = grupo[0];
        }
        return c;
      }
      if (c.tipo === "auth") {
        fatal = new ErroLote("auth", LOTE_MSG.auth);
        return null;
      }
      if (c.tipo === "fatal") {
        fatal = new ErroLote("aba", c.motivo);
        return null;
      }
      ultimoMotivo = c.motivo;
      if (c.tipo === "limite" || c.tipo === "suspeito") {
        // Limite (ou resposta que pode ser o limite): não é erro do código.
        // Espera e tenta de novo o MESMO código, sem gastar tentativa.
        ritmo.limite();
        if (!travouEm) {
          travouEm = Date.now();
          travouApos = seguidasOk;
          travouAceitas = janelaAceitas;
          // Bloqueou antes da cota: a rajada fica menor daqui pra frente
          if (c.tipo === "limite") {
            const nova = baixarCotaJms(janelaAceitas);
            if (nova != null) aoRegistro({ t: Date.now(), tipo: "cota", cota: nova, aceitas: janelaAceitas });
          }
        }
        limites++;
        if (c.tipo === "suspeito") suspeitas++;
        // Prova: resposta vazia de novo? Consulta o último código que respondeu
        // certo. Também vazio → é o limite (continua esperando, sem gastar).
        // Respondeu normal → o sistema está bem e este código não tem rastreio.
        if (c.tipo === "suspeito" && c.vazio && grupo.length === 1 && ultimoBom && ultimoBom !== grupo[0] && suspeitas >= 2) {
          await dormir(ritmo.pausa());
          if (!ativo()) return null;
          await pegarVagaExp(() => ritmo.concorrencia);
          let rp;
          const tp = Date.now();
          try {
            rp = await pedir([ultimoBom]);
          } catch (e) {
            rp = { erro: "aba" };
          } finally {
            soltarVagaExp();
          }
          if (!ativo()) return null;
          const cp = classificarRespostaExp(rp, [ultimoBom]);
          aoRegistro({ ...registroExp([ultimoBom], rp, cp, tp), prova: grupo[0] });
          if (cp.tipo === "ok") {
            // O sistema está respondendo. Confirma consultando o código de novo
            // AGORA: se a trava acabou neste meio-tempo, ele vem com rastreio.
            await dormir(ritmo.pausa());
            if (!ativo()) return null;
            await pegarVagaExp(() => ritmo.concorrencia);
            let rc;
            const tc = Date.now();
            try {
              rc = await pedir(grupo);
            } catch (e) {
              rc = { erro: "aba" };
            } finally {
              soltarVagaExp();
            }
            if (!ativo()) return null;
            const cc = classificarRespostaExp(rc, grupo);
            aoRegistro({ ...registroExp(grupo, rc, cc, tc), confirmacao: true });
            if (cc.tipo === "ok") {
              liberou();
              seguidasOk += 2; // a prova e a confirmação
              janelaAceitas += 2;
              ultimoBom = grupo[0];
              return cc;
            }
            if (cc.tipo === "suspeito" && cc.vazio) {
              aoRegistro({ t: Date.now(), tipo: "sem-rastreio", codigo: grupo[0], motivo: "o sistema respondeu outro código normal e este veio vazio de novo: não tem rastreio" });
              liberou();
              seguidasOk += 2;
              return { tipo: "ok", porCodigo: new Map([[grupo[0], { exp: false, semRastreio: true }]]), faltando: [] };
            }
          }
          suspeitas = 0; // a prova (ou a confirmação) travou: é o limite — continua esperando
        }
        const tabela = EXP_CFG.esperasLimiteMs;
        // Bloqueio: espera completar a janela desde a 1ª recusa; depois, testa
        // de novo em poucos segundos. Resposta suspeita: esperas crescentes.
        const desde = Date.now() - travouEm;
        const passo =
          c.tipo === "limite"
            ? desde < EXP_CFG.janelaMs
              ? EXP_CFG.janelaMs + EXP_CFG.janelaMargemMs - desde
              : EXP_CFG.sondaMs
            : tabela[Math.min(limites, tabela.length) - 1] || 60000;
        const pedido = c.retryAfter != null ? esperaDoRetryAfter(c.retryAfter, Math.min(limites, 5)) : 0;
        const espera = Math.max(passo, pedido);
        const estourou = Date.now() + espera - inicioCodigo > EXP_CFG.limiteTetoMs || (c.tipo === "suspeito" && suspeitas >= EXP_CFG.suspeitasMax);
        if (estourou) return { tipo: "falha", motivo: c.tipo === "suspeito" ? `sem resposta do sistema (${c.motivo})` : "o sistema não liberou a consulta" };
        pausaAte = Math.max(pausaAte, Date.now() + espera);
        aoRegistro({ t: Date.now(), tipo: "espera", motivo: c.tipo, esperaMs: espera, seguidasAntes: travouApos, tentativaNoCodigo: limites });
        aoAguardar(pausaAte, c.tipo === "limite" ? "limite" : "suspeito");
        tentativa--;
      } else {
        ritmo.instavel();
        if (tentativa < LOTE_CFG.tentativas) await dormir(esperaBackoff(tentativa));
      }
    }
    return { tipo: "falha", motivo: ultimoMotivo };
  }

  async function trabalhador(n) {
    // Os trabalhadores extras só entram quando a concorrência sobe
    while (ativo()) {
      while (n >= ritmo.concorrencia && ativo() && (fila.length || noAr.size)) await dormir(50);
      if (!ativo()) return;
      const grupo = fila.shift(); // atômico: dois trabalhadores nunca pegam o mesmo grupo
      if (grupo === undefined) {
        if (!noAr.size) return;
        await dormir(50); // outro trabalhador pode devolver códigos para a fila
        continue;
      }
      noAr.add(grupo);
      const resultado = await consultarGrupo(grupo);
      noAr.delete(grupo);
      if (resultado === null) {
        if (!fatal && !ativo()) fila.unshift(grupo); // cancelado: fica na fotografia
        return;
      }
      if (resultado.tipo === "ok") {
        resultado.porCodigo.forEach((c, codigo) => anotar(codigo, c));
        if (resultado.faltando.length) fila.unshift(...resultado.faltando.map((cod) => [cod]));
      } else if (grupo.length > 1) {
        fila.unshift(...grupo.map((cod) => [cod])); // grupo recusado: tenta cada código sozinho
      } else {
        falhas.set(grupo[0], resultado.motivo);
        feitos++;
      }
      aoProgresso(feitos, codigos.length, fotografia());
      if (fila.length) await dormir(ritmo.pausa());
    }
  }

  const max = Math.max(1, Math.floor(EXP_CFG.concorrenciaMax) || 1);
  await Promise.all(Array.from({ length: max }, (_, n) => trabalhador(n)));
  // Repasse: os que deram erro voltam para a fila sozinhos, depois de uma
  // pausa (consulta todos os pacotes sem a pessoa precisar clicar).
  while (ativo() && falhas.size && repasse < EXP_CFG.repasses) {
    repasse++;
    // Mostra a espera (antes a tela parecia travada neste minuto)
    const ateRepasse = Date.now() + EXP_CFG.repasseEsperaMs;
    aoAguardar(ateRepasse, "repasse");
    while (ativo() && Date.now() < ateRepasse) await dormir(Math.min(1000, ateRepasse - Date.now()));
    aoAguardar(0, "");
    if (!ativo()) break;
    const deNovo = [...falhas.keys()];
    falhas.clear();
    feitos -= deNovo.length;
    deNovo.forEach((cod) => fila.push([cod]));
    aoProgresso(feitos, codigos.length, fotografia());
    await Promise.all(Array.from({ length: max }, (_, n) => trabalhador(n)));
  }
  // Rede de segurança: nenhum código termina sem resposta. Se algum ficou sem
  // classificação (ex.: estava no ar quando o Chrome encerrou o segundo plano),
  // volta para a fila e é consultado agora.
  const classificado = (cod) => expedidos.has(cod) || outros.has(cod) || semRastreio.has(cod) || falhas.has(cod);
  const sumidos = ativo() ? [...new Set(codigos)].filter((cod) => !classificado(cod)) : [];
  if (sumidos.length) {
    aoRegistro({ t: Date.now(), tipo: "recuperou", n: sumidos.length, motivo: "códigos sem resposta voltaram para a fila" });
    sumidos.forEach((cod) => fila.push([cod]));
    feitos = codigos.length - sumidos.length;
    await Promise.all(Array.from({ length: max }, (_, n) => trabalhador(n)));
  }
  return { expedidos, outros, semRastreio, falhas, fatal };
}

// ---------- Consulta em segundo plano (contrato popup ↔ background.js) ----------
// O background.js roda a consulta e guarda o andamento em storage.session
// (nunca o token). O popup só mostra: progresso enquanto "rodando" e, quando
// termina, o mesmo resultado de sempre.
const FUNDO_CHAVE = { lote: "fundo_lote", exp: "fundo_exp" };
