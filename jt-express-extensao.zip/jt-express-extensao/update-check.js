// update-check.js
// Fala com o version.json hospedado no GitHub por dois motivos:
//
// 1) Aviso de nova versão — roda só UMA vez por sessão do navegador
//    (chrome.storage.session, que zera sozinho quando o navegador fecha
//    por completo).
//
// 2) Kill switch remoto (campo "permissao") — roda TODA VEZ que o popup
//    abre, porque é um controle de segurança, não um aviso informativo.
//    Se "permissao" vier como false, a extensão trava por completo.
//    O último estado conhecido fica salvo em chrome.storage.local, então:
//      - se travar remotamente e a pessoa estiver sem internet, continua
//        travada (não destrava sozinha por falta de conexão);
//      - se o campo nunca existiu ou a 1ª checagem falhar (sem internet
//        ainda, GitHub fora do ar), a extensão NÃO trava por engano —
//        só trava com um "false" explícito, alguma vez confirmado.

// ---------- Configuração — troque pelos dados do seu repositório ----------
const UPDATE_CONFIG = {
  // Raw do arquivo version.json que fica no seu repositório (branch, ex.: main)
  jsonUrl: "https://raw.githubusercontent.com/edxsnz/Chrome/main/version.json",
  // Página do repositório que abre quando a pessoa aceita atualizar
  // (não é uma Release — é só a página normal do repo, onde o .zip está)
  repoUrl: "https://github.com/edxsnz/Chrome",
};

const UPDATE_SESSION_KEY = "verificacao_atualizacao_feita";
const PERMISSAO_CACHE_KEY = "permissao_extensao";

// Compara "3.1.0" com "3.0.0" → positivo se a primeira for mais nova
function compararVersoes(a, b) {
  const pa = String(a).split(".").map(Number);
  const pb = String(b).split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const na = pa[i] || 0;
    const nb = pb[i] || 0;
    if (na !== nb) return na - nb;
  }
  return 0;
}

// Busca o version.json. Retorna null em qualquer falha (offline, GitHub
// fora do ar, URL errada, JSON inválido) — nunca lança erro pra quem chamou.
function buscarDadosRemotos() {
  return fetch(UPDATE_CONFIG.jsonUrl, { cache: "no-store" })
    .then((res) => (res.ok ? res.json() : null))
    .catch(() => null);
}

// Aceita true/false, "true"/"false" (com espaços ou maiúsculas) e 1/0,
// já que o arquivo é editado à mão no GitHub e é fácil digitar diferente.
// Retorna null se não reconhecer nada — nesse caso ninguém decide nada.
function interpretarPermissao(valor) {
  if (valor === false || valor === 0) return false;
  if (valor === true || valor === 1) return true;
  if (typeof valor === "string") {
    const normalizado = valor.trim().toLowerCase();
    if (normalizado === "false") return false;
    if (normalizado === "true") return true;
  }
  return null;
}

function mostrarBannerAtualizacao(versaoRemota) {
  const banner = document.getElementById("update-banner");
  const texto = document.getElementById("update-banner-text");
  const btnSim = document.getElementById("update-banner-yes");
  const btnNao = document.getElementById("update-banner-no");

  texto.textContent = `Nova versão disponível: v${versaoRemota}`;
  banner.classList.add("is-visible");

  btnSim.onclick = () => {
    chrome.tabs.create({ url: UPDATE_CONFIG.repoUrl });
    banner.classList.remove("is-visible");
  };
  btnNao.onclick = () => {
    banner.classList.remove("is-visible");
  };
}

function verificarAtualizacao() {
  chrome.storage.session.get(UPDATE_SESSION_KEY, (resultado) => {
    if (resultado[UPDATE_SESSION_KEY]) return; // já checou nesta sessão do navegador

    // Marca antes mesmo da resposta chegar, pra garantir 1 checagem por sessão
    chrome.storage.session.set({ [UPDATE_SESSION_KEY]: true });

    buscarDadosRemotos().then((dados) => {
      if (!dados || !dados.versao) return;
      const versaoAtual = chrome.runtime.getManifest().version;
      if (compararVersoes(dados.versao, versaoAtual) > 0) {
        mostrarBannerAtualizacao(dados.versao);
      }
    });
  });
}

// ---------- Kill switch ----------

function travarExtensao() {
  const overlay = document.getElementById("kill-switch-overlay");
  const app = document.querySelector(".app");
  overlay.classList.add("is-active");
  app.inert = true; // impede clique/foco/teclado em qualquer coisa por baixo
}

function destravarExtensao() {
  const overlay = document.getElementById("kill-switch-overlay");
  const app = document.querySelector(".app");
  overlay.classList.remove("is-active");
  app.inert = false;
}

function verificarPermissao() {
  chrome.storage.local.get(PERMISSAO_CACHE_KEY, (cache) => {
    // Aplica o último estado conhecido imediatamente, sem esperar a rede
    // (importante: se a pessoa estiver offline, mantém o estado travado).
    const permitidoConhecido = cache[PERMISSAO_CACHE_KEY];
    if (permitidoConhecido === false) travarExtensao();

    buscarDadosRemotos().then((dados) => {
      if (!dados) return; // sem internet/GitHub fora do ar — mantém o estado já aplicado, em silêncio

      const permitido = interpretarPermissao(dados.permissao);
      if (permitido === null) return; // campo ausente ou valor não reconhecido — não decide nada

      chrome.storage.local.set({ [PERMISSAO_CACHE_KEY]: permitido });
      if (permitido === false) travarExtensao();
      else destravarExtensao();
    });
  });
}

verificarPermissao();
verificarAtualizacao();
