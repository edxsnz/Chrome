// update-check.js
// Fala com o version.json hospedado no GitHub por dois motivos:
//
// 1) Aviso de nova versão — roda só UMA vez por sessão do navegador
//    (chrome.storage.session, que zera sozinho quando o navegador fecha
//    por completo).
//
// 2) Kill switch remoto (campo "permissao") — roda TODA VEZ que o popup
//    abre, porque é um controle de segurança, não um aviso informativo.
//    Se "permissao" vier como false, a extensão trava por completo.
//    O último estado conhecido fica salvo em chrome.storage.local, então:
//      - se travar remotamente e a pessoa estiver sem internet, continua
//        travada (não destrava sozinha por falta de conexão);
//      - se o campo nunca existiu ou a 1ª checagem falhar (sem internet
//        ainda, GitHub fora do ar), a extensão NÃO trava por engano —
//        só trava com um "false" explícito, alguma vez confirmado.

// ---------- Configuração — troque pelos dados do seu repositório ----------
const UPDATE_CONFIG = {
  // Raw do arquivo version.json que fica no seu repositório (branch, ex.: main)
  jsonUrl: "https://raw.githubusercontent.com/edxsnz/Chrome/main/version.json",
  // Página do repositório que abre quando a pessoa aceita atualizar
  // (não é uma Release — é só a página normal do repo, onde o .zip está)
  repoUrl: "https://github.com/edxsnz/Chrome",
};

const UPDATE_SESSION_KEY = "verificacao_atualizacao_feita";
const PERMISSAO_CACHE_KEY = "permissao_extensao";

// Compara "3.1.0" com "3.0.0" → positivo se a primeira for mais nova
function compararVersoes(a, b) {
  const pa = String(a).split(".").map(Number);
  const pb = String(b).split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const na = pa[i] || 0;
    const nb = pb[i] || 0;
    if (na !== nb) return na - nb;
  }
  return 0;
}

// Versão do version.json só vale no formato N.N.N ou N.N.N.N (aceita um "v"
// na frente). Desde 26.10.28 a versão é a data: ANO.MÊS.DIA (ex.: 26.10.28;
// 2ª versão no mesmo dia: 26.10.28.1). Zeros na frente valem ("26.09.05").
// Qualquer outra coisa ("1e3", texto, número gigante) é ignorada.
function normalizarVersaoRemota(valor) {
  if (typeof valor !== "string") return null; // objeto/número/lista: ignorado em silêncio
  const m = /^v?(\d{1,6})\.(\d{1,6})\.(\d{1,6})(?:\.(\d{1,6}))?$/i.exec(valor.trim());
  if (!m) return null;
  const partes = [m[1], m[2], m[3]].map(Number);
  if (m[4] !== undefined) partes.push(Number(m[4]));
  return partes.join(".");
}

// Para mostrar: versão-data com 2 dígitos no mês e no dia (26.9.5 → 26.09.05).
// O Chrome não aceita zero na frente no manifest, por isso só na tela.
function formatarVersao(v) {
  const p = String(v).split(".");
  if (p.length < 3 || p.length > 4 || !p.every((x) => /^\d+$/.test(x))) return String(v);
  const [ano, mes, dia] = p.map(Number);
  // só data de verdade (ano 24–99, mês 1–12, dia 1–31); versões antigas (3.x) ficam como eram
  if (ano < 24 || ano > 99 || mes < 1 || mes > 12 || dia < 1 || dia > 31) return String(v);
  const dois = (x) => String(Number(x)).padStart(2, "0");
  return [String(ano), dois(p[1]), dois(p[2]), ...(p[3] !== undefined ? [String(Number(p[3]))] : [])].join(".");
}

// Busca o version.json. Retorna null em qualquer falha (offline, GitHub
// fora do ar, URL errada, JSON inválido) — nunca lança erro pra quem chamou.
function buscarDadosRemotos() {
  return fetch(UPDATE_CONFIG.jsonUrl, { cache: "no-store" })
    .then((res) => (res.ok ? res.json() : null))
    .catch(() => null);
}

// Aceita true/false, "true"/"false" (com espaços ou maiúsculas) e 1/0,
// já que o arquivo é editado à mão no GitHub e é fácil digitar diferente.
// Retorna null se não reconhecer nada — nesse caso ninguém decide nada.
function interpretarPermissao(valor) {
  if (valor === false || valor === 0) return false;
  if (valor === true || valor === 1) return true;
  if (typeof valor === "string") {
    const normalizado = valor.trim().toLowerCase();
    if (normalizado === "false") return false;
    if (normalizado === "true") return true;
  }
  return null;
}

function mostrarBannerAtualizacao(versaoRemota) {
  const banner = document.getElementById("update-banner");
  const texto = document.getElementById("update-banner-text");
  const btnSim = document.getElementById("update-banner-yes");
  const btnNao = document.getElementById("update-banner-no");

  texto.textContent = `Nova versão disponível: v${formatarVersao(versaoRemota)}`;
  banner.classList.add("is-visible");

  btnSim.onclick = () => {
    chrome.tabs.create({ url: UPDATE_CONFIG.repoUrl });
    banner.classList.remove("is-visible");
  };
  btnNao.onclick = () => {
    banner.classList.remove("is-visible");
  };
}

function verificarAtualizacao() {
  chrome.storage.session.get(UPDATE_SESSION_KEY, (resultado) => {
    if (resultado && resultado[UPDATE_SESSION_KEY]) return; // já checou nesta sessão do navegador

    buscarDadosRemotos().then((dados) => {
      try {
        // Só uma checagem que trouxe o arquivo gasta o "1 vez por sessão":
        // offline, erro do GitHub ou JSON inválido → tenta de novo na próxima abertura.
        if (!dados || typeof dados !== "object") return;
        const marcado = chrome.storage.session.set({ [UPDATE_SESSION_KEY]: true });
        if (marcado && marcado.catch) marcado.catch(() => {}); // sessão cheia: no pior caso checa de novo
        const versaoRemota = normalizarVersaoRemota(dados.versao);
        if (!versaoRemota) return;
        const versaoAtual = chrome.runtime.getManifest().version;
        if (compararVersoes(versaoRemota, versaoAtual) > 0) {
          mostrarBannerAtualizacao(versaoRemota);
        }
      } catch (e) {
        /* dado estranho no arquivo remoto: ignora em silêncio */
      }
    });
  });
}

// ---------- Kill switch ----------

// Tudo o que fica fora de .app e ainda poderia receber foco/clique.
const PARTES_FORA_DO_APP = ["changelog-overlay", "wifi-overlay", "update-banner"];

function extensaoTravada() {
  const overlay = document.getElementById("kill-switch-overlay");
  return !!overlay && overlay.classList.contains("is-active");
}

function travarExtensao() {
  const overlay = document.getElementById("kill-switch-overlay");
  const app = document.querySelector(".app");
  overlay.classList.add("is-active");
  app.inert = true; // impede clique/foco/teclado em qualquer coisa por baixo
  PARTES_FORA_DO_APP.forEach((id) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.remove("is-open");
    el.inert = true;
  });
  // O botão que estava focado continuaria recebendo Enter/Espaço mesmo inerte
  const ativo = document.activeElement;
  if (ativo && ativo !== document.body && typeof ativo.blur === "function") ativo.blur();
}

function destravarExtensao() {
  const overlay = document.getElementById("kill-switch-overlay");
  const app = document.querySelector(".app");
  overlay.classList.remove("is-active");
  const modalAberto = document.getElementById("changelog-overlay");
  app.inert = !!modalAberto && modalAberto.classList.contains("is-open");
  PARTES_FORA_DO_APP.forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.inert = false;
  });
}

// Travada: nenhum teclado, clique ou digitação chega a quem está por baixo
// (atalhos globais de teclado também ficam de fora). Registrado antes de
// tudo e na fase de captura, então vale para qualquer ouvinte do popup.
["keydown", "keyup", "keypress", "click", "input", "beforeinput"].forEach((tipo) =>
  window.addEventListener(
    tipo,
    (e) => {
      if (!extensaoTravada()) return;
      e.preventDefault();
      e.stopImmediatePropagation();
    },
    true
  )
);

// O theme-init.js deixa a página escondida quando o cache diz que está
// travada; ela só aparece aqui, já com a tela de falha ativa (nenhum quadro
// mostra o app). Em qualquer erro de leitura, mostra o app (nunca tela vazia).
function mostrarPagina() {
  document.documentElement.style.visibility = "visible";
}

function verificarPermissao() {
  try {
    chrome.storage.local.get(PERMISSAO_CACHE_KEY, (cache) => {
      try {
        aplicarPermissaoDoCache(cache);
      } finally {
        if (document.documentElement.dataset.travaCache) mostrarPagina();
      }
    });
  } catch (e) {
    mostrarPagina();
  }
}

function aplicarPermissaoDoCache(cache) {
  {
    // Aplica o último estado conhecido imediatamente, sem esperar a rede
    // (importante: se a pessoa estiver offline, mantém o estado travado).
    const permitidoConhecido = cache && cache[PERMISSAO_CACHE_KEY];
    if (permitidoConhecido === false) travarExtensao();

    buscarDadosRemotos().then((dados) => {
      if (!dados) return; // sem internet/GitHub fora do ar — mantém o estado já aplicado, em silêncio

      const permitido = interpretarPermissao(dados.permissao);
      if (permitido === null) return; // campo ausente ou valor não reconhecido — não decide nada

      chrome.storage.local.set({ [PERMISSAO_CACHE_KEY]: permitido });
      if (permitido === false) travarExtensao();
      else destravarExtensao();
    });
  }
}

verificarPermissao();
verificarAtualizacao();
