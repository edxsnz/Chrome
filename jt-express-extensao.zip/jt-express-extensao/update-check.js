// update-check.js
// Verifica se existe uma versão mais nova publicada no GitHub, comparando
// com a versão instalada (do próprio manifest.json). A checagem só roda
// UMA vez por sessão do navegador — usa chrome.storage.session, que é
// zerado sozinho quando o navegador fecha por completo. Ou seja: abriu o
// navegador, abriu a extensão, checou; fechou/abriu só o popup de novo,
// não checa mais; fechou o navegador inteiro e abriu de novo, checa outra vez.

// ---------- Configuração — troque pelos dados do seu repositório ----------
const UPDATE_CONFIG = {
  // Raw do arquivo version.json que fica no seu repositório (branch, ex.: main)
  jsonUrl: "https://raw.githubusercontent.com/edxsnz/Chrome/main/version.json",
  // Página do repositório que abre quando a pessoa aceita atualizar
  // (não é uma Release — é só a página normal do repo, onde o .zip está)
  repoUrl: "https://github.com/edxsnz/Chrome",
};

const UPDATE_SESSION_KEY = "verificacao_atualizacao_feita";

// Compara "3.1.0" com "3.0.0" → positivo se a primeira for mais nova
function compararVersoes(a, b) {
  const pa = String(a).split(".").map(Number);
  const pb = String(b).split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const na = pa[i] || 0;
    const nb = pb[i] || 0;
    if (na !== nb) return na - nb;
  }
  return 0;
}

function mostrarBannerAtualizacao(versaoRemota) {
  const banner = document.getElementById("update-banner");
  const texto = document.getElementById("update-banner-text");
  const btnSim = document.getElementById("update-banner-yes");
  const btnNao = document.getElementById("update-banner-no");

  texto.textContent = `Nova versão disponível: v${versaoRemota}`;
  banner.classList.add("is-visible");

  btnSim.onclick = () => {
    chrome.tabs.create({ url: UPDATE_CONFIG.repoUrl });
    banner.classList.remove("is-visible");
  };
  btnNao.onclick = () => {
    banner.classList.remove("is-visible");
  };
}

function verificarAtualizacao() {
  chrome.storage.session.get(UPDATE_SESSION_KEY, (resultado) => {
    if (resultado[UPDATE_SESSION_KEY]) return; // já checou nesta sessão do navegador

    // Marca antes mesmo da resposta chegar, pra garantir 1 checagem por sessão
    chrome.storage.session.set({ [UPDATE_SESSION_KEY]: true });

    fetch(UPDATE_CONFIG.jsonUrl, { cache: "no-store" })
      .then((res) => (res.ok ? res.json() : null))
      .then((dados) => {
        if (!dados || !dados.versao) return;
        const versaoAtual = chrome.runtime.getManifest().version;
        if (compararVersoes(dados.versao, versaoAtual) > 0) {
          mostrarBannerAtualizacao(dados.versao);
        }
      })
      .catch(() => {
        // Sem internet, GitHub fora do ar, URL ainda não configurada etc.
        // Falha silenciosa — nunca atrapalha o uso normal da extensão.
      });
  });
}

verificarAtualizacao();
