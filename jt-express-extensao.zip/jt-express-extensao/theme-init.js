// theme-init.js
// Roda antes do body renderizar. Lê o tema salvo permanentemente em
// chrome.storage.local (única informação da extensão que sobrevive ao
// fechamento completo do navegador) e aplica antes de exibir a página,
// evitando o "flash" de tema claro antes do escuro carregar.

(function () {
  var THEME_KEY = "tema";

  function aplicarTema(tema) {
    document.documentElement.setAttribute("data-theme", tema === "dark" ? "dark" : "light");
    document.documentElement.style.visibility = "visible";
  }

  try {
    chrome.storage.local.get(THEME_KEY, function (resultado) {
      aplicarTema(resultado && resultado[THEME_KEY]);
    });
  } catch (e) {
    // Ambiente sem chrome.storage disponível (ex.: aberto fora da extensão)
    aplicarTema("light");
  }
})();
