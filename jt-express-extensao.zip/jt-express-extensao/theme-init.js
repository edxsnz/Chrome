// theme-init.js
// Roda antes do body renderizar. Lê o tema salvo permanentemente em
// chrome.storage.local (única informação da extensão que sobrevive ao
// fechamento completo do navegador) e aplica antes de exibir a página,
// evitando o "flash" de tema claro antes do escuro carregar.
// Se o último estado conhecido for "travado", a página continua escondida:
// quem mostra é o update-check.js, já com a tela de falha ativa — assim
// nenhum quadro pinta o app. Se algo der errado, mostra (nunca tela vazia).

(function () {
  var THEME_KEY = "tema";
  var TRAVA_KEY = "permissao_extensao";
  var raiz = document.documentElement;

  function mostrar() {
    raiz.style.visibility = "visible";
  }

  // Rede de segurança para QUALQUER caso (leitura que nunca responde, fora de
  // ordem...): em 1,5 s a página aparece — travada se o cache disse travado,
  // normal se não se sabe. Nunca fica vazia.
  setTimeout(function () {
    if (raiz.style.visibility === "visible") return;
    if (raiz.dataset.travaCache) {
      var trava = document.getElementById("kill-switch-overlay");
      var app = document.querySelector(".app");
      if (trava) trava.classList.add("is-active");
      if (app) app.inert = true;
    }
    mostrar();
  }, 1500);

  function aplicarTema(tema) {
    raiz.setAttribute("data-theme", tema === "dark" ? "dark" : "light");
  }

  try {
    chrome.storage.local.get([THEME_KEY, TRAVA_KEY], function (resultado) {
      aplicarTema(resultado && resultado[THEME_KEY]);
      if (resultado && resultado[TRAVA_KEY] === false) {
        raiz.dataset.travaCache = "1"; // quem mostra é o update-check.js, já travado
        return;
      }
      mostrar();
    });
  } catch (e) {
    // Ambiente sem chrome.storage disponível (ex.: aberto fora da extensão)
    aplicarTema("light");
    mostrar();
  }
})();
