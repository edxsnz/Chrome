@echo off
rem Lancador do "Pelo cabo" (Native Messaging). Nao escrever nada aqui: a saida e o canal com o navegador.
powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0jt-usb.ps1" %*
