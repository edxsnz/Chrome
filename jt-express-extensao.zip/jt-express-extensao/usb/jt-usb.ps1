﻿# jt-usb.ps1 — "Pelo cabo" da extensão J&T Express - Respostas Rápidas.
# Host de Native Messaging: a extensão manda um comando por vez e este script
# fala com o celular pelo adb. Manda o código ao app da J&T como um coletor
# faria (broadcast de leitor: android.intent.action.SCANRESULT, extra "value").
#
# - Só a extensão (ID fixo, no registro) consegue abrir este script.
# - Comandos fechados: status, prepararLote, bipar, contagem. Nada de texto
#   livre para o adb: os argumentos são montados aqui e o código é conferido.
# - O adb (Android Platform Tools, do Google) é baixado sozinho no 1º uso.
# - NADA pode ser escrito no console: a saída padrão é o canal com o navegador.

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$PACOTE = "com.jtexpress.brain"
$TELA_LOTE = "PackScanActivity"
$TELA_RASTREIO = "ExpressTrackingActivity"
$ACAO = "android.intent.action.SCANRESULT"
$EXTRA = "value"
$URL_ADB = "https://dl.google.com/android/repository/platform-tools-latest-windows.zip"
$BASE = if ($env:JT_USB_BASE) { $env:JT_USB_BASE } else { Join-Path $env:LOCALAPPDATA "JTRespostas" }
$RE_CODIGO = '^[0-9A-Z]{6,40}$'

$entrada = [Console]::OpenStandardInput()
$saida = [Console]::OpenStandardOutput()

# ---------- Protocolo do Native Messaging (4 bytes de tamanho + JSON UTF-8) ----------
function Ler-Exato([int]$n) {
  $buf = New-Object byte[] $n
  $lidos = 0
  while ($lidos -lt $n) {
    $r = $entrada.Read($buf, $lidos, $n - $lidos)
    if ($r -le 0) { return $null }
    $lidos += $r
  }
  return , $buf
}
function Ler-Mensagem {
  $cab = Ler-Exato 4
  if ($null -eq $cab) { return $null }
  $tam = [BitConverter]::ToInt32($cab, 0)
  if ($tam -le 0 -or $tam -gt 65536) { return $null }
  $corpo = Ler-Exato $tam
  if ($null -eq $corpo) { return $null }
  return ([Text.Encoding]::UTF8.GetString($corpo) | ConvertFrom-Json)
}
function Responder($obj) {
  $json = $obj | ConvertTo-Json -Compress -Depth 6
  $b = [Text.Encoding]::UTF8.GetBytes($json)
  $saida.Write([BitConverter]::GetBytes([int]$b.Length), 0, 4)
  $saida.Write($b, 0, $b.Length)
  $saida.Flush()
}

# ---------- adb ----------
$script:adb = $null
$script:serial = $null

function Achar-Adb {
  $locais = @(
    $env:JT_ADB,
    (Join-Path $BASE "platform-tools\adb.exe"),
    (Join-Path $env:USERPROFILE "platform-tools\adb.exe")
  )
  foreach ($l in $locais) { if ($l -and (Test-Path $l)) { return $l } }
  $cmd = Get-Command adb.exe -ErrorAction SilentlyContinue
  if ($cmd) { return $cmd.Source }
  return $null
}

function Baixar-Adb {
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  if (-not (Test-Path $BASE)) { New-Item -ItemType Directory -Force -Path $BASE | Out-Null }
  $zip = Join-Path $BASE "platform-tools.zip"
  Invoke-WebRequest -UseBasicParsing -Uri $URL_ADB -OutFile $zip -TimeoutSec 120
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $z = [IO.Compression.ZipFile]::OpenRead($zip)
  try {
    # só arquivos dentro de platform-tools/ (nada de caminho estranho)
    foreach ($e in $z.Entries) {
      if ($e.FullName -notmatch '^platform-tools/[^:]*$' -or $e.FullName -match '\.\.') { throw "zip do adb estranho" }
    }
  } finally { $z.Dispose() }
  $destino = Join-Path $BASE "platform-tools"
  if (Test-Path $destino) { Remove-Item -Recurse -Force $destino }
  [IO.Compression.ZipFile]::ExtractToDirectory($zip, $BASE)
  Remove-Item -Force $zip
  $adb = Join-Path $destino "adb.exe"
  if (-not (Test-Path $adb)) { throw "adb não veio no zip" }
  return $adb
}

# Roda o adb sem passar por shell. Devolve @{ codigo; texto }.
function Rodar-Adb([string[]]$args2, [int]$tempoMs = 15000) {
  $psi = New-Object Diagnostics.ProcessStartInfo
  $psi.FileName = $script:adb
  $todos = @()
  if ($script:serial) { $todos += @("-s", $script:serial) }
  $todos += $args2
  $psi.Arguments = ($todos | ForEach-Object { if ($_ -match '[\s"]') { '"' + ($_ -replace '"', '') + '"' } else { $_ } }) -join " "
  $psi.UseShellExecute = $false
  $psi.CreateNoWindow = $true
  $psi.RedirectStandardOutput = $true
  $psi.RedirectStandardError = $true
  $psi.RedirectStandardInput = $true
  $psi.StandardOutputEncoding = [Text.Encoding]::UTF8
  $p = [Diagnostics.Process]::Start($psi)
  $p.StandardInput.Close()
  $tOut = $p.StandardOutput.ReadToEndAsync()
  $tErr = $p.StandardError.ReadToEndAsync()
  if (-not $p.WaitForExit($tempoMs)) { try { $p.Kill() } catch {} ; return @{ codigo = -1; texto = "tempo esgotado" } }
  return @{ codigo = $p.ExitCode; texto = ($tOut.Result + $tErr.Result) }
}

function Garantir-Adb {
  if ($script:adb -and (Test-Path $script:adb)) { return $null }
  $script:adb = Achar-Adb
  if (-not $script:adb) {
    try { $script:adb = Baixar-Adb } catch { return "Não consegui baixar o adb (Android Platform Tools). Confira a internet e tente de novo." }
  }
  Rodar-Adb @("start-server") 20000 | Out-Null
  return $null
}

# Escolhe o aparelho. Devolve $null (ok) ou o motivo.
function Escolher-Aparelho {
  $r = Rodar-Adb @("devices") 10000
  $prontos = @(); $semPermissao = 0; $off = 0
  foreach ($l in ($r.texto -split "`r?`n")) {
    if ($l -match '^(\S+)\s+device$') { $prontos += $Matches[1] }
    elseif ($l -match '^\S+\s+unauthorized') { $semPermissao++ }
    elseif ($l -match '^\S+\s+offline') { $off++ }
  }
  $script:serial = $null
  if ($prontos.Count -eq 1) { $script:serial = $prontos[0]; return $null }
  if ($prontos.Count -gt 1) { return "varios" }
  if ($semPermissao) { return "nao_autorizado" }
  return "sem"
}

function Tela-Frente {
  $r = Rodar-Adb @("shell", "dumpsys activity activities | grep -m1 topResumedActivity") 10000
  $t = $r.texto
  if ($t -notmatch "topResumedActivity") {
    # tela apagada: acende e confere de novo (com senha, quem desbloqueia é a pessoa)
    Rodar-Adb @("shell", "input", "keyevent", "KEYCODE_WAKEUP") 8000 | Out-Null
    Start-Sleep -Milliseconds 700
    $t = (Rodar-Adb @("shell", "dumpsys activity activities | grep -m1 topResumedActivity") 10000).texto
    if ($t -notmatch "topResumedActivity") { return @{ app = $false; tela = "apagada" } }
  }
  $app = $t -match [regex]::Escape($PACOTE)
  $tela = "outra"
  if ($app -and $t -match $TELA_LOTE) { $tela = "lote" }
  elseif ($app -and $t -match $TELA_RASTREIO) { $tela = "rastreamento" }
  return @{ app = [bool]$app; tela = $tela }
}

# Lê a tela do app (uiautomator) direto pela saída, sem arquivo no celular.
function Ler-Tela {
  $r = Rodar-Adb @("exec-out", "uiautomator", "dump", "/dev/tty") 20000
  return $r.texto
}
function Info-Lote([string]$xml) {
  $info = @{ verificacaoOnline = $null; bounds = $null; total = $null; carregados = $null; lote = "" }
  $no = [regex]::Match($xml, '<node [^>]*resource-id="[^"]*cb_check_network"[^>]*>')
  if ($no.Success) {
    $info.verificacaoOnline = $no.Value -match 'checked="true"'
    $b = [regex]::Match($no.Value, 'bounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"')
    if ($b.Success) { $info.bounds = @([int]$b.Groups[1].Value, [int]$b.Groups[2].Value, [int]$b.Groups[3].Value, [int]$b.Groups[4].Value) }
  }
  $c = [regex]::Match($xml, 'Total (\d+) itens, (\d+) itens carregados')
  if ($c.Success) { $info.total = [int]$c.Groups[1].Value; $info.carregados = [int]$c.Groups[2].Value }
  $ed = [regex]::Matches($xml, '<node [^>]*class="android.widget.EditText"[^>]*>')
  if ($ed.Count -ge 1) {
    $t = [regex]::Match($ed[0].Value, ' text="([^"]*)"').Groups[1].Value
    if ($t -match '^[0-9A-Z]{6,40}$') { $info.lote = $t }
  }
  return $info
}

# ---------- Comandos ----------
function Cmd-Status {
  $erroAdb = Garantir-Adb
  if ($erroAdb) { return @{ ok = $false; erro = "adb"; mensagem = $erroAdb } }
  $ap = Escolher-Aparelho
  if ($ap -eq "sem") { return @{ ok = $false; erro = "sem_aparelho"; mensagem = "Celular não encontrado: ligue o cabo e a Depuração USB." } }
  if ($ap -eq "nao_autorizado") { return @{ ok = $false; erro = "nao_autorizado"; mensagem = "Aceite o aviso 'Permitir depuração USB' no celular." } }
  if ($ap -eq "varios") { return @{ ok = $false; erro = "varios"; mensagem = "Tem mais de um celular no cabo: deixe só um." } }
  $modelo = (Rodar-Adb @("shell", "getprop", "ro.product.model") 8000).texto.Trim()
  $f = Tela-Frente
  $res = @{ ok = $true; modelo = $modelo; app = $f.app; tela = $f.tela; verificacaoOnline = $null }
  if ($f.tela -eq "lote") {
    $i = Info-Lote (Ler-Tela)
    $res.verificacaoOnline = $i.verificacaoOnline
    $res.total = $i.total; $res.carregados = $i.carregados; $res.lote = $i.lote
  }
  return $res
}

function Cmd-PrepararLote {
  $st = Cmd-Status
  if (-not $st.ok) { return $st }
  if (-not $st.app) { return @{ ok = $false; erro = "sem_app"; mensagem = "Abra o app da J&T no celular." } }
  if ($st.tela -ne "lote") { return @{ ok = $false; erro = "tela"; mensagem = "Abra a Criação de lote no app." } }
  $i = Info-Lote (Ler-Tela)
  if ($i.verificacaoOnline -eq $true) {
    if (-not $i.bounds) { return @{ ok = $false; erro = "verificacao"; mensagem = "Desligue a Verificação on-line no app." } }
    $x = [int](($i.bounds[0] + $i.bounds[2]) / 2); $y = [int](($i.bounds[1] + $i.bounds[3]) / 2)
    Rodar-Adb @("shell", "input", "tap", "$x", "$y") 8000 | Out-Null
    Start-Sleep -Milliseconds 600
    $i = Info-Lote (Ler-Tela)
    if ($i.verificacaoOnline -ne $false) { return @{ ok = $false; erro = "verificacao"; mensagem = "Não consegui desligar a Verificação on-line: desligue no app." } }
    return @{ ok = $true; desligouVerificacao = $true; total = $i.total; carregados = $i.carregados; lote = $i.lote }
  }
  return @{ ok = $true; desligouVerificacao = $false; total = $i.total; carregados = $i.carregados; lote = $i.lote }
}

function Cmd-Bipar([string]$codigo) {
  $c = ("" + $codigo).Trim().ToUpper()
  if ($c -notmatch $RE_CODIGO) { return @{ ok = $false; erro = "invalido"; mensagem = "Código inválido." } }
  if (-not $script:serial) {
    $st = Cmd-Status
    if (-not $st.ok) { return $st }
  }
  $r = Rodar-Adb @("shell", "am", "broadcast", "-a", $ACAO, "--es", $EXTRA, $c) 10000
  if ($r.texto -match "Broadcast completed") { return @{ ok = $true; codigo = $c } }
  # o cabo pode ter saído: tenta achar o aparelho de novo uma vez
  $script:serial = $null
  $st = Cmd-Status
  if (-not $st.ok) { return $st }
  $r = Rodar-Adb @("shell", "am", "broadcast", "-a", $ACAO, "--es", $EXTRA, $c) 10000
  if ($r.texto -match "Broadcast completed") { return @{ ok = $true; codigo = $c } }
  return @{ ok = $false; erro = "envio"; mensagem = "O celular não recebeu o código." }
}

function Cmd-Contagem {
  if (-not $script:serial) {
    $st = Cmd-Status
    if (-not $st.ok) { return $st }
  }
  $f = Tela-Frente
  if ($f.tela -ne "lote") { return @{ ok = $true; tela = $f.tela } }
  $i = Info-Lote (Ler-Tela)
  return @{ ok = $true; tela = "lote"; total = $i.total; carregados = $i.carregados; lote = $i.lote }
}

# ---------- Laço ----------
while ($true) {
  $m = $null
  try { $m = Ler-Mensagem } catch { break }
  if ($null -eq $m) { break }
  $id = $m.id
  try {
    switch ("" + $m.cmd) {
      "status" { $r = Cmd-Status }
      "prepararLote" { $r = Cmd-PrepararLote }
      "bipar" { $r = Cmd-Bipar $m.codigo }
      "contagem" { $r = Cmd-Contagem }
      default { $r = @{ ok = $false; erro = "comando"; mensagem = "Comando desconhecido." } }
    }
  } catch {
    $r = @{ ok = $false; erro = "interno"; mensagem = "Erro no programa do cabo: " + $_.Exception.Message }
  }
  $r.id = $id
  Responder $r
}
