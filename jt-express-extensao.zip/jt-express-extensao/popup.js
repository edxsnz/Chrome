// ---------- Tema claro/escuro (chrome.storage.local — única chave que
// sobrevive ao fechamento completo do navegador; todo o resto usa
// chrome.storage.session) ----------
const THEME_STORAGE_KEY = "tema";
const themeToggleBtn = document.getElementById("theme-toggle");

function aplicarTema(tema, { salvar = true } = {}) {
  document.documentElement.setAttribute("data-theme", tema === "dark" ? "dark" : "light");
  if (salvar) chrome.storage.local.set({ [THEME_STORAGE_KEY]: tema });
}

themeToggleBtn.addEventListener("click", () => {
  const atual = document.documentElement.getAttribute("data-theme") === "dark" ? "dark" : "light";
  aplicarTema(atual === "dark" ? "light" : "dark");
});

// ---------- Navegação entre abas principais (Tickets / POD) ----------
const tabButtons = document.querySelectorAll(".tab-btn");
const tabPanels = document.querySelectorAll(".tab-panel");
const tabsIndicator = document.getElementById("tabs-indicator");

const TAB_STORAGE_KEY = "aba_ativa";

function ativarAba(nomeAba, { salvar = true } = {}) {
  const indice = [...tabButtons].findIndex((b) => b.dataset.tab === nomeAba);
  if (indice === -1) return;

  tabButtons.forEach((b) => {
    b.classList.toggle("is-active", b.dataset.tab === nomeAba);
    b.setAttribute("aria-selected", b.dataset.tab === nomeAba ? "true" : "false");
  });
  tabPanels.forEach((p) => p.classList.toggle("is-active", p.id === `panel-${nomeAba}`));
  tabsIndicator.style.transform = `translateX(${indice * 100}%)`;

  fecharTodasPrevias();

  if (salvar) chrome.storage.session.set({ [TAB_STORAGE_KEY]: nomeAba });
}

tabButtons.forEach((btn) => {
  btn.addEventListener("click", () => ativarAba(btn.dataset.tab));
});

// ---------- Navegação entre sub-abas de Tickets (Ocorrência / Endereço) ----------
const subtabButtons = document.querySelectorAll(".subtab-btn");
const subtabPanels = document.querySelectorAll(".subtab-panel");
const subtabsIndicator = document.getElementById("subtabs-indicator");

const SUBTAB_STORAGE_KEY = "subaba_ativa";

function ativarSubaba(nomeSubaba, { salvar = true } = {}) {
  const indice = [...subtabButtons].findIndex((b) => b.dataset.subtab === nomeSubaba);
  if (indice === -1) return;

  subtabButtons.forEach((b) => {
    b.classList.toggle("is-active", b.dataset.subtab === nomeSubaba);
    b.setAttribute("aria-selected", b.dataset.subtab === nomeSubaba ? "true" : "false");
  });
  subtabPanels.forEach((p) => p.classList.toggle("is-active", p.id === `subpanel-${nomeSubaba}`));
  subtabsIndicator.style.transform = `translateX(${indice * 100}%)`;

  fecharTodasPrevias();

  if (salvar) chrome.storage.session.set({ [SUBTAB_STORAGE_KEY]: nomeSubaba });
}

subtabButtons.forEach((btn) => {
  btn.addEventListener("click", (e) => {
    e.stopPropagation();
    ativarSubaba(btn.dataset.subtab);
  });
});

// ---------- Utilidades ----------

// Converte "2026-07-30 13:28:12" -> "30/07/2026 às 13:28"
function formatarData(valor) {
  if (!valor) return "";

  const match = valor
    .trim()
    .match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::\d{2})?/);

  if (!match) return valor;

  const [, ano, mes, dia, hora, minuto] = match;
  return `${dia}/${mes}/${ano} às ${hora}:${minuto}`;
}

function copiarTexto(texto, feedbackEl) {
  navigator.clipboard.writeText(texto).then(() => {
    feedbackEl.classList.add("is-visible");
    setTimeout(() => feedbackEl.classList.remove("is-visible"), 1500);
  });
}

// Remove quebras de linha reais (de texto colado), sem deixar espaço sobrando no final
function removerQuebrasDeLinha(el) {
  const valorOriginal = el.value;
  const valorLimpo = valorOriginal
    .replace(/[\r\n]+/g, " ")
    .replace(/ {2,}/g, " ")
    .replace(/ +$/, "");

  if (valorLimpo !== valorOriginal) {
    const posicaoCursor = Math.max(
      0,
      el.selectionStart - (valorOriginal.length - valorLimpo.length)
    );
    el.value = valorLimpo;
    el.setSelectionRange(posicaoCursor, posicaoCursor);
  }
}

// ---------- Telefone do cliente + WhatsApp ----------
// Cada sub-aba de Tickets (Ocorrência e Endereço incorreto) tem seu
// próprio campo de telefone, salvo junto com os demais campos daquela
// sub-aba — não existe na aba POD, por decisão do usuário.

// Extrai só os dígitos e garante o código do país (assume Brasil: 55)
function normalizarTelefone(valor) {
  const digitos = (valor || "").replace(/\D/g, "");
  if (!digitos) return "";
  if (digitos.startsWith("55") && digitos.length >= 12) return digitos;
  return `55${digitos}`;
}

function marcarTelefoneInvalido(inputTelefone) {
  inputTelefone.classList.remove("phone-invalid");
  void inputTelefone.offsetWidth; // força reflow pra animação rodar de novo
  inputTelefone.classList.add("phone-invalid");
  inputTelefone.focus();
}

// Abre o WhatsApp (Web/Desktop) já na conversa do número e copia a
// mensagem pra área de transferência — é só colar (Ctrl+V) e enviar.
// A cópia acontece ANTES de abrir a aba: abrir a aba tira o foco do
// popup (às vezes ele até fecha), e se isso acontecer no meio da cópia
// ela pode não terminar a tempo.
function abrirWhatsApp(inputTelefone, mensagem, feedbackEl) {
  const numero = normalizarTelefone(inputTelefone.value);
  if (!numero || numero.length < 12) {
    marcarTelefoneInvalido(inputTelefone);
    return;
  }
  navigator.clipboard.writeText(mensagem).then(() => {
    if (feedbackEl) {
      feedbackEl.classList.add("is-visible");
      setTimeout(() => feedbackEl.classList.remove("is-visible"), 1500);
    }
    chrome.tabs.create({ url: `https://wa.me/${numero}` });
  });
}

// ---------- SUB-ABA OCORRÊNCIA ----------
const rcNome = document.getElementById("rc-nome");
const rcTelefone = document.getElementById("rc-telefone");
const rcOrigem = document.getElementById("rc-origem");
const rcRastreio = document.getElementById("rc-rastreio");
const rcPedido = document.getElementById("rc-pedido");
const rcData = document.getElementById("rc-data");
const rcConteudo = document.getElementById("rc-conteudo");
const rcPreview = document.getElementById("rc-preview"); // guarda o texto puro (oculto)
const rcPreviewText = document.getElementById("rc-preview-text"); // exibição visual
const rcPreviewPanel = document.getElementById("rc-preview-panel");
const rcPreviewToggle = document.getElementById("rc-preview-toggle");
const rcCopyBtn = document.getElementById("rc-copy");
const rcClearBtn = document.getElementById("rc-clear");
const rcFeedback = document.getElementById("rc-feedback");
const rcWhatsappBtn = document.getElementById("rc-whatsapp");

const RC_STORAGE_KEY = "rc_campos";
const rcCampos = [rcNome, rcTelefone, rcOrigem, rcRastreio, rcPedido, rcData, rcConteudo];

chrome.storage.session.get(RC_STORAGE_KEY, (resultado) => {
  const salvos = resultado[RC_STORAGE_KEY];
  if (salvos) {
    rcNome.value = salvos.nome || "";
    rcTelefone.value = salvos.telefone || "";
    rcOrigem.value = salvos.origem || "";
    rcRastreio.value = salvos.rastreio || "";
    rcPedido.value = salvos.pedido || "";
    rcData.value = salvos.data || "";
    rcConteudo.value = salvos.conteudo || "";
  }
  atualizarPreviewReclamacao();
});

function salvarCamposReclamacao() {
  chrome.storage.session.set({
    [RC_STORAGE_KEY]: {
      nome: rcNome.value,
      telefone: rcTelefone.value,
      origem: rcOrigem.value,
      rastreio: rcRastreio.value,
      pedido: rcPedido.value,
      data: rcData.value,
      conteudo: rcConteudo.value,
    },
  });
}

function montarMensagemReclamacao() {
  const nome = rcNome.value.trim() || "(Nome)";
  const origem = rcOrigem.value.trim() || "(Origem)";
  const rastreio = rcRastreio.value.trim() || "(Rastreio)";
  const pedido = rcPedido.value.trim() || "(N° pedido)";
  const dataFormatada = formatarData(rcData.value) || "(Data)";
  const conteudo = rcConteudo.value.trim() || "(Conteúdo)";

  return `Olá ${nome}, tudo bem com você?
Me chamo Carla falo em nome da J&T Express, prestadora de serviços de transportes da ${origem}.
Verificamos que você abriu uma reclamação referente ao Pedido:

Código: ${rastreio} Pedido: ${pedido}
Loja: ${origem}
Item: ${conteudo}
Entregue ${dataFormatada}.
Para que possamos te auxiliar, escolha uma opção:

1 - Recebi o produto
2 - Não recebi o produto
3 - Recebi o pacote com produtos faltantes
4 - Recebi o produto com defeito
5 - Recebi um produto diferente do comprado
6 - Recebi o produto danificado

Atenciosamente,
J&T Express \u{1F69A}`;
}

function atualizarPreviewReclamacao() {
  const texto = montarMensagemReclamacao();
  rcPreview.value = texto;
  rcPreviewText.textContent = texto;
}

rcConteudo.addEventListener("keydown", (e) => {
  if (e.key === "Enter") e.preventDefault();
});

rcConteudo.addEventListener("input", () => removerQuebrasDeLinha(rcConteudo));

rcTelefone.addEventListener("input", () => rcTelefone.classList.remove("phone-invalid"));

rcCampos.forEach((el) =>
  el.addEventListener("input", () => {
    atualizarPreviewReclamacao();
    salvarCamposReclamacao();
  })
);

rcCopyBtn.addEventListener("click", () => {
  atualizarPreviewReclamacao();
  copiarTexto(rcPreview.value, rcFeedback);
});

rcWhatsappBtn.addEventListener("click", () => {
  atualizarPreviewReclamacao();
  abrirWhatsApp(rcTelefone, rcPreview.value, rcFeedback);
});

rcClearBtn.addEventListener("click", () => {
  rcCampos.forEach((el) => (el.value = ""));
  atualizarPreviewReclamacao();
  chrome.storage.session.remove(RC_STORAGE_KEY);
  fecharTodasPrevias();
});

function abrirPreviaReclamacao() {
  atualizarPreviewReclamacao();
  rcPreviewPanel.classList.add("is-open");
  rcPreviewToggle.classList.add("is-active");
}

rcPreviewToggle.addEventListener("click", (e) => {
  e.stopPropagation();
  const estaAberta = rcPreviewPanel.classList.contains("is-open");
  estaAberta ? fecharTodasPrevias() : abrirPreviaReclamacao();
});

// ---------- SUB-ABA ENDEREÇO INCORRETO ----------
const enRastreio = document.getElementById("en-rastreio");
const enTelefone = document.getElementById("en-telefone");
const enOrigem = document.getElementById("en-origem");
const enConteudo = document.getElementById("en-conteudo");
const enPreview = document.getElementById("en-preview");
const enPreviewText = document.getElementById("en-preview-text");
const enPreviewPanel = document.getElementById("en-preview-panel");
const enPreviewToggle = document.getElementById("en-preview-toggle");
const enCopyBtn = document.getElementById("en-copy");
const enClearBtn = document.getElementById("en-clear");
const enFeedback = document.getElementById("en-feedback");
const enWhatsappBtn = document.getElementById("en-whatsapp");

const EN_STORAGE_KEY = "en_campos";
const enCampos = [enTelefone, enRastreio, enOrigem, enConteudo];

chrome.storage.session.get(EN_STORAGE_KEY, (resultado) => {
  const salvos = resultado[EN_STORAGE_KEY];
  if (salvos) {
    enTelefone.value = salvos.telefone || "";
    enRastreio.value = salvos.rastreio || "";
    enOrigem.value = salvos.origem || "";
    enConteudo.value = salvos.conteudo || "";
  }
  atualizarPreviewEndereco();
});

function salvarCamposEndereco() {
  chrome.storage.session.set({
    [EN_STORAGE_KEY]: {
      telefone: enTelefone.value,
      rastreio: enRastreio.value,
      origem: enOrigem.value,
      conteudo: enConteudo.value,
    },
  });
}

function montarMensagemEndereco() {
  const rastreio = enRastreio.value.trim() || "(Rastreio)";
  const origem = enOrigem.value.trim() || "(Origem)";
  const conteudo = enConteudo.value.trim() || "(Conteúdo)";

  return `Olá!

Segue as informações do seu pedido:

\u{1F4E6} Código do pacote: ${rastreio}
\u{1F3EA} Loja: ${origem}
\u{1F4E6} Produto: ${conteudo}

Verificamos que foi realizada uma tentativa de entrega no seu endereço, porém não foi possível concluir a entrega, pois o endereço se encontra incorreto.

Pedimos, por gentileza, que nos informe o endereço correto para prosseguirmos com a entrega.

Agradecemos pela compreensão.`;
}

function atualizarPreviewEndereco() {
  const texto = montarMensagemEndereco();
  enPreview.value = texto;
  enPreviewText.textContent = texto;
}

enConteudo.addEventListener("keydown", (e) => {
  if (e.key === "Enter") e.preventDefault();
});

enConteudo.addEventListener("input", () => removerQuebrasDeLinha(enConteudo));

enTelefone.addEventListener("input", () => enTelefone.classList.remove("phone-invalid"));

enCampos.forEach((el) =>
  el.addEventListener("input", () => {
    atualizarPreviewEndereco();
    salvarCamposEndereco();
  })
);

enCopyBtn.addEventListener("click", () => {
  atualizarPreviewEndereco();
  copiarTexto(enPreview.value, enFeedback);
});

enWhatsappBtn.addEventListener("click", () => {
  atualizarPreviewEndereco();
  abrirWhatsApp(enTelefone, enPreview.value, enFeedback);
});

enClearBtn.addEventListener("click", () => {
  enCampos.forEach((el) => (el.value = ""));
  atualizarPreviewEndereco();
  chrome.storage.session.remove(EN_STORAGE_KEY);
  fecharTodasPrevias();
});

function abrirPreviaEndereco() {
  atualizarPreviewEndereco();
  enPreviewPanel.classList.add("is-open");
  enPreviewToggle.classList.add("is-active");
}

enPreviewToggle.addEventListener("click", (e) => {
  e.stopPropagation();
  const estaAberta = enPreviewPanel.classList.contains("is-open");
  estaAberta ? fecharTodasPrevias() : abrirPreviaEndereco();
});

// ---- Fecha qualquer prévia aberta (clique fora, troca de aba/sub-aba) ----
function fecharTodasPrevias() {
  rcPreviewPanel.classList.remove("is-open");
  rcPreviewToggle.classList.remove("is-active");
  enPreviewPanel.classList.remove("is-open");
  enPreviewToggle.classList.remove("is-active");
}

document.addEventListener("click", fecharTodasPrevias);

// Restaura a última aba/sub-aba usadas nesta sessão do navegador
chrome.storage.session.get([TAB_STORAGE_KEY, SUBTAB_STORAGE_KEY], (resultado) => {
  const abaSalva = resultado[TAB_STORAGE_KEY];
  const subabaSalva = resultado[SUBTAB_STORAGE_KEY];
  if (abaSalva) ativarAba(abaSalva, { salvar: false });
  if (subabaSalva) ativarSubaba(subabaSalva, { salvar: false });
});

// ---------- ABA POD ----------
const podNome = document.getElementById("pod-nome");
const podPreviewText = document.getElementById("pod-preview-text");
const podCopyBtn = document.getElementById("pod-copy");
const podFeedback = document.getElementById("pod-feedback");

const POD_STORAGE_KEY = "pod_campos";

chrome.storage.session.get(POD_STORAGE_KEY, (resultado) => {
  const salvos = resultado[POD_STORAGE_KEY];
  if (salvos && salvos.nome) podNome.value = salvos.nome;
  atualizarPreviewPod();
});

function montarMensagemPod() {
  const nome = podNome.value.trim() || "(Nome)";
  return `POD CORRETO, Parabéns ${nome} continue assim \u{1F44F}\u{1F3FB}\u{1F44F}\u{1F3FB}`;
}

function atualizarPreviewPod() {
  podPreviewText.textContent = montarMensagemPod();
}

podNome.addEventListener("input", () => {
  atualizarPreviewPod();
  chrome.storage.session.set({ [POD_STORAGE_KEY]: { nome: podNome.value } });
});

podCopyBtn.addEventListener("click", () => {
  copiarTexto(montarMensagemPod(), podFeedback);
});

atualizarPreviewPod();

// ---------- Changelog ----------
const changelogBtn = document.getElementById("changelog-btn");
const changelogOverlay = document.getElementById("changelog-overlay");
const changelogClose = document.getElementById("changelog-close");
const changelogBody = document.getElementById("changelog-body");

function renderizarChangelog() {
  changelogBody.innerHTML = "";

  CHANGELOG.forEach((entrada, indice) => {
    const bloco = document.createElement("div");
    bloco.className = "changelog-entry";

    const head = document.createElement("div");
    head.className = "changelog-entry-head";

    const versao = document.createElement("span");
    versao.className = "changelog-version";
    versao.textContent = `v${entrada.versao}`;
    head.appendChild(versao);

    if (indice === 0) {
      const badge = document.createElement("span");
      badge.className = "changelog-current-badge";
      badge.textContent = "atual";
      head.appendChild(badge);
    }

    const data = document.createElement("span");
    data.className = "changelog-date";
    data.textContent = entrada.data;
    head.appendChild(data);

    const titulo = document.createElement("div");
    titulo.className = "changelog-title";
    titulo.textContent = entrada.titulo;

    const lista = document.createElement("ul");
    lista.className = "changelog-list";
    entrada.itens.forEach((item) => {
      const li = document.createElement("li");
      li.textContent = item;
      lista.appendChild(li);
    });

    bloco.appendChild(head);
    bloco.appendChild(titulo);
    bloco.appendChild(lista);
    changelogBody.appendChild(bloco);

    if (indice < CHANGELOG.length - 1) {
      changelogBody.appendChild(document.createElement("hr")).className = "changelog-divider";
    }
  });
}

function abrirChangelog() {
  renderizarChangelog();
  changelogOverlay.classList.add("is-open");
}

function fecharChangelog() {
  changelogOverlay.classList.remove("is-open");
}

changelogBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  abrirChangelog();
});

changelogClose.addEventListener("click", (e) => {
  e.stopPropagation();
  fecharChangelog();
});

changelogOverlay.addEventListener("click", (e) => {
  if (e.target === changelogOverlay) fecharChangelog();
});
