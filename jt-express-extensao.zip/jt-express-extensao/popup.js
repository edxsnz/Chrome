// ---------- Tema claro/escuro (chrome.storage.local — única chave que
// sobrevive ao fechamento completo do navegador; todo o resto usa
// chrome.storage.session) ----------
const THEME_STORAGE_KEY = "tema";
const themeToggleBtn = document.getElementById("theme-toggle");

function aplicarTema(tema, { salvar = true } = {}) {
  document.documentElement.setAttribute("data-theme", tema === "dark" ? "dark" : "light");
  if (salvar) chrome.storage.local.set({ [THEME_STORAGE_KEY]: tema });
}

themeToggleBtn.addEventListener("click", () => {
  const atual = document.documentElement.getAttribute("data-theme") === "dark" ? "dark" : "light";
  aplicarTema(atual === "dark" ? "light" : "dark");
});

// Versão no topo (vem do manifest, então nunca fica desatualizada)
const appVersao = document.getElementById("app-versao");
if (appVersao) appVersao.textContent = `v${typeof formatarVersao === "function" ? formatarVersao(chrome.runtime.getManifest().version) : chrome.runtime.getManifest().version}`;

// ---------- Navegação entre abas principais (Tickets / Código / Lote / Expedido) ----------
const tabButtons = document.querySelectorAll(".tab-btn");
const tabPanels = document.querySelectorAll(".tab-panel");

const tabsIndicator = document.getElementById("tabs-indicator");

const TAB_STORAGE_KEY = "aba_ativa";

function ativarAba(nomeAba, { salvar = true } = {}) {
  const indice = [...tabButtons].findIndex((b) => b.dataset.tab === nomeAba);
  if (indice === -1) return;

  tabButtons.forEach((b) => {
    b.classList.toggle("is-active", b.dataset.tab === nomeAba);
    b.setAttribute("aria-selected", b.dataset.tab === nomeAba ? "true" : "false");
  });
  tabPanels.forEach((p) => p.classList.toggle("is-active", p.id === `panel-${nomeAba}`));
  tabsIndicator.style.transform = `translateX(${indice * 100}%)`;

  fecharTodasPrevias();
  esconderDesfazer(); // o "Desfazer" é da aba que ficou para trás
  aoAbrirAbaFundo(nomeAba); // resultado de consulta esperando nesta aba: visto

  if (salvar) gravarSessao({ [TAB_STORAGE_KEY]: nomeAba });
}

// Clicou numa aba antes de a última aba usada ser restaurada? A escolha vence.
const navCarga = { aba: false, subaba: false };

tabButtons.forEach((btn, i) => {
  btn.addEventListener("click", () => {
    navCarga.aba = true;
    ativarAba(btn.dataset.tab);
  });
  btn.title = `${btn.textContent.trim()} (Alt+${i + 1})`;
});

// Alt+1…4 troca de aba sem tirar a mão do teclado (funciona até dentro dos campos)
document.addEventListener("keydown", (e) => {
  if (!e.altKey || e.ctrlKey || e.metaKey || e.shiftKey || interfaceBloqueada()) return;
  const m = /^Digit([1-9])$/.exec(e.code || "");
  const btn = m && tabButtons[Number(m[1]) - 1];
  if (!btn) return;
  e.preventDefault();
  navCarga.aba = true;
  ativarAba(btn.dataset.tab);
});

// ---------- Navegação entre sub-abas de Tickets (Ocorrência / Endereço) ----------
const subtabButtons = document.querySelectorAll(".subtab-btn");
const subtabPanels = document.querySelectorAll(".subtab-panel");
const subtabsIndicator = document.getElementById("subtabs-indicator");

const SUBTAB_STORAGE_KEY = "subaba_ativa";

function ativarSubaba(nomeSubaba, { salvar = true } = {}) {
  const indice = [...subtabButtons].findIndex((b) => b.dataset.subtab === nomeSubaba);
  if (indice === -1) return;

  subtabButtons.forEach((b) => {
    b.classList.toggle("is-active", b.dataset.subtab === nomeSubaba);
    b.setAttribute("aria-selected", b.dataset.subtab === nomeSubaba ? "true" : "false");
  });
  subtabPanels.forEach((p) => p.classList.toggle("is-active", p.id === `subpanel-${nomeSubaba}`));
  // Sub-abas com larguras proporcionais (data-peso): o traço acompanha a ativa
  const pesos = [...subtabButtons].map((b) => Number(b.dataset.peso) || 1);
  const total = pesos.reduce((a, b) => a + b, 0);
  const antes = pesos.slice(0, indice).reduce((a, b) => a + b, 0);
  subtabsIndicator.style.left = `${(antes / total) * 100}%`;
  subtabsIndicator.style.width = `${(pesos[indice] / total) * 100}%`;
  if (nomeSubaba === "guia") abrirGuia();

  fecharTodasPrevias();

  if (salvar) gravarSessao({ [SUBTAB_STORAGE_KEY]: nomeSubaba });
}

subtabButtons.forEach((btn) => {
  btn.addEventListener("click", (e) => {
    e.stopPropagation();
    navCarga.subaba = true;
    ativarSubaba(btn.dataset.subtab);
  });
});

// ---------- Utilidades ----------

// Caracteres invisíveis que vêm junto ao copiar de páginas/planilhas/Outlook/
// Teams: toda a categoria Cf (espaço de largura zero, BOM, hífen suave, marcas
// de direção LRM/RLM, controles bidi U+202A–202E e U+2066–2069, U+061C, U+180E,
// tags...), os seletores de variação (U+FE00–FE0F, U+E0100–E01EF), o grafema
// vazio U+034F e os preenchimentos Hangul. Não aparecem na tela, mas mudariam o
// código de barras: são sempre tirados antes de usar um código. Espaços
// visíveis ou não (categoria Zs, NBSP...) continuam valendo como separador.
const INVISIVEIS = /[\p{Cf}\u034F\u115F\u1160\u180E\u3164\uFFA0\uFE00-\uFE0F\u{E0100}-\u{E01EF}]/gu;
function limparInvisiveis(texto) {
  return String(texto == null ? "" : texto).replace(INVISIVEIS, "");
}

// Aspas e apóstrofos nas pontas vêm de CSV/Excel ("888...", '888...): saem.
const ASPAS_NAS_PONTAS = /^["'\u201C\u201D\u2018\u2019]+|["'\u201C\u201D\u2018\u2019]+$/g;
function tirarAspas(trecho) {
  return trecho.replace(ASPAS_NAS_PONTAS, "");
}

// Modal de Novidades aberto ou extensão travada: atalhos de teclado do que
// está por trás não fazem nada.
function interfaceBloqueada() {
  const modal = document.getElementById("changelog-overlay");
  const trava = document.getElementById("kill-switch-overlay");
  return (!!modal && modal.classList.contains("is-open")) || (!!trava && trava.classList.contains("is-active"));
}

// Grava na sessão sem deixar promessa rejeitada solta (ex.: cota de 10 MB
// estourada). aoFalhar recebe o erro, se quiser avisar a pessoa.
function gravarSessao(dados, aoFalhar) {
  let p;
  try {
    p = chrome.storage.session.set(dados);
  } catch (e) {
    if (aoFalhar) aoFalhar(e);
    return;
  }
  if (p && typeof p.catch === "function") p.catch((e) => aoFalhar && aoFalhar(e));
}

// Converte "2026-07-30 13:28:12" -> "30/07/2026 às 13:28"
function formatarData(valor) {
  if (!valor) return "";

  const match = valor
    .trim()
    .match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::\d{2})?/);

  if (!match) return valor.trim(); // texto livre ("ontem às 14h") sai sem espaços sobrando

  const [, ano, mes, dia, hora, minuto] = match;
  return `${dia}/${mes}/${ano} às ${hora}:${minuto}`;
}

// ---------- Avisos curtos abaixo dos botões ----------
// Um único timer por elemento: cliques seguidos não deixam um timer antigo
// esconder o aviso novo antes da hora nem trocar o texto pelo errado.
// O texto padrão ("Mensagem copiada"...) fica guardado desde o início.
document.querySelectorAll(".copy-feedback").forEach((el) => {
  el.dataset.textoOriginal = el.textContent;
});

function mostrarFeedback(el, { texto = null, erro = false, ms = 1500 } = {}) {
  clearTimeout(el._timerFeedback);
  el.textContent = texto === null ? el.dataset.textoOriginal : texto;
  el.classList.toggle("is-erro", erro);
  el.classList.add("is-visible");
  el._timerFeedback = setTimeout(() => esconderFeedback(el), ms);
}

function esconderFeedback(el) {
  clearTimeout(el._timerFeedback);
  el.classList.remove("is-visible", "is-erro");
  el.textContent = el.dataset.textoOriginal;
}

// ---------- Listas grandes sem travar a digitação ----------
// Reanalisar e salvar uma lista de milhares de códigos a cada tecla levava
// ~120 ms por tecla. Lista pequena: faz na hora (como sempre). Lista grande:
// espera a pessoa parar de digitar um instante. Fechar a janela continua
// salvando o que estiver no campo (pagehide/visibilidade).
const LISTA_GRANDE_CARACTERES = 20000; // ~1.200 códigos
function quandoParar(campo, fn, ms = 250) {
  let timer = null;
  return () => {
    clearTimeout(timer);
    if (campo.value.length < LISTA_GRANDE_CARACTERES) fn();
    else timer = setTimeout(fn, ms);
  };
}

// ---------- Desfazer a lixeira ----------
// Apagar sem querer uma lista de centenas de códigos custava refazer tudo.
// Depois de limpar, um aviso no rodapé oferece "Desfazer" por alguns
// segundos: os campos voltam como estavam (e são salvos de novo, como se a
// pessoa tivesse digitado).
const desfazerAviso = document.createElement("div");
desfazerAviso.className = "desfazer-aviso";
desfazerAviso.setAttribute("role", "status");
const desfazerTexto = document.createElement("span");
const desfazerBtn = document.createElement("button");
desfazerBtn.type = "button";
desfazerBtn.className = "desfazer-btn";
desfazerBtn.textContent = "Desfazer";
desfazerAviso.append(desfazerTexto, desfazerBtn);
document.body.append(desfazerAviso);
let desfazerAcao = null;
let desfazerTimer = null;

function esconderDesfazer() {
  clearTimeout(desfazerTimer);
  desfazerAcao = null;
  desfazerAviso.classList.remove("is-visible");
}

// campos: lista de inputs/textarea/checkbox. Guarda o conteúdo de agora.
function fotografarCampos(campos) {
  return campos.map((el) => [el, el.type === "checkbox" ? el.checked : el.value]);
}

function oferecerDesfazer(foto, texto = "Campos limpos") {
  const tinhaAlgo = foto.some(([el, v]) => (el.type === "checkbox" ? v : String(v).trim() !== ""));
  if (!tinhaAlgo) return;
  clearTimeout(desfazerTimer);
  desfazerTexto.textContent = texto;
  desfazerAcao = () => {
    foto.forEach(([el, v]) => {
      if (el.type === "checkbox") {
        el.checked = v;
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } else {
        el.value = v;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      }
    });
  };
  desfazerAviso.classList.add("is-visible");
  desfazerTimer = setTimeout(esconderDesfazer, 7000);
}

desfazerBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  const acao = desfazerAcao;
  esconderDesfazer();
  if (acao) acao();
});

// ---------- Restaurar sem atropelar ----------
// Os dados salvos chegam do armazenamento um instante depois de o popup abrir.
// Se a pessoa já digitou ou colou algo nesse intervalo, o que ela fez vence:
// aquele campo não é sobrescrito, e nada é salvo por cima (o que apagaria os
// outros campos guardados) antes de a restauração terminar.
function criarCarga(campos) {
  const tocados = new Set();
  let pronto = false;
  campos.forEach((el) => {
    const marcar = () => {
      if (!pronto) tocados.add(el);
    };
    el.addEventListener("input", marcar);
    el.addEventListener("change", marcar);
  });
  return {
    get pronto() {
      return pronto;
    },
    livre: (chave) => !tocados.has(chave),
    marcar: (chave) => {
      if (!pronto) tocados.add(chave);
    },
    // Termina a carga; devolve true se algo foi mexido antes (aí vale salvar)
    concluir() {
      pronto = true;
      return tocados.size > 0;
    },
  };
}

// textoOk: aviso no lugar do "copiada" (ex.: o lembrete do Meli), por mais tempo
function copiarTexto(texto, feedbackEl, textoOk = null) {
  navigator.clipboard.writeText(texto).then(
    () => mostrarFeedback(feedbackEl, textoOk ? { texto: textoOk, ms: 3200 } : {}),
    // Falha ao copiar (ex.: permissão negada): avisa em vez de parecer que nada aconteceu
    () => mostrarFeedback(feedbackEl, { texto: "Não foi possível copiar", erro: true, ms: 2200 })
  );
}

// Mostra a mensagem como o WhatsApp vai exibir: *texto* vira negrito e os
// asteriscos somem. Monta tudo com nós de texto (nunca HTML), então nada que
// for digitado nos campos vira código na página.
function renderizarComoWhatsApp(destino, texto) {
  destino.textContent = "";
  const negrito = /\*(\S(?:[^*\n]*?\S)?)\*/g;
  let ultimo = 0;
  for (const m of texto.matchAll(negrito)) {
    if (m.index > ultimo) destino.append(texto.slice(ultimo, m.index));
    const forte = document.createElement("strong");
    forte.textContent = m[1];
    destino.append(forte);
    ultimo = m.index + m[0].length;
  }
  if (ultimo < texto.length) destino.append(texto.slice(ultimo));
}

// Remove quebras de linha reais (de texto colado), sem deixar espaço sobrando no final
function removerQuebrasDeLinha(el) {
  const valorOriginal = el.value;
  const valorLimpo = valorOriginal
    .replace(/[\r\n]+/g, " ")
    .replace(/ {2,}/g, " ")
    .replace(/ +$/, "");

  if (valorLimpo !== valorOriginal) {
    const posicaoCursor = Math.max(
      0,
      el.selectionStart - (valorOriginal.length - valorLimpo.length)
    );
    el.value = valorLimpo;
    el.setSelectionRange(posicaoCursor, posicaoCursor);
  }
}

// ---------- Telefone do cliente + WhatsApp ----------
// Cada sub-aba de Tickets (Ocorrência e Endereço incorreto) tem seu
// próprio campo de telefone, salvo junto com os demais campos daquela
// sub-aba.

// Extrai só os dígitos e garante o código do país (assume Brasil: 55).
// O 0 de discagem antes do DDD ("(011) 9...") é descartado.
// Com "+" ou "00" na frente, o código do país é explícito: só Brasil (55)
// vale; depois do 55, o 0/0xx de discagem também é descartado.
function telefoneInternacional(valor) {
  const texto = String(valor || "").trim();
  return texto.startsWith("+") || texto.replace(/\D/g, "").startsWith("00");
}

function telefoneEstrangeiro(valor) {
  const digitos = String(valor || "").replace(/\D/g, "").replace(/^0+/, "");
  return telefoneInternacional(valor) && !!digitos && !digitos.startsWith("55");
}

function normalizarTelefone(valor) {
  if (telefoneInternacional(valor)) {
    const digitos = String(valor).replace(/\D/g, "").replace(/^0+/, "");
    if (!digitos.startsWith("55")) return ""; // outro país
    const nacional = digitos.slice(2).replace(/^0+/, "");
    return nacional ? `55${nacional}` : "";
  }
  const digitos = (valor || "").replace(/\D/g, "").replace(/^0+/, "");
  if (!digitos) return "";
  if (digitos.startsWith("55") && digitos.length >= 12) return digitos;
  return `55${digitos}`;
}

// Celular (13) ou fixo (12) com o 55. Mais que isso costuma ser dois números
// colados juntos — abriria a conversa de um número que não existe.
// DDD de 11 a 99 (sem 0); celular (11 dígitos) começa com 9 depois do DDD,
// fixo (10 dígitos) com 2 a 8.
function telefoneValido(valor) {
  const n = normalizarTelefone(valor);
  if (n.length !== 12 && n.length !== 13) return false;
  const nacional = n.slice(2);
  if (!/^[1-9][1-9]/.test(nacional)) return false;
  return nacional.length === 11 ? nacional[2] === "9" : /[2-8]/.test(nacional[2]);
}

function marcarTelefoneInvalido(inputTelefone) {
  inputTelefone.classList.remove("phone-invalid");
  void inputTelefone.offsetWidth; // força reflow pra animação rodar de novo
  inputTelefone.classList.add("phone-invalid");
  inputTelefone.focus();
}

// Abre o WhatsApp (Web/Desktop) já na conversa do número e copia a
// mensagem pra área de transferência — é só colar (Ctrl+V) e enviar.
// A cópia acontece ANTES de abrir a aba: abrir a aba tira o foco do
// popup (às vezes ele até fecha), e se isso acontecer no meio da cópia
// ela pode não terminar a tempo.
function abrirWhatsApp(inputTelefone, mensagem, feedbackEl, textoOk = null) {
  const numero = normalizarTelefone(inputTelefone.value);
  if (!telefoneValido(inputTelefone.value)) {
    marcarTelefoneInvalido(inputTelefone);
    mostrarFeedback(feedbackEl, {
      texto: telefoneEstrangeiro(inputTelefone.value)
        ? "Só telefones do Brasil (+55): esse número é de outro país."
        : "Telefone inválido: confira o DDD e o número.",
      erro: true,
      ms: 2600,
    });
    return;
  }
  // Clique duplo (ou clique enquanto a cópia termina) não abre duas conversas
  if (inputTelefone._abrindoWhatsApp) return;
  inputTelefone._abrindoWhatsApp = true;
  setTimeout(() => {
    inputTelefone._abrindoWhatsApp = false;
  }, 1200);

  navigator.clipboard.writeText(mensagem).then(
    () => {
      mostrarFeedback(feedbackEl, textoOk ? { texto: textoOk, ms: 3200 } : {});
      chrome.tabs.create({ url: `https://wa.me/${numero}` });
    },
    () => {
      // Mesmo sem conseguir copiar, ainda vale abrir a conversa — a
      // pessoa consegue usar o botão Copiar manualmente depois.
      mostrarFeedback(feedbackEl, { texto: "Não copiou — abrindo mesmo assim", erro: true, ms: 2200 });
      chrome.tabs.create({ url: `https://wa.me/${numero}` });
    }
  );
}

// ---------- SUB-ABA OCORRÊNCIA ----------
// Cada embarcador tem o seu script de acareação (Manual de Scripts de
// Acareação, SAC Regional MG, out/2026). A extensão reconhece o embarcador
// pelo que está escrito em "Origem" e troca os campos e o texto sozinha.
// Os textos seguem o manual com os erros dele corrigidos (artigo sobrando
// em "Olá, a ...", frases emendadas, concordância, pontuação irregular nas
// opções e quebra de linha acidental) e com o mesmo espaçamento entre blocos.
const rcNome = document.getElementById("rc-nome");
const rcLinhaTelefone = document.getElementById("rc-linha-telefone");
const rcLinhaRastreio = document.getElementById("rc-linha-rastreio");
const rcConteudoField = document.getElementById("rc-conteudo-field");
const rcTelefone = document.getElementById("rc-telefone");
const rcSeuNomeField = document.getElementById("rc-seu-nome-field");
const rcSeuNome = document.getElementById("rc-seu-nome");
const rcOrigem = document.getElementById("rc-origem");
const rcEmbarcadorTag = document.getElementById("rc-embarcador");
const rcRastreio = document.getElementById("rc-rastreio");
const rcPedidoField = document.getElementById("rc-pedido-field");
const rcPedidoLabel = document.getElementById("rc-pedido-label");
const rcPedido = document.getElementById("rc-pedido");
const rcLinhaExtra = document.getElementById("rc-linha-extra");
const rcDataField = document.getElementById("rc-data-field");
const rcData = document.getElementById("rc-data");
const rcRastreioClienteField = document.getElementById("rc-rastreio-cliente-field");
const rcRastreioClienteLabel = document.getElementById("rc-rastreio-cliente-label");
const rcRastreioCliente = document.getElementById("rc-rastreio-cliente");
const rcNfField = document.getElementById("rc-nf-field");
const rcNf = document.getElementById("rc-nf");
const rcNfHint = document.getElementById("rc-nf-hint");
const rcMotorolaField = document.getElementById("rc-motorola-field");
const rcMotorola = document.getElementById("rc-motorola");
const rcBloqueio = document.getElementById("rc-bloqueio");
const rcConteudo = document.getElementById("rc-conteudo");
const rcPreview = document.getElementById("rc-preview"); // guarda o texto puro (oculto)
const rcPreviewText = document.getElementById("rc-preview-text"); // exibição visual
const rcPreviewPanel = document.getElementById("rc-preview-panel");
const rcPreviewToggle = document.getElementById("rc-preview-toggle");
const rcCopyBtn = document.getElementById("rc-copy");
const rcClearBtn = document.getElementById("rc-clear");
const rcFeedback = document.getElementById("rc-feedback");
const rcWhatsappBtn = document.getElementById("rc-whatsapp");

const RC_STORAGE_KEY = "rc_campos";
// "Seu nome" é preferência de quem atende: fica salvo mesmo fechando o
// navegador (chrome.storage.local), diferente dos dados do cliente.
const SEU_NOME_KEY = "seu_nome";
const rcCampos = [rcNome, rcTelefone, rcOrigem, rcRastreio, rcPedido, rcData, rcRastreioCliente, rcNf, rcConteudo];

// Textos dos scripts (OPCOES_*, montarScript, EMBARCADORES, EMBARCADOR_PADRAO,
// MOTOROLA): ficam em mensagens.js, carregado antes deste arquivo.

function normalizarOrigem(valor) {
  return String(valor || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "") // tira os acentos (á → a)
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "");
}

// Palavras da Origem (sem acento, maiúsculas). Um nome só é reconhecido
// dentro de uma palavra ("ArezzoShop") ou como palavras inteiras seguidas
// ("Via Varejo", "Infra Commerce") — nunca atravessando o meio de duas
// palavras ("Mozza Bar" não é ZZAB, "Park Waikiki" não é Kwai).
function palavrasDaOrigem(valor) {
  return String(valor || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toUpperCase()
    .split(/[^A-Z0-9]+/)
    .filter(Boolean);
}

// Começo de palavra só vale para nome comprido ou seguido de um complemento
// comum de loja ("ArezzoShop", "Kwaishop"); "Marlone", "Pizzabella" não.
const COMPLEMENTOS_DE_LOJA = ["SHOP", "STORE", "OFICIAL", "BR", "BRASIL", "ONLINE", "LOJA", "MODAS", "OUTLET", "CO"];
function palavraTemNome(palavra, nome) {
  if (palavra === nome) return true;
  if (!palavra.startsWith(nome)) return false;
  return nome.length >= 7 || COMPLEMENTOS_DE_LOJA.includes(palavra.slice(nome.length));
}

function origemTemNome(palavras, nome) {
  for (let i = 0; i < palavras.length; i++) {
    if (palavraTemNome(palavras[i], nome)) return true;
    let junto = palavras[i];
    for (let j = i + 1; j < palavras.length && junto.length < nome.length; j++) {
      junto += palavras[j];
      if (junto === nome) return true;
    }
  }
  return false;
}

function detectarEmbarcador(origemCrua) {
  const n = normalizarOrigem(origemCrua);
  if (!n) return EMBARCADOR_PADRAO;
  const palavras = palavrasDaOrigem(origemCrua);
  const tem = (nome) => origemTemNome(palavras, nome);
  return EMBARCADORES.find((e) => e.reconhece(n, tem)) || EMBARCADOR_PADRAO;
}

// Infracommerce com remetente "loja MOTOROLA/MOTOROLA" só aceita física
function embarcadorAtual() {
  const e = detectarEmbarcador(rcOrigem.value);
  return e.motorola && rcMotorola.checked ? MOTOROLA : e;
}

function avisoNotaFiscal(e) {
  const digitos = rcNf.value.replace(/\D/g, "");
  if (digitos.length === 44) return "é a chave!";
  return e.nf ? e.nf.dica : "";
}

function atualizarCamposEmbarcador() {
  const origem = detectarEmbarcador(rcOrigem.value);
  const e = embarcadorAtual();
  const bloqueado = !!e.soFisica;

  rcEmbarcadorTag.textContent = e.soFisica ? "Só física" : e.nome;
  rcEmbarcadorTag.title = e.nome ? `Regra aplicada: ${e.nome}` : "";
  rcEmbarcadorTag.classList.toggle("is-hidden", !e.nome);

  // Só física: nada vai ser enviado, então ficam só Nome, Origem e o aviso
  // (o que já foi digitado nos outros campos continua guardado).
  rcLinhaTelefone.classList.toggle("is-hidden", bloqueado);
  rcLinhaRastreio.classList.toggle("is-hidden", bloqueado);
  rcConteudoField.classList.toggle("is-hidden", bloqueado);
  rcSeuNomeField.classList.toggle("is-hidden", bloqueado);

  rcPedidoField.classList.toggle("is-hidden", bloqueado || !e.pedido);
  if (e.pedido) {
    rcPedidoLabel.textContent = e.pedido.rotulo;
    if (!e.pedido.obrigatorio) {
      const dica = document.createElement("span");
      dica.className = "hint";
      dica.textContent = " (se tiver)";
      rcPedidoLabel.append(dica);
    }
    rcPedido.placeholder = e.pedido.exemplo;
  }

  const mostraData = !bloqueado; // data da entrega vai em todos os scripts
  const mostraNf = !bloqueado && !!e.nf;
  rcRastreioClienteField.classList.toggle("is-hidden", bloqueado || !e.rastreioCliente);
  if (e.rastreioCliente) {
    rcRastreioClienteLabel.textContent = e.rastreioCliente.rotulo;
    rcRastreioCliente.placeholder = e.rastreioCliente.exemplo;
  }
  const mostraMotorola = !!origem.motorola; // continua visível marcado, pra poder desmarcar
  rcDataField.classList.toggle("is-hidden", !mostraData);
  rcNfField.classList.toggle("is-hidden", !mostraNf);
  rcMotorolaField.classList.toggle("is-hidden", !mostraMotorola);
  rcLinhaExtra.classList.toggle("is-hidden", !(mostraData || mostraNf));

  const dicaNf = avisoNotaFiscal(e);
  rcNfHint.textContent = dicaNf;
  rcNfHint.classList.toggle("tem-aviso", dicaNf === "é a chave!");
  rcNfHint.title = dicaNf === "é a chave!" ? "Isso é a chave da nota (44 dígitos). O número da NF tem 6 dígitos." : "";

  rcBloqueio.classList.toggle("is-hidden", !bloqueado);
  if (bloqueado) {
    rcBloqueio.textContent = "";
    const titulo = document.createElement("strong");
    titulo.textContent = `${e.nome} não aceita acareação por mensagem.`;
    rcBloqueio.append(titulo, " Faça a acareação física (modelo J&T) — por mensagem o pedido vira extravio.");
  }

  rcCopyBtn.disabled = bloqueado;
  rcWhatsappBtn.disabled = bloqueado;
  rcPreviewToggle.disabled = bloqueado;
  if (bloqueado) fecharTodasPrevias();
}

const rcCarga = criarCarga([...rcCampos, rcMotorola]);
const seuNomeCarga = criarCarga([rcSeuNome]);

chrome.storage.session.get(RC_STORAGE_KEY, (resultado) => {
  const salvos = resultado[RC_STORAGE_KEY];
  if (salvos) {
    const repor = (el, valor) => {
      if (rcCarga.livre(el)) el.value = typeof valor === "string" ? valor : "";
    };
    repor(rcNome, salvos.nome);
    repor(rcTelefone, salvos.telefone);
    repor(rcOrigem, salvos.origem);
    repor(rcRastreio, salvos.rastreio);
    repor(rcPedido, salvos.pedido || salvos.meli); // "meli" = campo das versões anteriores
    repor(rcData, salvos.data);
    repor(rcRastreioCliente, salvos.rastreioCliente);
    repor(rcNf, salvos.nf);
    repor(rcConteudo, salvos.conteudo);
    if (rcCarga.livre(rcMotorola)) rcMotorola.checked = salvos.motorola === true;
  }
  if (rcCarga.concluir()) salvarCamposReclamacao();
  atualizarCamposEmbarcador();
  atualizarPreviewReclamacao();
});

chrome.storage.local.get(SEU_NOME_KEY, (resultado) => {
  const salvo = resultado[SEU_NOME_KEY];
  if (typeof salvo === "string" && seuNomeCarga.livre(rcSeuNome)) rcSeuNome.value = salvo;
  if (seuNomeCarga.concluir()) salvarSeuNome();
  atualizarPreviewReclamacao();
});

function salvarSeuNome() {
  if (!seuNomeCarga.pronto) return;
  chrome.storage.local.set({ [SEU_NOME_KEY]: rcSeuNome.value.trim() });
}

function salvarCamposReclamacao() {
  if (!rcCarga.pronto) return;
  gravarSessao({
    [RC_STORAGE_KEY]: {
      nome: rcNome.value,
      telefone: rcTelefone.value,
      origem: rcOrigem.value,
      rastreio: rcRastreio.value,
      pedido: rcPedido.value,
      data: rcData.value,
      rastreioCliente: rcRastreioCliente.value,
      nf: rcNf.value,
      conteudo: rcConteudo.value,
      motorola: rcMotorola.checked,
    },
  });
}

// O sistema mostra "--" quando o campo não existe naquele pedido: vale como
// vazio (também com travessão ou espaços entre os traços). Caractere
// invisível sozinho (copiado de página/planilha) também é vazio.
function valorDoSistema(valor) {
  const v = limparInvisiveis(valor).trim();
  return /^[-–—\s]+$/.test(v) ? "" : v;
}

function montarMensagemReclamacao() {
  const e = embarcadorAtual();
  const origemCrua = rcOrigem.value.trim();
  const limpo = (el) => limparInvisiveis(el.value).trim(); // nada invisível vai para a cliente
  const v = {
    nome: limpo(rcNome) || "(Nome)",
    seuNome: limpo(rcSeuNome) || "(Seu nome)",
    origem: limparInvisiveis(origemCrua).trim() || "(Origem)",
    rastreio: limpo(rcRastreio) || "(Rastreio)",
    // Opcional em branco (ou "--", como o sistema mostra quando não tem): a linha não entra
    pedido: valorDoSistema(rcPedido.value) || (e.pedido && e.pedido.obrigatorio ? `(${e.pedido.rotulo})` : ""),
    data: formatarData(limparInvisiveis(rcData.value)) || "(Data)",
    rastreioCliente: valorDoSistema(rcRastreioCliente.value) || `(${e.rastreioCliente ? e.rastreioCliente.rotulo : "Código"})`,
    nf: limpo(rcNf) || "(Nota fiscal)",
    conteudo: limpo(rcConteudo) || "(Conteúdo)",
  };
  return e.montar ? e.montar(v) : "";
}

// O texto puro é atualizado sempre (é ele que é copiado); o balão da prévia
// só é desenhado com a prévia aberta (desenhar a cada tecla deixava lixo).
function atualizarPreviewReclamacao(desenhar = rcPreviewPanel.classList.contains("is-open")) {
  const texto = montarMensagemReclamacao();
  rcPreview.value = texto;
  if (desenhar) renderizarComoWhatsApp(rcPreviewText, texto);
}

rcConteudo.addEventListener("keydown", (e) => {
  if (e.key === "Enter") e.preventDefault();
});

rcConteudo.addEventListener("input", () => removerQuebrasDeLinha(rcConteudo));

rcTelefone.addEventListener("input", () => rcTelefone.classList.remove("phone-invalid"));

rcOrigem.addEventListener("input", atualizarCamposEmbarcador);
rcNf.addEventListener("input", atualizarCamposEmbarcador);

rcMotorola.addEventListener("change", () => {
  atualizarCamposEmbarcador();
  atualizarPreviewReclamacao();
  salvarCamposReclamacao();
});

rcSeuNome.addEventListener("input", () => {
  salvarSeuNome();
  atualizarPreviewReclamacao();
});

rcCampos.forEach((el) =>
  el.addEventListener("input", () => {
    atualizarPreviewReclamacao();
    salvarCamposReclamacao();
  })
);

// Campos que entram na mensagem do embarcador atual. Nenhum pode ir vazio:
// a cliente receberia "(Rastreio)" no lugar do código.
function camposObrigatoriosOcorrencia() {
  const e = embarcadorAtual();
  const usaOrigem = e === EMBARCADOR_PADRAO || e.id === "shopee" || e.id === "cainiao" || e.id === "infracommerce";
  const lista = [[rcSeuNome, "Seu nome"], [rcNome, "Nome"]];
  if (usaOrigem) lista.push([rcOrigem, "Origem"]); // vira a "Loja" da mensagem
  lista.push([rcRastreio, "Rastreio"]);
  if (e.pedido && e.pedido.obrigatorio) lista.push([rcPedido, e.pedido.rotulo]);
  lista.push([rcData, "Data"]);
  if (e.rastreioCliente) lista.push([rcRastreioCliente, e.rastreioCliente.rotulo]);
  if (e.nf) lista.push([rcNf, "NF"]);
  lista.push([rcConteudo, "Conteúdo"]);
  return lista; // na ordem em que aparecem no formulário
}

function marcarCampoFaltando(el) {
  el.classList.remove("phone-invalid");
  void el.offsetWidth; // reinicia a animação
  el.classList.add("phone-invalid");
}

// Confere uma lista [[campo, "Nome do campo"], ...]. Devolve true se está tudo
// preenchido; senão marca os vazios em vermelho, foca o primeiro e avisa.
// telefoneEl (só no WhatsApp) também é conferido e marcado.
function conferirCampos(lista, feedbackEl, telefoneEl = null) {
  const faltando = lista.filter(([el]) => !valorDoSistema(el.value));
  const telefoneRuim = !!telefoneEl && !telefoneValido(telefoneEl.value);
  const nomes = faltando.map(([, nome]) => nome).concat(telefoneRuim ? ["Telefone"] : []);
  if (!faltando.length) {
    esconderFeedback(feedbackEl); // tira um "falta preencher" que ainda esteja na tela
    return true;
  }
  faltando.forEach(([el]) => marcarCampoFaltando(el));
  if (telefoneRuim) marcarCampoFaltando(telefoneEl);
  (telefoneRuim ? telefoneEl : faltando[0][0]).focus();
  // O aviso tem uma linha só: com muitos campos, diz quantos (já estão marcados em vermelho)
  avisarFeedback(
    feedbackEl,
    nomes.length <= 3 ? `Falta preencher: ${nomes.join(", ")}` : `Preencha os ${nomes.length} campos marcados em vermelho`
  );
  return false;
}

// Mercado Livre não aceita acareação sem a HORA da entrega (data divergente
// da baixa = extravio). "2026-07-30 13:28:12", "30/07 às 13h28", "13:28"...
function temHora(valor) {
  // hora logo depois de qualquer não-dígito (espaço, "T" do ISO, "às"...)
  return /(?:^|\D)\d{1,2}\s*(?::|h)\s*\d{2}(?!\d)/i.test(limparInvisiveis(valor));
}

function conferirOcorrencia(incluirTelefone) {
  if (!conferirCampos(camposObrigatoriosOcorrencia(), rcFeedback, incluirTelefone ? rcTelefone : null)) return false;
  if (embarcadorAtual().id === "mercadolivre" && !temHora(rcData.value)) {
    marcarCampoFaltando(rcData);
    rcData.focus();
    avisarFeedback(rcFeedback, "Mercado Livre: coloque a hora da entrega, igual à da baixa");
    return false;
  }
  return true;
}

// Limpar também tira as marcas vermelhas e o aviso de "falta preencher"
function limparMarcas(campos, feedbackEl) {
  campos.forEach((el) => el.classList.remove("phone-invalid"));
  esconderFeedback(feedbackEl);
}

function avisarFeedback(feedbackEl, texto) {
  mostrarFeedback(feedbackEl, { texto, erro: true, ms: 2600 });
}

rcCopyBtn.addEventListener("click", () => {
  if (embarcadorAtual().soFisica) return;
  if (!conferirOcorrencia(false)) return;
  atualizarPreviewReclamacao();
  copiarTexto(rcPreview.value, rcFeedback, lembreteAoCopiar(embarcadorAtual()));
});

rcWhatsappBtn.addEventListener("click", () => {
  if (embarcadorAtual().soFisica) return;
  if (!conferirOcorrencia(true)) return;
  atualizarPreviewReclamacao();
  abrirWhatsApp(rcTelefone, rcPreview.value, rcFeedback, lembreteAoCopiar(embarcadorAtual()));
});

// Ao digitar, o campo deixa de estar marcado como faltando.
[rcSeuNome, rcNome, rcOrigem, rcRastreio, rcPedido, rcData, rcRastreioCliente, rcNf, rcConteudo].forEach((el) =>
  el.addEventListener("input", () => el.classList.remove("phone-invalid"))
);

// Limpar apaga os dados do cliente; "Seu nome" é de quem atende e fica.
rcClearBtn.addEventListener("click", () => {
  const foto = fotografarCampos([...rcCampos, rcMotorola]);
  rcCampos.forEach((el) => {
    el.value = "";
    rcCarga.marcar(el); // Limpar antes de carregar: não deixa a restauração trazer de volta
  });
  rcMotorola.checked = false;
  rcCarga.marcar(rcMotorola);
  limparMarcas([...rcCampos, rcSeuNome], rcFeedback);
  atualizarCamposEmbarcador();
  atualizarPreviewReclamacao();
  chrome.storage.session.remove(RC_STORAGE_KEY);
  fecharTodasPrevias();
  oferecerDesfazer(foto);
});

// ---------- Preencher pelo JMS (botão de raio ao lado do Rastreio) ----------
// Cola o rastreio, clica no raio (ou Enter) e a extensão busca no JMS:
// telefone e nome (getPhoneByWaybillNo), origem, pedido e conteúdo
// (getOrderDetail) e a data da assinatura (rastreio). Quem consulta é o
// background.js (mesmo bloqueio do Lote/Expedido); os dados voltam só na
// resposta. Só preenche campos VAZIOS: o que a pessoa digitou fica.
const rcPreencherBtn = document.getElementById("rc-preencher");
const rcPreencherAviso = document.getElementById("rc-preencher-aviso");
let preencherConsultando = ""; // rastreio que está sendo consultado agora
let preencherEsperaTimer = null;

function avisoPreencher(texto, tipo = "aviso") {
  rcPreencherAviso.textContent = texto;
  rcPreencherAviso.classList.toggle("tem-aviso", !!texto && tipo === "aviso");
  rcPreencherAviso.classList.toggle("tem-sucesso", !!texto && tipo === "ok");
}

function pararEsperaPreencher() {
  clearTimeout(preencherEsperaTimer);
  preencherEsperaTimer = null;
}

// Mensagens de acesso da aba Lote, ditas do jeito desta tela
function mensagemErroPreencher(erro) {
  const tipo = erro && erro.tipo;
  if (tipo === "permitir") return "A extensão está sem permissão para acessar o JMS. Abra a aba Lote e clique em Permitir acesso.";
  if (tipo === "recarregar") return "A extensão foi atualizada: recarregue-a em chrome://extensions e tente de novo.";
  return (erro && typeof erro.mensagem === "string" && erro.mensagem) || PREENCHER_MSG.generico;
}

// O sistema pediu pausa: conta e tenta de novo sozinho (se o rastreio não mudar)
function esperarPreencher(ate, rastreio) {
  pararEsperaPreencher();
  const tique = () => {
    if (rastreioJtValido(rcRastreio.value) !== rastreio) return pararEsperaPreencher();
    const seg = Math.ceil((ate - Date.now()) / 1000);
    if (seg <= 0) {
      preencherEsperaTimer = null;
      preencherOcorrencia();
      return;
    }
    avisoPreencher(`O sistema pediu uma pausa. Tentando de novo em ${seg} s…`);
    preencherEsperaTimer = setTimeout(tique, 1000);
  };
  tique();
}

function aplicarPreenchimento(d) {
  const mapa = [
    [rcOrigem, "origem", "Origem"], // primeiro: o embarcador define os outros campos
    [rcTelefone, "telefone", "Telefone"],
    [rcNome, "nome", "Nome"],
    [rcPedido, "pedido", "N° do pedido"],
    [rcData, "data", "Data"],
    [rcConteudo, "conteudo", "Conteúdo"],
  ];
  const mantidos = [];
  let preenchidos = 0;
  for (const [el, chave, nome] of mapa) {
    const valor = d[chave];
    if (!valor) continue;
    const atual = limparInvisiveis(el.value).trim();
    if (atual) {
      const igual = el === rcTelefone ? normalizarTelefone(atual) === normalizarTelefone(valor) : atual === valor;
      if (!igual) mantidos.push(nome);
      continue;
    }
    rcCarga.marcar(el); // a restauração da sessão não passa por cima
    el.value = valor;
    el.dispatchEvent(new Event("input", { bubbles: true })); // embarcador, prévia, salvar, marcas
    preenchidos++;
  }
  const avisos = Array.isArray(d.avisos) ? d.avisos.slice() : [];
  if (mantidos.length) avisos.push(`mantive o que você digitou em ${mantidos.join(", ")}`);
  if (!preenchidos && !mantidos.length) {
    avisoPreencher("O JMS não trouxe dados para esse rastreio.");
    return;
  }
  if (avisos.length) avisoPreencher(`Preenchido, mas: ${avisos.join(" · ")}.`);
  else avisoPreencher("");
  mostrarFeedback(rcFeedback, { texto: "Preenchido pelo JMS", ms: 2200 });
}

async function preencherOcorrencia() {
  pararEsperaPreencher();
  const rastreio = rastreioJtValido(rcRastreio.value);
  if (!rastreio) {
    marcarCampoFaltando(rcRastreio);
    rcRastreio.focus();
    avisoPreencher(PREENCHER_MSG.invalido);
    return;
  }
  if (preencherConsultando) return; // clique duplo: uma consulta por vez
  preencherConsultando = rastreio;
  rcPreencherBtn.disabled = true;
  rcPreencherBtn.classList.add("is-carregando");
  avisoPreencher("");
  mostrarFeedback(rcFeedback, { texto: "Buscando no JMS…", ms: 60000 });
  let r;
  try {
    r = await falarComFundo({ acao: "preencher", rastreio });
  } catch (e) {
    r = { ok: false, erro: { tipo: "fundo", mensagem: LOTE_MSG.semFundo } };
  }
  preencherConsultando = "";
  rcPreencherBtn.disabled = false;
  rcPreencherBtn.classList.remove("is-carregando");
  esconderFeedback(rcFeedback);
  // Trocou o rastreio enquanto buscava: a resposta é de outro pedido, descarta
  if (rastreioJtValido(rcRastreio.value) !== rastreio) return;
  if (r && r.limite && Number.isFinite(r.ate)) return esperarPreencher(r.ate, rastreio);
  if (!r || !r.ok || !r.dados || r.rastreio !== rastreio) {
    avisoPreencher(mensagemErroPreencher(r && r.erro));
    return;
  }
  aplicarPreenchimento(r.dados);
}

rcPreencherBtn.addEventListener("click", preencherOcorrencia);
rcRastreio.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.ctrlKey && !e.altKey && !e.metaKey) {
    e.preventDefault();
    preencherOcorrencia();
  }
});
// Mexeu no rastreio, limpou ou trocou de aba: a espera/aviso antigos não valem mais
rcRastreio.addEventListener("input", () => {
  pararEsperaPreencher();
  avisoPreencher("");
});
rcClearBtn.addEventListener("click", () => {
  pararEsperaPreencher();
  avisoPreencher("");
});
tabButtons.forEach((b) => b.addEventListener("click", pararEsperaPreencher));

function abrirPreviaReclamacao() {
  fecharTodasPrevias(); // uma sobreposição por vez
  atualizarPreviewReclamacao(true);
  rcPreviewPanel.classList.add("is-open");
  rcPreviewToggle.classList.add("is-active");
}

rcPreviewToggle.addEventListener("click", (e) => {
  e.stopPropagation();
  if (embarcadorAtual().soFisica) return;
  const estaAberta = rcPreviewPanel.classList.contains("is-open");
  estaAberta ? fecharTodasPrevias() : abrirPreviaReclamacao();
});

// ---------- SUB-ABA ENDEREÇO INCORRETO ----------
const enRastreio = document.getElementById("en-rastreio");
const enTelefone = document.getElementById("en-telefone");
const enOrigem = document.getElementById("en-origem");
const enConteudo = document.getElementById("en-conteudo");
const enPreview = document.getElementById("en-preview");
const enPreviewText = document.getElementById("en-preview-text");
const enPreviewPanel = document.getElementById("en-preview-panel");
const enPreviewToggle = document.getElementById("en-preview-toggle");
const enCopyBtn = document.getElementById("en-copy");
const enClearBtn = document.getElementById("en-clear");
const enFeedback = document.getElementById("en-feedback");
const enWhatsappBtn = document.getElementById("en-whatsapp");

const EN_STORAGE_KEY = "en_campos";
const enCampos = [enTelefone, enRastreio, enOrigem, enConteudo];

const enCarga = criarCarga(enCampos);

chrome.storage.session.get(EN_STORAGE_KEY, (resultado) => {
  const salvos = resultado[EN_STORAGE_KEY];
  if (salvos) {
    const repor = (el, valor) => {
      if (enCarga.livre(el)) el.value = typeof valor === "string" ? valor : "";
    };
    repor(enTelefone, salvos.telefone);
    repor(enRastreio, salvos.rastreio);
    repor(enOrigem, salvos.origem);
    repor(enConteudo, salvos.conteudo);
  }
  if (enCarga.concluir()) salvarCamposEndereco();
  atualizarPreviewEndereco();
});

function salvarCamposEndereco() {
  if (!enCarga.pronto) return;
  gravarSessao({
    [EN_STORAGE_KEY]: {
      telefone: enTelefone.value,
      rastreio: enRastreio.value,
      origem: enOrigem.value,
      conteudo: enConteudo.value,
    },
  });
}

function montarMensagemEndereco() {
  const limpo = (el) => limparInvisiveis(el.value).trim();
  const rastreio = limpo(enRastreio) || "(Rastreio)";
  const origem = limpo(enOrigem) || "(Origem)";
  const conteudo = limpo(enConteudo) || "(Conteúdo)";

  return textoEndereco({ rastreio, origem, conteudo });
}

function atualizarPreviewEndereco(desenhar = enPreviewPanel.classList.contains("is-open")) {
  const texto = montarMensagemEndereco();
  enPreview.value = texto;
  if (desenhar) renderizarComoWhatsApp(enPreviewText, texto);
}

enConteudo.addEventListener("keydown", (e) => {
  if (e.key === "Enter") e.preventDefault();
});

enConteudo.addEventListener("input", () => removerQuebrasDeLinha(enConteudo));

enTelefone.addEventListener("input", () => enTelefone.classList.remove("phone-invalid"));

enCampos.forEach((el) =>
  el.addEventListener("input", () => {
    atualizarPreviewEndereco();
    salvarCamposEndereco();
  })
);

// Mesma proteção da Ocorrência: nada de "(Rastreio)" chegando para a cliente
const EN_OBRIGATORIOS = () => [
  [enRastreio, "Rastreio"],
  [enOrigem, "Origem"],
  [enConteudo, "Conteúdo"],
];

enCopyBtn.addEventListener("click", () => {
  if (!conferirCampos(EN_OBRIGATORIOS(), enFeedback)) return;
  atualizarPreviewEndereco();
  copiarTexto(enPreview.value, enFeedback);
});

enWhatsappBtn.addEventListener("click", () => {
  if (!conferirCampos(EN_OBRIGATORIOS(), enFeedback, enTelefone)) return;
  atualizarPreviewEndereco();
  abrirWhatsApp(enTelefone, enPreview.value, enFeedback);
});

[enRastreio, enOrigem, enConteudo].forEach((el) =>
  el.addEventListener("input", () => el.classList.remove("phone-invalid"))
);

enClearBtn.addEventListener("click", () => {
  const foto = fotografarCampos(enCampos);
  enCampos.forEach((el) => {
    el.value = "";
    enCarga.marcar(el);
  });
  limparMarcas(enCampos, enFeedback);
  atualizarPreviewEndereco();
  chrome.storage.session.remove(EN_STORAGE_KEY);
  fecharTodasPrevias();
  oferecerDesfazer(foto);
});

function abrirPreviaEndereco() {
  atualizarPreviewEndereco(true);
  enPreviewPanel.classList.add("is-open");
  enPreviewToggle.classList.add("is-active");
}

enPreviewToggle.addEventListener("click", (e) => {
  e.stopPropagation();
  const estaAberta = enPreviewPanel.classList.contains("is-open");
  estaAberta ? fecharTodasPrevias() : abrirPreviaEndereco();
});

// ---------- RESPOSTA DE CONTINUAÇÃO (depois que o cliente escolhe a opção) ----------
// Cartilha de Continuidade do Mercado Livre + tratativa por opção do Manual de
// Scripts: cada opção pede o que a análise precisa (qual item, lacre, proteção
// interna, etiqueta duplicada, fotos) — a conversa não fica "sem desenvolvimento".
const rcRespostaToggle = document.getElementById("rc-resposta-toggle");
const rcRespostaPanel = document.getElementById("rc-resposta-panel");
const rcRespostaNumeros = document.getElementById("rc-resposta-numeros");
const rcRespostaTexto = document.getElementById("rc-resposta-texto");
const rcRespostaFeedback = document.getElementById("rc-resposta-feedback");
// Textos das respostas (RESPOSTAS, montarResposta, opcoesDoEmbarcador): mensagens.js

function valoresDaOcorrencia() {
  const e = embarcadorAtual();
  const limpo = (el) => limparInvisiveis(el.value).trim();
  return {
    e,
    v: {
      nome: limpo(rcNome) || "(Nome)",
      seuNome: limpo(rcSeuNome) || "(Seu nome)",
      rastreio: limpo(rcRastreio) || "(Rastreio)",
      pedido: valorDoSistema(rcPedido.value) || (e.pedido ? `(${e.pedido.rotulo})` : ""),
      conteudo: limpo(rcConteudo) || "(Conteúdo)",
    },
  };
}

function montarBotoesResposta() {
  const { e } = valoresDaOcorrencia();
  rcRespostaNumeros.replaceChildren(
    ...opcoesDoEmbarcador(e).map((o, i) => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "resposta-num";
      b.textContent = String(i + 1);
      b.title = o.texto;
      b.setAttribute("aria-label", `Cliente respondeu ${i + 1}: ${o.texto}`);
      b.addEventListener("click", (ev) => {
        ev.stopPropagation();
        responderOpcao(i, b);
      });
      return b;
    })
  );
  rcRespostaTexto.textContent = "";
  rcRespostaTexto.classList.add("is-hidden");
}

function responderOpcao(i, botao) {
  const ok = conferirCampos([[rcSeuNome, "Seu nome"], [rcNome, "Nome"], [rcRastreio, "Rastreio"], [rcConteudo, "Conteúdo"]], rcRespostaFeedback);
  if (!ok) return;
  const { e, v } = valoresDaOcorrencia();
  const opcao = opcoesDoEmbarcador(e)[i];
  if (!opcao) return;
  const texto = montarResposta(v, opcao, e);
  rcRespostaNumeros.querySelectorAll(".resposta-num").forEach((b) => b.classList.toggle("is-active", b === botao));
  renderizarComoWhatsApp(rcRespostaTexto, texto);
  rcRespostaTexto.classList.remove("is-hidden");
  copiarTexto(texto, rcRespostaFeedback);
}

function abrirRespostas() {
  fecharTodasPrevias();
  montarBotoesResposta();
  rcRespostaPanel.classList.add("is-open");
  rcRespostaToggle.classList.add("is-active");
}

rcRespostaToggle.addEventListener("click", (e) => {
  e.stopPropagation();
  if (embarcadorAtual().soFisica) return;
  const aberta = rcRespostaPanel.classList.contains("is-open");
  aberta ? fecharTodasPrevias() : abrirRespostas();
});
// Clicar dentro do quadro (fora dos números) não fecha; clicar no fundo escuro fecha
rcRespostaPanel.querySelector(".preview-panel-inner").addEventListener("click", (e) => e.stopPropagation());

// ---- Fecha qualquer prévia aberta (clique fora, troca de aba/sub-aba) ----
function fecharTodasPrevias() {
  rcRespostaPanel.classList.remove("is-open");
  rcRespostaToggle.classList.remove("is-active");
  rcPreviewPanel.classList.remove("is-open");
  rcPreviewToggle.classList.remove("is-active");
  enPreviewPanel.classList.remove("is-open");
  enPreviewToggle.classList.remove("is-active");
}

document.addEventListener("click", fecharTodasPrevias);

// Restaura a última aba/sub-aba usadas nesta sessão do navegador
chrome.storage.session.get([TAB_STORAGE_KEY, SUBTAB_STORAGE_KEY], (resultado) => {
  const abaSalva = resultado[TAB_STORAGE_KEY];
  const subabaSalva = resultado[SUBTAB_STORAGE_KEY];
  if (abaSalva && !navCarga.aba) ativarAba(abaSalva, { salvar: false });
  if (subabaSalva && !navCarga.subaba) ativarSubaba(subabaSalva, { salvar: false });
});

// ---------- Sub-aba Scripts: respostas do ticket comum ----------
// Os textos ficam em mensagens.js (SCRIPTS_TICKET). Aqui: escolher o script,
// preencher o "aguarde até" (quando o script pede) e copiar.
const SC_STORAGE_KEY = "sc_campos"; // { id, data } — só na sessão
const scScript = document.getElementById("sc-script");
const scQuando = document.getElementById("sc-quando");
const scDataField = document.getElementById("sc-data-field");
const scData = document.getElementById("sc-data");
const scTexto = document.getElementById("sc-texto");
const scCopyBtn = document.getElementById("sc-copy");
const scFeedback = document.getElementById("sc-feedback");
const SC_TODOS = SCRIPTS_TICKET.flatMap((g) => g.itens);

SCRIPTS_TICKET.forEach((g) => {
  const grupo = document.createElement("optgroup");
  grupo.label = g.grupo;
  g.itens.forEach((s) => {
    const op = document.createElement("option");
    op.value = s.id;
    op.textContent = s.nome;
    grupo.append(op);
  });
  scScript.append(grupo);
});

const scAtual = () => SC_TODOS.find((s) => s.id === scScript.value) || SC_TODOS[0];

// "5/11", "05/11", "05/11/2026", "5-11" → "05/11". Inválida → "".
function normalizarDiaMes(valor) {
  const m = limparInvisiveis(String(valor || "")).trim().match(/^(\d{1,2})[/.-](\d{1,2})(?:[/.-]\d{2,4})?$/);
  if (!m) return "";
  const dia = Number(m[1]);
  const mes = Number(m[2]);
  if (dia < 1 || dia > 31 || mes < 1 || mes > 12) return "";
  return `${String(dia).padStart(2, "0")}/${String(mes).padStart(2, "0")}`;
}

// Hoje + n dias úteis (pula sábado e domingo; feriado não entra na conta)
function maisDiasUteis(n, base = new Date()) {
  const d = new Date(base.getFullYear(), base.getMonth(), base.getDate());
  let faltam = n;
  while (faltam > 0) {
    d.setDate(d.getDate() + 1);
    if (d.getDay() !== 0 && d.getDay() !== 6) faltam--;
  }
  return d;
}

// Função pura: o texto final do script (data em branco → "[DD/MM]")
function montarScriptTicket(script, data) {
  return script.texto.replace(/\{data\}/g, data || "[DD/MM]");
}

function atualizarScriptTicket() {
  const s = scAtual();
  const pedeData = s.texto.includes("{data}");
  const data = normalizarDiaMes(scData.value);
  scQuando.textContent = s.quando;
  scDataField.classList.toggle("is-hidden", !pedeData);
  // Mostra o texto com o "[DD/MM]" em destaque enquanto a data falta
  const texto = montarScriptTicket(s, pedeData ? data : "");
  scTexto.textContent = "";
  texto.split("[DD/MM]").forEach((parte, i) => {
    if (i) {
      const falta = document.createElement("span");
      falta.className = "sc-falta";
      falta.textContent = "[DD/MM]";
      scTexto.append(falta);
    }
    scTexto.append(parte);
  });
}

function salvarScriptTicket() {
  gravarSessao({ [SC_STORAGE_KEY]: { id: scScript.value, data: scData.value } });
}

scScript.addEventListener("change", () => {
  esconderFeedback(scFeedback);
  atualizarScriptTicket();
  salvarScriptTicket();
});
scData.addEventListener("input", () => {
  scData.classList.remove("phone-invalid");
  atualizarScriptTicket();
  salvarScriptTicket();
});
document.querySelectorAll(".sc-chip").forEach((b) =>
  b.addEventListener("click", () => {
    const d = maisDiasUteis(Number(b.dataset.uteis));
    scData.value = normalizarDiaMes(`${d.getDate()}/${d.getMonth() + 1}`);
    scData.classList.remove("phone-invalid");
    atualizarScriptTicket();
    salvarScriptTicket();
  })
);

scCopyBtn.addEventListener("click", () => {
  const s = scAtual();
  const data = normalizarDiaMes(scData.value);
  if (s.texto.includes("{data}") && !data) {
    marcarCampoFaltando(scData);
    scData.focus();
    avisarFeedback(scFeedback, "Coloque a data limite (DD/MM) ou use +3/+5/+7");
    return;
  }
  copiarTexto(montarScriptTicket(s, data), scFeedback);
});

chrome.storage.session.get(SC_STORAGE_KEY, (r) => {
  const salvo = r && r[SC_STORAGE_KEY];
  if (salvo && typeof salvo === "object") {
    if (SC_TODOS.some((s) => s.id === salvo.id) && !scScript.matches(":focus")) scScript.value = salvo.id;
    if (typeof salvo.data === "string" && !scData.value) scData.value = salvo.data;
  }
  atualizarScriptTicket();
});
atualizarScriptTicket();

// ---------- Sub-aba Guia: prazo do ticket ----------
// Prazos (Tratamento de Tickets): TikTok LATAM 22h, demais TikTok 46h, ticket
// comum 24h, contados da criação. Agilização TikTok: previsão a informar —
// rota de entrega e last mile no 1º ou 2º dia; em trânsito do 5º ao 7º dia.
const GUIA_PRAZO_HORAS = { latam: 22, tiktok: 46, comum: 24 };
const GUIA_KEY = "guia_prazo"; // { tipo, criado, tipoManual } — só na sessão
const gpTipo = document.getElementById("gp-tipo");
const gpCriado = document.getElementById("gp-criado");
const gpResultado = document.getElementById("gp-resultado");
const gpAgil = document.getElementById("gp-agil");
let gpTipoManual = false;

// "2026-10-16 10:03:22", "16/10/2026 10:03", "16/10 10:03", "16/10/26 às 10h03"
// → Date (hora local). Sem hora ou inválida → null (prazo precisa da hora).
function lerDataHoraTicket(valor, agora = new Date()) {
  const t = limparInvisiveis(String(valor || "")).trim();
  let m = t.match(/^(\d{4})-(\d{1,2})-(\d{1,2})[ T]+(\d{1,2}):(\d{2})/);
  let ano, mes, dia, hora, min;
  if (m) [, ano, mes, dia, hora, min] = m.map(Number);
  else {
    m = t.match(/^(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?\s*(?:,|às|as|-)?\s*(\d{1,2})\s*(?::|h)\s*(\d{2})/i);
    if (!m) return null;
    dia = Number(m[1]); mes = Number(m[2]); hora = Number(m[4]); min = Number(m[5]);
    ano = m[3] ? Number(m[3].length === 2 ? "20" + m[3] : m[3]) : agora.getFullYear();
  }
  if (mes < 1 || mes > 12 || dia < 1 || dia > 31 || hora > 23 || min > 59) return null;
  const d = new Date(ano, mes - 1, dia, hora, min);
  return d.getMonth() === mes - 1 && d.getDate() === dia ? d : null; // 31/02 não existe
}

const DIAS_SEMANA = ["dom", "seg", "ter", "qua", "qui", "sex", "sáb"];
const dois = (n) => String(n).padStart(2, "0");
const fmtDiaMes = (d) => `${dois(d.getDate())}/${dois(d.getMonth() + 1)}`;
const fmtQuando = (d) => `${DIAS_SEMANA[d.getDay()]} ${fmtDiaMes(d)} às ${dois(d.getHours())}:${dois(d.getMinutes())}`;
function fmtDuracao(ms) {
  const min = Math.max(0, Math.round(ms / 60000));
  const h = Math.floor(min / 60);
  return h ? `${h}h ${dois(min % 60)}min` : `${min} min`;
}
const maisDias = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);

// Função pura: os textos do prazo para um tipo e uma data de criação
function calcularPrazoTicket(tipo, criado, agora = new Date()) {
  const horas = GUIA_PRAZO_HORAS[tipo];
  if (!horas || !(criado instanceof Date)) return null;
  const limite = new Date(criado.getTime() + horas * 3600000);
  const falta = limite.getTime() - agora.getTime();
  const resultado = falta >= 0 ? `Responder até ${fmtQuando(limite)} · faltam ${fmtDuracao(falta)}` : `Prazo vencido em ${fmtQuando(limite)} (há ${fmtDuracao(-falta)})`;
  const agil = tipo === "comum" ? "" : `Agilização: rota e last mile, informe ${fmtDiaMes(maisDias(criado, 1))} a ${fmtDiaMes(maisDias(criado, 2))}; em trânsito, ${fmtDiaMes(maisDias(criado, 5))} a ${fmtDiaMes(maisDias(criado, 7))}.`;
  return { limite, vencido: falta < 0, resultado, agil };
}

function atualizarGuia() {
  const valor = gpCriado.value.trim();
  const criado = lerDataHoraTicket(valor);
  const c = calcularPrazoTicket(gpTipo.value, criado);
  gpResultado.classList.toggle("is-vazio", !c);
  gpResultado.classList.toggle("is-vencido", !!c && c.vencido);
  gpResultado.textContent = c ? c.resultado : valor ? "Coloque a data com a hora (ex.: 16/10 10:03)." : "Cole a data e hora de criação do ticket.";
  gpAgil.textContent = c ? c.agil : "";
  gpAgil.classList.toggle("is-hidden", !c || !c.agil);
}

function salvarGuia() {
  gravarSessao({ [GUIA_KEY]: { tipo: gpTipo.value, criado: gpCriado.value, tipoManual: gpTipoManual } });
}

// Ao abrir a Guia: o tipo vem do código da Ocorrência (999 TikTok, 888 comum),
// a não ser que a pessoa já tenha escolhido. LATAM é sempre escolha manual.
function abrirGuia() {
  if (!gpTipoManual) {
    const cod = limparInvisiveis(rcRastreio.value).trim();
    if (/^999/.test(cod) && gpTipo.value === "comum") gpTipo.value = "tiktok";
    else if (/^888/.test(cod)) gpTipo.value = "comum";
  }
  atualizarGuia();
  aplicarRolagemGuia();
}

gpTipo.addEventListener("change", () => {
  gpTipoManual = true;
  atualizarGuia();
  salvarGuia();
});
gpCriado.addEventListener("input", () => {
  atualizarGuia();
  salvarGuia();
});
// O "faltam" anda sozinho enquanto a Guia está aberta
setInterval(() => {
  if (document.getElementById("subpanel-guia").classList.contains("is-active")) atualizarGuia();
}, 30000);

// Seções da Guia: as que estavam abertas (e onde a lista estava rolada)
// voltam iguais ao reabrir o popup. Só na sessão: { abertas: [índices], rolagem }.
const GUIA_SECOES_KEY = "guia_secoes";
const guiaLista = document.getElementById("guia-lista");
const guiaSecoes = [...guiaLista.querySelectorAll("details.guia-sec")];
let guiaSecoesCarregadas = false;
let guiaRolagemTimer = null;
let guiaRolagemPendente = 0;

function salvarSecoesGuia() {
  if (!guiaSecoesCarregadas) return;
  const abertas = guiaSecoes.map((d, i) => (d.open ? i : -1)).filter((i) => i >= 0);
  gravarSessao({ [GUIA_SECOES_KEY]: { abertas, rolagem: Math.round(guiaLista.scrollTop) } });
}

let guiaCliqueEm = 0; // abrir/fechar feito pela pessoa (não pela busca nem pela restauração)
guiaSecoes.forEach((d) => {
  d.querySelector("summary").addEventListener("click", () => {
    guiaCliqueEm = Date.now();
  });
  d.addEventListener("toggle", () => {
    // Abriu uma seção perto do fim da lista: rola até ela aparecer inteira
    if (d.open && Date.now() - guiaCliqueEm < 600) d.scrollIntoView({ block: "nearest", behavior: "smooth" });
    if (!guiaBusca.value.trim()) salvarSecoesGuia(); // aberta pela busca não conta
  });
});
guiaLista.addEventListener("scroll", () => {
  clearTimeout(guiaRolagemTimer);
  guiaRolagemTimer = setTimeout(salvarSecoesGuia, 150);
});

chrome.storage.session.get(GUIA_SECOES_KEY, (r) => {
  const s = r && r[GUIA_SECOES_KEY];
  if (s && Array.isArray(s.abertas)) {
    s.abertas.forEach((i) => {
      if (Number.isInteger(i) && guiaSecoes[i]) guiaSecoes[i].open = true;
    });
  }
  if (s && Number.isFinite(s.rolagem) && s.rolagem > 0) guiaRolagemPendente = s.rolagem;
  aplicarRolagemGuia();
  // O "toggle" de quem abriu agora chega depois: só então volta a salvar
  setTimeout(() => {
    guiaSecoesCarregadas = true;
  }, 50);
});

// Busca na Guia: mostra só os itens com o termo (sem diferenciar acento nem
// maiúscula) e abre as seções onde eles estão. Apagar a busca volta as
// seções como a pessoa tinha deixado.
const guiaBusca = document.getElementById("guia-busca");
const guiaBuscaInfo = document.getElementById("guia-busca-info");
const semAcento = (t) => String(t).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
let guiaAbertasAntesDaBusca = null;

function filtrarGuia() {
  const termo = semAcento(guiaBusca.value.trim());
  if (!termo) {
    guiaSecoes.forEach((d, i) => {
      d.classList.remove("is-hidden");
      d.querySelectorAll("li").forEach((li) => li.classList.remove("is-hidden"));
      if (guiaAbertasAntesDaBusca) d.open = guiaAbertasAntesDaBusca.includes(i);
    });
    guiaAbertasAntesDaBusca = null;
    guiaBuscaInfo.textContent = "";
    return;
  }
  if (!guiaAbertasAntesDaBusca) guiaAbertasAntesDaBusca = guiaSecoes.map((d, i) => (d.open ? i : -1)).filter((i) => i >= 0);
  let achados = 0;
  guiaSecoes.forEach((d) => {
    const titulo = semAcento(d.querySelector("summary").textContent).includes(termo);
    let naSecao = 0;
    d.querySelectorAll("li").forEach((li) => {
      const ok = titulo || semAcento(li.textContent).includes(termo);
      li.classList.toggle("is-hidden", !ok);
      if (ok) naSecao++;
    });
    d.classList.toggle("is-hidden", naSecao === 0);
    d.open = naSecao > 0;
    achados += naSecao;
  });
  guiaBuscaInfo.textContent = achados ? `${achados} item(ns)` : "Nada encontrado";
  guiaLista.scrollTop = 0;
}

guiaBusca.addEventListener("input", filtrarGuia);
guiaBusca.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && guiaBusca.value) {
    e.stopPropagation();
    guiaBusca.value = "";
    filtrarGuia();
  }
});

// Com a Guia escondida a rolagem não pega: fica pendente até ela aparecer.
function aplicarRolagemGuia() {
  if (!guiaRolagemPendente || !guiaLista.offsetParent) return;
  guiaLista.scrollTop = guiaRolagemPendente;
  guiaRolagemPendente = 0;
}

chrome.storage.session.get(GUIA_KEY, (r) => {
  const g = r && r[GUIA_KEY];
  if (!g || typeof g !== "object") return atualizarGuia();
  if (GUIA_PRAZO_HORAS[g.tipo] && !gpTipo.matches(":focus")) gpTipo.value = g.tipo;
  if (typeof g.criado === "string" && !gpCriado.value) gpCriado.value = g.criado;
  gpTipoManual = !!g.tipoManual;
  atualizarGuia();
});

// Lembrete curto no aviso de "copiada" (checklist completo na Guia)
function lembreteAoCopiar(e) {
  if (e.id === "mercadolivre") return "Copiada · Meli: data igual à baixa, nada de áudio";
  if (e.id === "tiktok") return "Copiada · TikTok: retorno só com print da conversa";
  return null;
}

// ---------- Aba POD (removida na 3.11.0) ----------
// Apaga o que a aba antiga deixou na sessão. "aba_ativa" = "pod" não acha
// mais o botão e a extensão abre em Tickets.
chrome.storage.session.remove("pod_campos");

// ---------- ABA CÓDIGO DE BARRAS ----------
const barrasInput = document.getElementById("barras-input");
const barrasSetup = document.getElementById("barras-setup");
const barrasPergunta = document.getElementById("barras-pergunta");
const barrasPerguntaNaoBtn = document.getElementById("barras-pergunta-nao");
const barrasPerguntaSimBtn = document.getElementById("barras-pergunta-sim");
const barrasPerguntaVoltarBtn = document.getElementById("barras-pergunta-voltar");
const barrasCancelados = document.getElementById("barras-cancelados");
const barrasCanceladosInput = document.getElementById("barras-cancelados-input");
const barrasCanceladosAviso = document.getElementById("barras-cancelados-aviso");
const barrasCanceladosVoltarBtn = document.getElementById("barras-cancelados-voltar");
const barrasCanceladosConfirmarBtn = document.getElementById("barras-cancelados-confirmar");
const barrasViewer = document.getElementById("barras-viewer");
const barrasQuebrarBtn = document.getElementById("barras-quebrar");
const barrasGerarBtn = document.getElementById("barras-gerar");
const barrasFeedback = document.getElementById("barras-feedback");
const barrasCounter = document.getElementById("barras-counter");
const barrasSvg = document.getElementById("barras-svg");
const barrasLabel = document.getElementById("barras-label");
const barrasPrevBtn = document.getElementById("barras-prev");
const barrasNextBtn = document.getElementById("barras-next");
const barrasRemoverBtn = document.getElementById("barras-remover");
const barrasVoltarBtn = document.getElementById("barras-voltar");
const barrasViewerNota = document.getElementById("barras-viewer-nota");

const BARRAS_STORAGE_KEY = "barras_texto";
// Visualizador aberto: a lista fica salva uma vez e a posição a cada código,
// para reabrir o popup no mesmo ponto (sem pular nem repetir código).
const BARRAS_LISTA_KEY = "barras_viewer_lista";
const BARRAS_POS_KEY = "barras_viewer_pos";
// Etapa antes do visualizador ("pergunta" ou "cancelados") e o texto dos
// cancelados: clicar fora para copiar os cancelados não perde o que já foi feito.
const BARRAS_ETAPA_KEY = "barras_etapa";
let codigosColados = []; // lista completa, extraída do textarea principal
let listaCodigos = []; // só os que sobraram depois de tirar os cancelados
let indiceCodigoAtual = 0;

const barrasCarga = criarCarga([barrasInput]);

function salvarTextoBarras() {
  if (!barrasCarga.pronto) return;
  gravarSessao({ [BARRAS_STORAGE_KEY]: barrasInput.value });
}

chrome.storage.session.get([BARRAS_STORAGE_KEY, BARRAS_LISTA_KEY, BARRAS_POS_KEY, BARRAS_ETAPA_KEY], (resultado) => {
  const salvo = resultado[BARRAS_STORAGE_KEY];
  const livre = barrasCarga.livre(barrasInput);
  if (typeof salvo === "string" && salvo && livre) barrasInput.value = salvo;
  if (barrasCarga.concluir()) salvarTextoBarras();
  restaurarVisualizadorBarras(resultado[BARRAS_LISTA_KEY], resultado[BARRAS_POS_KEY], livre);
  restaurarEtapaBarras(resultado[BARRAS_ETAPA_KEY], livre);
});

function esquecerVisualizadorBarras() {
  chrome.storage.session.remove([BARRAS_LISTA_KEY, BARRAS_POS_KEY]);
}

function salvarEtapaBarras(etapa) {
  if (!etapa) {
    chrome.storage.session.remove(BARRAS_ETAPA_KEY);
    return;
  }
  gravarSessao({ [BARRAS_ETAPA_KEY]: { etapa, cancelados: barrasCanceladosInput.value } });
}

// Reabre a pergunta (ou a tela dos cancelados, com o que já estava colado),
// refazendo a conta a partir da lista colada, que também ficou salva.
function restaurarEtapaBarras(salvo, livre) {
  if (!salvo || typeof salvo !== "object" || (salvo.etapa !== "pergunta" && salvo.etapa !== "cancelados")) {
    if (salvo !== undefined) salvarEtapaBarras(null);
    return;
  }
  const ocupado = barrasViewer.classList.contains("is-active") || barrasPergunta.classList.contains("is-active") || barrasCancelados.classList.contains("is-active");
  if (!livre || ocupado || !barrasInput.value.trim()) return;
  if (!prepararGeracaoBarras({ restaurando: true })) return;
  if (salvo.etapa === "cancelados" && barrasPergunta.classList.contains("is-active")) {
    abrirTelaCancelados(typeof salvo.cancelados === "string" ? salvo.cancelados : "");
  }
}

// Lista/posição salvas só valem se forem exatamente o que a extensão grava;
// qualquer outra coisa é descartada sem erro.
function restaurarVisualizadorBarras(lista, pos, livre) {
  const ok = Array.isArray(lista) && lista.length > 0 && lista.every(codigoBarrasValido);
  const ocupado = barrasViewer.classList.contains("is-active") || barrasPergunta.classList.contains("is-active") || barrasCancelados.classList.contains("is-active");
  if (!ok || !livre || ocupado) {
    if (!ok && (lista !== undefined || pos !== undefined)) esquecerVisualizadorBarras();
    return;
  }
  codigosColados = lista.slice();
  listaCodigos = lista.slice();
  indiceCodigoAtual = Number.isInteger(pos) ? Math.min(Math.max(0, pos), listaCodigos.length - 1) : 0;
  barrasViewerNota.textContent = "";
  barrasSetup.classList.add("is-hidden");
  barrasViewer.classList.add("is-active");
  renderizarCodigoAtual();
}

const salvarTextoBarrasAoParar = quandoParar(barrasInput, salvarTextoBarras);
barrasInput.addEventListener("input", () => {
  barrasInput.classList.remove("barras-input-invalid");
  salvarTextoBarrasAoParar();
});
window.addEventListener("pagehide", () => barrasCarga.pronto && salvarTextoBarras());

// Lixeira: apaga a lista colada (e o que ficou salvo dela na sessão)
document.getElementById("barras-limpar").addEventListener("click", () => {
  const foto = fotografarCampos([barrasInput]);
  barrasInput.value = "";
  barrasInput.classList.remove("barras-input-invalid");
  codigosColados = [];
  listaCodigos = [];
  indiceCodigoAtual = 0;
  esconderFeedback(barrasFeedback);
  barrasPergunta.classList.remove("is-active");
  barrasCancelados.classList.remove("is-active");
  barrasViewer.classList.remove("is-active");
  barrasSetup.classList.remove("is-hidden");
  chrome.storage.session.remove([BARRAS_STORAGE_KEY, BARRAS_LISTA_KEY, BARRAS_POS_KEY, BARRAS_ETAPA_KEY]);
  barrasInput.focus();
  oferecerDesfazer(foto, "Lista apagada");
});

// Mesmo separador da aba Lote: espaço, quebra de linha, tab, vírgula e
// ponto e vírgula. Invisíveis saem antes. O que tem cara de rastreio/lote
// (mesma regra da aba Lote: pareceCodigo) vira maiúsculas — no sistema eles são
// maiúsculos e o leitor bipa exatamente o que o código de barras tem.
function extrairCodigos(texto) {
  return limparInvisiveis(texto)
    .split(/[\s,;]+/)
    .map(tirarAspas)
    .filter(Boolean)
    .map((c) => (pareceCodigo(c) ? c.toUpperCase() : c));
}

// Notação científica de planilha (9.99E+14): o número original se perdeu.
const NOTACAO_CIENTIFICA = /^\d+(?:[.,]\d+)?E\+?\d+$/i;

// O CODE128 só representa com segurança ASCII visível. O JsBarcode aceita
// mais (controles e É..Ó, que ele usa como funções internas) e desenharia
// barras diferentes do texto mostrado — por isso tudo fora daqui é recusado,
// nas abas Código e Lote.
function codigoBarrasValido(codigo) {
  return typeof codigo === "string" && /^[\x21-\x7E]+$/.test(codigo);
}

// Separa o que pode virar código de barras do que precisa ser recusado com aviso.
function separarCodigosBarras(texto) {
  const validos = [];
  const cientificos = [];
  const invalidos = [];
  for (const c of extrairCodigos(texto)) {
    if (NOTACAO_CIENTIFICA.test(c)) cientificos.push(c);
    else if (!codigoBarrasValido(c)) invalidos.push(c);
    else validos.push(c);
  }
  return { validos, cientificos, invalidos };
}

// Mostra o código recusado sem caracteres de controle (que não aparecem na tela).
// No aviso, todo caractere sem desenho visível (controle, formatação, espaço
// estranho, braille em branco U+2800, preenchimentos Hangul...) aparece como
// "␣(U+XXXX)": a pessoa vê onde está o problema num código que parece certo.
const SEM_DESENHO = /[\p{C}\p{Z}\u2800\u3164\u115F\u1160\uFFA0]/u;
function mostravel(codigo) {
  let v = "";
  for (const ch of String(codigo)) {
    v += SEM_DESENHO.test(ch) ? `␣(U+${ch.codePointAt(0).toString(16).toUpperCase().padStart(4, "0")})` : ch;
  }
  return v.length > 40 ? v.slice(0, 39) + "…" : v;
}

function avisosDaEntradaBarras(sep) {
  const avisos = [];
  if (sep.invalidos.length) {
    avisos.push(
      `${sep.invalidos.length} código(s) com caractere que o código de barras não aceita (acento, símbolo ou caractere de controle) ficaram de fora: ${sep.invalidos.slice(0, 2).map(mostravel).join(", ")}${sep.invalidos.length > 2 ? "…" : ""}.`
    );
  }
  if (sep.cientificos.length) {
    avisos.push(
      `${sep.cientificos.length} item(ns) em notação científica de planilha (${sep.cientificos.slice(0, 2).join(", ")}) ficaram de fora — o número original se perdeu; copie de novo como texto.`
    );
  }
  return avisos;
}

function marcarListaInvalida() {
  barrasInput.classList.remove("barras-input-invalid");
  void barrasInput.offsetWidth;
  barrasInput.classList.add("barras-input-invalid");
  barrasInput.focus();
}

// Remove códigos repetidos (mesma comparação usada nos cancelados: sem
// diferenciar maiúsculas/minúsculas), mantendo a primeira ocorrência de
// cada um. Sem isso, um código duplicado gerava 2 códigos de barra
// idênticos, e ao cancelar um dos dois a contagem ficava incorreta.
function removerDuplicados(codigos) {
  const vistos = new Set();
  const unicos = [];
  for (const codigo of codigos) {
    const chave = codigo.toUpperCase();
    if (!vistos.has(chave)) {
      vistos.add(chave);
      unicos.push(codigo);
    }
  }
  return unicos;
}

// Reorganiza os códigos digitados/colados em uma lista com quebra de
// linha (um por linha) e copia o resultado pra área de transferência.
barrasQuebrarBtn.addEventListener("click", () => {
  const codigos = extrairCodigos(barrasInput.value);
  if (codigos.length === 0) {
    marcarListaInvalida();
    return;
  }
  const textoComQuebras = codigos.join("\n");
  barrasInput.value = textoComQuebras;
  barrasCarga.marcar(barrasInput);
  salvarTextoBarras();
  copiarTexto(textoComQuebras, barrasFeedback);
});

// ---- Pergunta: existem códigos cancelados? ----

// A sessão tem cota (10 MB no Chrome): lista enorme não cabe. Avisa e segue.
const BARRAS_AVISO_NAO_SALVA = "A lista é grande demais para o popup lembrar: se fechar, ela não volta (o texto colado continua salvo).";
function salvarListaBarras() {
  const lista = listaCodigos;
  gravarSessao({ [BARRAS_LISTA_KEY]: lista }, () => {
    esquecerVisualizadorBarras();
    if (listaCodigos !== lista || !barrasViewer.classList.contains("is-active")) return;
    if (!barrasViewerNota.textContent.includes(BARRAS_AVISO_NAO_SALVA)) {
      barrasViewerNota.textContent = [barrasViewerNota.textContent, BARRAS_AVISO_NAO_SALVA].filter(Boolean).join(" ");
    }
  });
}

function irParaViewerCom(codigos, nota = "") {
  listaCodigos = codigos;
  indiceCodigoAtual = 0;
  salvarListaBarras();
  salvarEtapaBarras(null);
  barrasViewerNota.textContent = nota;
  barrasPergunta.classList.remove("is-active");
  barrasCancelados.classList.remove("is-active");
  barrasViewer.classList.add("is-active");
  renderizarCodigoAtual();
}

const barrasPerguntaNota = document.getElementById("barras-pergunta-nota");

// Lê a lista colada e vai para a pergunta (ou direto ao visualizador com 1
// código). restaurando: reabrindo o popup — sem marcar erro nem focar nada.
// Devolve true se chegou à pergunta.
function prepararGeracaoBarras({ restaurando = false } = {}) {
  const sep = separarCodigosBarras(barrasInput.value);
  const codigos = sep.validos;
  const avisosEntrada = avisosDaEntradaBarras(sep);
  esconderFeedback(barrasFeedback); // aviso de uma geração anterior nunca fica na tela
  if (codigos.length === 0) {
    if (restaurando) {
      salvarEtapaBarras(null);
      return false;
    }
    marcarListaInvalida();
    if (avisosEntrada.length) mostrarFeedback(barrasFeedback, { texto: "Nenhum código válido: " + avisosEntrada.join(" "), erro: true, ms: 6000 });
    return false;
  }

  const codigosUnicos = removerDuplicados(codigos);
  const duplicados = codigos.length - codigosUnicos.length;
  codigosColados = codigosUnicos;
  const extra = avisosEntrada.length ? " " + avisosEntrada.join(" ") : "";

  // Só sobrou 1 código: não faz sentido perguntar se tem cancelados —
  // gera direto (e avisa se duplicados foram removidos pelo caminho).
  if (codigosUnicos.length === 1) {
    if (restaurando) {
      salvarEtapaBarras(null);
      return false;
    }
    barrasSetup.classList.add("is-hidden");
    irParaViewerCom(
      codigosUnicos,
      (duplicados > 0
        ? `${duplicados} código(s) duplicado(s) foram removidos automaticamente — restou 1 código único.`
        : "") + extra
    );
    return false;
  }

  barrasPerguntaNota.textContent = ((duplicados > 0
    ? `${duplicados} código(s) duplicado(s) foram removidos automaticamente — restam ${codigosUnicos.length} código(s) únicos.`
    : "") + extra).trim();
  barrasNotaEntrada = extra.trim();

  barrasSetup.classList.add("is-hidden");
  barrasPergunta.classList.add("is-active");
  if (!restaurando) salvarEtapaBarras("pergunta");
  return true;
}

barrasGerarBtn.addEventListener("click", () => prepararGeracaoBarras());

let barrasNotaEntrada = ""; // aviso de itens deixados de fora, levado até o visualizador

barrasPerguntaNaoBtn.addEventListener("click", () => {
  irParaViewerCom(codigosColados, barrasNotaEntrada);
});

barrasPerguntaVoltarBtn.addEventListener("click", () => {
  barrasPergunta.classList.remove("is-active");
  barrasSetup.classList.remove("is-hidden");
  salvarEtapaBarras(null);
});

// Mexeu na lista de cancelados depois de ver o resultado: a conta velha não vale mais
barrasCanceladosInput.addEventListener("input", () => {
  if (restantesPendentes !== null) resetarTelaCancelados();
  salvarEtapaBarras("cancelados");
});

function abrirTelaCancelados(texto = "") {
  barrasCanceladosInput.value = texto;
  resetarTelaCancelados();
  barrasPergunta.classList.remove("is-active");
  barrasCancelados.classList.add("is-active");
  salvarEtapaBarras("cancelados");
  barrasCanceladosInput.focus();
}

barrasPerguntaSimBtn.addEventListener("click", () => abrirTelaCancelados(""));

barrasCanceladosVoltarBtn.addEventListener("click", () => {
  resetarTelaCancelados();
  barrasCancelados.classList.remove("is-active");
  barrasPergunta.classList.add("is-active");
  salvarEtapaBarras("pergunta");
});

// Depois de calcular o resultado, a pessoa precisa confirmar de novo pra
// avançar — assim dá tempo de ler se algum código cancelado não foi
// encontrado, em vez da tela mudar direto pro visualizador.
let restantesPendentes = null;

function resetarTelaCancelados() {
  restantesPendentes = null;
  barrasCanceladosAviso.textContent = "";
  barrasCanceladosAviso.classList.remove("tem-aviso", "tem-sucesso");
  barrasCanceladosConfirmarBtn.textContent = "Gerar o restante";
}

// Tira da lista completa qualquer código que também apareça na lista de
// cancelados (comparação exata, sem diferenciar maiúsculas/minúsculas).
barrasCanceladosConfirmarBtn.addEventListener("click", () => {
  // Segunda etapa: o resultado já foi mostrado, esse clique confirma.
  if (restantesPendentes !== null) {
    const restantes = restantesPendentes;
    resetarTelaCancelados();
    irParaViewerCom(restantes, barrasNotaEntrada);
    return;
  }

  const cancelados = extrairCodigos(barrasCanceladosInput.value);

  if (cancelados.length === 0) {
    irParaViewerCom(codigosColados, barrasNotaEntrada);
    return;
  }

  // Sets: comparar 10 mil × 5 mil um a um travava o popup por segundos.
  const canceladosUnicos = [...new Set(cancelados.map((c) => c.toUpperCase()))];
  const canceladosSet = new Set(canceladosUnicos);
  const restantes = codigosColados.filter((c) => !canceladosSet.has(c.toUpperCase()));
  const originais = new Set(codigosColados.map((c) => c.toUpperCase()));

  const encontrados = canceladosUnicos.filter((c) => originais.has(c)).length;
  barrasCanceladosAviso.classList.remove("tem-aviso", "tem-sucesso");
  const naoEncontrados = canceladosUnicos.length - encontrados;

  if (restantes.length === 0) {
    barrasCanceladosAviso.textContent = "Todos os códigos da lista foram marcados como cancelados — não sobrou nenhum pra gerar.";
    barrasCanceladosAviso.classList.add("tem-aviso");
    return;
  }

  if (naoEncontrados > 0) {
    barrasCanceladosAviso.textContent = `${naoEncontrados} código(s) cancelado(s) não encontrado(s) na lista original — confira a digitação. ${encontrados} removido(s) com sucesso, restam ${restantes.length}. Clique em "Confirmar" pra continuar mesmo assim, ou em "Voltar" pra corrigir.`;
    barrasCanceladosAviso.classList.add("tem-aviso");
  } else {
    barrasCanceladosAviso.textContent = `${encontrados} código(s) cancelado(s) removido(s) com sucesso — restam ${restantes.length} pra gerar.`;
    barrasCanceladosAviso.classList.add("tem-sucesso");
  }

  restantesPendentes = restantes;
  barrasCanceladosConfirmarBtn.textContent = "Confirmar";
});

// ---- Visualizador: navega e gera o código de barras atual ----

// Desenha um código de barras CODE128 no <svg> indicado. Usado pela aba
// Código e pela tela de bipar da aba Lote (mesmo formato e tamanho). Lança
// erro se o código não puder ser representado.
function desenharCodigoBarras(svg, codigo) {
  if (!codigoBarrasValido(codigo)) throw new Error("caractere que o CODE128 não representa");
  JsBarcode(svg, codigo, {
    format: "CODE128",
    width: 2.2,
    height: 80,
    displayValue: false,
    margin: 6,
  });
}

// Acima disso (em px do desenho), cada barra fica com menos de 1 px na tela.
const BARRAS_LARGURA_LEGIVEL = 700;

function renderizarCodigoAtual() {
  const codigo = listaCodigos[indiceCodigoAtual];
  barrasLabel.textContent = codigo;
  barrasCounter.textContent = `${indiceCodigoAtual + 1} / ${listaCodigos.length}`;

  try {
    desenharCodigoBarras(barrasSvg, codigo);
  } catch (erro) {
    // Código que o Code128 não consegue representar — mostra um aviso
    // em vez de deixar o código de barras antigo na tela com o texto
    // do código novo embaixo (poderia levar a biparem o pacote errado).
    barrasSvg.replaceChildren();
    barrasLabel.textContent = `${mostravel(codigo)} — não foi possível gerar`;
  }
  // Código muito comprido fica com barras finas demais na largura do popup
  if (barrasSvg.childNodes.length && parseFloat(barrasSvg.getAttribute("width")) > BARRAS_LARGURA_LEGIVEL) {
    barrasLabel.textContent = `${codigo} — longo demais: o leitor pode não ler na tela`;
  }
  gravarSessao({ [BARRAS_POS_KEY]: indiceCodigoAtual });

  barrasPrevBtn.disabled = indiceCodigoAtual === 0;
  barrasNextBtn.disabled = indiceCodigoAtual === listaCodigos.length - 1;
}

function avancarCodigo() {
  if (indiceCodigoAtual < listaCodigos.length - 1) {
    indiceCodigoAtual++;
    renderizarCodigoAtual();
  }
}

function voltarCodigo() {
  if (indiceCodigoAtual > 0) {
    indiceCodigoAtual--;
    renderizarCodigoAtual();
  }
}

// Tira o código atual da lista sem precisar voltar e editar tudo de novo
// (ex.: percebeu no meio da bipagem que aquele pedido foi cancelado)
barrasRemoverBtn.addEventListener("click", () => {
  listaCodigos.splice(indiceCodigoAtual, 1);

  if (listaCodigos.length === 0) {
    barrasViewer.classList.remove("is-active");
    barrasSetup.classList.remove("is-hidden");
    esquecerVisualizadorBarras();
    return;
  }

  if (indiceCodigoAtual >= listaCodigos.length) {
    indiceCodigoAtual = listaCodigos.length - 1;
  }
  salvarListaBarras();
  renderizarCodigoAtual();
});

barrasVoltarBtn.addEventListener("click", () => {
  barrasViewer.classList.remove("is-active");
  barrasSetup.classList.remove("is-hidden");
  esquecerVisualizadorBarras();
});

barrasPrevBtn.addEventListener("click", voltarCodigo);
barrasNextBtn.addEventListener("click", avancarCodigo);

// Teclado na aba Código: ver "Navegação pelo teclado" (junto da bipagem do Lote).
const painelBarras = document.getElementById("panel-barras");

// ---------- ABA LOTE (consulta de erro de lote) ----------
// Recebe a lista da coleta e a lista de lotes, consulta cada lote no sistema
// e devolve só os códigos da coleta que NÃO aparecem em nenhum lote.
//
// Como a consulta é feita: o fetch roda DENTRO da aba do JMS (chrome.scripting),
// igual ao que o próprio site faz — assim a requisição sai com a origem e o
// Referer reais do sistema (chamadas vindas direto da extensão costumam ser
// recusadas por gateways). O token vem do cookie YL_TOKEN, lido na hora de
// cada consulta; ele nunca é guardado nem exibido. A rede e o laço da consulta
// ficam em consulta-core.js e rodam no background.js (continuam com o popup
// fechado); aqui fica a tela.

// Quantos pacotes cabem em um lote: LOTE_TAMANHO, em consulta-core.js.

// Separa o que é código do que é texto solto (títulos como "Número da saca",
// "Total: 2", "Página 1 de 3"). Código = trecho só com letras/números/._- ,
// com pelo menos 8 caracteres e 6 dígitos (rastreios têm 15 dígitos e lotes
// BR + 11). Repetidos são descartados. Trechos com caractere estranho e
// dígitos (ex.: 9.99E+14 vindo de planilha) voltam em "suspeitos" pra não
// sumirem em silêncio.
const CODIGO_MIN_CARACTERES = 8;
const CODIGO_MIN_DIGITOS = 6;

// Datas e horas de cabeçalho ("Exportado em 2026-10-19 14:32:10") são texto.
// Datas e horas de cabeçalho. Inequívocas (nunca são código): ISO aaaa-mm-dd
// com mês/dia válidos (com ou sem hora "T…"), dd/mm/aaaa (barra não existe em
// código) e hh:mm(:ss). As ambíguas (aaaa.mm.dd, dd.mm.aaaa, dd-mm-aaaa) só
// são texto numa linha que também tem palavra — senão podem ser código e
// nunca somem (Regra nº 1).
const DATA_INEQUIVOCA = /^(?:(?:19|20)\d{2}-(?:0?[1-9]|1[0-2])-(?:0?[1-9]|[12]\d|3[01])(?:T\d{1,2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:?\d{2})?)?|\d{1,2}\/\d{1,2}\/\d{2,4}|\d{1,2}:\d{2}(?::\d{2})?)$/;
const DATA_AMBIGUA = /^(?:\d{4}[-.]\d{1,2}[-.]\d{1,2}|\d{1,2}[-.]\d{1,2}[-.]\d{2,4})$/;
function ehDataOuHora(trecho, linhaTemPalavra) {
  return DATA_INEQUIVOCA.test(trecho) || (linhaTemPalavra && DATA_AMBIGUA.test(trecho));
}
const PARECE_DATA_OU_HORA = DATA_INEQUIVOCA;

function pareceCodigo(trecho) {
  if (PARECE_DATA_OU_HORA.test(trecho)) return false;
  return (
    /^[A-Za-z0-9._-]+$/.test(trecho) &&
    trecho.length >= CODIGO_MIN_CARACTERES &&
    (trecho.match(/\d/g) || []).length >= CODIGO_MIN_DIGITOS
  );
}

// Código que provavelmente se estragou no caminho (ex.: planilha que virou
// 9.99E+14, ou um apóstrofo grudado). Datas e números curtos de títulos não
// entram aqui — são só texto.
function pareceCodigoEstragado(trecho) {
  if (PARECE_DATA_OU_HORA.test(trecho)) return false;
  if (/^\d+(?:[.,]\d+)?E\+?\d+$/i.test(trecho)) return true;
  return (trecho.match(/\d/g) || []).length >= CODIGO_MIN_DIGITOS;
}

function analisarCodigos(texto) {
  const vistos = new Set();
  const codigos = [];
  const linhasIgnoradas = new Set();
  const suspeitos = [];
  let duplicados = 0;

  limparInvisiveis(texto)
    .split(/\r\n|\r|\n/)
    .forEach((linha, indice) => {
      const trechos = linha.split(/[\s,;]+/).map(tirarAspas).filter(Boolean);
      // Palavra = só letras (título como "Relatório", "Exportado em")
      const temPalavra = trechos.some((t) => /^[^\d]*[A-Za-zÀ-ÿ]{2,}[^\d]*$/.test(t));
      for (const trecho of trechos) {
        if (ehDataOuHora(trecho, temPalavra)) {
          linhasIgnoradas.add(indice);
          continue;
        }
        if (pareceCodigo(trecho)) {
          const codigo = trecho.toUpperCase();
          if (vistos.has(codigo)) duplicados++;
          else {
            vistos.add(codigo);
            codigos.push(codigo);
          }
        } else {
          linhasIgnoradas.add(indice);
          if (pareceCodigoEstragado(trecho)) suspeitos.push(trecho);
        }
      }
    });

  return { codigos, duplicados, linhasIgnoradas: linhasIgnoradas.size, suspeitos };
}



// Cada execução tem um número. Se a pessoa cancelar (ou começar outra), as
// respostas atrasadas da execução antiga são ignoradas — nada vaza pra nova.
let loteRunAtual = 0;
let loteEmAndamento = false;


// ---- Interface ----
//
// Regra nº 1: todo código da coleta precisa terminar em algum lote. Por isso:
// - a única tela de "tudo certo" é o estado Z do resultado, e só depois de uma
//   consulta COMPLETA (nenhum lote com falha), sem código sem lote e sem item
//   inválido na coleta;
// - a lista para bipar é sempre "coleta − encontrados" da última consulta
//   completa: bipar/avançar nunca tira código da lista; só uma consulta tira.

const loteColeta = document.getElementById("lote-coleta");
const loteLotes = document.getElementById("lote-lotes");
const loteColetaInfo = document.getElementById("lote-coleta-info");
const loteLotesInfo = document.getElementById("lote-lotes-info");
const loteErro = document.getElementById("lote-erro");
const loteSetup = document.getElementById("lote-setup");
const loteProgresso = document.getElementById("lote-progresso");
const loteResultado = document.getElementById("lote-resultado");
const loteConsultarBtn = document.getElementById("lote-consultar");
const loteLimparBtn = document.getElementById("lote-limpar");
const loteCancelarBtn = document.getElementById("lote-cancelar");
const loteBarra = document.getElementById("lote-barra");
const loteBarraPreench = document.getElementById("lote-barra-preench");
const loteProgressoTitulo = document.getElementById("lote-progresso-titulo");
const loteProgressoTexto = document.getElementById("lote-progresso-texto");
const loteProgressoExtra = document.getElementById("lote-progresso-extra");
const loteResTitulo = document.getElementById("lote-res-titulo");
const loteResLista = document.getElementById("lote-res-lista");
const loteResResumo = document.getElementById("lote-res-resumo");
const loteResAvisos = document.getElementById("lote-res-avisos");
const loteResCopiarBtn = document.getElementById("lote-res-copiar");
const loteResCapacidade = document.getElementById("lote-res-capacidade");
const loteResPergunta = document.getElementById("lote-res-pergunta");
const loteResGerarBtn = document.getElementById("lote-res-gerar");
const loteResGerarTexto = document.getElementById("lote-res-gerar-texto");
const loteResCriarBtn = document.getElementById("lote-res-criar");
const loteResReconsultarBtn = document.getElementById("lote-res-reconsultar");
const loteBipar = document.getElementById("lote-bipar");
const loteCriarTela = document.getElementById("lote-criar");
const loteResRetryBtn = document.getElementById("lote-res-retry");
const loteResVoltarBtn = document.getElementById("lote-res-voltar");
const loteFeedback = document.getElementById("lote-feedback");

const LOTE_CAMPOS_KEY = "lote_campos";
const LOTE_RESULT_KEY = "lote_resultado";
const LOTE_BIPAR_KEY = "lote_bipar"; // { pos, max } da bipagem atual
const LOTE_BIPAR_ANTIGO_KEY = "lote_bipar_pos"; // da 3.9.0: só é apagado
const LOTE_ATUAL_KEY = "lote_atual"; // { lote, ocup } — último lote escolhido em Criar lote → Continuar

// Último resultado: { coleta, lotes, encontrados:Set, falhas:Map, vazios:Set,
// contagem:Map|null, invalidos:string[] } — contagem = pacotes que cada lote
// já tem; null quando o resultado veio de uma versão antiga.
let loteConsulta = null;
let loteSemLoteAtual = [];
let lotePlanoAtual = null;
// Bipagem: posição atual (0..X, X = cartão de fim) e a maior já mostrada
// (-1 = a bipagem desta lista ainda não foi aberta).
let lotePos = 0;
let lotePosMax = -1;
let loteAtual = null; // { lote, ocup: número | null }
let loteCriar = null; // { candidatos: [lotes com vaga], i }
let loteModoAtual = "tudo";
let loteComparacaoPendente = null; // { antes, mostrados } de uma reconsulta que ficou parcial

const fmtLote = (n) => Number(n).toLocaleString("pt-BR");

function mostrarEstadoLote(qual) {
  loteSetup.classList.toggle("is-hidden", qual !== "setup");
  loteProgresso.classList.toggle("is-active", qual === "progresso");
  loteResultado.classList.toggle("is-active", qual === "resultado");
  loteBipar.classList.toggle("is-active", qual === "bipar");
  loteCriarTela.classList.toggle("is-active", qual === "criar");
}

// Calcula as vagas a partir do resultado da consulta.
// Função pura (não mexe na tela): fácil de testar.
// - Lotes que falharam ficam fora das vagas (capacidade desconhecida).
// - Lote vazio conta como LOTE_TAMANHO vagas (pode ser um lote novo).
// - candidatos: lotes consultados com vaga, na ordem em que foram colados
//   (são os que o Criar lote oferece).
// - completo: nenhum lote falhou e há contagem — só assim dá para bipar,
//   escolher lote ou dizer que terminou.
function calcularPlanoLote(consulta) {
  const c = consulta;
  const semLote = c.coleta.filter((codigo) => !c.encontrados.has(codigo));
  const parcial = c.falhas.size > 0;
  if (!(c.contagem instanceof Map)) {
    return { semLote, parcial, semContagem: true, completo: false, abertos: [], cheios: [], candidatos: [], vagasLivres: 0, faltamCodigos: 0, lotesNovos: 0, grupos: [] };
  }
  const consultados = c.lotes.filter((l) => c.contagem.has(l));
  const ocupados = (l) => c.contagem.get(l);
  const vagas = (l) => Math.max(0, LOTE_TAMANHO - ocupados(l));
  // Criar lote termina primeiro os lotes pela metade (o mais cheio antes) e
  // só depois usa os vazios: nada de lote novo enquanto há lote começado.
  const parciais = consultados.filter((l) => ocupados(l) > 0 && ocupados(l) < LOTE_TAMANHO).sort((a, b) => ocupados(b) - ocupados(a));
  const abertos = parciais.concat(consultados.filter((l) => ocupados(l) === 0));
  const cheios = consultados.filter((l) => ocupados(l) >= LOTE_TAMANHO);
  const vagasLivres = abertos.reduce((soma, l) => soma + vagas(l), 0);
  const faltamCodigos = Math.max(0, semLote.length - vagasLivres);
  const lotesNovos = Math.ceil(faltamCodigos / LOTE_TAMANHO);

  // Distribuição de referência (ordem colada, sem passar do limite de cada lote).
  const grupos = [];
  let pos = 0;
  for (const lote of abertos) {
    if (pos >= semLote.length) break;
    const codigos = semLote.slice(pos, pos + vagas(lote));
    pos += codigos.length;
    grupos.push({ lote, novo: 0, ocupados: ocupados(lote), codigos });
  }
  for (let k = 1; pos < semLote.length; k++) {
    const codigos = semLote.slice(pos, pos + LOTE_TAMANHO);
    pos += codigos.length;
    grupos.push({ lote: null, novo: k, ocupados: 0, codigos });
  }
  return { semLote, parcial, semContagem: false, completo: !parcial, abertos, cheios, candidatos: abertos, vagasLivres, faltamCodigos, lotesNovos, grupos };
}

// Estado do resultado (ordem de prioridade):
// S = sem contagem (resultado antigo) · F = parcial · A = há código sem lote ·
// I = nada sem lote, mas a coleta tem item inválido · Z = tudo em lote (sucesso).
function estadoResultadoLote(plano, invalidos) {
  if (plano.semContagem) return "S";
  if (plano.parcial) return "F";
  if (plano.semLote.length > 0) return "A";
  if (invalidos.length > 0) return "I";
  return "Z";
}

function textoSucessoLote(c) {
  return `Todos os ${fmtLote(c.coleta.length)} códigos da coleta estão em lote`;
}

// Hora da consulta que confirmou (o resultado pode ter sido reaberto bem depois).
function textoConferidoLote(c) {
  if (!Number.isFinite(c.em)) return "Conferido em uma consulta anterior.";
  const d = new Date(c.em);
  return `Conferido às ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}.`;
}

const curtoLote = (texto) => mostravel(texto);

function textoCapacidadeLote(plano, c) {
  const invalidos = c.invalidos || [];
  const estado = estadoResultadoLote(plano, invalidos);
  const n = plano.semLote.length;
  if (estado === "S") return { texto: "Consulte de novo para calcular as vagas dos lotes.", tipo: "neutro" };
  if (estado === "F") {
    return {
      texto: `${fmtLote(c.falhas.size)} lote(s) não puderam ser consultados. Os códigos deles podem estar fora da conta — tente de novo antes de bipar.`,
      tipo: "falta",
    };
  }
  if (estado === "I") {
    const exemplos = invalidos.slice(0, 2).map(curtoLote).join(", ") + (invalidos.length > 2 ? "…" : "");
    return {
      texto:
        `Os códigos válidos já entraram em lote, mas ${fmtLote(invalidos.length)} item(ns) da coleta não são códigos válidos (${exemplos}). ` +
        "Corrija na lista e consulte de novo.",
      tipo: "falta",
    };
  }
  if (estado === "Z") return { texto: `${textoSucessoLote(c)}. ${textoConferidoLote(c)}`, tipo: "ok" };
  if (plano.lotesNovos === 0) {
    return { texto: `Lotes suficientes: ${fmtLote(plano.vagasLivres)} vaga(s) livre(s) para ${fmtLote(n)} código(s) sem lote.`, tipo: "ok" };
  }
  return {
    texto:
      `Faltam ${fmtLote(plano.lotesNovos)} lote(s): ${fmtLote(n)} código(s) sem lote e só ${fmtLote(plano.vagasLivres)} vaga(s) livre(s). ` +
      `Cada lote comporta ${LOTE_TAMANHO}.`,
    tipo: "falta",
  };
}

// Mensagens depois de uma reconsulta (função pura). antes/depois = listas sem
// lote; mostrados = códigos que a bipagem já mostrou antes desta reconsulta.
function montarAvisoReconsulta(antes, depois, mostrados = []) {
  // Conta pelos códigos (Sets), não pelo tamanho: 2 entrarem e 2 saírem
  // não é "nada mudou".
  const avisos = [];
  const aindaSem = new Set(depois);
  const antesSem = new Set(antes);
  const entraram = antes.filter((codigo) => !aindaSem.has(codigo)).length;
  const sairam = depois.filter((codigo) => !antesSem.has(codigo)).length;
  if (entraram > 0) avisos.push(`Reconsulta: ${fmtLote(entraram)} código(s) entraram em lote. Restam ${fmtLote(depois.length)}.`);
  else if (sairam === 0) avisos.push(`Reconsulta: nada mudou. Restam ${fmtLote(depois.length)}.`);
  if (sairam > 0) avisos.push(`Atenção: ${fmtLote(sairam)} código(s) saíram de lote desde a última consulta e voltaram para a lista.`);
  if (mostrados.length) {
    const naoEntraram = mostrados.filter((codigo) => aindaSem.has(codigo)).length;
    if (naoEntraram > 0) avisos.push(`Atenção: ${fmtLote(naoEntraram)} código(s) mostrados não estão em lote e voltaram para a lista.`);
  }
  return avisos;
}

function mostrarErroLote(mensagem) {
  loteErro.textContent = mensagem;
}

// ---- Aviso de acesso ao sistema (extensão sem recarregar / sem permissão) ----
const loteAcesso = document.getElementById("lote-acesso");
const loteAcessoTexto = document.getElementById("lote-acesso-texto");
const loteAcessoBtn = document.getElementById("lote-acesso-btn");
let loteAcessoTipo = "ok";

function mostrarAvisoAcessoLote(tipo) {
  loteAcessoTipo = tipo;
  const problema = tipo === "recarregar" || tipo === "permitir";
  loteAcesso.classList.toggle("is-hidden", !problema);
  if (!problema) return;
  mostrarErroLote(""); // o aviso já explica; não empilha outra mensagem embaixo
  loteAcessoTexto.textContent = LOTE_MSG[tipo];
  loteAcessoBtn.textContent = tipo === "recarregar" ? "Recarregar extensão" : "Permitir acesso";
}

loteAcessoBtn.addEventListener("click", async () => {
  if (loteAcessoTipo === "recarregar") {
    chrome.runtime.reload(); // fecha o popup; ao abrir de novo já vem com as permissões novas
    return;
  }
  try {
    const ok = await chrome.permissions.request({ origins: [LOTE_API.padraoAba] });
    if (ok) {
      mostrarAvisoAcessoLote("ok");
      mostrarErroLote("");
    }
  } catch (e) {
    /* pedido recusado ou indisponível: o aviso continua na tela */
  }
});

verificarAcessoLote().then(mostrarAvisoAcessoLote, () => {});

function atualizarInfoLote(textarea, infoEl) {
  const a = analisarCodigos(textarea.value);
  infoEl.classList.remove("tem-aviso");
  if (!textarea.value.trim()) {
    infoEl.textContent = "";
    return;
  }
  const partes = [`${fmtLote(a.codigos.length)} código(s)`];
  if (a.duplicados) partes.push(`${fmtLote(a.duplicados)} repetido(s) ignorado(s)`);
  if (a.suspeitos.length) {
    partes.push(`atenção: ${a.suspeitos.length} item(ns) inválido(s) (${a.suspeitos.slice(0, 2).map(mostravel).join(", ")})`);
    infoEl.classList.add("tem-aviso");
  } else if (a.linhasIgnoradas) {
    partes.push(`${a.linhasIgnoradas} linha(s) de texto ignorada(s)`);
  }
  infoEl.textContent = partes.join(" · ");
}

// Só salva depois de carregar o que já estava salvo: senão, fechar o popup
// no instante em que ele abre gravaria campos vazios por cima das listas.
let loteCamposCarregados = false;

// Duas janelas abertas (popup + janela destacada): fechar a que NÃO mexeu na
// lista não pode gravar a lista velha dela por cima da nova.
// - "Sujo" = a lista foi mexida nesta janela (digitar/colar/adicionar).
//   Fechar a janela (pagehide/visibilidade) só grava se estiver suja.
// - Sair do campo (blur/change) é ação nesta janela: grava se o texto mudou.
// - Outra janela gravou uma lista diferente depois: a desta deixa de ser a
//   mais nova (não é mais "suja").
let loteCamposSujos = false;
let expCamposSujos = false;
// outra janela gravou uma lista diferente depois do último mexer desta
let loteCamposVelhos = false;
let expCamposVelhos = false;
function salvarCamposLoteSeMudou() {
  if (loteCamposSujos) salvarCamposLote();
}
function salvarCamposExpSeMudou() {
  if (expCamposSujos) salvarCamposExp();
}
function salvarCamposLoteAoSair() {
  if (loteCamposVelhos && !loteCamposSujos) return;
  loteCamposSujos = true;
  salvarCamposLote();
}
function salvarCamposExpAoSair() {
  if (expCamposVelhos && !expCamposSujos) return;
  expCamposSujos = true;
  salvarCamposExp();
}
if (chrome.storage && chrome.storage.onChanged && typeof chrome.storage.onChanged.addListener === "function") {
  chrome.storage.onChanged.addListener((mudancas, area) => {
    if (area !== "session") return;
    const l = mudancas[LOTE_CAMPOS_KEY];
    if (l && l.newValue && (l.newValue.coleta !== loteColeta.value || l.newValue.lotes !== loteLotes.value)) {
      loteCamposSujos = false;
      loteCamposVelhos = true;
    }
    const e = mudancas[EXP_CAMPOS_KEY];
    if (e && e.newValue && e.newValue.codigos !== expCodigos.value) {
      expCamposSujos = false;
      expCamposVelhos = true;
    }
  });
}

function salvarCamposLote() {
  if (!loteCamposCarregados) return;
  gravarSessao({ [LOTE_CAMPOS_KEY]: { coleta: loteColeta.value, lotes: loteLotes.value } }, () =>
    mostrarErroLote("A lista é grande demais para ficar salva: se o popup fechar, ela não volta. Consulte com ele aberto.")
  );
}

function marcarCampoLoteInvalido(el) {
  el.classList.remove("lote-invalid");
  void el.offsetWidth;
  el.classList.add("lote-invalid");
  el.focus();
}

[
  [loteColeta, loteColetaInfo],
  [loteLotes, loteLotesInfo],
].forEach(([campo, info]) => {
  const analisarESalvar = quandoParar(campo, () => {
    atualizarInfoLote(campo, info);
    salvarCamposLote();
  });
  campo.addEventListener("input", () => {
    campo.classList.remove("lote-invalid");
    mostrarErroLote("");
    descartarResultadoLote(); // listas mudaram: o resultado antigo não corresponde mais
    esquecerLoteAtual();
    loteCamposSujos = true;
    loteCamposVelhos = false;
    analisarESalvar();
  });
});

// Salvar a cada tecla já cobre quase tudo; estes reforços garantem o que foi
// colado também ao sair do campo e quando o popup fecha (ex.: clicar fora
// pra ir copiar os lotes no sistema).
[loteColeta, loteLotes].forEach((campo) => {
  campo.addEventListener("change", salvarCamposLoteAoSair);
  campo.addEventListener("blur", salvarCamposLoteAoSair);
});
window.addEventListener("pagehide", salvarCamposLoteSeMudou);
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "hidden") salvarCamposLoteSeMudou();
});

// Pausa do minuto / bloqueio do JMS no Lote: mesma contagem do Expedido
let loteAguardo = { ate: 0, motivo: "" };
let loteAguardoTimer = null;
function textoAguardoLote(ate, motivo, agora = Date.now()) {
  return textoAguardoExp(ate, motivo, agora).replace("o mesmo código", "o mesmo lote");
}
function atualizarAguardoLote(st) {
  loteAguardo = { ate: Number(st && st.aguardandoAte) || 0, motivo: String((st && st.aguardandoMotivo) || "") };
  mostrarAguardoLote();
}
// Consulta nova ou cancelada: a contagem de espera da anterior não vale mais
function zerarAguardoLote() {
  loteAguardo = { ate: 0, motivo: "" };
  clearTimeout(loteAguardoTimer);
}
function mostrarAguardoLote() {
  clearTimeout(loteAguardoTimer);
  const t = loteEmAndamento ? textoAguardoLote(loteAguardo.ate, loteAguardo.motivo) : "";
  if (!t) return;
  loteProgressoTexto.textContent = t;
  loteAguardoTimer = setTimeout(mostrarAguardoLote, 1000);
}

function atualizarProgressoLote(feitos, total, texto) {
  const pct = total ? Math.round((feitos / total) * 100) : 0;
  loteBarraPreench.style.width = `${pct}%`;
  loteBarra.setAttribute("aria-valuenow", String(pct));
  loteProgressoTexto.textContent = texto || `${feitos} de ${total} lotes consultados`;
}

function resumirLotes(nomes, max = 4) {
  const lista = [...nomes];
  const mostrados = lista.slice(0, max).join(", ");
  return lista.length > max ? `${mostrados} +${lista.length - max}` : mostrados;
}

function descartarResultadoLote() {
  if (!loteConsulta) return;
  loteConsulta = null;
  loteSemLoteAtual = [];
  lotePlanoAtual = null;
  loteCriar = null;
  loteComparacaoPendente = null;
  zerarPosicaoBipar();
  chrome.storage.session.remove(LOTE_RESULT_KEY);
}

function salvarResultadoLote() {
  const c = loteConsulta;
  gravarSessao(
    {
      [LOTE_RESULT_KEY]: {
        coleta: c.coleta,
        lotes: c.lotes,
        encontrados: [...c.encontrados],
        falhas: [...c.falhas],
        vazios: [...c.vazios],
        invalidos: c.invalidos || [],
        ...(Number.isFinite(c.em) ? { em: c.em } : {}),
        ...(c.contagem instanceof Map ? { contagem: [...c.contagem] } : {}),
        ...(c.daMemoria > 0 ? { daMemoria: c.daMemoria } : {}),
      },
    },
    () => mostrarErroLote("O resultado é grande demais para ficar salvo: se o popup fechar, consulte de novo.")
  );
}

// ---- Lote atual (só para a estimativa "≈ n/LOTE_TAMANHO" na bipagem) ----
function salvarLoteAtual() {
  if (loteAtual) gravarSessao({ [LOTE_ATUAL_KEY]: loteAtual });
  else chrome.storage.session.remove(LOTE_ATUAL_KEY);
}

function esquecerLoteAtual() {
  if (!loteAtual) return;
  loteAtual = null;
  salvarLoteAtual();
}

// Depois de cada consulta: o lote escolhido no Continuar (ou o que já era o
// atual) recebe a contagem nova. Saiu da lista → esquecido. Não consultado
// (falhou) → sem número, e a estimativa some até consultar de novo.
function atualizarLoteAtual(c, escolhido) {
  if (escolhido) loteAtual = { lote: escolhido, ocup: null };
  if (!loteAtual) return;
  const lote = loteAtual.lote;
  if (!c.lotes.includes(lote)) loteAtual = null;
  else if (c.contagem instanceof Map && c.contagem.has(lote)) loteAtual = { lote, ocup: c.contagem.get(lote) };
  else loteAtual = { lote, ocup: null };
  salvarLoteAtual();
}

// Avisos do resultado: informação em cor neutra; vermelho só para alerta de
// verdade (erro, cancelamento, parcial, inválido, código que voltou).
function preencherAvisosLote(itens) {
  const nos = [];
  itens.forEach((aviso, i) => {
    if (i) nos.push(document.createTextNode(" "));
    const span = document.createElement("span");
    span.textContent = aviso.texto;
    if (aviso.alerta) span.className = "lote-aviso-alerta";
    nos.push(span);
  });
  loteResAvisos.replaceChildren(...nos);
}

// avisoExtra: texto ou lista de textos. "Reconsulta: …" é informação; o resto
// (erro, cancelamento, "Atenção: …") é alerta.
function mostrarResultadoLote(avisoExtra = "", { foco = false } = {}) {
  const c = loteConsulta;
  const plano = calcularPlanoLote(c);
  lotePlanoAtual = plano;
  const semLote = plano.semLote;
  loteSemLoteAtual = semLote;
  const n = semLote.length;
  const invalidos = c.invalidos || [];
  const estado = estadoResultadoLote(plano, invalidos);

  if (estado === "Z") loteResTitulo.textContent = textoSucessoLote(c);
  else if (estado === "I") loteResTitulo.textContent = `Falta conferir ${fmtLote(invalidos.length)} item(ns) inválido(s)`;
  else if (estado === "F") loteResTitulo.textContent = `Ainda não conferido (parcial): ${fmtLote(n)} sem lote`;
  else loteResTitulo.textContent = `Sem lote: ${fmtLote(n)}`;
  loteResLista.value = semLote.join("\n");
  loteResLista.classList.toggle("is-hidden", n === 0); // sucesso/inválidos: sem caixa vazia
  loteResResumo.textContent =
    `Coleta: ${fmtLote(c.coleta.length)} · Em lote: ${fmtLote(c.coleta.length - n)} · Sem lote: ${fmtLote(n)}` +
    ` · Lotes consultados: ${c.lotes.length - c.falhas.size}/${c.lotes.length}` +
    (c.daMemoria > 0 ? ` (${fmtLote(c.daMemoria)} da memória)` : "") +
    (invalidos.length ? ` · Inválidos: ${fmtLote(invalidos.length)}` : "");

  const avisos = [];
  [].concat(avisoExtra).filter(Boolean).forEach((texto) => avisos.push({ texto, alerta: !texto.startsWith("Reconsulta:") }));
  const alerta = (texto) => avisos.push({ texto, alerta: true });
  const info = (texto) => avisos.push({ texto, alerta: false });
  if (invalidos.length) {
    alerta(`Inválidos na coleta (${fmtLote(invalidos.length)}): ${resumirLotes(invalidos.map(curtoLote))} — corrija a lista.`);
  }
  if (plano.parcial) {
    const motivos = [...new Set(c.falhas.values())].slice(0, 2).map((m) => (m.length > 40 ? m.slice(0, 39) + "…" : m)).join("; ");
    alerta(
      `${c.falhas.size} lote(s) não puderam ser consultados (${resumirLotes(c.falhas.keys(), 2)}${motivos ? " — " + motivos : ""}). ` +
        "A lista pode incluir códigos que estão nesses lotes."
    );
  }
  // Parcial: a capacidade ainda não vale (falta lote), então não mostra vagas.
  // Avisos curtos: nenhuma frase pode ficar cortada na tela.
  if (c.vazios.size && !plano.parcial) info(`Lotes sem pacotes (${c.vazios.size}): ${resumirLotes(c.vazios, 2)}.`);
  if (plano.abertos.length && !plano.parcial) {
    const lista = plano.abertos.map((l) => `${l} (${c.contagem.get(l)}/${LOTE_TAMANHO})`);
    info(`Não terminados (${plano.abertos.length}): ${resumirLotes(lista, 1)}.`); // 1º = o próximo a terminar
  }
  preencherAvisosLote(avisos);

  const cap = textoCapacidadeLote(plano, c);
  loteResCapacidade.textContent = cap.texto;
  loteResCapacidade.classList.remove("is-hidden", "is-ok", "is-falta", "is-neutro");
  loteResCapacidade.classList.add(`is-${cap.tipo}`);

  // Bipar e Criar lote só com consulta completa e código sem lote (estado A).
  const podeBipar = estado === "A";
  loteResPergunta.textContent = podeBipar ? "Lote do app cheio? Clique em Criar lote." : "";
  loteResPergunta.classList.toggle("is-hidden", !podeBipar);
  loteResGerarBtn.classList.toggle("is-hidden", !podeBipar);
  loteResCriarBtn.classList.toggle("is-hidden", !podeBipar);
  if (podeBipar) {
    const pos = Math.min(lotePos, n);
    loteResGerarTexto.textContent =
      pos <= 0 ? `Bipar códigos (${fmtLote(n)})` : pos >= n ? "Continuar do fim da lista" : `Continuar do código ${fmtLote(pos + 1)} de ${fmtLote(n)}`;
  }
  loteResCopiarBtn.classList.toggle("is-hidden", n === 0);
  loteResRetryBtn.classList.toggle("is-hidden", estado !== "F");
  loteResReconsultarBtn.classList.toggle("is-hidden", estado === "F");
  mostrarEstadoLote("resultado");
  if (foco) {
    if (estado === "A") loteResGerarBtn.focus();
    else if (estado === "F") loteResRetryBtn.focus();
  }
}

// ---- Consulta em segundo plano ----
// As consultas longas (Lote e Expedido) rodam no background.js: o popup pode
// fechar (clicar fora, trocar de aba, minimizar) e a consulta continua. O
// popup só manda começar/cancelar e acompanha o andamento pela sessão
// (FUNDO_CHAVE); quando termina, mostra o resultado exatamente como antes.
// Cada consulta tem um id (job): mudança de outra consulta é ignorada.
function falarComFundo(msg) {
  try {
    if (!chrome.runtime || typeof chrome.runtime.sendMessage !== "function") return Promise.reject(new Error("sem background"));
    return Promise.resolve(chrome.runtime.sendMessage(msg)).then((r) => r || {});
  } catch (e) {
    return Promise.reject(e);
  }
}

function novoIdConsulta() {
  try {
    if (crypto && typeof crypto.randomUUID === "function") return crypto.randomUUID();
  } catch (e) {
    /* sem randomUUID: usa o relógio */
  }
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

const painelAberto = (tipo) => {
  const painel = document.getElementById(`panel-${tipo}`);
  return !!painel && painel.classList.contains("is-active");
};

// O popup mostrou o resultado: não mostra de novo ao reabrir. Se a pessoa
// está vendo a aba, o aviso do ícone também some.
function marcarAplicadoFundo(tipo, job) {
  falarComFundo({ acao: "aplicado", tipo, job, visto: painelAberto(tipo) }).catch(() => {});
}

function marcarVistoFundo(tipo) {
  falarComFundo({ acao: "visto", tipo }).catch(() => {});
}

// Abriu a aba Lote/Expedido: o resultado que estava esperando foi visto.
function aoAbrirAbaFundo(nomeAba) {
  if (nomeAba === "lote" || nomeAba === "exp") marcarVistoFundo(nomeAba);
}

const ouvintesFundo = { lote: null, exp: null };
if (chrome.storage && chrome.storage.onChanged && typeof chrome.storage.onChanged.addListener === "function") {
  chrome.storage.onChanged.addListener((mudancas, area) => {
    if (area !== "session" || !mudancas) return;
    ["lote", "exp"].forEach((tipo) => {
      const m = mudancas[FUNDO_CHAVE[tipo]];
      if (m && ouvintesFundo[tipo]) ouvintesFundo[tipo](m.newValue);
    });
  });
}

// Erro que veio do background (ou ao falar com ele) volta a ser um ErroLote.
function erroDoFundo(erro, generico) {
  if (erro && typeof erro.tipo === "string" && typeof erro.mensagem === "string") return new ErroLote(erro.tipo, erro.mensagem);
  return new Error(erro && typeof erro.mensagem === "string" ? erro.mensagem : generico);
}

// Retoma no background o que ficou pela metade (ex.: o Chrome encerrou o
// service worker enquanto o popup estava fechado).
falarComFundo({ acao: "retomar" }).catch(() => {});

// 2ª fase: o resultado deu "tudo em lote" usando a memória; antes de dizer
// isso, os lotes que vieram dela são conferidos de novo.
function mostrarFaseLote(st) {
  if (st.fase !== 2) return;
  loteProgressoTitulo.textContent = "Conferência final";
  loteProgressoExtra.textContent = "Tudo parece em lote: conferindo de novo os lotes da memória.";
}

const LOTE_TITULO_MODO = {
  tudo: "Consultando lotes",
  reconsulta: "Reconsultando lotes",
  falhas: "Consultando de novo os que falharam",
};

// Consulta que esta janela acompanha: { job, run, contexto, local }.
// local = esta janela começou a consulta e ficou aberta (o destino vale);
// numa janela reaberta o resultado sempre vai para "resultado".
let loteJob = null;

function serializarConsultaLote(c) {
  return {
    coleta: c.coleta,
    lotes: c.lotes,
    encontrados: [...c.encontrados],
    falhas: [...c.falhas],
    vazios: [...c.vazios],
    invalidos: c.invalidos || [],
    em: Number.isFinite(c.em) ? c.em : null,
    contagem: c.contagem instanceof Map ? [...c.contagem] : null,
    daMemoria: c.daMemoria > 0 ? c.daMemoria : 0,
  };
}

function lerConsultaLoteSerializada(s) {
  return {
    coleta: s.coleta.map(String),
    lotes: s.lotes.map(String),
    encontrados: new Set(s.encontrados.map(String)),
    falhas: new Map(s.falhas.map(([lote, motivo]) => [String(lote), String(motivo)])),
    vazios: new Set(s.vazios.map(String)),
    invalidos: Array.isArray(s.invalidos) ? s.invalidos.map(String) : [],
    em: Number.isFinite(s.em) ? s.em : null,
    contagem: Array.isArray(s.contagem) ? lerContagemSalva(s.contagem) : null,
    daMemoria: Number.isFinite(s.daMemoria) && s.daMemoria > 0 ? s.daMemoria : 0,
  };
}

// Continuar / Criar lote: os lotes conferidos há pouco vêm da memória (o
// background guarda). Sempre consultados: o escolhido, o atual (onde se
// bipou) e, no Criar lote, os não terminados (para escolher com número novo).
// Reconsultar, consulta nova e Tentar de novo: tudo consultado de verdade.
function memoriaDaReconsulta(modo, destino, loteEscolhido) {
  if (modo !== "reconsulta" || (destino !== "bipar" && destino !== "criar")) return null;
  const consultar = [loteEscolhido, loteAtual && loteAtual.lote].filter((l) => typeof l === "string" && l);
  return { consultar, cheioCom: destino === "criar" ? LOTE_TAMANHO : 0 };
}

function textoExtraProgressoLote(destino) {
  return destino === "criar" ? "Depois mostro o lote para bipar." : destino === "bipar" ? "Depois volto para os códigos." : "";
}

// modo "tudo": consulta nova (descarta o resultado antes).
// modo "falhas": refaz só os lotes que falharam e funde com o resultado atual.
// modo "reconsulta": consulta tudo de novo SEM descartar o resultado atual (ele
//   fica de reserva para cancelamento/erro) e, se ficar completo, segue para
//   o destino: "resultado", "criar" (tela do lote) ou "bipar" (1º restante).
async function iniciarConsultaLote(modo = "tudo", destino = "resultado", { loteEscolhido = null } = {}) {
  if (loteEmAndamento) return;
  mostrarErroLote("");
  // Resultado que usou a memória e ficou parcial: refazer só as falhas daria
  // "tudo em lote" com dado guardado. Confere tudo de novo, de verdade.
  if (modo === "falhas" && loteConsulta && loteConsulta.daMemoria > 0) {
    modo = "reconsulta";
    destino = "resultado";
  }

  let coleta;
  let lotes;
  let invalidos;
  const base = modo === "falhas" && loteConsulta ? loteConsulta : null;
  const anterior = modo === "reconsulta" && loteConsulta ? loteConsulta : null;
  const modoEfetivo = base ? "falhas" : anterior ? "reconsulta" : "tudo";
  if (!anterior) destino = "resultado";

  if (base) {
    coleta = base.coleta;
    lotes = [...base.falhas.keys()];
    invalidos = base.invalidos || [];
  } else {
    const a = analisarCodigos(loteColeta.value);
    const b = analisarCodigos(loteLotes.value);
    if (!a.codigos.length) {
      mostrarEstadoLote("setup");
      marcarCampoLoteInvalido(loteColeta);
      mostrarErroLote("Cole a lista da coleta.");
      return;
    }
    if (!b.codigos.length) {
      mostrarEstadoLote("setup");
      marcarCampoLoteInvalido(loteLotes);
      mostrarErroLote("Cole a lista de lotes.");
      return;
    }
    // Um código da coleta na lista de Lotes seria consultado e oferecido
    // como lote (e bipado como lote). Não consulta até corrigir.
    const daColeta = new Set(a.codigos);
    const repetido = b.codigos.find((codigo) => daColeta.has(codigo));
    if (repetido) {
      mostrarEstadoLote("setup");
      marcarCampoLoteInvalido(loteLotes);
      mostrarErroLote(`${repetido} está na coleta e na lista de Lotes. Tire da lista de Lotes (lote é o código BR... da saca).`);
      return;
    }
    coleta = a.codigos;
    lotes = b.codigos;
    invalidos = a.suspeitos.slice();
  }

  if (modoEfetivo === "tudo") descartarResultadoLote(); // consulta nova: o resultado antigo não vale mais

  // Para avisar se algum código já passado na bipagem não entrou em lote
  // (os que ficaram para trás do cartão mais adiante; o cartão que está na
  // tela pode ainda não ter sido bipado).
  const semLoteAntes = anterior ? calcularPlanoLote(anterior).semLote : [];
  const mostrados = anterior && lotePosMax > 0 ? semLoteAntes.slice(0, Math.min(lotePosMax, semLoteAntes.length)) : [];

  loteEmAndamento = true;
  zerarAguardoLote();
  loteModoAtual = modoEfetivo;
  const run = ++loteRunAtual;
  loteProgressoTitulo.textContent = LOTE_TITULO_MODO[modoEfetivo];
  loteProgressoExtra.textContent = textoExtraProgressoLote(destino);
  atualizarProgressoLote(0, lotes.length, "Preparando a consulta…");
  mostrarEstadoLote("progresso");

  // Tudo o que o fim da consulta precisa (o popup pode fechar e reabrir).
  // Comparação da reconsulta: a desta reconsulta, ou a que ficou pendente de
  // uma reconsulta parcial (Tentar de novo).
  const contexto = {
    modo: modoEfetivo,
    destino,
    loteEscolhido,
    coleta,
    lotes,
    invalidos,
    base: base ? serializarConsultaLote(base) : null,
    comparar: anterior ? { antes: semLoteAntes, mostrados } : base && loteComparacaoPendente ? loteComparacaoPendente : null,
  };
  const params = {
    coleta,
    lotes,
    baseEncontrados: base ? [...base.encontrados] : [],
    invalidos: invalidos.length,
    semContagem: !!base && !(base.contagem instanceof Map),
    memoria: memoriaDaReconsulta(modoEfetivo, destino, loteEscolhido),
  };
  const job = novoIdConsulta();
  loteJob = { job, run, contexto, local: true, desde: Date.now() };
  falarComFundo({ acao: "iniciar", tipo: "lote", job, params, contexto }).then(
    (r) => {
      if (!r.ok) falhaLote(job, new ErroLote("fundo", r.bloqueado ? LOTE_MSG.generico : LOTE_MSG.semFundo), { cancelar: false });
    },
    () => falhaLote(job, new ErroLote("fundo", LOTE_MSG.semFundo), { cancelar: false })
  );
}

// Mudanças da consulta no background (esta janela ou uma reaberta).
const MSG_SUBSTITUIDA = "Outra janela da extensão começou uma consulta nova: esta foi parada.";

// Outra janela começou uma consulta NOVA (mais nova que a desta): a desta foi
// substituída no background e nunca vai terminar aqui. Sem isto, esta janela
// ficaria presa em "Consultando…".
function foiSubstituida(meuJob, st) {
  return !!(meuJob && st && st.job !== meuJob.job && st.estado === "rodando" && Number(st.iniciadoEm) > Number(meuJob.desde || 0));
}

ouvintesFundo.lote = (st) => {
  if (foiSubstituida(loteJob, st)) {
    loteJob = null;
    telaCanceladaLote();
    mostrarErroLote(MSG_SUBSTITUIDA);
    return;
  }
  if (!loteJob || !st || st.job !== loteJob.job) return; // de outra consulta (cancelada/antiga): ignorada
  try {
    if (st.estado === "rodando") {
      mostrarFaseLote(st);
      if (!st.preparando) {
        atualizarProgressoLote(st.feitos, st.total);
        atualizarAguardoLote(st);
      }
    } else if (st.estado === "pronto") aplicarFundoLote(st);
    else if (st.estado === "erro") falhaLote(st.job, erroDoFundo(st.erro, LOTE_MSG.generico), { aplicado: true });
    else if (st.estado === "cancelado") {
      loteJob = null;
      telaCanceladaLote();
    }
  } catch (e) {
    falhaLote(st.job, e, { aplicado: st.estado !== "rodando" });
  }
};

// Mesmo fim de antes, com o resultado que veio do background.
function aplicarFundoLote(st) {
  const { contexto: cx, local } = loteJob;
  loteJob = null;
  loteEmAndamento = false;
  const res = st.resultado || {};
  const r = {
    encontrados: new Set(res.encontrados || []),
    falhas: new Map(res.falhas || []),
    vazios: new Set(res.vazios || []),
    contagem: new Map(res.contagem || []),
  };
  const base = cx.base ? lerConsultaLoteSerializada(cx.base) : null;
  const coleta = cx.coleta;
  const lotes = cx.lotes;
  const invalidos = cx.invalidos || [];
  // Janela reaberta: nunca abre bipagem/lote direto (só o resultado).
  const destino = local ? cx.destino : "resultado";

  const encontrados = new Set(base ? base.encontrados : []);
  r.encontrados.forEach((codigo) => encontrados.add(codigo));
  const vazios = new Set(base ? base.vazios : []);
  r.vazios.forEach((lote) => vazios.add(lote));
  // Refazendo só as falhas de um resultado antigo (sem contagem): continua
  // sem contagem — os lotes que deram certo antes não teriam número.
  let contagem = null;
  if (!base || base.contagem instanceof Map) {
    contagem = new Map(base ? base.contagem : []);
    r.contagem.forEach((n, lote) => contagem.set(lote, n));
  }

  // "Conferido às": hora da parte mais antiga (Tentar de novo só refaz uma parte)
  const agora = local || !Number.isFinite(st.atualizadoEm) ? Date.now() : st.atualizadoEm;
  const em = base && Number.isFinite(base.em) ? Math.min(base.em, agora) : agora;
  loteConsulta = { coleta, lotes: base ? base.lotes : lotes, encontrados, falhas: r.falhas, vazios, contagem, invalidos, em, daMemoria: Number(res.daMemoria) > 0 ? Number(res.daMemoria) : 0 };
  zerarPosicaoBipar(); // lista nova: a bipagem recomeça do 1º código restante
  loteCriar = null;
  atualizarLoteAtual(loteConsulta, cx.destino === "bipar" ? cx.loteEscolhido : null);
  salvarResultadoLote();

  const plano = calcularPlanoLote(loteConsulta);
  // Parcial: os números ainda não valem — nada de "entraram/saíram/voltaram"
  // (seriam frases falsas); só o aviso de parcial e o Tentar de novo.
  // Reconsulta que deu parcial guarda a comparação para quando o Tentar de
  // novo completar (o aviso dos mostrados que não entraram não se perde).
  const comparar = cx.comparar && Array.isArray(cx.comparar.antes) ? cx.comparar : null;
  loteComparacaoPendente = comparar && !plano.completo ? comparar : null;
  const avisos = comparar && plano.completo ? montarAvisoReconsulta(comparar.antes, plano.semLote, comparar.mostrados || []) : [];
  // Parcial ou nada sem lote: fica no resultado, qualquer que seja o destino.
  const segue = destino !== "resultado" && plano.completo && plano.semLote.length > 0;
  // O resultado é sempre atualizado (é para ele que "Voltar" leva).
  mostrarResultadoLote(avisos, { foco: !segue });
  if (segue && destino === "criar") abrirTelaLote(avisos.filter((t) => t.startsWith("Atenção")));
  else if (segue && destino === "bipar") abrirBipagem(avisos);
  marcarAplicadoFundo("lote", st.job);
}

// Erro (do background, ao falar com ele ou inesperado na tela): mesmo
// tratamento de antes. cancelar: a consulta ainda roda e precisa parar.
function falhaLote(job, e, { cancelar = true, aplicado = false } = {}) {
  if (!loteJob || loteJob.job !== job) return;
  const { contexto } = loteJob;
  loteJob = null;
  if (aplicado) marcarAplicadoFundo("lote", job);
  else if (cancelar) falarComFundo({ acao: "cancelar", tipo: "lote", job }).catch(() => {});
  loteRunAtual++; // interrompe qualquer consulta desta execução que ainda esteja na fila
  loteEmAndamento = false;
  const reserva = contexto.modo !== "tudo" && loteConsulta; // há um resultado para onde voltar
  const mensagem = e instanceof ErroLote ? e.message : LOTE_MSG.generico;
  if (e instanceof ErroLote && (e.tipo === "recarregar" || e.tipo === "permitir")) {
    mostrarAvisoAcessoLote(e.tipo);
    if (reserva) mostrarResultadoLote(mensagem);
    else mostrarEstadoLote("setup"); // o aviso com o botão já explica; sem repetir no erro
    return;
  }
  if (reserva) mostrarResultadoLote(mensagem); // volta pro resultado que já existia (posição da bipagem mantida)
  else {
    mostrarEstadoLote("setup");
    mostrarErroLote(mensagem);
  }
}

// Abriu o popup: consulta ainda rodando → mostra o andamento; terminou com
// ele fechado → mostra o resultado (sempre na tela de resultado).
function verFundoLoteAoAbrir(st, { colouAntes = false } = {}) {
  if (!st || typeof st !== "object" || typeof st.job !== "string" || !st.contexto || loteJob || loteEmAndamento) return;
  const pendente = st.estado === "pronto" || st.estado === "erro";
  if (colouAntes) {
    // Listas novas coladas antes de carregar: a consulta antiga não corresponde mais.
    if (st.estado === "rodando") falarComFundo({ acao: "cancelar", tipo: "lote", job: st.job }).catch(() => {});
    else if (pendente && !st.aplicado) marcarAplicadoFundo("lote", st.job);
    return;
  }
  if (st.estado === "rodando") {
    const cx = st.contexto;
    loteJob = { job: st.job, run: ++loteRunAtual, contexto: cx, local: false, desde: st.iniciadoEm || 0 };
    loteEmAndamento = true;
    loteModoAtual = cx.modo === "falhas" || cx.modo === "reconsulta" ? cx.modo : "tudo";
    loteProgressoTitulo.textContent = LOTE_TITULO_MODO[loteModoAtual];
    loteProgressoExtra.textContent = "";
    mostrarFaseLote(st);
    if (st.preparando) atualizarProgressoLote(0, st.total, "Preparando a consulta…");
    else atualizarProgressoLote(st.feitos, st.total);
    mostrarEstadoLote("progresso");
    // O que mudou entre a leitura e agora (ex.: terminou nesse meio-tempo)
    chrome.storage.session.get(FUNDO_CHAVE.lote, (r) => ouvintesFundo.lote(r && r[FUNDO_CHAVE.lote]));
    return;
  }
  if (pendente && !st.aplicado) {
    loteJob = { job: st.job, run: ++loteRunAtual, contexto: st.contexto, local: false, desde: st.iniciadoEm || 0 };
    loteEmAndamento = true;
    loteModoAtual = st.contexto.modo === "falhas" || st.contexto.modo === "reconsulta" ? st.contexto.modo : "tudo";
    ouvintesFundo.lote(st);
    return;
  }
  if (pendente && !st.visto && painelAberto("lote")) marcarVistoFundo("lote");
}

const reconsultarLote = (destino) => iniciarConsultaLote("reconsulta", destino);

loteConsultarBtn.addEventListener("click", () => iniciarConsultaLote("tudo"));
loteResRetryBtn.addEventListener("click", () => iniciarConsultaLote("falhas"));
loteResReconsultarBtn.addEventListener("click", () => reconsultarLote("resultado"));
loteResCriarBtn.addEventListener("click", () => reconsultarLote("criar"));

function telaCanceladaLote() {
  loteRunAtual++; // invalida tudo o que ainda estiver a caminho
  loteEmAndamento = false;
  zerarAguardoLote();
  // Reconsulta/tentar de novo: volta para o resultado que já existia (nunca
  // para a bipagem ou a tela do lote, que mostrariam números velhos).
  if (loteModoAtual !== "tudo" && loteConsulta) {
    mostrarResultadoLote("Consulta cancelada. Os números são da consulta anterior.");
    return;
  }
  zerarPosicaoBipar();
  mostrarEstadoLote("setup");
}

loteCancelarBtn.addEventListener("click", () => {
  if (loteJob) falarComFundo({ acao: "cancelar", tipo: "lote", job: loteJob.job }).catch(() => {});
  loteJob = null; // o que ainda chegar desta consulta é ignorado
  telaCanceladaLote();
});

loteResVoltarBtn.addEventListener("click", () => mostrarEstadoLote("setup"));

loteResCopiarBtn.addEventListener("click", () => {
  copiarTexto(loteSemLoteAtual.join("\n"), loteFeedback);
});

loteLimparBtn.addEventListener("click", () => {
  const foto = fotografarCampos([loteColeta, loteLotes]);
  loteRunAtual++;
  loteEmAndamento = false;
  loteJob = null;
  falarComFundo({ acao: "limpar", tipo: "lote" }).catch(() => {}); // para a consulta em segundo plano e apaga o andamento
  loteColeta.value = "";
  loteLotes.value = "";
  atualizarInfoLote(loteColeta, loteColetaInfo);
  atualizarInfoLote(loteLotes, loteLotesInfo);
  mostrarErroLote("");
  descartarResultadoLote();
  zerarPosicaoBipar();
  loteAtual = null;
  loteCriar = null;
  chrome.storage.session.remove([LOTE_CAMPOS_KEY, LOTE_RESULT_KEY, LOTE_BIPAR_KEY, LOTE_BIPAR_ANTIGO_KEY, LOTE_ATUAL_KEY, FUNDO_CHAVE.lote]);
  mostrarEstadoLote("setup");
  oferecerDesfazer(foto, "Listas apagadas");
});

// ---- Bipagem: os códigos sem lote em UMA sequência, um código de barras por vez ----
// A extensão NÃO cria lotes nem bipa nada no sistema: ela só mostra o código
// de barras (CODE128, igual à aba Código) do cartão atual — nunca milhares de
// uma vez. Posição p de 0 a X: p < X é o código lista[p]; p = X é o cartão de
// fim, que pede para reconsultar (o fim da lista não é o fim do trabalho).
const loteBipTopo = document.getElementById("lote-bip-topo");
const loteBipSub = document.getElementById("lote-bip-sub");
const loteBipAviso = document.getElementById("lote-bip-aviso");
const loteBarrasSvg = document.getElementById("lote-barras-svg");
const loteBipTexto = document.getElementById("lote-bip-texto");
const loteBipLabel = document.getElementById("lote-bip-label");
const loteBipNota = document.getElementById("lote-bip-nota");
const loteBipPrevBtn = document.getElementById("lote-bip-prev");
const loteBipNextBtn = document.getElementById("lote-bip-next");
const loteBipCriarBtn = document.getElementById("lote-bip-criar");
const loteBipReconsultarBtn = document.getElementById("lote-bip-reconsultar");
const loteBiparVoltarBtn = document.getElementById("lote-bipar-voltar");
const painelLote = document.getElementById("panel-lote");

function zerarPosicaoBipar() {
  lotePos = 0;
  lotePosMax = -1;
  chrome.storage.session.remove(LOTE_BIPAR_KEY);
}

// Contagem salva na sessão: [[lote, n], ...]. Se vier estragada, descarta
// só ela (o resultado continua valendo, sem o cálculo de vagas).
function lerContagemSalva(valor) {
  if (!Array.isArray(valor)) return null;
  const ok = valor.every(
    (par) => Array.isArray(par) && par.length === 2 && typeof par[0] === "string" && typeof par[1] === "number" && Number.isFinite(par[1]) && par[1] >= 0
  );
  return ok ? new Map(valor.map(([lote, n]) => [lote, Math.floor(n)])) : null;
}

// Validadores do que vem da sessão: estragado → null (descartado sem erro).
function lerBiparSalvo(v) {
  if (!v || typeof v !== "object") return null;
  const { pos, max } = v;
  if (!Number.isInteger(pos) || !Number.isInteger(max) || pos < 0 || max < pos) return null;
  return { pos, max };
}

function lerLoteAtualSalvo(v) {
  if (!v || typeof v !== "object" || typeof v.lote !== "string" || !/^[A-Z0-9._-]{1,40}$/.test(v.lote)) return null;
  const ocup = v.ocup === null ? null : Number.isInteger(v.ocup) && v.ocup >= 0 ? v.ocup : undefined;
  return ocup === undefined ? null : { lote: v.lote, ocup };
}

function textoEstimativaLote(total) {
  if (!loteAtual || !Number.isInteger(loteAtual.ocup)) return null;
  const mostrados = Math.min(lotePosMax + 1, total);
  const estimado = loteAtual.ocup + mostrados;
  if (estimado >= LOTE_TAMANHO) {
    return { texto: `Lote ${loteAtual.lote} deve estar com ${LOTE_TAMANHO} (estimativa) — clique em Criar lote.`, aviso: true };
  }
  return { texto: `Lote ${loteAtual.lote} ≈ ${estimado}/${LOTE_TAMANHO} (estimativa)`, aviso: false };
}

function mostrarCartaoLote() {
  const lista = loteSemLoteAtual;
  const total = lista.length;
  if (!total) return;
  lotePos = Math.min(Math.max(0, lotePos), total);
  lotePosMax = Math.min(Math.max(lotePosMax, lotePos), total);
  gravarSessao({ [LOTE_BIPAR_KEY]: { pos: lotePos, max: lotePosMax } });
  const fim = lotePos === total;

  let barras = "";
  let legenda = "";
  let textoCartao = "";
  if (fim) {
    loteBipTopo.textContent = "Fim da lista";
    textoCartao = `${fmtLote(total)} código(s) mostrados`;
  } else {
    loteBipTopo.textContent = `Código ${fmtLote(lotePos + 1)} de ${fmtLote(total)} · restam ${fmtLote(total - lotePos)}`;
    barras = lista[lotePos];
    legenda = barras;
  }
  if (barras) {
    try {
      desenharCodigoBarras(loteBarrasSvg, barras);
    } catch (e) {
      barras = ""; // o código continua na lista; só não dá para desenhar
      legenda = `${legenda} — não foi possível gerar`;
    }
  }
  if (!barras) loteBarrasSvg.replaceChildren();
  loteBarrasSvg.classList.toggle("is-hidden", !barras);
  loteBipTexto.textContent = textoCartao;
  loteBipTexto.classList.toggle("is-hidden", !textoCartao);
  loteBipLabel.textContent = legenda;
  // Fora do fim, a nota mostra os avisos da reconsulta que trouxe até aqui.
  const alertaBip = loteAvisosBip.some((t) => !t.startsWith("Reconsulta:"));
  loteBipNota.textContent = fim
    ? "Ainda não está conferido. Reconsulte: o que entrou em lote sai da lista e o que faltou volta para bipar."
    : loteAvisosBip.join(" ");
  loteBipNota.classList.toggle("tem-aviso", fim || alertaBip);

  const est = textoEstimativaLote(total);
  loteBipSub.textContent = est ? est.texto : "";
  loteBipSub.classList.toggle("tem-aviso", !!(est && est.aviso));
  const plano = lotePlanoAtual;
  loteBipAviso.textContent =
    plano && plano.lotesNovos > 0 ? `Faltam ${fmtLote(plano.lotesNovos)} lote(s) com vaga para os códigos restantes — use Criar lote.` : "";

  loteBipReconsultarBtn.classList.toggle("is-hidden", !fim);
  loteBipPrevBtn.disabled = lotePos === 0;
  loteBipNextBtn.disabled = fim;
  if (fim) loteBipReconsultarBtn.focus();
}

let loteAvisosBip = []; // avisos da reconsulta que levou à bipagem (Continuar)

function abrirBipagem(avisos = []) {
  loteAvisosBip = Array.isArray(avisos) ? avisos : [];
  const plano = lotePlanoAtual;
  if (!plano || !plano.completo || !plano.semLote.length) return; // parcial/sem contagem: nunca abre a bipagem
  mostrarEstadoLote("bipar");
  mostrarCartaoLote();
}

function avancarCartaoLote() {
  if (lotePos < loteSemLoteAtual.length) {
    lotePos++;
    mostrarCartaoLote();
  }
}

function voltarCartaoLote() {
  if (lotePos > 0) {
    lotePos--;
    mostrarCartaoLote();
  }
}

loteResGerarBtn.addEventListener("click", () => abrirBipagem());
loteBipNextBtn.addEventListener("click", avancarCartaoLote);
loteBipPrevBtn.addEventListener("click", voltarCartaoLote);
loteBipCriarBtn.addEventListener("click", () => reconsultarLote("criar"));
loteBipReconsultarBtn.addEventListener("click", () => reconsultarLote("resultado"));
loteBiparVoltarBtn.addEventListener("click", () => {
  if (loteConsulta) mostrarResultadoLote();
});

// ---- Navegação pelo teclado (bipagem do Lote e aba Código) ----
// Feita para milhares de toques por dia: qualquer tecla grande avança
// (Espaço, Enter, →, ↓, Page Down — este é o que passadores de slide e
// pedais mandam) e ←, ↑, Page Up voltam. Só fora de campos de texto e sem
// Ctrl/Alt/⌘ (não rouba atalhos).
// - Tecla segurada não dispara de novo (pularia códigos sem você ver).
//   Na aba Código as setas continuam passando rápido quando seguradas.
// - Espaço/Enter nunca "clicam" o botão que estiver com foco (ex.: Criar lote).
const TECLAS_PROXIMO = new Set([" ", "Spacebar", "Enter", "ArrowRight", "ArrowDown", "PageDown"]);
const TECLAS_ANTERIOR = new Set(["ArrowLeft", "ArrowUp", "PageUp"]);
const TECLAS_DE_CLIQUE = new Set([" ", "Spacebar", "Enter"]);

function ehCampoDeTexto(el) {
  return !!el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.tagName === "SELECT" || el.isContentEditable);
}

// Qual tela navega agora (ou null)
function telaDeNavegacao() {
  if (interfaceBloqueada()) return null;
  if (loteBipar.classList.contains("is-active") && painelLote.classList.contains("is-active")) {
    return { proximo: avancarCartaoLote, anterior: voltarCartaoLote, repeteSetas: false };
  }
  if (barrasViewer.classList.contains("is-active") && painelBarras.classList.contains("is-active")) {
    return { proximo: avancarCodigo, anterior: voltarCodigo, repeteSetas: true };
  }
  return null;
}

document.addEventListener(
  "keydown",
  (e) => {
    if (e.ctrlKey || e.altKey || e.metaKey) return;
    const vai = TECLAS_PROXIMO.has(e.key);
    const volta = TECLAS_ANTERIOR.has(e.key);
    if ((!vai && !volta) || ehCampoDeTexto(e.target)) return;
    const tela = telaDeNavegacao();
    if (!tela) return;
    e.preventDefault();
    e.stopPropagation();
    const seta = e.key.startsWith("Arrow");
    if (e.repeat && !(tela.repeteSetas && seta)) return;
    (vai ? tela.proximo : tela.anterior)();
  },
  true
);
// O "clique" do Espaço num botão acontece ao soltar a tecla: segura aqui também.
document.addEventListener(
  "keyup",
  (e) => {
    if (!TECLAS_DE_CLIQUE.has(e.key) || e.ctrlKey || e.altKey || e.metaKey || ehCampoDeTexto(e.target) || !telaDeNavegacao()) return;
    e.preventDefault();
    e.stopPropagation();
  },
  true
);

// ---- Passar sozinho (autobipe pela câmera) ----
// O app do celular tem "escaneamento contínuo": a câmera fica lendo sem
// tocar na tela. Aqui a extensão troca o código de barras sozinha a cada
// intervalo; o celular, apontado para a tela, vai bipando. Nada fala com o
// celular: se algum código escapar, o Reconsultar devolve ele para a lista.
// Para sozinho: no fim da lista, quando o lote deve ter enchido (Lote), ao
// navegar à mão, trocar de aba/tela ou esconder a janela.
const AUTO_MS_KEY = "auto_passo_ms"; // intervalo escolhido (ms) — só na sessão
const AUTO_MS_MIN = 300;
const AUTO_MS_MAX = 10000;
const AUTO_MS_PADRAO = 1500;

// "1,5", "1.5", "2", " 0,8s " → milissegundos dentro do limite. Inválido → null.
function lerSegundos(valor) {
  const t = String(valor || "").trim().toLowerCase().replace(/s$/, "").trim().replace(",", ".");
  if (!/^\d{1,2}(\.\d{1,2})?$|^\.\d{1,2}$/.test(t)) return null;
  const ms = Math.round(Number(t) * 1000);
  return Number.isFinite(ms) && ms > 0 ? Math.min(AUTO_MS_MAX, Math.max(AUTO_MS_MIN, ms)) : null;
}

// 1500 → "1,5"; 2000 → "2"
const mostrarSegundos = (ms) => String(Math.round(ms / 100) / 10).replace(".", ",");

function criarAutoPasso({ btn, sel, ativo, proximo, podeSeguir }) {
  let timer = null;
  const rodando = () => timer !== null;
  function mostrar() {
    btn.classList.toggle("is-rodando", rodando());
    btn.setAttribute("aria-pressed", rodando() ? "true" : "false");
    btn.textContent = rodando() ? "Pausar" : "Passar sozinho";
  }
  function parar() {
    if (!rodando()) return;
    clearTimeout(timer);
    timer = null;
    mostrar();
  }
  function agendar() {
    timer = setTimeout(() => {
      if (!ativo() || interfaceBloqueada() || document.visibilityState === "hidden") return parar();
      proximo();
      if (!podeSeguir()) return parar();
      agendar();
    }, lerSegundos(sel.value) || AUTO_MS_PADRAO);
  }
  function iniciar() {
    if (rodando() || !ativo() || !podeSeguir()) return;
    timer = 0; // marca como rodando antes do 1º intervalo
    mostrar();
    agendar(); // o código que já está na tela fica o intervalo inteiro
  }
  btn.addEventListener("click", () => (rodando() ? parar() : iniciar()));
  // Ao sair do campo (ou Enter): corrige o valor e vale para as duas telas
  sel.addEventListener("change", () => {
    const ms = lerSegundos(sel.value) || AUTO_MS_PADRAO;
    document.querySelectorAll(".auto-ms").forEach((campo) => (campo.value = mostrarSegundos(ms)));
    gravarSessao({ [AUTO_MS_KEY]: ms });
    if (rodando()) {
      clearTimeout(timer);
      agendar();
    }
  });
  return { parar, rodando };
}

// Lote: segue enquanto houver código e o lote atual não tiver enchido (estimativa)
const loteAutoMs = document.getElementById("lote-auto-ms");
const barrasAutoMs = document.getElementById("barras-auto-ms");
const loteAuto = criarAutoPasso({
  btn: document.getElementById("lote-auto-btn"),
  sel: loteAutoMs,
  ativo: () => loteBipar.classList.contains("is-active") && painelLote.classList.contains("is-active"),
  proximo: avancarCartaoLote,
  podeSeguir: () => {
    const total = loteSemLoteAtual.length;
    if (lotePos >= total) return false; // cartão de fim: hora de reconsultar
    const est = textoEstimativaLote(total);
    return !(est && est.aviso); // lote deve estar cheio: para para criar outro
  },
});
const barrasAuto = criarAutoPasso({
  btn: document.getElementById("barras-auto-btn"),
  sel: barrasAutoMs,
  ativo: () => barrasViewer.classList.contains("is-active") && painelBarras.classList.contains("is-active"),
  proximo: avancarCodigo,
  podeSeguir: () => indiceCodigoAtual < listaCodigos.length - 1,
});

function pararAutoPasso() {
  loteAuto.parar();
  barrasAuto.parar();
}

// Navegar à mão (botões ou teclado), trocar de aba ou esconder a janela: para
[loteBipPrevBtn, loteBipNextBtn, loteBipCriarBtn, loteBiparVoltarBtn, barrasPrevBtn, barrasNextBtn, barrasRemoverBtn, barrasVoltarBtn].forEach((b) =>
  b.addEventListener("click", pararAutoPasso, true)
);
tabButtons.forEach((b) => b.addEventListener("click", pararAutoPasso));
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "hidden") pararAutoPasso();
});
document.addEventListener(
  "keydown",
  (e) => {
    if (e.ctrlKey || e.altKey || e.metaKey || ehCampoDeTexto(e.target)) return;
    if (TECLAS_PROXIMO.has(e.key) || TECLAS_ANTERIOR.has(e.key) || e.key === "Escape") pararAutoPasso();
  },
  true
);

chrome.storage.session.get(AUTO_MS_KEY, (r) => {
  const ms = r && Number(r[AUTO_MS_KEY]);
  if (Number.isFinite(ms) && ms >= AUTO_MS_MIN && ms <= AUTO_MS_MAX && !document.activeElement.classList.contains("auto-ms")) {
    loteAutoMs.value = barrasAutoMs.value = mostrarSegundos(ms);
  }
});
// Enter no campo do tempo: confirma o valor (sem passar código)
[loteAutoMs, barrasAutoMs].forEach((campo) =>
  campo.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      campo.dispatchEvent(new Event("change"));
      campo.blur();
    }
  })
);

// ---- Criar lote: mostra o código de barras de UM lote da lista com vaga ----
const loteCriarTitulo = document.getElementById("lote-criar-titulo");
const loteCriarInfo = document.getElementById("lote-criar-info");
const loteCriarAviso = document.getElementById("lote-criar-aviso");
const loteCriarFalta = document.getElementById("lote-criar-falta");
const loteCriarCom = document.getElementById("lote-criar-com");
const loteCriarSvg = document.getElementById("lote-criar-svg");
const loteCriarLabel = document.getElementById("lote-criar-label");
const loteCriarContinuarBtn = document.getElementById("lote-criar-continuar");
const loteCriarOutroBtn = document.getElementById("lote-criar-outro");
const loteCriarVoltarBtn = document.getElementById("lote-criar-voltar");
const loteAdd = document.getElementById("lote-add");
const loteAddCampo = document.getElementById("lote-add-campo");
const loteAddErro = document.getElementById("lote-add-erro");
const loteAddBtn = document.getElementById("lote-add-btn");

function mostrarLoteCandidato() {
  const { candidatos, i } = loteCriar;
  const temLote = candidatos.length > 0;
  loteCriarCom.classList.toggle("is-hidden", !temLote);
  loteAdd.classList.toggle("is-hidden", temLote);
  loteCriarFalta.classList.toggle("is-hidden", temLote);
  loteCriarInfo.classList.toggle("is-hidden", !temLote);
  loteCriarOutroBtn.classList.toggle("is-hidden", candidatos.length < 2);
  // Mostra em qual dos lotes com vaga está (o último volta ao primeiro)
  loteCriarOutroBtn.textContent = `Outro lote · ${i + 1} de ${candidatos.length}`;
  if (!temLote) {
    const plano = lotePlanoAtual;
    loteCriarTitulo.textContent = "Nenhum lote da lista tem vaga";
    loteCriarFalta.textContent =
      `Faltam ${fmtLote(plano.lotesNovos)} lote(s) para ${fmtLote(plano.semLote.length)} código(s) sem lote. Crie no JMS e cole abaixo.`;
    loteCriarSvg.replaceChildren();
    loteCriarLabel.textContent = "";
    return;
  }
  const lote = candidatos[i];
  const ocup = loteConsulta.contagem.get(lote);
  loteCriarTitulo.textContent = "Bipe este lote no app";
  loteCriarInfo.textContent =
    ocup === 0
      ? `${lote} — não usado (0/${LOTE_TAMANHO})`
      : `${lote} — incompleto: ${ocup}/${LOTE_TAMANHO} · cabem mais ${LOTE_TAMANHO - ocup}`;
  let legenda = lote;
  try {
    desenharCodigoBarras(loteCriarSvg, lote);
  } catch (e) {
    loteCriarSvg.replaceChildren();
    legenda = `${lote} — não foi possível gerar`;
  }
  loteCriarLabel.textContent = legenda;
}

function abrirTelaLote(avisos = []) {
  const plano = lotePlanoAtual;
  if (!plano || !plano.completo || !plano.semLote.length) return; // parcial/sem contagem: nunca mostra lote
  loteCriar = { candidatos: plano.candidatos.slice(), i: 0 };
  loteCriarAviso.textContent = avisos.join(" ");
  loteAddErro.textContent = "";
  mostrarLoteCandidato();
  mostrarEstadoLote("criar");
  if (loteCriar.candidatos.length) loteCriarContinuarBtn.focus();
  else loteAddCampo.focus();
}

// Passa para o próximo lote com vaga da mesma consulta (sem requisição).
function outroLoteCandidato() {
  if (loteEmAndamento || !loteCriar || loteCriar.candidatos.length < 2) return;
  loteCriar.i = (loteCriar.i + 1) % loteCriar.candidatos.length;
  mostrarLoteCandidato();
}

// Lotes criados no JMS: anexa à lista de Lotes (sem perder o progresso) e reconsulta.
function adicionarLotesNovos() {
  if (loteEmAndamento) return;
  loteAddErro.textContent = "";
  const a = analisarCodigos(loteAddCampo.value);
  if (!a.codigos.length) {
    marcarCampoLoteInvalido(loteAddCampo);
    loteAddErro.textContent = "Cole pelo menos um código de lote (BR...).";
    return;
  }
  const daColeta = new Set(analisarCodigos(loteColeta.value).codigos);
  const errado = a.codigos.find((codigo) => daColeta.has(codigo));
  if (errado) {
    marcarCampoLoteInvalido(loteAddCampo);
    loteAddErro.textContent = `${errado} é um código da coleta, não de lote.`;
    return;
  }
  const jaNaLista = new Set(analisarCodigos(loteLotes.value).codigos);
  const novos = a.codigos.filter((codigo) => !jaNaLista.has(codigo));
  if (!novos.length) {
    marcarCampoLoteInvalido(loteAddCampo);
    loteAddErro.textContent = "Esses lotes já estão na lista.";
    return;
  }
  // Sem disparar "input": mudar a lista por aqui não descarta o resultado atual.
  const atual = loteLotes.value.replace(/\s*$/, "");
  loteLotes.value = (atual ? atual + "\n" : "") + novos.join("\n");
  atualizarInfoLote(loteLotes, loteLotesInfo);
  loteCamposVelhos = false;
  loteCamposSujos = true;
  salvarCamposLote();
  loteAddCampo.value = "";
  loteAddCampo.classList.remove("lote-invalid");
  reconsultarLote("criar");
}

loteCriarContinuarBtn.addEventListener("click", () => {
  if (loteEmAndamento || !loteCriar || !loteCriar.candidatos.length) return;
  // Continuar sempre consulta tudo de novo: o que foi bipado sai da lista.
  iniciarConsultaLote("reconsulta", "bipar", { loteEscolhido: loteCriar.candidatos[loteCriar.i] });
});
loteCriarOutroBtn.addEventListener("click", outroLoteCandidato);
loteCriarVoltarBtn.addEventListener("click", () => {
  loteCriar = null;
  if (loteConsulta) mostrarResultadoLote();
});
loteAddBtn.addEventListener("click", adicionarLotesNovos);
loteAddCampo.addEventListener("input", () => {
  loteAddCampo.classList.remove("lote-invalid");
  loteAddErro.textContent = "";
});

chrome.storage.session.get([LOTE_CAMPOS_KEY, LOTE_RESULT_KEY, LOTE_BIPAR_KEY, LOTE_BIPAR_ANTIGO_KEY, LOTE_ATUAL_KEY, FUNDO_CHAVE.lote], (resultado) => {
  if (LOTE_BIPAR_ANTIGO_KEY in resultado) chrome.storage.session.remove(LOTE_BIPAR_ANTIGO_KEY); // posição da 3.9.0 não vale na sequência nova
  const campos = resultado[LOTE_CAMPOS_KEY];
  // Se a pessoa já começou a colar antes de carregar, o que ela colou vence
  // (e o resultado antigo, que não corresponde mais, é descartado).
  const colouAntes = !!(loteColeta.value || loteLotes.value);
  if (campos && !colouAntes) {
    loteColeta.value = typeof campos.coleta === "string" ? campos.coleta : "";
    loteLotes.value = typeof campos.lotes === "string" ? campos.lotes : "";
    atualizarInfoLote(loteColeta, loteColetaInfo);
    atualizarInfoLote(loteLotes, loteLotesInfo);
  }
  loteCamposCarregados = true;
  if (colouAntes) {
    salvarCamposLote();
    // Só apaga o que é da sessão antiga: se já houve consulta nesta janela
    // (colou e consultou antes de carregar), o resultado salvo é o novo.
    if (!loteConsulta) chrome.storage.session.remove([LOTE_RESULT_KEY, LOTE_BIPAR_KEY, LOTE_ATUAL_KEY]);
    verFundoLoteAoAbrir(resultado[FUNDO_CHAVE.lote], { colouAntes: true });
    return;
  }

  const bip = lerBiparSalvo(resultado[LOTE_BIPAR_KEY]);
  if (bip) {
    lotePos = bip.pos;
    lotePosMax = bip.max;
  } else if (LOTE_BIPAR_KEY in resultado) chrome.storage.session.remove(LOTE_BIPAR_KEY);
  loteAtual = lerLoteAtualSalvo(resultado[LOTE_ATUAL_KEY]);
  if (!loteAtual && LOTE_ATUAL_KEY in resultado) chrome.storage.session.remove(LOTE_ATUAL_KEY);

  const salvo = resultado[LOTE_RESULT_KEY];
  const valido = salvo && [salvo.coleta, salvo.lotes, salvo.encontrados, salvo.falhas, salvo.vazios].every(Array.isArray);
  if (valido) {
    try {
      loteConsulta = {
        coleta: salvo.coleta.map(String),
        lotes: salvo.lotes.map(String),
        encontrados: new Set(salvo.encontrados.map(String)),
        falhas: new Map(salvo.falhas.map(([lote, motivo]) => [String(lote), String(motivo)])),
        vazios: new Set(salvo.vazios.map(String)),
        contagem: lerContagemSalva(salvo.contagem),
        em: Number.isFinite(salvo.em) ? salvo.em : null,
        daMemoria: Number.isFinite(salvo.daMemoria) && salvo.daMemoria > 0 ? salvo.daMemoria : 0,
        // Resultado da 3.9.0 (sem a lista): confere de novo na coleta colada,
        // para nunca mostrar "tudo em lote" com item inválido na coleta.
        invalidos: Array.isArray(salvo.invalidos) ? salvo.invalidos.map(String) : analisarCodigos(loteColeta.value).suspeitos,
      };
      mostrarResultadoLote();
    } catch (e) {
      loteConsulta = null; // dado salvo estragado: começa do zero em vez de quebrar a aba
      chrome.storage.session.remove(LOTE_RESULT_KEY);
    }
  } else if (bip) zerarPosicaoBipar(); // posição sem resultado não serve para nada
  verFundoLoteAoAbrir(resultado[FUNDO_CHAVE.lote]);
});

// ---------- ABA EXPEDIDO NÃO CHEGOU ----------
// Recebe uma lista de rastreios, consulta o rastreio de cada um no JMS (a
// mesma consulta da tela "Rastreamento" do sistema) e devolve só os códigos
// cujo ÚLTIMO evento é "Encomenda expedida mas não chegou".
//
// Mesmas garantias da aba Lote: o fetch roda dentro da aba do JMS, o token é
// lido na hora (nunca guardado nem exibido) e as consultas usam a MESMA fila
// do Lote (uma por vez no total, com pausa entre elas), então as duas abas
// juntas nunca passam desse ritmo. O motor fica em consulta-core.js e roda
// no background.js (a consulta continua com o popup fechado).

let expRunAtual = 0;
let expEmAndamento = false;


// ---- Interface ----
const expCodigos = document.getElementById("exp-codigos");
const expCodigosInfo = document.getElementById("exp-codigos-info");
const expErro = document.getElementById("exp-erro");
const expSetup = document.getElementById("exp-setup");
const expProgresso = document.getElementById("exp-progresso");
const expResultado = document.getElementById("exp-resultado");
const expConsultarBtn = document.getElementById("exp-consultar");
const expLimparBtn = document.getElementById("exp-limpar");
const expCancelarBtn = document.getElementById("exp-cancelar");
const expBarra = document.getElementById("exp-barra");
const expBarraPreench = document.getElementById("exp-barra-preench");
const expProgressoTexto = document.getElementById("exp-progresso-texto");
const expProgressoExtra = document.getElementById("exp-progresso-extra");
const expResTitulo = document.getElementById("exp-res-titulo");
const expResLista = document.getElementById("exp-res-lista");
const expResResumo = document.getElementById("exp-res-resumo");
const expResAvisos = document.getElementById("exp-res-avisos");
const expResRetryBtn = document.getElementById("exp-res-retry");
const expResVoltarBtn = document.getElementById("exp-res-voltar");
const expResCopiarBtn = document.getElementById("exp-res-copiar");
const expFeedback = document.getElementById("exp-feedback");
const expAcesso = document.getElementById("exp-acesso");
const expAcessoTexto = document.getElementById("exp-acesso-texto");
const expAcessoBtn = document.getElementById("exp-acesso-btn");

const EXP_CAMPOS_KEY = "exp_campos";
const EXP_RESULT_KEY = "exp_resultado";

// { codigos, expedidos:Set, outros:Set, semRastreio:Set, falhas:Map, invalidos, em }
let expConsulta = null;
let expModoAtual = "tudo";
let expCamposCarregados = false;
let expAcessoTipo = "ok";

function mostrarEstadoExp(qual) {
  expSetup.classList.toggle("is-hidden", qual !== "setup");
  expProgresso.classList.toggle("is-active", qual === "progresso");
  expResultado.classList.toggle("is-active", qual === "resultado");
}

function mostrarErroExp(mensagem) {
  expErro.textContent = mensagem;
}

function mostrarAvisoAcessoExp(tipo) {
  expAcessoTipo = tipo;
  const problema = tipo === "recarregar" || tipo === "permitir";
  expAcesso.classList.toggle("is-hidden", !problema);
  if (!problema) return;
  mostrarErroExp("");
  expAcessoTexto.textContent = LOTE_MSG[tipo];
  expAcessoBtn.textContent = tipo === "recarregar" ? "Recarregar extensão" : "Permitir acesso";
}

expAcessoBtn.addEventListener("click", async () => {
  if (expAcessoTipo === "recarregar") {
    chrome.runtime.reload();
    return;
  }
  try {
    const ok = await chrome.permissions.request({ origins: [LOTE_API.padraoAba] });
    if (ok) {
      mostrarAvisoAcessoExp("ok");
      mostrarAvisoAcessoLote("ok");
    }
  } catch (e) {
    /* recusado: o aviso continua */
  }
});

verificarAcessoLote().then(mostrarAvisoAcessoExp, () => {});

function salvarCamposExp() {
  if (!expCamposCarregados) return;
  gravarSessao({ [EXP_CAMPOS_KEY]: { codigos: expCodigos.value } }, () =>
    mostrarErroExp("A lista é grande demais para ficar salva: se o popup fechar, ela não volta. Consulte com ele aberto.")
  );
}

function descartarResultadoExp() {
  expConsulta = null;
  chrome.storage.session.remove(EXP_RESULT_KEY);
}

function salvarResultadoExp() {
  if (!expConsulta) return;
  const c = expConsulta;
  gravarSessao({
    [EXP_RESULT_KEY]: {
      codigos: c.codigos,
      expedidos: [...c.expedidos],
      outros: [...c.outros],
      semRastreio: [...c.semRastreio],
      falhas: [...c.falhas],
      invalidos: c.invalidos,
      em: c.em,
    },
  });
}

// Aviso de espera (o sistema pediu pausa ou pausa preventiva), com contagem regressiva
let expAguardo = { ate: 0, motivo: "" };
let expAguardoTimer = null;
function textoAguardoExp(ate, motivo, agora = Date.now()) {
  const seg = Math.ceil((ate - agora) / 1000);
  if (!ate || seg <= 0) return "";
  const quando = seg >= 60 ? `${Math.floor(seg / 60)} min ${String(seg % 60).padStart(2, "0")} s` : `${seg} s`;
  if (motivo === "preventiva") return `Pausa preventiva para o sistema não travar: continua em ${quando}.`;
  if (motivo === "limite") return `O sistema bloqueou por ~1 minuto (limite de consultas). Testando de novo o mesmo código em ${quando}…`;
  if (motivo === "rajada") return `Pausa do minuto (o sistema aceita ~60 consultas por minuto): continua em ${quando}…`;
  if (motivo === "repasse") return `Quase lá: refazendo os que deram erro em ${quando}…`;
  return `O sistema pediu uma pausa. Tentando de novo o mesmo código em ${quando}…`;
}
function mostrarAguardoExp() {
  clearTimeout(expAguardoTimer);
  const t = textoAguardoExp(expAguardo.ate, expAguardo.motivo);
  if (!t) return;
  expProgressoExtra.textContent = t;
  expAguardoTimer = setTimeout(mostrarAguardoExp, 1000);
}

function atualizarProgressoExp(feitos, total, texto, aguardandoAte = 0, aguardandoMotivo = "") {
  const pct = total ? Math.round((feitos / total) * 100) : 0;
  expBarraPreench.style.width = `${pct}%`;
  expBarra.setAttribute("aria-valuenow", String(pct));
  expProgressoTexto.textContent = texto || `${fmtLote(feitos)} de ${fmtLote(total)} rastreios consultados`;
  expProgressoExtra.textContent = texto ? "" : textoEstimativaExp(feitos, total);
  expAguardo = { ate: Number(aguardandoAte) || 0, motivo: String(aguardandoMotivo || "") };
  if (!texto) mostrarAguardoExp();
}

// Estimativa pelo ritmo REAL medido nesta consulta (o ritmo é adaptativo).
// Até ter medida suficiente, usa ~0,8 s por código.
let expMedida = null; // { total, feitos0, t0 }
function textoEstimativaExp(feitos, total, agora = Date.now()) {
  const faltam = Math.max(0, total - feitos);
  if (!faltam) return "";
  if (!expMedida || expMedida.total !== total || feitos < expMedida.feitos0) expMedida = { total, feitos0: feitos, t0: agora };
  const andou = feitos - expMedida.feitos0;
  const passou = (agora - expMedida.t0) / 1000;
  // Em rajadas o começo é rápido, mas o sistema só aceita ~60 por minuto:
  // listas grandes nunca saem mais rápido que ~1 s por código.
  const medido = andou >= 10 && passou >= 3 ? passou / andou : 1;
  const porCodigo = faltam > 60 ? Math.max(1, medido) : medido;
  const seg = faltam * porCodigo;
  if (seg < 60) return "Falta menos de 1 minuto.";
  const min = Math.ceil(seg / 60);
  return `Falta${min > 1 ? "m" : ""} cerca de ${min} minuto${min > 1 ? "s" : ""}.`;
}

// ---- Diagnóstico (texto para copiar e enviar) ----
const EXP_DIAG_CHAVE = "exp_diag";
const EXP_RITMO_KEY = "exp_ritmo";
const horaDiag = (t) => (Number.isFinite(t) ? new Date(t).toLocaleTimeString("pt-BR", { hour12: false }) : "--:--:--");
function segDiag(ms) {
  const s2 = Math.round((Number(ms) || 0) / 1000);
  return s2 >= 60 ? `${Math.floor(s2 / 60)} min ${s2 % 60} s` : `${s2} s`;
}
// Função pura: monta o relatório (nunca há token nos dados)
function textoDiagnosticoExp(diag, ritmo, versao, agora = Date.now()) {
  if (!diag || !Array.isArray(diag.linhas) || !diag.linhas.length) return "";
  const L = diag.linhas.filter((x) => x && typeof x === "object");
  const consultas = L.filter((x) => x.cod);
  const conta = (f) => consultas.filter(f).length;
  const cfg = diag.config || {};
  const out = [];
  out.push(`Diagnóstico Expedido — extensão v${versao} — gerado ${new Date(agora).toLocaleString("pt-BR", { hour12: false })}`);
  out.push(`Consulta iniciada às ${horaDiag(diag.inicio)}${diag.fim ? ` · terminou às ${horaDiag(diag.fim)}` : " · ainda rodando"} · ${consultas.length} requisição(ões)`);
  out.push(
    cfg.janelaMs
      ? `Ritmo: rajada${cfg.rajadaCota ? ` de ${cfg.rajadaCota} por minuto` : ""} · ${cfg.concorrenciaMax || 1} por vez · folga ${cfg.pausaMinMs}–${cfg.pausaMaxMs} ms · no bloqueio espera ${segDiag(cfg.janelaMs + (cfg.janelaMargemMs || 0))} e testa a cada ${segDiag(cfg.sondaMs)} · teto ${segDiag(cfg.limiteTetoMs)} por código`
      : `Ritmo: ${cfg.concorrenciaMax || 1} por vez · pausa ${cfg.pausaMinMs}–${cfg.pausaMaxMs} ms · esperas ${(cfg.esperasLimiteMs || []).map((m) => m / 1000).join("/")} s · teto ${segDiag(cfg.limiteTetoMs)} por código`
  );
  const janelas = L.filter((x) => x.tipo === "janela");
  const rajadas = L.filter((x) => x.tipo === "rajada");
  const cotas = L.filter((x) => x.tipo === "cota");
  if (rajadas.length) out.push(`Rajadas completas: ${rajadas.length} (${rajadas.map((x) => x.enviadas).join(", ")} consultas)${cotas.length ? ` · rajada diminuiu para ${cotas[cotas.length - 1].cota}` : ""}`);
  if (janelas.length) {
    out.push(`Aceitas antes do bloqueio: ${janelas.map((x) => x.aceitas).join(", ")} (em ${janelas.map((x) => segDiag(x.duracaoMs)).join(", ")})`);
    out.push(`Bloqueio durou: ${janelas.map((x) => segDiag(x.bloqueioMs)).join(", ")}`);
  } else if (cfg.janelaMs) {
    out.push("Bloqueios: nenhum");
  } else {
    out.push(ritmo && ritmo.cota ? `Limite aprendido: trava depois de ~${ritmo.cota} consultas; leva ~${segDiag(ritmo.pausaMs)} para liberar` : "Limite aprendido: ainda não");
  }
  out.push(
    `Respostas: ok ${conta((x) => x.tipo === "ok")} · Expedido não chegou ${conta((x) => x.exp)} · limite ${conta((x) => x.tipo === "limite")} · suspeitas ${conta((x) => x.tipo === "suspeito")} · erro de rede/servidor ${conta((x) => x.tipo === "tentar")} · falha ${conta((x) => x.tipo === "falha")}`
  );
  const esperas = L.filter((x) => x.tipo === "espera" || x.tipo === "pausa");
  out.push(`Esperas: ${esperas.length} · total ${segDiag(esperas.reduce((t, x) => t + (Number(x.esperaMs) || 0), 0))}`);
  out.push("");
  out.push("hora | ms | código | http | code | msg | itens | eventos | último status | entendido | motivo");
  for (const x of L) {
    if (x.cod) {
      out.push(
        [horaDiag(x.t), x.ms, mascararCodigosDiag(x.cod), x.http, x.code, x.msg, x.itens == null ? "-" : x.itens, x.eventos == null ? "-" : x.eventos, x.status || "-", x.tipo + (x.exp ? " EXP" : ""), [x.prova ? `prova para ${mascararCodigosDiag(x.prova)}` : "", x.motivo, x.retryAfter ? `retry-after ${x.retryAfter}` : ""].filter(Boolean).join(" ")].join(" | ")
      );
    } else if (x.tipo === "espera") {
      out.push(`${horaDiag(x.t)} | -- espera ${segDiag(x.esperaMs)} (${x.motivo}; ${x.tentativaNoCodigo}ª no mesmo código; ${x.seguidasAntes} boas antes de travar)`);
    } else if (x.tipo === "pausa") {
      out.push(`${horaDiag(x.t)} | -- pausa ${x.motivo} ${segDiag(x.esperaMs)} (limite aprendido ~${x.cota})`);
    } else if (x.tipo === "recuperou") {
      out.push(`${horaDiag(x.t)} | -- rede de segurança: ${x.n} código(s) sem resposta voltaram para a fila`);
    } else if (x.tipo === "sem-rastreio") {
      out.push(`${horaDiag(x.t)} | -- ${x.codigo}: sem rastreio (${x.motivo})`);
    } else if (x.tipo === "rajada") {
      out.push(`${horaDiag(x.t)} | -- pausa do minuto: ${x.enviadas} consultas em ${segDiag(x.duracaoMs)}; espera ${segDiag(x.esperaMs)}`);
    } else if (x.tipo === "cota") {
      out.push(`${horaDiag(x.t)} | -- bloqueou depois de ${x.aceitas}: rajada diminuiu para ${x.cota}`);
    } else if (x.tipo === "janela") {
      out.push(`${horaDiag(x.t)} | -- liberou: aceitou ${x.aceitas} em ${segDiag(x.duracaoMs)} antes do bloqueio; bloqueio durou ${segDiag(x.bloqueioMs)}`);
    } else if (x.tipo === "aprendeu") {
      out.push(`${horaDiag(x.t)} | -- aprendeu: trava depois de ~${x.cota}; libera em ~${segDiag(x.esperaMs)}`);
    }
  }
  return out.join("\n");
}

// O diagnóstico costuma ser colado em conversas: os códigos de pedido vão
// mascarados (início e fim, que bastam para achar o caso), nunca inteiros.
function mascararCodigosDiag(cod) {
  return String(cod || "")
    .split("+")
    .map((c) => (c.length > 8 ? `${c.slice(0, 4)}…${c.slice(-4)}` : c))
    .join("+");
}

function copiarDiagnosticoExp(feedbackEl) {
  chrome.storage.session.get([EXP_DIAG_CHAVE, EXP_RITMO_KEY], (r) => {
    let texto = "";
    try {
      texto = textoDiagnosticoExp(r && r[EXP_DIAG_CHAVE], r && r[EXP_RITMO_KEY], chrome.runtime.getManifest().version);
    } catch (e) {
      texto = "";
    }
    if (!texto) {
      mostrarFeedback(feedbackEl, { texto: "Ainda não há diagnóstico: rode uma consulta", erro: true, ms: 2200 });
      return;
    }
    navigator.clipboard.writeText(texto).then(
      () => mostrarFeedback(feedbackEl, { texto: "Diagnóstico copiado" }),
      () => mostrarFeedback(feedbackEl, { texto: "Não foi possível copiar", erro: true, ms: 2200 })
    );
  });
}

// Mostra o resultado. Só lista os que o sistema CONFIRMOU com o último status
// "Expedido não chegou"; os que falharam aparecem como aviso, nunca somem.
function mostrarResultadoExp(avisoExtra = "") {
  const c = expConsulta;
  if (!c) {
    mostrarEstadoExp("setup");
    return;
  }
  const lista = c.codigos.filter((cod) => c.expedidos.has(cod));
  expResTitulo.textContent = `Expedido não chegou: ${fmtLote(lista.length)}`;
  expResLista.value = lista.join("\n");
  expResLista.classList.toggle("is-hidden", lista.length === 0);
  expResCopiarBtn.disabled = lista.length === 0;
  const partes = [`Consultados: ${fmtLote(c.codigos.length - c.falhas.size)}/${fmtLote(c.codigos.length)}`, `Outro status: ${fmtLote(c.outros.size)}`];
  if (c.semRastreio.size) partes.push(`Sem rastreio: ${fmtLote(c.semRastreio.size)}`);
  expResResumo.textContent = partes.join(" · ");

  const avisos = [];
  if (avisoExtra) avisos.push(avisoExtra);
  if (c.falhas.size) {
    const nomes = [...c.falhas.keys()];
    avisos.push(
      `Atenção: ${fmtLote(c.falhas.size)} código(s) não puderam ser consultados (${nomes.slice(0, 2).join(", ")}${nomes.length > 2 ? ` +${nomes.length - 2}` : ""}). Eles podem estar com "Expedido não chegou" — clique em Tentar de novo.`
    );
  }
  if (c.invalidos && c.invalidos.length) {
    avisos.push(`Atenção: ${c.invalidos.length} item(ns) inválido(s) na lista não foram consultados (${c.invalidos.slice(0, 2).map(mostravel).join(", ")}).`);
  }
  if (!lista.length && !c.falhas.size) avisos.push("Nenhum código está com o último status Expedido não chegou.");
  expResAvisos.textContent = avisos.join(" ");
  expResAvisos.classList.toggle("tem-aviso", avisos.some((t) => t.startsWith("Atenção")));
  expResRetryBtn.classList.toggle("is-hidden", c.falhas.size === 0);
  mostrarEstadoExp("resultado");
}

// Consulta que esta janela acompanha: { job, run, contexto, local } (igual ao Lote).
let expJob = null;

function serializarConsultaExp(c) {
  return {
    codigos: c.codigos,
    expedidos: [...c.expedidos],
    outros: [...c.outros],
    semRastreio: [...c.semRastreio],
    falhas: [...c.falhas],
    invalidos: c.invalidos || [],
    em: Number.isFinite(c.em) ? c.em : null,
  };
}

function lerConsultaExpSerializada(s) {
  return {
    codigos: s.codigos.map(String),
    expedidos: new Set(s.expedidos.map(String)),
    outros: new Set(s.outros.map(String)),
    semRastreio: new Set(s.semRastreio.map(String)),
    falhas: new Map(s.falhas.map(([cod, motivo]) => [String(cod), String(motivo)])),
    invalidos: Array.isArray(s.invalidos) ? s.invalidos.map(String) : [],
    em: Number.isFinite(s.em) ? s.em : null,
  };
}

async function iniciarConsultaExp(modo = "tudo") {
  if (expEmAndamento) return;
  mostrarErroExp("");
  const base = modo === "falhas" && expConsulta && expConsulta.falhas.size ? expConsulta : null;
  let codigos;
  let invalidos;
  if (base) {
    codigos = [...base.falhas.keys()];
    invalidos = base.invalidos;
  } else {
    const a = analisarCodigos(expCodigos.value);
    if (!a.codigos.length) {
      mostrarEstadoExp("setup");
      marcarCampoLoteInvalido(expCodigos);
      mostrarErroExp(a.suspeitos.length ? `Nenhum código válido na lista (${a.suspeitos.slice(0, 2).map(mostravel).join(", ")}).` : "Cole a lista de códigos.");
      return;
    }
    codigos = a.codigos;
    invalidos = a.suspeitos.slice();
    descartarResultadoExp();
  }

  expEmAndamento = true;
  expModoAtual = base ? "falhas" : "tudo";
  const run = ++expRunAtual;
  atualizarProgressoExp(0, codigos.length, "Preparando a consulta…");
  mostrarEstadoExp("progresso");

  const contexto = { modo: expModoAtual, codigos, invalidos, base: base ? serializarConsultaExp(base) : null };
  const params = { codigos, baseExpedidos: base ? base.expedidos.size : 0 };
  const job = novoIdConsulta();
  expJob = { job, run, contexto, local: true, desde: Date.now() };
  falarComFundo({ acao: "iniciar", tipo: "exp", job, params, contexto }).then(
    (r) => {
      if (!r.ok) falhaExp(job, new ErroLote("fundo", r.bloqueado ? EXP_MSG.generico : LOTE_MSG.semFundo), { cancelar: false });
    },
    () => falhaExp(job, new ErroLote("fundo", LOTE_MSG.semFundo), { cancelar: false })
  );
}

ouvintesFundo.exp = (st) => {
  if (foiSubstituida(expJob, st)) {
    expJob = null;
    telaCanceladaExp();
    mostrarErroExp(MSG_SUBSTITUIDA);
    return;
  }
  if (!expJob || !st || st.job !== expJob.job) return; // de outra consulta (cancelada/antiga): ignorada
  try {
    if (st.estado === "rodando") {
      if (!st.preparando) atualizarProgressoExp(st.feitos, st.total, "", st.aguardandoAte, st.aguardandoMotivo);
    } else if (st.estado === "pronto") aplicarFundoExp(st);
    else if (st.estado === "erro") falhaExp(st.job, erroDoFundo(st.erro, EXP_MSG.generico), { aplicado: true });
    else if (st.estado === "cancelado") {
      expJob = null;
      telaCanceladaExp();
    }
  } catch (e) {
    falhaExp(st.job, e, { aplicado: st.estado !== "rodando" });
  }
};

function aplicarFundoExp(st) {
  const { contexto: cx, local } = expJob;
  expJob = null;
  expEmAndamento = false;
  const res = st.resultado || {};
  const r = {
    expedidos: new Set(res.expedidos || []),
    outros: new Set(res.outros || []),
    semRastreio: new Set(res.semRastreio || []),
    falhas: new Map(res.falhas || []),
  };
  const agora = local || !Number.isFinite(st.atualizadoEm) ? Date.now() : st.atualizadoEm;
  const base = cx.base ? lerConsultaExpSerializada(cx.base) : null;
  if (base) {
    // Refaz só os que falharam: junta com o que já estava confirmado
    r.expedidos.forEach((x) => base.expedidos.add(x));
    r.outros.forEach((x) => base.outros.add(x));
    r.semRastreio.forEach((x) => base.semRastreio.add(x));
    expConsulta = { ...base, falhas: r.falhas, em: Math.min(base.em || agora, agora) };
  } else {
    expConsulta = { codigos: cx.codigos, expedidos: r.expedidos, outros: r.outros, semRastreio: r.semRastreio, falhas: r.falhas, invalidos: cx.invalidos || [], em: agora };
  }
  salvarResultadoExp();
  mostrarResultadoExp();
  marcarAplicadoFundo("exp", st.job);
}

function falhaExp(job, e, { cancelar = true, aplicado = false } = {}) {
  if (!expJob || expJob.job !== job) return;
  const { contexto } = expJob;
  expJob = null;
  if (aplicado) marcarAplicadoFundo("exp", job);
  else if (cancelar) falarComFundo({ acao: "cancelar", tipo: "exp", job }).catch(() => {});
  expRunAtual++;
  expEmAndamento = false;
  const reserva = contexto.modo === "falhas" && expConsulta;
  const mensagem = e instanceof ErroLote ? e.message : EXP_MSG.generico;
  if (e instanceof ErroLote && (e.tipo === "recarregar" || e.tipo === "permitir")) {
    mostrarAvisoAcessoExp(e.tipo);
    if (reserva) mostrarResultadoExp(mensagem);
    else mostrarEstadoExp("setup");
    return;
  }
  if (reserva) mostrarResultadoExp(mensagem);
  else {
    mostrarEstadoExp("setup");
    mostrarErroExp(mensagem);
  }
}

function verFundoExpAoAbrir(st, { colouAntes = false } = {}) {
  if (!st || typeof st !== "object" || typeof st.job !== "string" || !st.contexto || expJob || expEmAndamento) return;
  const pendente = st.estado === "pronto" || st.estado === "erro";
  if (colouAntes) {
    if (st.estado === "rodando") falarComFundo({ acao: "cancelar", tipo: "exp", job: st.job }).catch(() => {});
    else if (pendente && !st.aplicado) marcarAplicadoFundo("exp", st.job);
    return;
  }
  if (st.estado === "rodando" || (pendente && !st.aplicado)) {
    expJob = { job: st.job, run: ++expRunAtual, contexto: st.contexto, local: false, desde: st.iniciadoEm || 0 };
    expEmAndamento = true;
    expModoAtual = st.contexto.modo === "falhas" ? "falhas" : "tudo";
    if (st.estado === "rodando") {
      if (st.preparando) atualizarProgressoExp(0, st.total, "Preparando a consulta…");
      else atualizarProgressoExp(st.feitos, st.total, "", st.aguardandoAte, st.aguardandoMotivo);
      mostrarEstadoExp("progresso");
      chrome.storage.session.get(FUNDO_CHAVE.exp, (r) => ouvintesFundo.exp(r && r[FUNDO_CHAVE.exp]));
    } else ouvintesFundo.exp(st);
    return;
  }
  if (pendente && !st.visto && painelAberto("exp")) marcarVistoFundo("exp");
}

expConsultarBtn.addEventListener("click", () => iniciarConsultaExp("tudo"));
expResRetryBtn.addEventListener("click", () => iniciarConsultaExp("falhas"));

function telaCanceladaExp() {
  expRunAtual++; // respostas atrasadas desta execução são ignoradas
  expEmAndamento = false;
  expAguardo = { ate: 0, motivo: "" };
  clearTimeout(expAguardoTimer);
  if (expModoAtual === "falhas" && expConsulta) {
    mostrarResultadoExp("Consulta cancelada. Os números são da consulta anterior.");
    return;
  }
  mostrarEstadoExp("setup");
}

expCancelarBtn.addEventListener("click", () => {
  if (expJob) falarComFundo({ acao: "cancelar", tipo: "exp", job: expJob.job }).catch(() => {});
  expJob = null; // o que ainda chegar desta consulta é ignorado
  telaCanceladaExp();
});

expResVoltarBtn.addEventListener("click", () => mostrarEstadoExp("setup"));

expResCopiarBtn.addEventListener("click", () => {
  if (!expConsulta) return;
  const lista = expConsulta.codigos.filter((cod) => expConsulta.expedidos.has(cod));
  if (lista.length) copiarTexto(lista.join("\n"), expFeedback);
});

expLimparBtn.addEventListener("click", () => {
  const foto = fotografarCampos([expCodigos]);
  expRunAtual++;
  expEmAndamento = false;
  expJob = null;
  falarComFundo({ acao: "limpar", tipo: "exp" }).catch(() => {}); // para a consulta em segundo plano e apaga o andamento
  expCodigos.value = "";
  atualizarInfoLote(expCodigos, expCodigosInfo);
  mostrarErroExp("");
  descartarResultadoExp();
  chrome.storage.session.remove([EXP_CAMPOS_KEY, EXP_RESULT_KEY, FUNDO_CHAVE.exp, EXP_DIAG_CHAVE]);
  mostrarEstadoExp("setup");
  oferecerDesfazer(foto, "Lista apagada");
});

document.getElementById("exp-diag-progresso").addEventListener("click", () => copiarDiagnosticoExp(document.getElementById("exp-diag-feedback")));
document.getElementById("exp-diag-resultado").addEventListener("click", () => copiarDiagnosticoExp(expFeedback));

const analisarESalvarExp = quandoParar(expCodigos, () => {
  atualizarInfoLote(expCodigos, expCodigosInfo);
  salvarCamposExp();
});
expCodigos.addEventListener("input", () => {
  expCodigos.classList.remove("lote-invalid");
  mostrarErroExp("");
  if (!expEmAndamento) descartarResultadoExp(); // lista mudou: o resultado antigo não vale mais
  expCamposSujos = true;
  expCamposVelhos = false;
  analisarESalvarExp();
});
expCodigos.addEventListener("change", salvarCamposExpAoSair);
expCodigos.addEventListener("blur", salvarCamposExpAoSair);
window.addEventListener("pagehide", salvarCamposExpSeMudou);
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "hidden") salvarCamposExpSeMudou();
});

function restaurarResultadoExp(s) {
  const valido = s && [s.codigos, s.expedidos, s.outros, s.semRastreio, s.falhas].every(Array.isArray);
  if (!valido) {
    if (s) chrome.storage.session.remove(EXP_RESULT_KEY);
    return;
  }
  if (expConsulta || expEmAndamento) return; // já houve consulta nesta abertura: ela vale
  try {
    expConsulta = {
      codigos: s.codigos.map(String),
      expedidos: new Set(s.expedidos.map(String)),
      outros: new Set(s.outros.map(String)),
      semRastreio: new Set(s.semRastreio.map(String)),
      falhas: new Map(s.falhas.map(([cod, motivo]) => [String(cod), String(motivo)])),
      invalidos: Array.isArray(s.invalidos) ? s.invalidos.map(String) : [],
      em: Number.isFinite(s.em) ? s.em : null,
    };
    mostrarResultadoExp();
  } catch (e) {
    expConsulta = null; // dado salvo estragado: começa do zero
    chrome.storage.session.remove(EXP_RESULT_KEY);
  }
}

chrome.storage.session.get([EXP_CAMPOS_KEY, EXP_RESULT_KEY, FUNDO_CHAVE.exp], (resultado) => {
  const campos = resultado && resultado[EXP_CAMPOS_KEY];
  const colouAntes = !!expCodigos.value;
  if (campos && !colouAntes && typeof campos.codigos === "string") {
    expCodigos.value = campos.codigos;
    atualizarInfoLote(expCodigos, expCodigosInfo);
  }
  expCamposCarregados = true;
  if (colouAntes) {
    salvarCamposExp();
    if (!expConsulta) chrome.storage.session.remove(EXP_RESULT_KEY);
  } else restaurarResultadoExp(resultado && resultado[EXP_RESULT_KEY]);
  verFundoExpAoAbrir(resultado && resultado[FUNDO_CHAVE.exp], { colouAntes });
});

// ---------- Changelog ----------
const changelogBtn = document.getElementById("changelog-btn");
const changelogOverlay = document.getElementById("changelog-overlay");
const changelogClose = document.getElementById("changelog-close");
const changelogBody = document.getElementById("changelog-body");

function renderizarChangelog() {
  changelogBody.replaceChildren();

  CHANGELOG.forEach((entrada, indice) => {
    const bloco = document.createElement("div");
    bloco.className = "changelog-entry";

    const head = document.createElement("div");
    head.className = "changelog-entry-head";

    const versao = document.createElement("span");
    versao.className = "changelog-version";
    versao.textContent = `v${entrada.versao}`;
    head.appendChild(versao);

    if (indice === 0) {
      const badge = document.createElement("span");
      badge.className = "changelog-current-badge";
      badge.textContent = "atual";
      head.appendChild(badge);
    }

    const data = document.createElement("span");
    data.className = "changelog-date";
    data.textContent = entrada.data;
    head.appendChild(data);

    const titulo = document.createElement("div");
    titulo.className = "changelog-title";
    titulo.textContent = entrada.titulo;

    const lista = document.createElement("ul");
    lista.className = "changelog-list";
    entrada.itens.forEach((item) => {
      const li = document.createElement("li");
      li.textContent = item;
      lista.appendChild(li);
    });

    bloco.appendChild(head);
    bloco.appendChild(titulo);
    bloco.appendChild(lista);
    changelogBody.appendChild(bloco);

    if (indice < CHANGELOG.length - 1) {
      changelogBody.appendChild(document.createElement("hr")).className = "changelog-divider";
    }
  });
}

// Modal de verdade: o resto do popup fica inerte (clique, Tab e teclado não
// chegam por trás), o foco entra no modal e volta para a estrela ao fechar.
function abrirChangelog() {
  if (interfaceBloqueada()) return;
  renderizarChangelog();
  changelogOverlay.classList.add("is-open");
  document.querySelector(".app").inert = true;
  document.getElementById("update-banner").inert = true;
  changelogClose.focus();
}

function fecharChangelog() {
  if (!changelogOverlay.classList.contains("is-open")) return;
  changelogOverlay.classList.remove("is-open");
  const travada = document.getElementById("kill-switch-overlay").classList.contains("is-active");
  document.querySelector(".app").inert = travada;
  document.getElementById("update-banner").inert = travada;
  if (!travada) changelogBtn.focus();
}

changelogBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  abrirChangelog();
});

changelogClose.addEventListener("click", (e) => {
  e.stopPropagation();
  fecharChangelog();
});

changelogOverlay.addEventListener("click", (e) => {
  if (e.target === changelogOverlay) fecharChangelog();
});

// Esc fecha o que estiver aberto por cima (Novidades ou a prévia da mensagem)
document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  if (changelogOverlay.classList.contains("is-open")) fecharChangelog();
  else fecharTodasPrevias();
});
