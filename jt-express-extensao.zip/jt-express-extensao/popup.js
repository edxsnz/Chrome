// ---------- Tema claro/escuro (chrome.storage.local — única chave que
// sobrevive ao fechamento completo do navegador; todo o resto usa
// chrome.storage.session) ----------
const THEME_STORAGE_KEY = "tema";
const themeToggleBtn = document.getElementById("theme-toggle");

function aplicarTema(tema, { salvar = true } = {}) {
  document.documentElement.setAttribute("data-theme", tema === "dark" ? "dark" : "light");
  if (salvar) chrome.storage.local.set({ [THEME_STORAGE_KEY]: tema });
}

themeToggleBtn.addEventListener("click", () => {
  const atual = document.documentElement.getAttribute("data-theme") === "dark" ? "dark" : "light";
  aplicarTema(atual === "dark" ? "light" : "dark");
});

// Versão no topo (vem do manifest, então nunca fica desatualizada)
const appVersao = document.getElementById("app-versao");
if (appVersao) appVersao.textContent = `v${chrome.runtime.getManifest().version}`;

// ---------- Navegação entre abas principais (Tickets / POD / Código / Lote) ----------
const tabButtons = document.querySelectorAll(".tab-btn");
const tabPanels = document.querySelectorAll(".tab-panel");

const tabsIndicator = document.getElementById("tabs-indicator");

const TAB_STORAGE_KEY = "aba_ativa";

function ativarAba(nomeAba, { salvar = true } = {}) {
  const indice = [...tabButtons].findIndex((b) => b.dataset.tab === nomeAba);
  if (indice === -1) return;

  tabButtons.forEach((b) => {
    b.classList.toggle("is-active", b.dataset.tab === nomeAba);
    b.setAttribute("aria-selected", b.dataset.tab === nomeAba ? "true" : "false");
  });
  tabPanels.forEach((p) => p.classList.toggle("is-active", p.id === `panel-${nomeAba}`));
  tabsIndicator.style.transform = `translateX(${indice * 100}%)`;

  fecharTodasPrevias();

  if (salvar) chrome.storage.session.set({ [TAB_STORAGE_KEY]: nomeAba });
}

// Clicou numa aba antes de a última aba usada ser restaurada? A escolha vence.
const navCarga = { aba: false, subaba: false };

tabButtons.forEach((btn) => {
  btn.addEventListener("click", () => {
    navCarga.aba = true;
    ativarAba(btn.dataset.tab);
  });
});

// ---------- Navegação entre sub-abas de Tickets (Ocorrência / Endereço) ----------
const subtabButtons = document.querySelectorAll(".subtab-btn");
const subtabPanels = document.querySelectorAll(".subtab-panel");
const subtabsIndicator = document.getElementById("subtabs-indicator");

const SUBTAB_STORAGE_KEY = "subaba_ativa";

function ativarSubaba(nomeSubaba, { salvar = true } = {}) {
  const indice = [...subtabButtons].findIndex((b) => b.dataset.subtab === nomeSubaba);
  if (indice === -1) return;

  subtabButtons.forEach((b) => {
    b.classList.toggle("is-active", b.dataset.subtab === nomeSubaba);
    b.setAttribute("aria-selected", b.dataset.subtab === nomeSubaba ? "true" : "false");
  });
  subtabPanels.forEach((p) => p.classList.toggle("is-active", p.id === `subpanel-${nomeSubaba}`));
  subtabsIndicator.style.transform = `translateX(${indice * 100}%)`;

  fecharTodasPrevias();

  if (salvar) chrome.storage.session.set({ [SUBTAB_STORAGE_KEY]: nomeSubaba });
}

subtabButtons.forEach((btn) => {
  btn.addEventListener("click", (e) => {
    e.stopPropagation();
    navCarga.subaba = true;
    ativarSubaba(btn.dataset.subtab);
  });
});

// ---------- Utilidades ----------

// Converte "2026-07-30 13:28:12" -> "30/07/2026 às 13:28"
function formatarData(valor) {
  if (!valor) return "";

  const match = valor
    .trim()
    .match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::\d{2})?/);

  if (!match) return valor;

  const [, ano, mes, dia, hora, minuto] = match;
  return `${dia}/${mes}/${ano} às ${hora}:${minuto}`;
}

// ---------- Avisos curtos abaixo dos botões ----------
// Um único timer por elemento: cliques seguidos não deixam um timer antigo
// esconder o aviso novo antes da hora nem trocar o texto pelo errado.
// O texto padrão ("Mensagem copiada"...) fica guardado desde o início.
document.querySelectorAll(".copy-feedback").forEach((el) => {
  el.dataset.textoOriginal = el.textContent;
});

function mostrarFeedback(el, { texto = null, erro = false, ms = 1500 } = {}) {
  clearTimeout(el._timerFeedback);
  el.textContent = texto === null ? el.dataset.textoOriginal : texto;
  el.classList.toggle("is-erro", erro);
  el.classList.add("is-visible");
  el._timerFeedback = setTimeout(() => esconderFeedback(el), ms);
}

function esconderFeedback(el) {
  clearTimeout(el._timerFeedback);
  el.classList.remove("is-visible", "is-erro");
  el.textContent = el.dataset.textoOriginal;
}

// ---------- Restaurar sem atropelar ----------
// Os dados salvos chegam do armazenamento um instante depois de o popup abrir.
// Se a pessoa já digitou ou colou algo nesse intervalo, o que ela fez vence:
// aquele campo não é sobrescrito, e nada é salvo por cima (o que apagaria os
// outros campos guardados) antes de a restauração terminar.
function criarCarga(campos) {
  const tocados = new Set();
  let pronto = false;
  campos.forEach((el) => {
    const marcar = () => {
      if (!pronto) tocados.add(el);
    };
    el.addEventListener("input", marcar);
    el.addEventListener("change", marcar);
  });
  return {
    get pronto() {
      return pronto;
    },
    livre: (chave) => !tocados.has(chave),
    marcar: (chave) => {
      if (!pronto) tocados.add(chave);
    },
    // Termina a carga; devolve true se algo foi mexido antes (aí vale salvar)
    concluir() {
      pronto = true;
      return tocados.size > 0;
    },
  };
}

function copiarTexto(texto, feedbackEl) {
  navigator.clipboard.writeText(texto).then(
    () => mostrarFeedback(feedbackEl),
    // Falha ao copiar (ex.: permissão negada): avisa em vez de parecer que nada aconteceu
    () => mostrarFeedback(feedbackEl, { texto: "Não foi possível copiar", erro: true, ms: 2200 })
  );
}

// Mostra a mensagem como o WhatsApp vai exibir: *texto* vira negrito e os
// asteriscos somem. Monta tudo com nós de texto (nunca HTML), então nada que
// for digitado nos campos vira código na página.
function renderizarComoWhatsApp(destino, texto) {
  destino.textContent = "";
  const negrito = /\*(\S(?:[^*\n]*?\S)?)\*/g;
  let ultimo = 0;
  for (const m of texto.matchAll(negrito)) {
    if (m.index > ultimo) destino.append(texto.slice(ultimo, m.index));
    const forte = document.createElement("strong");
    forte.textContent = m[1];
    destino.append(forte);
    ultimo = m.index + m[0].length;
  }
  if (ultimo < texto.length) destino.append(texto.slice(ultimo));
}

// Remove quebras de linha reais (de texto colado), sem deixar espaço sobrando no final
function removerQuebrasDeLinha(el) {
  const valorOriginal = el.value;
  const valorLimpo = valorOriginal
    .replace(/[\r\n]+/g, " ")
    .replace(/ {2,}/g, " ")
    .replace(/ +$/, "");

  if (valorLimpo !== valorOriginal) {
    const posicaoCursor = Math.max(
      0,
      el.selectionStart - (valorOriginal.length - valorLimpo.length)
    );
    el.value = valorLimpo;
    el.setSelectionRange(posicaoCursor, posicaoCursor);
  }
}

// ---------- Telefone do cliente + WhatsApp ----------
// Cada sub-aba de Tickets (Ocorrência e Endereço incorreto) tem seu
// próprio campo de telefone, salvo junto com os demais campos daquela
// sub-aba — não existe na aba POD, por decisão do usuário.

// Extrai só os dígitos e garante o código do país (assume Brasil: 55)
function normalizarTelefone(valor) {
  const digitos = (valor || "").replace(/\D/g, "");
  if (!digitos) return "";
  if (digitos.startsWith("55") && digitos.length >= 12) return digitos;
  return `55${digitos}`;
}

// Celular (13) ou fixo (12) com o 55. Mais que isso costuma ser dois números
// colados juntos — abriria a conversa de um número que não existe.
function telefoneValido(valor) {
  const n = normalizarTelefone(valor);
  return n.length === 12 || n.length === 13;
}

function marcarTelefoneInvalido(inputTelefone) {
  inputTelefone.classList.remove("phone-invalid");
  void inputTelefone.offsetWidth; // força reflow pra animação rodar de novo
  inputTelefone.classList.add("phone-invalid");
  inputTelefone.focus();
}

// Abre o WhatsApp (Web/Desktop) já na conversa do número e copia a
// mensagem pra área de transferência — é só colar (Ctrl+V) e enviar.
// A cópia acontece ANTES de abrir a aba: abrir a aba tira o foco do
// popup (às vezes ele até fecha), e se isso acontecer no meio da cópia
// ela pode não terminar a tempo.
function abrirWhatsApp(inputTelefone, mensagem, feedbackEl) {
  const numero = normalizarTelefone(inputTelefone.value);
  if (!telefoneValido(inputTelefone.value)) {
    marcarTelefoneInvalido(inputTelefone);
    return;
  }
  // Clique duplo (ou clique enquanto a cópia termina) não abre duas conversas
  if (inputTelefone._abrindoWhatsApp) return;
  inputTelefone._abrindoWhatsApp = true;
  setTimeout(() => {
    inputTelefone._abrindoWhatsApp = false;
  }, 1200);

  navigator.clipboard.writeText(mensagem).then(
    () => {
      mostrarFeedback(feedbackEl);
      chrome.tabs.create({ url: `https://wa.me/${numero}` });
    },
    () => {
      // Mesmo sem conseguir copiar, ainda vale abrir a conversa — a
      // pessoa consegue usar o botão Copiar manualmente depois.
      mostrarFeedback(feedbackEl, { texto: "Não copiou — abrindo mesmo assim", erro: true, ms: 2200 });
      chrome.tabs.create({ url: `https://wa.me/${numero}` });
    }
  );
}

// ---------- SUB-ABA OCORRÊNCIA ----------
// Cada embarcador tem o seu script de acareação (Manual de Scripts de
// Acareação, SAC Regional MG, out/2026). A extensão reconhece o embarcador
// pelo que está escrito em "Origem" e troca os campos e o texto sozinha.
// Os textos seguem o manual com os erros dele corrigidos (artigo sobrando
// em "Olá, a ...", frases emendadas, concordância, pontuação irregular nas
// opções e quebra de linha acidental) e com o mesmo espaçamento entre blocos.
const rcNome = document.getElementById("rc-nome");
const rcLinhaTelefone = document.getElementById("rc-linha-telefone");
const rcLinhaRastreio = document.getElementById("rc-linha-rastreio");
const rcConteudoField = document.getElementById("rc-conteudo-field");
const rcTelefone = document.getElementById("rc-telefone");
const rcSeuNomeField = document.getElementById("rc-seu-nome-field");
const rcSeuNome = document.getElementById("rc-seu-nome");
const rcOrigem = document.getElementById("rc-origem");
const rcEmbarcadorTag = document.getElementById("rc-embarcador");
const rcRastreio = document.getElementById("rc-rastreio");
const rcPedidoField = document.getElementById("rc-pedido-field");
const rcPedidoLabel = document.getElementById("rc-pedido-label");
const rcPedido = document.getElementById("rc-pedido");
const rcLinhaExtra = document.getElementById("rc-linha-extra");
const rcDataField = document.getElementById("rc-data-field");
const rcData = document.getElementById("rc-data");
const rcNfField = document.getElementById("rc-nf-field");
const rcNf = document.getElementById("rc-nf");
const rcNfHint = document.getElementById("rc-nf-hint");
const rcMotorolaField = document.getElementById("rc-motorola-field");
const rcMotorola = document.getElementById("rc-motorola");
const rcBloqueio = document.getElementById("rc-bloqueio");
const rcConteudo = document.getElementById("rc-conteudo");
const rcPreview = document.getElementById("rc-preview"); // guarda o texto puro (oculto)
const rcPreviewText = document.getElementById("rc-preview-text"); // exibição visual
const rcPreviewPanel = document.getElementById("rc-preview-panel");
const rcPreviewToggle = document.getElementById("rc-preview-toggle");
const rcCopyBtn = document.getElementById("rc-copy");
const rcClearBtn = document.getElementById("rc-clear");
const rcFeedback = document.getElementById("rc-feedback");
const rcWhatsappBtn = document.getElementById("rc-whatsapp");

const RC_STORAGE_KEY = "rc_campos";
// "Seu nome" é preferência de quem atende: fica salvo mesmo fechando o
// navegador (chrome.storage.local), diferente dos dados do cliente.
const SEU_NOME_KEY = "seu_nome";
const rcCampos = [rcNome, rcTelefone, rcOrigem, rcRastreio, rcPedido, rcData, rcNf, rcConteudo];

const SORRISO = "\u{1F60A}";
const CAMINHAO = "\u{1F69A}";
const PACOTE = "\u{1F4E6}";
const DEDO = "\u{1F447}";
const ALERTA = "\u26A0\uFE0F";

// Opções de resposta de cada manual (texto do manual, só com a pontuação
// padronizada).
// "lacre: true" = opção em que o manual (Orientações Gerais) manda perguntar
// se o pacote estava lacrado: faltando itens, defeito, produto diferente e
// dano/embalagem. A mensagem já pede isso, como no exemplo real do manual.
const OPCOES_JT = [
  { texto: "Recebi o produto." },
  { texto: "Não recebi o produto." },
  { texto: "Recebi o pacote com produtos faltantes.", lacre: true },
  { texto: "Recebi o produto com defeito.", lacre: true },
  { texto: "Recebi um produto diferente do comprado.", lacre: true },
  { texto: "Recebi o produto danificado.", lacre: true },
];
const OPCOES_ML = OPCOES_JT.slice(0, 5); // modelo do Mercado Livre: 5 opções
const OPCOES_TIKTOK = [
  { texto: "Recebi o produto." },
  { texto: "Recebi o produto corretamente, lacrado e embalado." },
  { texto: "Não recebi o produto." },
  { texto: "Recebi o produto com itens faltantes.", lacre: true },
  { texto: "Recebi o produto com a embalagem externa em más condições.", lacre: true },
  { texto: "Recebi um produto diferente do que comprei.", lacre: true },
  { texto: "Recebi o produto com defeito.", lacre: true },
];

// "3, 4, 5 ou 6"
function listarNumeros(nums) {
  return nums.length === 1 ? String(nums[0]) : `${nums.slice(0, -1).join(", ")} ou ${nums[nums.length - 1]}`;
}

// Modelo único para todos os embarcadores: cada manual pede informações
// diferentes, mas TODOS os scripts levam o que deixa a acareação completa —
// nome de quem atende, nome da cliente, código de rastreio, loja, produto e
// os códigos/NF/data que o embarcador exige —, num bloco fácil de ler.
// Os *asteriscos* viram negrito no WhatsApp.
function montarScript(v, cfg) {
  return [
    `Olá, ${v.nome}! Tudo bem? ${SORRISO}`,
    "",
    `Me chamo *${v.seuNome}* e sou da *Transportadora J&T Express*, ${cfg.apresentacao}.`,
    "",
    `Verificamos que foi aberta uma reclamação referente ao seu pedido. ${cfg.objetivo}`,
    "",
    `${PACOTE} *Dados do pedido*`,
    ...cfg.dados.map(([rotulo, valor]) => `*${rotulo}:* ${valor}`),
    `*Entregue em:* ${v.data}`, // data e hora da entrega: em TODOS os scripts
    "",
    `Para que possamos te ajudar, responda apenas com o *número* da opção correspondente ${DEDO}`,
    "",
    ...cfg.opcoes.map((o, i) => `*${i + 1}* – ${o.texto}`),
    "",
    `${ALERTA} Se escolher a opção ${listarNumeros(cfg.opcoes.map((o, i) => (o.lacre ? i + 1 : 0)).filter(Boolean))}, informe também se o pacote chegou *lacrado*.`,
    "",
    "Atenciosamente,",
    `${v.seuNome} – J&T Express ${CAMINHAO}`,
  ].join("\n");
}

const OBJETIVO_PADRAO = "Seguem as informações:";

// Script J&T (demais embarcadores) e Script Digital (embarcadores com código
// próprio: o manual pede o código deles junto do código J&T, separado por barra).
function scriptJT(v, extras = {}) {
  const dados = [["Código de rastreio", extras.codigoProprio ? `${v.rastreio} / ${v.pedido}` : v.rastreio]];
  if (extras.rotuloPedido) dados.push([extras.rotuloPedido, v.pedido]);
  dados.push(["Loja", v.origem], ["Produto", v.conteudo]);
  if (extras.nf) dados.push(["Nota fiscal", v.nf]);
  return montarScript(v, {
    apresentacao: "responsável pela entrega do seu pedido",
    objetivo: OBJETIVO_PADRAO,
    dados,
    opcoes: OPCOES_JT,
  });
}

// Cada embarcador: como reconhecer a Origem (já normalizada: sem acento,
// maiúsculas, só letras e números), quais campos extras pede e o texto.
// A ordem importa: os que exigem acareação física vêm primeiro.
const EMBARCADORES = [
  { id: "arezzo", nome: "Arezzo", soFisica: true, reconhece: (n) => n.includes("AREZZO") },
  { id: "zzab", nome: "ZZAB", soFisica: true, reconhece: (n) => n.includes("ZZAB") },
  { id: "motorola", nome: "Motorola", soFisica: true, reconhece: (n) => n.includes("MOTOROLA") },
  { id: "aguiar", nome: "M. Aguiar & Garcia", soFisica: true, reconhece: (n) => n.includes("AGUIAR") && n.includes("GARCIA") },
  { id: "marlon", nome: "Marlon", soFisica: true, reconhece: (n) => n.includes("MARLON") },
  {
    id: "mercadolivre",
    nome: "Mercado Livre",
    reconhece: (n) => n === "MERCADO" || n.startsWith("MERCADOLIVRE"),
    pedido: { rotulo: "Código MELI", exemplo: "48064431495" },
    montar: (v) =>
      montarScript(v, {
        apresentacao: "parceira de entregas do *Mercado Livre*",
        objetivo: OBJETIVO_PADRAO,
        dados: [
          ["Código de rastreio", v.rastreio],
          ["ID MELI", v.pedido],
          ["Loja", "Mercado Livre"],
          ["Produto", v.conteudo],
        ],
        opcoes: OPCOES_ML,
      }),
  },
  {
    id: "viavarejo",
    nome: "Via Varejo",
    reconhece: (n) => n.includes("VIAVAREJO"),
    pedido: { rotulo: "ID Via", exemplo: "ID do pedido" },
    nf: { dica: "" },
    montar: (v) =>
      montarScript(v, {
        apresentacao: "prestadora de serviços de transporte da *Via Varejo*",
        objetivo: "Gostaríamos de confirmar o recebimento. Seguem as informações:",
        dados: [
          ["Código de rastreio", v.rastreio],
          ["Pedido (ID Via)", v.pedido],
          ["Loja", "Via Varejo"],
          ["Produto", v.conteudo],
          ["Nota fiscal", v.nf],
        ],
        opcoes: OPCOES_JT,
      }),
  },
  {
    id: "tiktok",
    nome: "TikTok Shop",
    reconhece: (n) => n.includes("TIKTOK"),
    pedido: { rotulo: "N° do pedido", exemplo: "Remessa/pedido" },
    montar: (v) =>
      montarScript(v, {
        apresentacao: "responsável pela entrega do seu pedido feito no *TikTok Shop*",
        objetivo: OBJETIVO_PADRAO,
        dados: [
          ["Código de rastreio", v.rastreio],
          ["N° do pedido", v.pedido],
          ["Loja", "TikTok Shop"],
          ["Produto", v.conteudo],
        ],
        opcoes: OPCOES_TIKTOK,
      }),
  },
  {
    id: "shopee",
    nome: "Shopee",
    reconhece: (n) => n.includes("SHOPEE"),
    pedido: { rotulo: "Código BR26", exemplo: "BR26..." },
    montar: (v) => scriptJT(v, { codigoProprio: true }),
  },
  {
    id: "cainiao",
    nome: "Cainiao",
    reconhece: (n) => n.includes("CAINIAO"),
    pedido: { rotulo: "Código CNBR", exemplo: "CNBR..." },
    montar: (v) => scriptJT(v, { codigoProprio: true }),
  },
  {
    id: "infracommerce",
    nome: "Infracommerce",
    reconhece: (n) => n.includes("INFRACOMMERCE"),
    pedido: { rotulo: "ID Infra", exemplo: "WEB-..." },
    nf: { dica: "(6 dígitos)" },
    motorola: true,
    montar: (v) => scriptJT(v, { rotuloPedido: "ID Infra", nf: true }),
  },
];

const EMBARCADOR_PADRAO = { id: "padrao", nome: "", montar: (v) => scriptJT(v) };

const MOTOROLA = EMBARCADORES.find((e) => e.id === "motorola");

function normalizarOrigem(valor) {
  return String(valor || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "") // tira os acentos (á → a)
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "");
}

function detectarEmbarcador(origemCrua) {
  const n = normalizarOrigem(origemCrua);
  if (!n) return EMBARCADOR_PADRAO;
  return EMBARCADORES.find((e) => e.reconhece(n)) || EMBARCADOR_PADRAO;
}

// Infracommerce com remetente "loja MOTOROLA/MOTOROLA" só aceita física
function embarcadorAtual() {
  const e = detectarEmbarcador(rcOrigem.value);
  return e.motorola && rcMotorola.checked ? MOTOROLA : e;
}

function avisoNotaFiscal(e) {
  const digitos = rcNf.value.replace(/\D/g, "");
  if (digitos.length === 44) return "é a chave!";
  return e.nf ? e.nf.dica : "";
}

function atualizarCamposEmbarcador() {
  const origem = detectarEmbarcador(rcOrigem.value);
  const e = embarcadorAtual();
  const bloqueado = !!e.soFisica;

  rcEmbarcadorTag.textContent = e.soFisica ? "Só física" : e.nome;
  rcEmbarcadorTag.title = e.nome ? `Regra aplicada: ${e.nome}` : "";
  rcEmbarcadorTag.classList.toggle("is-hidden", !e.nome);

  // Só física: nada vai ser enviado, então ficam só Nome, Origem e o aviso
  // (o que já foi digitado nos outros campos continua guardado).
  rcLinhaTelefone.classList.toggle("is-hidden", bloqueado);
  rcLinhaRastreio.classList.toggle("is-hidden", bloqueado);
  rcConteudoField.classList.toggle("is-hidden", bloqueado);
  rcSeuNomeField.classList.toggle("is-hidden", bloqueado);

  rcPedidoField.classList.toggle("is-hidden", bloqueado || !e.pedido);
  if (e.pedido) {
    rcPedidoLabel.textContent = e.pedido.rotulo;
    rcPedido.placeholder = e.pedido.exemplo;
  }

  const mostraData = !bloqueado; // data da entrega vai em todos os scripts
  const mostraNf = !bloqueado && !!e.nf;
  const mostraMotorola = !!origem.motorola; // continua visível marcado, pra poder desmarcar
  rcDataField.classList.toggle("is-hidden", !mostraData);
  rcNfField.classList.toggle("is-hidden", !mostraNf);
  rcMotorolaField.classList.toggle("is-hidden", !mostraMotorola);
  rcLinhaExtra.classList.toggle("is-hidden", !(mostraData || mostraNf));

  const dicaNf = avisoNotaFiscal(e);
  rcNfHint.textContent = dicaNf;
  rcNfHint.classList.toggle("tem-aviso", dicaNf === "é a chave!");
  rcNfHint.title = dicaNf === "é a chave!" ? "Isso é a chave da nota (44 dígitos). O número da NF tem 6 dígitos." : "";

  rcBloqueio.classList.toggle("is-hidden", !bloqueado);
  if (bloqueado) {
    rcBloqueio.textContent = "";
    const titulo = document.createElement("strong");
    titulo.textContent = `${e.nome} não aceita acareação por mensagem.`;
    rcBloqueio.append(titulo, " Faça a acareação física (modelo J&T) — por mensagem o pedido vira extravio.");
  }

  rcCopyBtn.disabled = bloqueado;
  rcWhatsappBtn.disabled = bloqueado;
  rcPreviewToggle.disabled = bloqueado;
  if (bloqueado) fecharTodasPrevias();
}

const rcCarga = criarCarga([...rcCampos, rcMotorola]);
const seuNomeCarga = criarCarga([rcSeuNome]);

chrome.storage.session.get(RC_STORAGE_KEY, (resultado) => {
  const salvos = resultado[RC_STORAGE_KEY];
  if (salvos) {
    const repor = (el, valor) => {
      if (rcCarga.livre(el)) el.value = typeof valor === "string" ? valor : "";
    };
    repor(rcNome, salvos.nome);
    repor(rcTelefone, salvos.telefone);
    repor(rcOrigem, salvos.origem);
    repor(rcRastreio, salvos.rastreio);
    repor(rcPedido, salvos.pedido || salvos.meli); // "meli" = campo das versões anteriores
    repor(rcData, salvos.data);
    repor(rcNf, salvos.nf);
    repor(rcConteudo, salvos.conteudo);
    if (rcCarga.livre(rcMotorola)) rcMotorola.checked = salvos.motorola === true;
  }
  if (rcCarga.concluir()) salvarCamposReclamacao();
  atualizarCamposEmbarcador();
  atualizarPreviewReclamacao();
});

chrome.storage.local.get(SEU_NOME_KEY, (resultado) => {
  const salvo = resultado[SEU_NOME_KEY];
  if (typeof salvo === "string" && seuNomeCarga.livre(rcSeuNome)) rcSeuNome.value = salvo;
  if (seuNomeCarga.concluir()) salvarSeuNome();
  atualizarPreviewReclamacao();
});

function salvarSeuNome() {
  if (!seuNomeCarga.pronto) return;
  chrome.storage.local.set({ [SEU_NOME_KEY]: rcSeuNome.value.trim() });
}

function salvarCamposReclamacao() {
  if (!rcCarga.pronto) return;
  chrome.storage.session.set({
    [RC_STORAGE_KEY]: {
      nome: rcNome.value,
      telefone: rcTelefone.value,
      origem: rcOrigem.value,
      rastreio: rcRastreio.value,
      pedido: rcPedido.value,
      data: rcData.value,
      nf: rcNf.value,
      conteudo: rcConteudo.value,
      motorola: rcMotorola.checked,
    },
  });
}

function montarMensagemReclamacao() {
  const e = embarcadorAtual();
  const origemCrua = rcOrigem.value.trim();
  const v = {
    nome: rcNome.value.trim() || "(Nome)",
    seuNome: rcSeuNome.value.trim() || "(Seu nome)",
    origem: origemCrua || "(Origem)",
    rastreio: rcRastreio.value.trim() || "(Rastreio)",
    pedido: rcPedido.value.trim() || `(${e.pedido ? e.pedido.rotulo : "N° pedido"})`,
    data: formatarData(rcData.value) || "(Data)",
    nf: rcNf.value.trim() || "(Nota fiscal)",
    conteudo: rcConteudo.value.trim() || "(Conteúdo)",
  };
  return e.montar ? e.montar(v) : "";
}

function atualizarPreviewReclamacao() {
  const texto = montarMensagemReclamacao();
  rcPreview.value = texto;
  renderizarComoWhatsApp(rcPreviewText, texto);
}

rcConteudo.addEventListener("keydown", (e) => {
  if (e.key === "Enter") e.preventDefault();
});

rcConteudo.addEventListener("input", () => removerQuebrasDeLinha(rcConteudo));

rcTelefone.addEventListener("input", () => rcTelefone.classList.remove("phone-invalid"));

rcOrigem.addEventListener("input", atualizarCamposEmbarcador);
rcNf.addEventListener("input", atualizarCamposEmbarcador);

rcMotorola.addEventListener("change", () => {
  atualizarCamposEmbarcador();
  atualizarPreviewReclamacao();
  salvarCamposReclamacao();
});

rcSeuNome.addEventListener("input", () => {
  salvarSeuNome();
  atualizarPreviewReclamacao();
});

rcCampos.forEach((el) =>
  el.addEventListener("input", () => {
    atualizarPreviewReclamacao();
    salvarCamposReclamacao();
  })
);

// Campos que entram na mensagem do embarcador atual. Nenhum pode ir vazio:
// a cliente receberia "(Rastreio)" no lugar do código.
function camposObrigatoriosOcorrencia() {
  const e = embarcadorAtual();
  const usaOrigem = e === EMBARCADOR_PADRAO || e.id === "shopee" || e.id === "cainiao" || e.id === "infracommerce";
  const lista = [[rcSeuNome, "Seu nome"], [rcNome, "Nome"]];
  if (usaOrigem) lista.push([rcOrigem, "Origem"]); // vira a "Loja" da mensagem
  lista.push([rcRastreio, "Rastreio"]);
  if (e.pedido) lista.push([rcPedido, e.pedido.rotulo]);
  lista.push([rcData, "Data"]);
  if (e.nf) lista.push([rcNf, "NF"]);
  lista.push([rcConteudo, "Conteúdo"]);
  return lista; // na ordem em que aparecem no formulário
}

function marcarCampoFaltando(el) {
  el.classList.remove("phone-invalid");
  void el.offsetWidth; // reinicia a animação
  el.classList.add("phone-invalid");
}

// Confere uma lista [[campo, "Nome do campo"], ...]. Devolve true se está tudo
// preenchido; senão marca os vazios em vermelho, foca o primeiro e avisa.
// telefoneEl (só no WhatsApp) também é conferido e marcado.
function conferirCampos(lista, feedbackEl, telefoneEl = null) {
  const faltando = lista.filter(([el]) => !el.value.trim());
  const telefoneRuim = !!telefoneEl && !telefoneValido(telefoneEl.value);
  if (!faltando.length) {
    esconderFeedback(feedbackEl); // tira um "falta preencher" que ainda esteja na tela
    return true;
  }
  faltando.forEach(([el]) => marcarCampoFaltando(el));
  if (telefoneRuim) marcarCampoFaltando(telefoneEl);
  (telefoneRuim ? telefoneEl : faltando[0][0]).focus();
  // O aviso tem uma linha só: com muitos campos, diz quantos (já estão marcados em vermelho)
  avisarFeedback(
    feedbackEl,
    faltando.length <= 3
      ? `Falta preencher: ${faltando.map(([, nome]) => nome).join(", ")}`
      : `Preencha os ${faltando.length} campos marcados em vermelho`
  );
  return false;
}

function conferirOcorrencia(incluirTelefone) {
  return conferirCampos(camposObrigatoriosOcorrencia(), rcFeedback, incluirTelefone ? rcTelefone : null);
}

// Limpar também tira as marcas vermelhas e o aviso de "falta preencher"
function limparMarcas(campos, feedbackEl) {
  campos.forEach((el) => el.classList.remove("phone-invalid"));
  esconderFeedback(feedbackEl);
}

function avisarFeedback(feedbackEl, texto) {
  mostrarFeedback(feedbackEl, { texto, erro: true, ms: 2600 });
}

rcCopyBtn.addEventListener("click", () => {
  if (embarcadorAtual().soFisica) return;
  if (!conferirOcorrencia(false)) return;
  atualizarPreviewReclamacao();
  copiarTexto(rcPreview.value, rcFeedback);
});

rcWhatsappBtn.addEventListener("click", () => {
  if (embarcadorAtual().soFisica) return;
  if (!conferirOcorrencia(true)) return;
  atualizarPreviewReclamacao();
  abrirWhatsApp(rcTelefone, rcPreview.value, rcFeedback);
});

// Ao digitar, o campo deixa de estar marcado como faltando.
[rcSeuNome, rcNome, rcOrigem, rcRastreio, rcPedido, rcData, rcNf, rcConteudo].forEach((el) =>
  el.addEventListener("input", () => el.classList.remove("phone-invalid"))
);

// Limpar apaga os dados do cliente; "Seu nome" é de quem atende e fica.
rcClearBtn.addEventListener("click", () => {
  rcCampos.forEach((el) => {
    el.value = "";
    rcCarga.marcar(el); // Limpar antes de carregar: não deixa a restauração trazer de volta
  });
  rcMotorola.checked = false;
  rcCarga.marcar(rcMotorola);
  limparMarcas([...rcCampos, rcSeuNome], rcFeedback);
  atualizarCamposEmbarcador();
  atualizarPreviewReclamacao();
  chrome.storage.session.remove(RC_STORAGE_KEY);
  fecharTodasPrevias();
});

function abrirPreviaReclamacao() {
  atualizarPreviewReclamacao();
  rcPreviewPanel.classList.add("is-open");
  rcPreviewToggle.classList.add("is-active");
}

rcPreviewToggle.addEventListener("click", (e) => {
  e.stopPropagation();
  if (embarcadorAtual().soFisica) return;
  const estaAberta = rcPreviewPanel.classList.contains("is-open");
  estaAberta ? fecharTodasPrevias() : abrirPreviaReclamacao();
});

// ---------- SUB-ABA ENDEREÇO INCORRETO ----------
const enRastreio = document.getElementById("en-rastreio");
const enTelefone = document.getElementById("en-telefone");
const enOrigem = document.getElementById("en-origem");
const enConteudo = document.getElementById("en-conteudo");
const enPreview = document.getElementById("en-preview");
const enPreviewText = document.getElementById("en-preview-text");
const enPreviewPanel = document.getElementById("en-preview-panel");
const enPreviewToggle = document.getElementById("en-preview-toggle");
const enCopyBtn = document.getElementById("en-copy");
const enClearBtn = document.getElementById("en-clear");
const enFeedback = document.getElementById("en-feedback");
const enWhatsappBtn = document.getElementById("en-whatsapp");

const EN_STORAGE_KEY = "en_campos";
const enCampos = [enTelefone, enRastreio, enOrigem, enConteudo];

const enCarga = criarCarga(enCampos);

chrome.storage.session.get(EN_STORAGE_KEY, (resultado) => {
  const salvos = resultado[EN_STORAGE_KEY];
  if (salvos) {
    const repor = (el, valor) => {
      if (enCarga.livre(el)) el.value = typeof valor === "string" ? valor : "";
    };
    repor(enTelefone, salvos.telefone);
    repor(enRastreio, salvos.rastreio);
    repor(enOrigem, salvos.origem);
    repor(enConteudo, salvos.conteudo);
  }
  if (enCarga.concluir()) salvarCamposEndereco();
  atualizarPreviewEndereco();
});

function salvarCamposEndereco() {
  if (!enCarga.pronto) return;
  chrome.storage.session.set({
    [EN_STORAGE_KEY]: {
      telefone: enTelefone.value,
      rastreio: enRastreio.value,
      origem: enOrigem.value,
      conteudo: enConteudo.value,
    },
  });
}

function montarMensagemEndereco() {
  const rastreio = enRastreio.value.trim() || "(Rastreio)";
  const origem = enOrigem.value.trim() || "(Origem)";
  const conteudo = enConteudo.value.trim() || "(Conteúdo)";

  return `Olá!

Seguem as informações do seu pedido:

\u{1F4E6} Código do pacote: ${rastreio}
\u{1F3EA} Loja: ${origem}
\u{1F4E6} Produto: ${conteudo}

Verificamos que foi realizada uma tentativa de entrega no seu endereço, porém não foi possível concluir a entrega, pois o endereço se encontra incorreto.

Pedimos, por gentileza, que nos informe o endereço correto para prosseguirmos com a entrega.

Agradecemos pela compreensão.`;
}

function atualizarPreviewEndereco() {
  const texto = montarMensagemEndereco();
  enPreview.value = texto;
  renderizarComoWhatsApp(enPreviewText, texto);
}

enConteudo.addEventListener("keydown", (e) => {
  if (e.key === "Enter") e.preventDefault();
});

enConteudo.addEventListener("input", () => removerQuebrasDeLinha(enConteudo));

enTelefone.addEventListener("input", () => enTelefone.classList.remove("phone-invalid"));

enCampos.forEach((el) =>
  el.addEventListener("input", () => {
    atualizarPreviewEndereco();
    salvarCamposEndereco();
  })
);

// Mesma proteção da Ocorrência: nada de "(Rastreio)" chegando para a cliente
const EN_OBRIGATORIOS = () => [
  [enRastreio, "Rastreio"],
  [enOrigem, "Origem"],
  [enConteudo, "Conteúdo"],
];

enCopyBtn.addEventListener("click", () => {
  if (!conferirCampos(EN_OBRIGATORIOS(), enFeedback)) return;
  atualizarPreviewEndereco();
  copiarTexto(enPreview.value, enFeedback);
});

enWhatsappBtn.addEventListener("click", () => {
  if (!conferirCampos(EN_OBRIGATORIOS(), enFeedback, enTelefone)) return;
  atualizarPreviewEndereco();
  abrirWhatsApp(enTelefone, enPreview.value, enFeedback);
});

[enRastreio, enOrigem, enConteudo].forEach((el) =>
  el.addEventListener("input", () => el.classList.remove("phone-invalid"))
);

enClearBtn.addEventListener("click", () => {
  enCampos.forEach((el) => {
    el.value = "";
    enCarga.marcar(el);
  });
  limparMarcas(enCampos, enFeedback);
  atualizarPreviewEndereco();
  chrome.storage.session.remove(EN_STORAGE_KEY);
  fecharTodasPrevias();
});

function abrirPreviaEndereco() {
  atualizarPreviewEndereco();
  enPreviewPanel.classList.add("is-open");
  enPreviewToggle.classList.add("is-active");
}

enPreviewToggle.addEventListener("click", (e) => {
  e.stopPropagation();
  const estaAberta = enPreviewPanel.classList.contains("is-open");
  estaAberta ? fecharTodasPrevias() : abrirPreviaEndereco();
});

// ---- Fecha qualquer prévia aberta (clique fora, troca de aba/sub-aba) ----
function fecharTodasPrevias() {
  rcPreviewPanel.classList.remove("is-open");
  rcPreviewToggle.classList.remove("is-active");
  enPreviewPanel.classList.remove("is-open");
  enPreviewToggle.classList.remove("is-active");
}

document.addEventListener("click", fecharTodasPrevias);

// Restaura a última aba/sub-aba usadas nesta sessão do navegador
chrome.storage.session.get([TAB_STORAGE_KEY, SUBTAB_STORAGE_KEY], (resultado) => {
  const abaSalva = resultado[TAB_STORAGE_KEY];
  const subabaSalva = resultado[SUBTAB_STORAGE_KEY];
  if (abaSalva && !navCarga.aba) ativarAba(abaSalva, { salvar: false });
  if (subabaSalva && !navCarga.subaba) ativarSubaba(subabaSalva, { salvar: false });
});

// ---------- ABA POD ----------
const podNome = document.getElementById("pod-nome");
const podMotivoField = document.getElementById("pod-motivo-field");
const podMotivo = document.getElementById("pod-motivo");
const podPreviewText = document.getElementById("pod-preview-text");
const podCopyBtn = document.getElementById("pod-copy");
const podFeedback = document.getElementById("pod-feedback");
const podToggleBtns = document.querySelectorAll(".pod-toggle-btn");
const podToggleIndicator = document.getElementById("pod-toggle-indicator");

const POD_STORAGE_KEY = "pod_campos";
let podTipo = "correto";

const podCarga = criarCarga([podNome, podMotivo]);

chrome.storage.session.get(POD_STORAGE_KEY, (resultado) => {
  const salvos = resultado[POD_STORAGE_KEY];
  if (salvos) {
    if (typeof salvos.nome === "string" && podCarga.livre(podNome)) podNome.value = salvos.nome;
    if (typeof salvos.motivo === "string" && podCarga.livre(podMotivo)) podMotivo.value = salvos.motivo;
    if ((salvos.tipo === "correto" || salvos.tipo === "incorreto") && podCarga.livre("tipo")) {
      ativarPodTipo(salvos.tipo, { salvar: false });
    }
  }
  if (podCarga.concluir()) salvarCamposPod();
  atualizarPreviewPod();
});

function ativarPodTipo(tipo, { salvar = true } = {}) {
  podTipo = tipo;
  const indice = tipo === "incorreto" ? 1 : 0;

  podToggleBtns.forEach((b) => {
    b.classList.toggle("is-active", b.dataset.podTipo === tipo);
    b.setAttribute("aria-selected", b.dataset.podTipo === tipo ? "true" : "false");
  });
  podToggleIndicator.style.transform = `translateX(${indice * 100}%)`;
  podMotivoField.classList.toggle("is-active", tipo === "incorreto");

  atualizarPreviewPod();
  if (salvar) salvarCamposPod();
}

podToggleBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    podCarga.marcar("tipo");
    ativarPodTipo(btn.dataset.podTipo);
  });
});

// Texto do POD incorreto ainda é um rascunho no mesmo tom do POD correto —
// ajuste livremente se quiser uma redação diferente.
function montarMensagemPod() {
  const nome = podNome.value.trim() || "(Nome)";

  if (podTipo === "incorreto") {
    const motivo = podMotivo.value.trim() || "(Motivo)";
    return `POD INCORRETO, ${nome}\nMotivo: ${motivo} \u{26A0}\u{FE0F}`;
  }

  return `POD CORRETO, Parabéns ${nome} continue assim \u{1F44F}\u{1F3FB}\u{1F44F}\u{1F3FB}`;
}

function atualizarPreviewPod() {
  podPreviewText.textContent = montarMensagemPod();
}

function salvarCamposPod() {
  if (!podCarga.pronto) return;
  chrome.storage.session.set({
    [POD_STORAGE_KEY]: {
      nome: podNome.value,
      motivo: podMotivo.value,
      tipo: podTipo,
    },
  });
}

podNome.addEventListener("input", () => {
  atualizarPreviewPod();
  salvarCamposPod();
});

podMotivo.addEventListener("input", () => {
  atualizarPreviewPod();
  salvarCamposPod();
});

podCopyBtn.addEventListener("click", () => {
  const obrigatorios = [[podNome, "Nome"]];
  if (podTipo === "incorreto") obrigatorios.push([podMotivo, "Motivo"]);
  if (!conferirCampos(obrigatorios, podFeedback)) return;
  copiarTexto(montarMensagemPod(), podFeedback);
});

[podNome, podMotivo].forEach((el) => el.addEventListener("input", () => el.classList.remove("phone-invalid")));

atualizarPreviewPod();

// ---------- ABA CÓDIGO DE BARRAS ----------
const barrasInput = document.getElementById("barras-input");
const barrasSetup = document.getElementById("barras-setup");
const barrasPergunta = document.getElementById("barras-pergunta");
const barrasPerguntaNaoBtn = document.getElementById("barras-pergunta-nao");
const barrasPerguntaSimBtn = document.getElementById("barras-pergunta-sim");
const barrasPerguntaVoltarBtn = document.getElementById("barras-pergunta-voltar");
const barrasCancelados = document.getElementById("barras-cancelados");
const barrasCanceladosInput = document.getElementById("barras-cancelados-input");
const barrasCanceladosAviso = document.getElementById("barras-cancelados-aviso");
const barrasCanceladosVoltarBtn = document.getElementById("barras-cancelados-voltar");
const barrasCanceladosConfirmarBtn = document.getElementById("barras-cancelados-confirmar");
const barrasViewer = document.getElementById("barras-viewer");
const barrasQuebrarBtn = document.getElementById("barras-quebrar");
const barrasGerarBtn = document.getElementById("barras-gerar");
const barrasFeedback = document.getElementById("barras-feedback");
const barrasCounter = document.getElementById("barras-counter");
const barrasSvg = document.getElementById("barras-svg");
const barrasLabel = document.getElementById("barras-label");
const barrasPrevBtn = document.getElementById("barras-prev");
const barrasNextBtn = document.getElementById("barras-next");
const barrasRemoverBtn = document.getElementById("barras-remover");
const barrasVoltarBtn = document.getElementById("barras-voltar");
const barrasViewerNota = document.getElementById("barras-viewer-nota");

const BARRAS_STORAGE_KEY = "barras_texto";
let codigosColados = []; // lista completa, extraída do textarea principal
let listaCodigos = []; // só os que sobraram depois de tirar os cancelados
let indiceCodigoAtual = 0;

const barrasCarga = criarCarga([barrasInput]);

function salvarTextoBarras() {
  if (!barrasCarga.pronto) return;
  chrome.storage.session.set({ [BARRAS_STORAGE_KEY]: barrasInput.value });
}

chrome.storage.session.get(BARRAS_STORAGE_KEY, (resultado) => {
  const salvo = resultado[BARRAS_STORAGE_KEY];
  if (typeof salvo === "string" && salvo && barrasCarga.livre(barrasInput)) barrasInput.value = salvo;
  if (barrasCarga.concluir()) salvarTextoBarras();
});

barrasInput.addEventListener("input", () => {
  barrasInput.classList.remove("barras-input-invalid");
  salvarTextoBarras();
});

// Aceita tanto quebras de linha quanto espaços como separador entre códigos
function extrairCodigos(texto) {
  return (texto || "")
    .split(/\s+/)
    .map((c) => c.trim())
    .filter(Boolean);
}

function marcarListaInvalida() {
  barrasInput.classList.remove("barras-input-invalid");
  void barrasInput.offsetWidth;
  barrasInput.classList.add("barras-input-invalid");
  barrasInput.focus();
}

// Remove códigos repetidos (mesma comparação usada nos cancelados: sem
// diferenciar maiúsculas/minúsculas), mantendo a primeira ocorrência de
// cada um. Sem isso, um código duplicado gerava 2 códigos de barra
// idênticos, e ao cancelar um dos dois a contagem ficava incorreta.
function removerDuplicados(codigos) {
  const vistos = new Set();
  const unicos = [];
  for (const codigo of codigos) {
    const chave = codigo.toUpperCase();
    if (!vistos.has(chave)) {
      vistos.add(chave);
      unicos.push(codigo);
    }
  }
  return unicos;
}

// Reorganiza os códigos digitados/colados em uma lista com quebra de
// linha (um por linha) e copia o resultado pra área de transferência.
barrasQuebrarBtn.addEventListener("click", () => {
  const codigos = extrairCodigos(barrasInput.value);
  if (codigos.length === 0) {
    marcarListaInvalida();
    return;
  }
  const textoComQuebras = codigos.join("\n");
  barrasInput.value = textoComQuebras;
  barrasCarga.marcar(barrasInput);
  salvarTextoBarras();
  copiarTexto(textoComQuebras, barrasFeedback);
});

// ---- Pergunta: existem códigos cancelados? ----

function irParaViewerCom(codigos, nota = "") {
  listaCodigos = codigos;
  indiceCodigoAtual = 0;
  barrasViewerNota.textContent = nota;
  barrasPergunta.classList.remove("is-active");
  barrasCancelados.classList.remove("is-active");
  barrasViewer.classList.add("is-active");
  renderizarCodigoAtual();
}

const barrasPerguntaNota = document.getElementById("barras-pergunta-nota");

barrasGerarBtn.addEventListener("click", () => {
  const codigos = extrairCodigos(barrasInput.value);
  if (codigos.length === 0) {
    marcarListaInvalida();
    return;
  }

  const codigosUnicos = removerDuplicados(codigos);
  const duplicados = codigos.length - codigosUnicos.length;
  codigosColados = codigosUnicos;

  barrasSetup.classList.add("is-hidden");

  // Só sobrou 1 código: não faz sentido perguntar se tem cancelados —
  // gera direto (e avisa se duplicados foram removidos pelo caminho).
  if (codigosUnicos.length === 1) {
    irParaViewerCom(
      codigosUnicos,
      duplicados > 0
        ? `${duplicados} código(s) duplicado(s) foram removidos automaticamente — restou 1 código único.`
        : ""
    );
    return;
  }

  barrasPerguntaNota.textContent = duplicados > 0
    ? `${duplicados} código(s) duplicado(s) foram removidos automaticamente — restam ${codigosUnicos.length} código(s) únicos.`
    : "";

  barrasPergunta.classList.add("is-active");
});

barrasPerguntaNaoBtn.addEventListener("click", () => {
  irParaViewerCom(codigosColados);
});

barrasPerguntaVoltarBtn.addEventListener("click", () => {
  barrasPergunta.classList.remove("is-active");
  barrasSetup.classList.remove("is-hidden");
});

barrasPerguntaSimBtn.addEventListener("click", () => {
  barrasCanceladosInput.value = "";
  resetarTelaCancelados();
  barrasPergunta.classList.remove("is-active");
  barrasCancelados.classList.add("is-active");
});

barrasCanceladosVoltarBtn.addEventListener("click", () => {
  resetarTelaCancelados();
  barrasCancelados.classList.remove("is-active");
  barrasPergunta.classList.add("is-active");
});

// Depois de calcular o resultado, a pessoa precisa confirmar de novo pra
// avançar — assim dá tempo de ler se algum código cancelado não foi
// encontrado, em vez da tela mudar direto pro visualizador.
let restantesPendentes = null;

function resetarTelaCancelados() {
  restantesPendentes = null;
  barrasCanceladosAviso.textContent = "";
  barrasCanceladosAviso.classList.remove("tem-aviso", "tem-sucesso");
  barrasCanceladosConfirmarBtn.textContent = "Gerar o restante";
}

// Tira da lista completa qualquer código que também apareça na lista de
// cancelados (comparação exata, sem diferenciar maiúsculas/minúsculas).
barrasCanceladosConfirmarBtn.addEventListener("click", () => {
  // Segunda etapa: o resultado já foi mostrado, esse clique confirma.
  if (restantesPendentes !== null) {
    const restantes = restantesPendentes;
    resetarTelaCancelados();
    irParaViewerCom(restantes);
    return;
  }

  const cancelados = extrairCodigos(barrasCanceladosInput.value);

  if (cancelados.length === 0) {
    irParaViewerCom(codigosColados);
    return;
  }

  const canceladosUnicos = [...new Set(cancelados.map((c) => c.toUpperCase()))];
  const canceladosSet = new Set(canceladosUnicos);
  const restantes = codigosColados.filter((c) => !canceladosSet.has(c.toUpperCase()));

  const encontrados = canceladosUnicos.filter((c) =>
    codigosColados.some((original) => original.toUpperCase() === c)
  ).length;
  const naoEncontrados = canceladosUnicos.length - encontrados;

  if (restantes.length === 0) {
    barrasCanceladosAviso.textContent = "Todos os códigos da lista foram marcados como cancelados — não sobrou nenhum pra gerar.";
    barrasCanceladosAviso.classList.add("tem-aviso");
    return;
  }

  if (naoEncontrados > 0) {
    barrasCanceladosAviso.textContent = `${naoEncontrados} código(s) cancelado(s) não encontrado(s) na lista original — confira a digitação. ${encontrados} removido(s) com sucesso, restam ${restantes.length}. Clique em "Confirmar" pra continuar mesmo assim, ou em "Voltar" pra corrigir.`;
    barrasCanceladosAviso.classList.add("tem-aviso");
  } else {
    barrasCanceladosAviso.textContent = `${encontrados} código(s) cancelado(s) removido(s) com sucesso — restam ${restantes.length} pra gerar.`;
    barrasCanceladosAviso.classList.add("tem-sucesso");
  }

  restantesPendentes = restantes;
  barrasCanceladosConfirmarBtn.textContent = "Confirmar";
});

// ---- Visualizador: navega e gera o código de barras atual ----

function renderizarCodigoAtual() {
  const codigo = listaCodigos[indiceCodigoAtual];
  barrasLabel.textContent = codigo;
  barrasCounter.textContent = `${indiceCodigoAtual + 1} / ${listaCodigos.length}`;

  try {
    JsBarcode(barrasSvg, codigo, {
      format: "CODE128",
      width: 2.2,
      height: 80,
      displayValue: false,
      margin: 6,
    });
  } catch (erro) {
    // Código que o Code128 não consegue representar — mostra um aviso
    // em vez de deixar o código de barras antigo na tela com o texto
    // do código novo embaixo (poderia levar a biparem o pacote errado).
    barrasSvg.replaceChildren();
    barrasLabel.textContent = `${codigo} — não foi possível gerar`;
  }

  barrasPrevBtn.disabled = indiceCodigoAtual === 0;
  barrasNextBtn.disabled = indiceCodigoAtual === listaCodigos.length - 1;
}

function avancarCodigo() {
  if (indiceCodigoAtual < listaCodigos.length - 1) {
    indiceCodigoAtual++;
    renderizarCodigoAtual();
  }
}

function voltarCodigo() {
  if (indiceCodigoAtual > 0) {
    indiceCodigoAtual--;
    renderizarCodigoAtual();
  }
}

// Tira o código atual da lista sem precisar voltar e editar tudo de novo
// (ex.: percebeu no meio da bipagem que aquele pedido foi cancelado)
barrasRemoverBtn.addEventListener("click", () => {
  listaCodigos.splice(indiceCodigoAtual, 1);

  if (listaCodigos.length === 0) {
    barrasViewer.classList.remove("is-active");
    barrasSetup.classList.remove("is-hidden");
    return;
  }

  if (indiceCodigoAtual >= listaCodigos.length) {
    indiceCodigoAtual = listaCodigos.length - 1;
  }
  renderizarCodigoAtual();
});

barrasVoltarBtn.addEventListener("click", () => {
  barrasViewer.classList.remove("is-active");
  barrasSetup.classList.remove("is-hidden");
});

barrasPrevBtn.addEventListener("click", voltarCodigo);
barrasNextBtn.addEventListener("click", avancarCodigo);

// Setas do teclado navegam entre os códigos — só com a aba Código aberta e
// fora de campos de texto (senão roubariam o cursor dos campos de Tickets).
const painelBarras = document.getElementById("panel-barras");
document.addEventListener("keydown", (e) => {
  if (!barrasViewer.classList.contains("is-active") || !painelBarras.classList.contains("is-active")) return;
  const alvo = e.target;
  if (alvo && (alvo.tagName === "INPUT" || alvo.tagName === "TEXTAREA" || alvo.isContentEditable)) return;
  if (e.key === "ArrowRight") { e.preventDefault(); avancarCodigo(); }
  if (e.key === "ArrowLeft") { e.preventDefault(); voltarCodigo(); }
});

// ---------- ABA LOTE (consulta de erro de lote) ----------
// Recebe a lista da coleta e a lista de lotes, consulta cada lote no sistema
// e devolve só os códigos da coleta que NÃO aparecem em nenhum lote.
//
// Como a consulta é feita: o fetch roda DENTRO da aba do JMS (chrome.scripting),
// igual ao que o próprio site faz — assim a requisição sai com a origem e o
// Referer reais do sistema (chamadas vindas direto da extensão costumam ser
// recusadas por gateways). O token vem do cookie YL_TOKEN, lido na hora de
// cada consulta; ele nunca é guardado nem exibido.

const LOTE_API = {
  hostPreferido: "jmsbr.jtjms-br.com",
  // Qualquer endereço do JMS (jmsbr, outro subdomínio...) — o mesmo padrão
  // do host_permissions do manifest.
  padraoAba: "https://*.jtjms-br.com/*",
  url: "https://gw.jtjms-br.com/operatingplatform/packScanList/waybillIdsByPackageNumber",
  cookie: "YL_TOKEN",
};

const LOTE_CFG = {
  concorrencia: 3, // consultas ao mesmo tempo (baixo de propósito: evita bloqueio por excesso de requisições)
  tentativas: 4, // por lote
  backoffBaseMs: 1000,
  backoffMaxMs: 15000,
  timeoutMs: 25000,
  espacoMinMs: 150, // pausa entre uma consulta e outra de cada "trabalhador"
  espacoMaxMs: 350,
};

const LOTE_MSG = {
  semAba: "Não encontrei o sistema JMS aberto. Abra o JMS em uma aba deste navegador, entre na sua conta e tente de novo.",
  recarregar: "A extensão foi atualizada e precisa ser recarregada para acessar o JMS. Depois de recarregar, cole as listas de novo.",
  permitir: "A extensão está sem permissão para acessar o sistema JMS. Clique abaixo e confirme.",
  semToken: "Não achei o seu login do sistema. Atualize a página do JMS (F5), confira se está logado e tente de novo.",
  tokenEstranho: "O login do sistema veio em um formato inesperado. Saia e entre de novo no JMS.",
  auth: "O sistema recusou o login (sessão expirada?). Entre de novo no JMS e tente outra vez.",
  abaPerdida: "A aba do sistema foi fechada ou recarregada durante a consulta. Deixe-a aberta e tente de novo.",
  generico: "Não foi possível consultar os lotes. Tente novamente.",
};

class ErroLote extends Error {
  constructor(tipo, mensagem) {
    super(mensagem);
    this.tipo = tipo;
  }
}

// ATENÇÃO: esta função roda DENTRO da aba do sistema (o chrome.scripting
// serializa o código dela), então NÃO pode usar nenhuma variável deste
// arquivo — só o que chega pelos argumentos e as APIs do navegador.
async function consultarLoteNaPagina(url, cabecalhos, corpoJson, timeoutMs) {
  const controle = new AbortController();
  const relogio = setTimeout(() => controle.abort(), timeoutMs);
  try {
    const resposta = await fetch(url, {
      method: "POST",
      headers: cabecalhos,
      body: corpoJson,
      credentials: "omit",
      redirect: "error", // se o sistema redirecionar, não manda o token pra outro lugar
      signal: controle.signal,
    });
    let json = null;
    try {
      json = await resposta.json();
    } catch (e) {
      json = null;
    }
    return {
      status: resposta.status,
      ok: resposta.ok,
      retryAfter: resposta.headers.get("retry-after"),
      json,
    };
  } catch (e) {
    return { status: 0, ok: false, erro: e && e.name === "AbortError" ? "timeout" : "rede" };
  } finally {
    clearTimeout(relogio);
  }
}

function montarCabecalhosLote(token) {
  return {
    accept: "application/json, text/plain, */*",
    "accept-language": "pt-BR,pt;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
    authtoken: token,
    "cache-control": "max-age=2, must-revalidate",
    "content-type": "application/json;charset=UTF-8",
    lang: "PT",
    langtype: "PT",
    routename: "trackingExpress",
    routernamelist:
      "%E6%93%8D%E4%BD%9C%E5%B9%B3%E5%8F%B0%3E%E5%BF%AB%E4%BB%B6%E6%9F%A5%E8%AF%A2%3E%E5%BF%AB%E4%BB%B6%E8%B7%9F%E8%B8%AA",
    timezone: "GMT-0300",
  };
}

// Separa o que é código do que é texto solto (títulos como "Número da saca",
// "Total: 2", "Página 1 de 3"). Código = trecho só com letras/números/._- ,
// com pelo menos 8 caracteres e 6 dígitos (rastreios têm 15 dígitos e lotes
// BR + 11). Repetidos são descartados. Trechos com caractere estranho e
// dígitos (ex.: 9.99E+14 vindo de planilha) voltam em "suspeitos" pra não
// sumirem em silêncio.
const CODIGO_MIN_CARACTERES = 8;
const CODIGO_MIN_DIGITOS = 6;

function pareceCodigo(trecho) {
  return (
    /^[A-Za-z0-9._-]+$/.test(trecho) &&
    trecho.length >= CODIGO_MIN_CARACTERES &&
    (trecho.match(/\d/g) || []).length >= CODIGO_MIN_DIGITOS
  );
}

// Código que provavelmente se estragou no caminho (ex.: planilha que virou
// 9.99E+14, ou um apóstrofo grudado). Datas e números curtos de títulos não
// entram aqui — são só texto.
function pareceCodigoEstragado(trecho) {
  if (/^\d+(?:[.,]\d+)?E\+?\d+$/i.test(trecho)) return true;
  return (trecho.match(/\d/g) || []).length >= CODIGO_MIN_DIGITOS;
}

function analisarCodigos(texto) {
  const vistos = new Set();
  const codigos = [];
  const linhasIgnoradas = new Set();
  const suspeitos = [];
  let duplicados = 0;

  String(texto || "")
    .split(/\r\n|\r|\n/)
    .forEach((linha, indice) => {
      for (const trecho of linha.split(/[\s,;]+/).filter(Boolean)) {
        if (pareceCodigo(trecho)) {
          const codigo = trecho.toUpperCase();
          if (vistos.has(codigo)) duplicados++;
          else {
            vistos.add(codigo);
            codigos.push(codigo);
          }
        } else {
          linhasIgnoradas.add(indice);
          if (pareceCodigoEstragado(trecho)) suspeitos.push(trecho);
        }
      }
    });

  return { codigos, duplicados, linhasIgnoradas: linhasIgnoradas.size, suspeitos };
}

const dormir = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const aleatorioEntre = (min, max) => min + Math.random() * (max - min);

function esperaBackoff(tentativa) {
  return Math.min(LOTE_CFG.backoffBaseMs * 2 ** (tentativa - 1), LOTE_CFG.backoffMaxMs) + Math.random() * 250;
}

function esperaDoRetryAfter(valor, tentativa) {
  const segundos = Number(valor);
  if (valor != null && valor !== "" && Number.isFinite(segundos) && segundos >= 0) {
    return Math.min(segundos * 1000, LOTE_CFG.backoffMaxMs * 2);
  }
  return esperaBackoff(tentativa);
}

// O login do JMS (cookie YL_TOKEN) só é aceito de jtjms-br.com ou subdomínios.
const LOTE_DOMINIO = "jtjms-br.com";
function ehDominioJms(dominio) {
  const d = String(dominio || "").replace(/^\./, "").toLowerCase();
  return d === LOTE_DOMINIO || d.endsWith("." + LOTE_DOMINIO);
}

function hostDaAba(aba) {
  try {
    return new URL(aba && aba.url).hostname.toLowerCase();
  } catch (e) {
    return "";
  }
}

// Limpa o valor lido (aspas, %xx) sem nunca mostrar ou guardar o token.
function limparToken(valor) {
  let v = String(valor == null ? "" : valor).trim().replace(/^"(.*)"$/, "$1").trim();
  if (/%[0-9A-Fa-f]{2}/.test(v)) {
    try {
      v = decodeURIComponent(v).trim();
    } catch (e) {
      /* deixa como veio */
    }
  }
  return v;
}

// Roda DENTRO da aba do JMS (precisa ser autocontida). Plano B para quando o
// login não aparece pela API de cookies: lê do próprio site.
function lerTokenNaPagina(nome) {
  const alvo = String(nome).toLowerCase();
  try {
    for (const parte of document.cookie.split(";")) {
      const k = parte.indexOf("=");
      if (k > 0 && parte.slice(0, k).trim().toLowerCase() === alvo) return parte.slice(k + 1).trim();
    }
  } catch (e) {
    /* sem acesso a document.cookie */
  }
  for (const area of ["localStorage", "sessionStorage"]) {
    try {
      const st = window[area];
      for (let n = 0; n < st.length; n++) {
        const chave = st.key(n);
        if (chave && chave.toLowerCase() === alvo) return st.getItem(chave) || "";
      }
    } catch (e) {
      /* armazenamento indisponível */
    }
  }
  return "";
}

// Junta todos os cookies YL_TOKEN do domínio do JMS: normais e particionados
// (o Chrome novo guarda alguns cookies "por site", e a busca simples não os vê),
// no mesmo perfil/janela da aba do sistema.
async function cookiesDoLogin(aba) {
  if (!chrome.cookies || !chrome.cookies.getAll) return [];
  let storeId;
  try {
    const lojas = chrome.cookies.getAllCookieStores ? await chrome.cookies.getAllCookieStores() : [];
    const loja = (lojas || []).find((l) => (l.tabIds || []).includes(aba && aba.id));
    if (loja) storeId = loja.id;
  } catch (e) {
    storeId = undefined;
  }
  const base = storeId ? { domain: LOTE_DOMINIO, storeId } : { domain: LOTE_DOMINIO };
  const achados = [];
  for (const filtro of [base, { ...base, partitionKey: {} }]) {
    try {
      const lista = await chrome.cookies.getAll(filtro);
      if (Array.isArray(lista)) achados.push(...lista);
    } catch (e) {
      /* Chrome antigo sem suporte a partitionKey: segue com o que tiver */
    }
  }
  const alvo = LOTE_API.cookie.toLowerCase();
  return achados.filter((c) => c && String(c.name).toLowerCase() === alvo && ehDominioJms(c.domain) && c.value);
}

// Confere se a extensão consegue falar com o JMS antes de procurar a aba.
// "recarregar": arquivos novos, mas o Chrome ainda roda o manifest antigo
//   (sem as permissões de cookies/scripting) — só recarregar resolve.
// "permitir": manifest certo, mas o acesso ao site foi negado/restrito.
async function verificarAcessoLote() {
  if (!chrome.cookies || !chrome.cookies.getAll || !chrome.scripting || !chrome.scripting.executeScript) return "recarregar";
  if (!chrome.permissions || !chrome.permissions.contains) return "ok"; // sem como checar: segue e deixa a consulta dizer
  try {
    const ok = await chrome.permissions.contains({ origins: [LOTE_API.padraoAba] });
    return ok ? "ok" : "permitir";
  } catch (e) {
    return "permitir";
  }
}

async function obterTokenLote(aba) {
  const host = hostDaAba(aba);
  const valido = (v) => /^[A-Za-z0-9._-]{8,300}$/.test(v);
  const cookies = await cookiesDoLogin(aba);
  // Prioridade: cookie do próprio endereço da aba > do domínio pai > qualquer outro do JMS
  const peso = (c) => {
    const d = String(c.domain).replace(/^\./, "").toLowerCase();
    if (d === host) return 0;
    if (host.endsWith("." + d)) return 1;
    return 2;
  };
  cookies.sort((a, b) => peso(a) - peso(b));
  const candidatos = cookies.map((c) => limparToken(c.value)).filter(Boolean);

  if (!candidatos.length && aba && aba.id != null && chrome.scripting) {
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId: aba.id }, func: lerTokenNaPagina, args: [LOTE_API.cookie] });
      const v = limparToken(r && r.result);
      if (v) candidatos.push(v);
    } catch (e) {
      /* aba indisponível: cai no aviso de login abaixo */
    }
  }

  if (!candidatos.length) throw new ErroLote("token", LOTE_MSG.semToken);
  const bom = candidatos.find(valido);
  if (!bom) throw new ErroLote("token", LOTE_MSG.tokenEstranho);
  return bom;
}

async function acharAbaSistema() {
  const acesso = await verificarAcessoLote();
  if (acesso !== "ok") throw new ErroLote(acesso, LOTE_MSG[acesso]);
  let abas = [];
  try {
    abas = await chrome.tabs.query({ url: LOTE_API.padraoAba });
  } catch (e) {
    abas = [];
  }
  // Prioridade: aba ativa do jmsbr > qualquer jmsbr > ativa de outro endereço do JMS > qualquer outra
  const vivas = (abas || []).filter((a) => a && !a.discarded && a.id != null);
  const preferidas = vivas.filter((a) => hostDaAba(a) === LOTE_API.hostPreferido);
  const aba =
    preferidas.find((a) => a.active) || preferidas[0] || vivas.find((a) => a.active) || vivas[0];
  if (!aba || aba.id == null) throw new ErroLote("aba", LOTE_MSG.semAba);
  return aba;
}

async function pedirLote(tabId, token, lote) {
  const [execucao] = await chrome.scripting.executeScript({
    target: { tabId },
    func: consultarLoteNaPagina,
    args: [LOTE_API.url, montarCabecalhosLote(token), JSON.stringify([lote]), LOTE_CFG.timeoutMs],
  });
  return execucao && execucao.result ? execucao.result : { status: 0, ok: false, erro: "rede" };
}

// Decide o que fazer com a resposta de UM lote.
function classificarRespostaLote(r, lote) {
  if (r.erro === "aba") return { tipo: "fatal", motivo: LOTE_MSG.abaPerdida };
  if (r.erro) return { tipo: "tentar", motivo: r.erro === "timeout" ? "demorou demais" : "sem conexão" };
  if (r.status === 401 || r.status === 403) return { tipo: "auth" };
  if (r.status === 429) return { tipo: "limite", retryAfter: r.retryAfter, motivo: "limite de requisições do servidor" };
  if (r.status >= 500) return { tipo: "tentar", motivo: `erro ${r.status} do servidor` };
  if (!r.ok) return { tipo: "falha", motivo: `erro HTTP ${r.status}` };

  const j = r.json;
  if (!j || typeof j !== "object") return { tipo: "tentar", motivo: "resposta inesperada (sessão expirada?)" };

  const sucesso = (j.succ === true || j.code === 1) && j.fail !== true;
  if (!sucesso) {
    const msg = String(j.msg || "").slice(0, 80);
    if (/token|login|sess[aã]o|expir|autent|unauthor/i.test(msg)) return { tipo: "auth" };
    return { tipo: "falha", motivo: msg || "o sistema recusou a consulta" };
  }
  if (!Array.isArray(j.data)) return { tipo: "tentar", motivo: "resposta sem dados" };

  // Pedimos 1 lote por vez. Se veio 1 item, é ele (mesmo que o código volte
  // formatado diferente); se vierem vários, só vale o que bate com o lote.
  const itens = j.data.filter((i) => i && typeof i === "object");
  const alvo = itens.length === 1 ? itens : itens.filter((i) => String(i.packageNumber || "").trim().toUpperCase() === lote);
  const ids = new Set();
  for (const item of alvo) {
    if (Array.isArray(item.waybillIds)) item.waybillIds.forEach((id) => ids.add(String(id).trim().toUpperCase()));
  }
  return { tipo: "ok", ids, vazio: ids.size === 0 };
}

// Cada execução tem um número. Se a pessoa cancelar (ou começar outra), as
// respostas atrasadas da execução antiga são ignoradas — nada vaza pra nova.
let loteRunAtual = 0;
let loteEmAndamento = false;

async function executarConsultaLotes({ lotes, coletaSet, tabId, token, run, aoProgresso }) {
  const fila = [...lotes];
  const encontrados = new Set();
  const falhas = new Map();
  const vazios = new Set();
  let concluidos = 0;
  let fatal = null;
  let pausaGlobal = Promise.resolve(); // 429 de qualquer um segura TODOS os trabalhadores

  const ativo = () => run === loteRunAtual && !fatal;

  async function consultarUm(lote) {
    let ultimoMotivo = LOTE_MSG.generico;
    for (let tentativa = 1; tentativa <= LOTE_CFG.tentativas; tentativa++) {
      await pausaGlobal;
      if (!ativo()) return null;

      let resposta;
      try {
        resposta = await pedirLote(tabId, token, lote);
      } catch (e) {
        resposta = { erro: "aba" };
      }
      if (!ativo()) return null;

      const c = classificarRespostaLote(resposta, lote);
      if (c.tipo === "ok") return c;
      if (c.tipo === "auth") {
        fatal = new ErroLote("auth", LOTE_MSG.auth);
        return null;
      }
      if (c.tipo === "fatal") {
        fatal = new ErroLote("aba", c.motivo);
        return null;
      }
      if (c.tipo === "falha") return c;

      ultimoMotivo = c.motivo;
      if (c.tipo === "limite") {
        const pausa = dormir(esperaDoRetryAfter(c.retryAfter, tentativa));
        pausaGlobal = pausaGlobal.then(() => pausa);
      } else if (tentativa < LOTE_CFG.tentativas) {
        await dormir(esperaBackoff(tentativa));
      }
    }
    return { tipo: "falha", motivo: ultimoMotivo };
  }

  async function trabalhador() {
    while (ativo()) {
      const lote = fila.shift(); // atômico: JS roda uma coisa por vez, dois trabalhadores nunca pegam o mesmo lote
      if (lote === undefined) return;

      const r = await consultarUm(lote);
      if (r === null) return; // cancelado ou erro fatal
      if (run !== loteRunAtual) return;

      if (r.tipo === "ok") {
        r.ids.forEach((id) => {
          if (coletaSet.has(id)) encontrados.add(id);
        });
        if (r.vazio) vazios.add(lote);
      } else {
        falhas.set(lote, r.motivo);
      }

      concluidos++;
      aoProgresso(concluidos, lotes.length);
      if (fila.length) await dormir(aleatorioEntre(LOTE_CFG.espacoMinMs, LOTE_CFG.espacoMaxMs));
    }
  }

  const quantos = Math.min(LOTE_CFG.concorrencia, lotes.length);
  await Promise.all(Array.from({ length: quantos }, trabalhador));
  return { encontrados, falhas, vazios, fatal };
}

// ---- Interface ----

const loteColeta = document.getElementById("lote-coleta");
const loteLotes = document.getElementById("lote-lotes");
const loteColetaInfo = document.getElementById("lote-coleta-info");
const loteLotesInfo = document.getElementById("lote-lotes-info");
const loteErro = document.getElementById("lote-erro");
const loteSetup = document.getElementById("lote-setup");
const loteProgresso = document.getElementById("lote-progresso");
const loteResultado = document.getElementById("lote-resultado");
const loteConsultarBtn = document.getElementById("lote-consultar");
const loteLimparBtn = document.getElementById("lote-limpar");
const loteCancelarBtn = document.getElementById("lote-cancelar");
const loteBarra = document.getElementById("lote-barra");
const loteBarraPreench = document.getElementById("lote-barra-preench");
const loteProgressoTexto = document.getElementById("lote-progresso-texto");
const loteResTitulo = document.getElementById("lote-res-titulo");
const loteResLista = document.getElementById("lote-res-lista");
const loteResResumo = document.getElementById("lote-res-resumo");
const loteResAvisos = document.getElementById("lote-res-avisos");
const loteResCopiarBtn = document.getElementById("lote-res-copiar");
const loteResRetryBtn = document.getElementById("lote-res-retry");
const loteResVoltarBtn = document.getElementById("lote-res-voltar");
const loteFeedback = document.getElementById("lote-feedback");

const LOTE_CAMPOS_KEY = "lote_campos";
const LOTE_RESULT_KEY = "lote_resultado";

// Último resultado: { coleta, lotes, encontrados:Set, falhas:Map, vazios:Set }
let loteConsulta = null;
let loteSemLoteAtual = [];

function mostrarEstadoLote(qual) {
  loteSetup.classList.toggle("is-hidden", qual !== "setup");
  loteProgresso.classList.toggle("is-active", qual === "progresso");
  loteResultado.classList.toggle("is-active", qual === "resultado");
}

function mostrarErroLote(mensagem) {
  loteErro.textContent = mensagem;
}

// ---- Aviso de acesso ao sistema (extensão sem recarregar / sem permissão) ----
const loteAcesso = document.getElementById("lote-acesso");
const loteAcessoTexto = document.getElementById("lote-acesso-texto");
const loteAcessoBtn = document.getElementById("lote-acesso-btn");
let loteAcessoTipo = "ok";

function mostrarAvisoAcessoLote(tipo) {
  loteAcessoTipo = tipo;
  const problema = tipo === "recarregar" || tipo === "permitir";
  loteAcesso.classList.toggle("is-hidden", !problema);
  if (!problema) return;
  mostrarErroLote(""); // o aviso já explica; não empilha outra mensagem embaixo
  loteAcessoTexto.textContent = LOTE_MSG[tipo];
  loteAcessoBtn.textContent = tipo === "recarregar" ? "Recarregar extensão" : "Permitir acesso";
}

loteAcessoBtn.addEventListener("click", async () => {
  if (loteAcessoTipo === "recarregar") {
    chrome.runtime.reload(); // fecha o popup; ao abrir de novo já vem com as permissões novas
    return;
  }
  try {
    const ok = await chrome.permissions.request({ origins: [LOTE_API.padraoAba] });
    if (ok) {
      mostrarAvisoAcessoLote("ok");
      mostrarErroLote("");
    }
  } catch (e) {
    /* pedido recusado ou indisponível: o aviso continua na tela */
  }
});

verificarAcessoLote().then(mostrarAvisoAcessoLote, () => {});

function atualizarInfoLote(textarea, infoEl) {
  const a = analisarCodigos(textarea.value);
  infoEl.classList.remove("tem-aviso");
  if (!textarea.value.trim()) {
    infoEl.textContent = "";
    return;
  }
  const partes = [`${a.codigos.length} código(s)`];
  if (a.duplicados) partes.push(`${a.duplicados} repetido(s) ignorado(s)`);
  if (a.suspeitos.length) {
    partes.push(`atenção: ${a.suspeitos.length} item(ns) inválido(s) (${a.suspeitos.slice(0, 2).join(", ")})`);
    infoEl.classList.add("tem-aviso");
  } else if (a.linhasIgnoradas) {
    partes.push(`${a.linhasIgnoradas} linha(s) de texto ignorada(s)`);
  }
  infoEl.textContent = partes.join(" · ");
}

// Só salva depois de carregar o que já estava salvo: senão, fechar o popup
// no instante em que ele abre gravaria campos vazios por cima das listas.
let loteCamposCarregados = false;

function salvarCamposLote() {
  if (!loteCamposCarregados) return;
  chrome.storage.session.set({ [LOTE_CAMPOS_KEY]: { coleta: loteColeta.value, lotes: loteLotes.value } });
}

function marcarCampoLoteInvalido(el) {
  el.classList.remove("lote-invalid");
  void el.offsetWidth;
  el.classList.add("lote-invalid");
  el.focus();
}

[
  [loteColeta, loteColetaInfo],
  [loteLotes, loteLotesInfo],
].forEach(([campo, info]) => {
  campo.addEventListener("input", () => {
    campo.classList.remove("lote-invalid");
    mostrarErroLote("");
    descartarResultadoLote(); // listas mudaram: o resultado antigo não corresponde mais
    atualizarInfoLote(campo, info);
    salvarCamposLote();
  });
});

// Salvar a cada tecla já cobre quase tudo; estes reforços garantem o que foi
// colado também ao sair do campo e quando o popup fecha (ex.: clicar fora
// pra ir copiar os lotes no sistema).
[loteColeta, loteLotes].forEach((campo) => {
  campo.addEventListener("change", salvarCamposLote);
  campo.addEventListener("blur", salvarCamposLote);
});
window.addEventListener("pagehide", salvarCamposLote);
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "hidden") salvarCamposLote();
});

function atualizarProgressoLote(feitos, total, texto) {
  const pct = total ? Math.round((feitos / total) * 100) : 0;
  loteBarraPreench.style.width = `${pct}%`;
  loteBarra.setAttribute("aria-valuenow", String(pct));
  loteProgressoTexto.textContent = texto || `${feitos} de ${total} lotes consultados`;
}

function resumirLotes(nomes) {
  const lista = [...nomes];
  const mostrados = lista.slice(0, 4).join(", ");
  return lista.length > 4 ? `${mostrados} +${lista.length - 4}` : mostrados;
}

function descartarResultadoLote() {
  if (!loteConsulta) return;
  loteConsulta = null;
  loteSemLoteAtual = [];
  chrome.storage.session.remove(LOTE_RESULT_KEY);
}

function salvarResultadoLote() {
  const c = loteConsulta;
  chrome.storage.session.set({
    [LOTE_RESULT_KEY]: {
      coleta: c.coleta,
      lotes: c.lotes,
      encontrados: [...c.encontrados],
      falhas: [...c.falhas],
      vazios: [...c.vazios],
    },
  });
}

function mostrarResultadoLote(avisoExtra = "") {
  const c = loteConsulta;
  const semLote = c.coleta.filter((codigo) => !c.encontrados.has(codigo));
  loteSemLoteAtual = semLote;
  const parcial = c.falhas.size > 0;

  loteResTitulo.textContent =
    semLote.length === 0 && !parcial ? "Nenhum código ficou sem lote" : `Sem lote${parcial ? " (parcial)" : ""}: ${semLote.length}`;
  loteResLista.value = semLote.join("\n");
  loteResResumo.textContent =
    `Coleta: ${c.coleta.length} · Em lote: ${c.coleta.length - semLote.length} · Sem lote: ${semLote.length}` +
    ` · Lotes consultados: ${c.lotes.length - c.falhas.size}/${c.lotes.length}`;

  const avisos = [];
  if (avisoExtra) avisos.push(avisoExtra);
  if (parcial) {
    const motivos = [...new Set(c.falhas.values())].slice(0, 2).join("; ");
    avisos.push(
      `${c.falhas.size} lote(s) não puderam ser consultados (${resumirLotes(c.falhas.keys())}${motivos ? " — " + motivos : ""}). ` +
        "A lista pode incluir códigos que estão nesses lotes."
    );
  }
  if (c.vazios.size) avisos.push(`${c.vazios.size} lote(s) vieram sem pacotes: ${resumirLotes(c.vazios)}.`);
  loteResAvisos.textContent = avisos.join(" ");

  loteResRetryBtn.classList.toggle("is-hidden", !parcial);
  mostrarEstadoLote("resultado");
}

async function iniciarConsultaLote(modo = "tudo") {
  if (loteEmAndamento) return;
  mostrarErroLote("");

  let coleta;
  let lotes;
  const base = modo === "falhas" && loteConsulta ? loteConsulta : null;

  if (base) {
    coleta = base.coleta;
    lotes = [...base.falhas.keys()];
  } else {
    const a = analisarCodigos(loteColeta.value);
    const b = analisarCodigos(loteLotes.value);
    if (!a.codigos.length) {
      marcarCampoLoteInvalido(loteColeta);
      mostrarErroLote("Cole a lista da coleta.");
      return;
    }
    if (!b.codigos.length) {
      marcarCampoLoteInvalido(loteLotes);
      mostrarErroLote("Cole a lista de lotes.");
      return;
    }
    coleta = a.codigos;
    lotes = b.codigos;
  }

  if (!base) descartarResultadoLote(); // consulta nova: o resultado antigo não vale mais

  loteEmAndamento = true;
  const run = ++loteRunAtual;
  atualizarProgressoLote(0, lotes.length, "Preparando a consulta…");
  mostrarEstadoLote("progresso");

  try {
    const aba = await acharAbaSistema();
    const token = await obterTokenLote(aba); // lido de novo a cada consulta (pode ter renovado)
    if (run !== loteRunAtual) return;

    atualizarProgressoLote(0, lotes.length);
    const r = await executarConsultaLotes({
      lotes,
      coletaSet: new Set(coleta),
      tabId: aba.id,
      token,
      run,
      aoProgresso: (feitos, total) => {
        if (run === loteRunAtual) atualizarProgressoLote(feitos, total);
      },
    });
    if (run !== loteRunAtual) return; // cancelado enquanto consultava
    if (r.fatal) throw r.fatal;

    const encontrados = new Set(base ? base.encontrados : []);
    r.encontrados.forEach((codigo) => encontrados.add(codigo));
    const vazios = new Set(base ? base.vazios : []);
    r.vazios.forEach((lote) => vazios.add(lote));

    loteConsulta = { coleta, lotes: base ? base.lotes : lotes, encontrados, falhas: r.falhas, vazios };
    salvarResultadoLote();
    mostrarResultadoLote();
  } catch (e) {
    if (run !== loteRunAtual) return;
    loteRunAtual++; // interrompe qualquer consulta desta execução que ainda esteja na fila
    loteEmAndamento = false;
    const mensagem = e instanceof ErroLote ? e.message : LOTE_MSG.generico;
    if (e instanceof ErroLote && (e.tipo === "recarregar" || e.tipo === "permitir")) {
      mostrarAvisoAcessoLote(e.tipo);
      if (base) mostrarResultadoLote(mensagem);
      else mostrarEstadoLote("setup"); // o aviso com o botão já explica; sem repetir no erro
      return;
    }
    if (base) mostrarResultadoLote(mensagem); // refazendo falhas: volta pro resultado que já existia
    else {
      mostrarEstadoLote("setup");
      mostrarErroLote(mensagem);
    }
  } finally {
    if (run === loteRunAtual) loteEmAndamento = false;
  }
}

loteConsultarBtn.addEventListener("click", () => iniciarConsultaLote("tudo"));
loteResRetryBtn.addEventListener("click", () => iniciarConsultaLote("falhas"));

loteCancelarBtn.addEventListener("click", () => {
  loteRunAtual++; // invalida tudo o que ainda estiver a caminho
  loteEmAndamento = false;
  mostrarEstadoLote("setup");
});

loteResVoltarBtn.addEventListener("click", () => mostrarEstadoLote("setup"));

loteResCopiarBtn.addEventListener("click", () => {
  copiarTexto(loteSemLoteAtual.join("\n"), loteFeedback);
});

loteLimparBtn.addEventListener("click", () => {
  loteRunAtual++;
  loteEmAndamento = false;
  loteColeta.value = "";
  loteLotes.value = "";
  atualizarInfoLote(loteColeta, loteColetaInfo);
  atualizarInfoLote(loteLotes, loteLotesInfo);
  mostrarErroLote("");
  descartarResultadoLote();
  chrome.storage.session.remove(LOTE_CAMPOS_KEY);
  mostrarEstadoLote("setup");
});

chrome.storage.session.get([LOTE_CAMPOS_KEY, LOTE_RESULT_KEY], (resultado) => {
  const campos = resultado[LOTE_CAMPOS_KEY];
  // Se a pessoa já começou a colar antes de carregar, o que ela colou vence
  // (e o resultado antigo, que não corresponde mais, é descartado).
  const colouAntes = !!(loteColeta.value || loteLotes.value);
  if (campos && !colouAntes) {
    loteColeta.value = typeof campos.coleta === "string" ? campos.coleta : "";
    loteLotes.value = typeof campos.lotes === "string" ? campos.lotes : "";
    atualizarInfoLote(loteColeta, loteColetaInfo);
    atualizarInfoLote(loteLotes, loteLotesInfo);
  }
  loteCamposCarregados = true;
  if (colouAntes) {
    salvarCamposLote();
    chrome.storage.session.remove(LOTE_RESULT_KEY);
    return;
  }

  const salvo = resultado[LOTE_RESULT_KEY];
  const valido = salvo && [salvo.coleta, salvo.lotes, salvo.encontrados, salvo.falhas, salvo.vazios].every(Array.isArray);
  if (valido) {
    try {
      loteConsulta = {
        coleta: salvo.coleta.map(String),
        lotes: salvo.lotes.map(String),
        encontrados: new Set(salvo.encontrados.map(String)),
        falhas: new Map(salvo.falhas.map(([lote, motivo]) => [String(lote), String(motivo)])),
        vazios: new Set(salvo.vazios.map(String)),
      };
      mostrarResultadoLote();
    } catch (e) {
      loteConsulta = null; // dado salvo estragado: começa do zero em vez de quebrar a aba
      chrome.storage.session.remove(LOTE_RESULT_KEY);
    }
  }
});

// ---------- Changelog ----------
const changelogBtn = document.getElementById("changelog-btn");
const changelogOverlay = document.getElementById("changelog-overlay");
const changelogClose = document.getElementById("changelog-close");
const changelogBody = document.getElementById("changelog-body");

function renderizarChangelog() {
  changelogBody.replaceChildren();

  CHANGELOG.forEach((entrada, indice) => {
    const bloco = document.createElement("div");
    bloco.className = "changelog-entry";

    const head = document.createElement("div");
    head.className = "changelog-entry-head";

    const versao = document.createElement("span");
    versao.className = "changelog-version";
    versao.textContent = `v${entrada.versao}`;
    head.appendChild(versao);

    if (indice === 0) {
      const badge = document.createElement("span");
      badge.className = "changelog-current-badge";
      badge.textContent = "atual";
      head.appendChild(badge);
    }

    const data = document.createElement("span");
    data.className = "changelog-date";
    data.textContent = entrada.data;
    head.appendChild(data);

    const titulo = document.createElement("div");
    titulo.className = "changelog-title";
    titulo.textContent = entrada.titulo;

    const lista = document.createElement("ul");
    lista.className = "changelog-list";
    entrada.itens.forEach((item) => {
      const li = document.createElement("li");
      li.textContent = item;
      lista.appendChild(li);
    });

    bloco.appendChild(head);
    bloco.appendChild(titulo);
    bloco.appendChild(lista);
    changelogBody.appendChild(bloco);

    if (indice < CHANGELOG.length - 1) {
      changelogBody.appendChild(document.createElement("hr")).className = "changelog-divider";
    }
  });
}

function abrirChangelog() {
  renderizarChangelog();
  changelogOverlay.classList.add("is-open");
}

function fecharChangelog() {
  changelogOverlay.classList.remove("is-open");
}

changelogBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  abrirChangelog();
});

changelogClose.addEventListener("click", (e) => {
  e.stopPropagation();
  fecharChangelog();
});

changelogOverlay.addEventListener("click", (e) => {
  if (e.target === changelogOverlay) fecharChangelog();
});

// Esc fecha o que estiver aberto por cima (Novidades ou a prévia da mensagem)
document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  if (changelogOverlay.classList.contains("is-open")) fecharChangelog();
  else fecharTodasPrevias();
});
