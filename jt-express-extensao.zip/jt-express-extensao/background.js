// background.js
// Roda a consulta longa do Lote mesmo com o popup fechado, as consultas do
// raio (Preencher) e as do painel ⚡ dentro do JMS.
//
// - Uma consulta do Lote por vez; começar outra cancela a anterior.
// - O andamento fica em chrome.storage.session (FUNDO_CHAVE): números,
//   resultado parcial para retomar e o contexto que o popup precisa para
//   mostrar o resultado. O token NUNCA vai para lá: é lido do JMS a cada
//   início/retomada e fica só na memória.
// - Se o Chrome encerrar este service worker no meio, o alarme (ou o popup
//   abrindo de novo) retoma do que foi salvo, sem repetir o que já terminou.
// - O ícone da extensão mostra o andamento e o resultado ainda não visto.
// - Kill switch (permissao_extensao = false): não começa nada e para tudo.
//   O background lê o version.json sozinho (a cada 30 min e antes das
//   consultas, se a última leitura tiver mais de 10 min): trava mesmo quem só
//   usa o painel do JMS e nunca abre o popup.

if (typeof importScripts === "function") importScripts("consulta-core.js", "permissao.js");

const FUNDO_TIPOS = ["lote"];
const FUNDO_ALARME = "fundo_manter_vivo";
const FUNDO_TOQUE_MS = 10000; // grava o andamento pelo menos a cada 10 s (esperas longas de 429/backoff)
const FUNDO_COR = { rodando: "#4a4a4a", achou: "#e3191b", zero: "#1f9d55", alerta: "#e08a00" };
const FUNDO_NOME = { lote: "Lote" };

const fundoJobs = { lote: null }; // em memória: { job, cancelado, estado }
let fundoFila = Promise.resolve(); // escritas em ordem (uma leitura-e-escrita nunca atropela outra)

const fundoCopia = (v) => JSON.parse(JSON.stringify(v));
const fundoFmt = (n) => Number(n || 0).toLocaleString("pt-BR");

function fundoEnfileirar(tarefa) {
  const p = fundoFila.then(tarefa);
  fundoFila = p.catch(() => {});
  return p;
}

// Grava uma cópia do estado como está AGORA (não como estará quando a fila andar).
function fundoGravar(tipo, estado) {
  const copia = fundoCopia(estado);
  return fundoEnfileirar(() => chrome.storage.session.set({ [FUNDO_CHAVE[tipo]]: copia })).catch(() => {});
}

async function fundoLerAgora(tipo) {
  try {
    const r = await chrome.storage.session.get(FUNDO_CHAVE[tipo]);
    const st = r && r[FUNDO_CHAVE[tipo]];
    return st && typeof st === "object" ? st : null;
  } catch (e) {
    return null;
  }
}

const fundoLer = (tipo) => fundoEnfileirar(() => fundoLerAgora(tipo)).catch(() => null);

// Lê, muda e grava na mesma vez da fila. fn devolve o estado novo, null para
// apagar a chave ou undefined para não mexer.
function fundoMudar(tipo, fn) {
  return fundoEnfileirar(async () => {
    const st = await fundoLerAgora(tipo);
    const novo = fn(st);
    if (novo === null) await chrome.storage.session.remove(FUNDO_CHAVE[tipo]);
    else if (novo !== undefined) await chrome.storage.session.set({ [FUNDO_CHAVE[tipo]]: fundoCopia(novo) });
  }).catch(() => {});
}

async function fundoBloqueado() {
  try {
    const r = await chrome.storage.local.get(PERMISSAO_CACHE_KEY);
    return !!r && r[PERMISSAO_CACHE_KEY] === false;
  } catch (e) {
    return false;
  }
}

// ---- Kill switch conferido pelo próprio background ----
// Grava o mesmo permissao_extensao do popup; os ouvintes de storage.onChanged
// (no fim do arquivo) param tudo, limpam a sessão e tiram o painel do JMS.
const PERMISSAO_ALARME = "permissao_verificar";
const PERMISSAO_A_CADA_MIN = 30;
const PERMISSAO_VALIDADE_MS = 10 * 60 * 1000;
let permissaoTentadaEm = 0; // última tentativa (com ou sem internet): no máximo 1 leitura a cada 10 min
let permissaoLendo = null;
function verificarPermissaoFundo() {
  if (permissaoLendo) return permissaoLendo;
  permissaoTentadaEm = Date.now();
  permissaoLendo = (async () => {
    const dados = await buscarDadosRemotos();
    if (!dados || typeof dados !== "object") return; // sem internet: vale o último estado
    const permitido = interpretarPermissao(dados.permissao);
    if (permitido === null) return; // campo ausente ou estranho: ninguém decide nada
    const r = await chrome.storage.local.get(PERMISSAO_CACHE_KEY);
    if (!r || r[PERMISSAO_CACHE_KEY] !== permitido) await chrome.storage.local.set({ [PERMISSAO_CACHE_KEY]: permitido });
  })()
    .catch(() => {})
    .finally(() => {
      permissaoLendo = null;
    });
  return permissaoLendo;
}
// Antes de consultar: lê de novo se a última leitura for velha; depois diz se está travada.
async function bloqueadoAgora() {
  if (Date.now() - permissaoTentadaEm > PERMISSAO_VALIDADE_MS) await verificarPermissaoFundo();
  return fundoBloqueado();
}
async function permissaoAgendar() {
  try {
    // criar de novo zeraria o relógio a cada vez que o service worker acorda
    const existe = await chrome.alarms.get(PERMISSAO_ALARME);
    if (!existe) await chrome.alarms.create(PERMISSAO_ALARME, { periodInMinutes: PERMISSAO_A_CADA_MIN, delayInMinutes: 1 });
  } catch (e) {
    /* sem alarmes: ainda confere antes de cada consulta e quando o popup abre */
  }
}

// ---- Resultado em formato que cabe no storage (Set → lista, Map → pares) ----
function fundoSerializar(tipo, r) {
  return { encontrados: [...r.encontrados], falhas: [...r.falhas], vazios: [...r.vazios], contagem: [...r.contagem], daMemoria: r.daMemoria ? r.daMemoria.size : 0, conferido: !!r.conferido };
}

// O que o ícone precisa saber do resultado (sem abrir o popup).
// Lote: parcial = algum lote falhou ou não há contagem — nunca vira sucesso.
function fundoResumo(tipo, p, r) {
  const achados = new Set(Array.isArray(p.baseEncontrados) ? p.baseEncontrados : []);
  r.encontrados.forEach((c) => achados.add(c));
  const semLote = (p.coleta || []).filter((c) => !achados.has(c)).length;
  return { quantos: semLote, parcial: r.falhas.size > 0 || !!p.semContagem, invalidos: Number(p.invalidos) || 0 };
}

// ---- Memória dos lotes (Lote) ----
// Uma chave por lote na sessão: { ids, em }. Nunca no storage.local.
const LOTE_MEM_PREFIXO = "lote_mem:";
function loteMemoriaGravar(lote, ids) {
  chrome.storage.session.set({ [LOTE_MEM_PREFIXO + lote]: { ids, em: Date.now() } }).catch(() => {});
}
async function loteMemoriaApagar() {
  try {
    const tudo = await chrome.storage.session.get(null);
    const chaves = Object.keys(tudo || {}).filter((k) => k.startsWith(LOTE_MEM_PREFIXO));
    if (chaves.length) await chrome.storage.session.remove(chaves);
  } catch (e) {
    /* sem memória para apagar */
  }
}
// Lotes que podem vir da memória nesta consulta (Map lote -> ids) ou null.
// memoria = { consultar: [sempre consultar], cheioCom: N (só lotes com N+ pacotes) }
async function loteProntos(p) {
  const m = p.memoria;
  if (!m || typeof m !== "object" || !Array.isArray(p.lotes)) return null;
  const sempre = new Set(Array.isArray(m.consultar) ? m.consultar : []);
  const cheioCom = Number.isFinite(m.cheioCom) ? m.cheioCom : 0;
  let g = {};
  try {
    g = (await chrome.storage.session.get(p.lotes.map((l) => LOTE_MEM_PREFIXO + l))) || {};
  } catch (e) {
    return null;
  }
  const agora = Date.now();
  const prontos = new Map();
  for (const lote of p.lotes) {
    if (sempre.has(lote)) continue;
    const e = g[LOTE_MEM_PREFIXO + lote];
    if (!e || typeof e !== "object" || !Array.isArray(e.ids) || !Number.isFinite(e.em)) continue;
    const idade = agora - e.em;
    const cheio = e.ids.length >= LOTE_TAMANHO;
    if (idade < 0 || idade >= (cheio ? LOTE_CFG.memoriaCheioValidadeMs : LOTE_CFG.memoriaValidadeMs)) continue;
    if (e.ids.length < cheioCom) continue;
    prontos.set(lote, e.ids);
  }
  return prontos;
}

// Lote em duas fases: 1) consulta (com a memória); 2) se deu "tudo em lote"
// usando a memória, confere de novo os lotes que vieram dela. O sucesso
// nunca sai de dado guardado.
async function fundoRodarLote(p, est, tabId, token, ativo, salvar, aoProgresso) {
  const coletaSet = new Set(p.coleta);
  const aoLote = (lote, ids) => {
    if (ativo()) loteMemoriaGravar(lote, ids);
  };
  // Pausa do minuto / bloqueio do JMS: a tela mostra quanto falta
  const aoAguardar = (ate, motivo) => salvar({ aguardandoAte: ate || 0, aguardandoMotivo: ate ? motivo : "" });
  if (est.fase !== 2) {
    const prontos = await loteProntos(p);
    if (!ativo()) return null;
    const r1 = await executarConsultaLotes({ lotes: p.lotes, coletaSet, tabId, token, ativo, aoProgresso, retomar: est.parcial, prontos, aoLote, aoAguardar });
    if (!ativo() || r1.fatal || !r1.daMemoria.size || r1.falhas.size) return r1;
    const antes = new Set(Array.isArray(p.baseEncontrados) ? p.baseEncontrados : []);
    if (!p.coleta.every((c) => r1.encontrados.has(c) || antes.has(c))) return r1;
    salvar({
      fase: 2,
      fase1: { porLote: [...r1.porLote], vazios: [...r1.vazios], contagem: [...r1.contagem], daMemoria: [...r1.daMemoria] },
      feitos: 0,
      total: r1.daMemoria.size,
      parcial: null,
    });
  }
  const f1 = est.fase1 && typeof est.fase1 === "object" ? est.fase1 : {};
  const daMemoria = listaDeTextos(f1.daMemoria);
  const r2 = await executarConsultaLotes({ lotes: daMemoria, coletaSet, tabId, token, ativo, aoProgresso, retomar: est.parcial, aoLote, aoAguardar });
  if (!ativo() || r2.fatal) return r2;
  // Os da memória saem; entra só o que a conferência viu agora.
  const conferir = new Set(daMemoria);
  const porLote = new Map(listaDePares(f1.porLote).filter(([l]) => !conferir.has(l)));
  r2.porLote.forEach((ids, l) => porLote.set(l, ids));
  const contagem = new Map(listaDePares(f1.contagem).filter(([l, n]) => !conferir.has(l) && Number.isFinite(n)));
  r2.contagem.forEach((n, l) => contagem.set(l, n));
  const vazios = new Set(listaDeTextos(f1.vazios).filter((l) => !conferir.has(l)));
  r2.vazios.forEach((l) => vazios.add(l));
  const encontrados = new Set();
  porLote.forEach((ids) => listaDeTextos(ids).forEach((id) => encontrados.add(id)));
  return { encontrados, falhas: r2.falhas, vazios, contagem, fatal: null, porLote, daMemoria: new Set(), conferido: true };
}

// ---- Rodar uma consulta ----
async function fundoRodar(tipo, reg) {
  const ativo = () => !reg.cancelado && fundoJobs[tipo] === reg;
  const est = reg.estado;
  const salvar = (mudancas) => {
    if (!ativo()) return; // cancelada/substituída: nada mais desta consulta vai para a sessão
    Object.assign(est, mudancas, { atualizadoEm: Date.now() });
    fundoGravar(tipo, est);
    fundoBadge();
  };
  const p = est.params || {};
  try {
    const aba = await acharAbaSistema();
    const token = await obterTokenLote(aba); // lido de novo a cada início/retomada; só na memória
    if (!ativo()) return;
    salvar({ preparando: false });
    const aoProgresso = (feitos, total, fotografia) => salvar({ feitos, total, parcial: fotografia });
    const r = await fundoRodarLote(p, est, aba.id, token, ativo, salvar, aoProgresso);
    if (!r) return;
    if (!ativo()) return;
    if (r.fatal) throw r.fatal;
    salvar({ estado: "pronto", parcial: null, resultado: fundoSerializar(tipo, r), resumo: fundoResumo(tipo, p, r) });
  } catch (e) {
    if (!ativo()) return;
    const conhecido = e instanceof ErroLote;
    const mensagem = conhecido ? e.message : LOTE_MSG.generico;
    salvar({ estado: "erro", parcial: null, erro: { tipo: conhecido ? e.tipo : null, mensagem } });
  } finally {
    if (fundoJobs[tipo] === reg) fundoJobs[tipo] = null;
    fundoAtualizarVida();
    fundoBadge();
  }
}

async function fundoIniciar(msg) {
  const tipo = msg.tipo;
  if (!FUNDO_TIPOS.includes(tipo) || typeof msg.job !== "string" || !msg.params || typeof msg.params !== "object") return { ok: false };
  if (await bloqueadoAgora()) return { ok: false, bloqueado: true };
  const lista = msg.params.lotes;
  if (!Array.isArray(lista)) return { ok: false };
  const antigo = fundoJobs[tipo];
  if (antigo) antigo.cancelado = true; // uma por aba: a nova substitui a antiga
  const estado = {
    job: msg.job,
    tipo,
    estado: "rodando",
    iniciadoEm: Date.now(), // outra janela sabe que esta consulta é mais nova que a dela
    preparando: true,
    feitos: 0,
    total: lista.length,
    params: msg.params,
    parcial: null,
    contexto: msg.contexto && typeof msg.contexto === "object" ? msg.contexto : {},
    aplicado: false,
    visto: false,
    atualizadoEm: Date.now(),
  };
  const reg = { job: msg.job, cancelado: false, estado };
  fundoJobs[tipo] = reg;
  fundoGravar(tipo, estado);
  fundoAtualizarVida();
  fundoBadge();
  fundoRodar(tipo, reg);
  return { ok: true };
}

function fundoCancelar(tipo, job) {
  const reg = fundoJobs[tipo];
  if (reg && reg.job === job) {
    reg.cancelado = true;
    fundoJobs[tipo] = null;
  }
  fundoAtualizarVida();
  return fundoMudar(tipo, (st) => (st && st.job === job && st.estado === "rodando" ? { ...st, estado: "cancelado", parcial: null, atualizadoEm: Date.now() } : undefined)).then(() => {
    fundoBadge();
    return { ok: true };
  });
}

function fundoLimpar(tipo) {
  if (tipo === "lote") loteMemoriaApagar();
  const reg = fundoJobs[tipo];
  if (reg) reg.cancelado = true;
  fundoJobs[tipo] = null;
  fundoAtualizarVida();
  return fundoMudar(tipo, () => null).then(() => {
    fundoBadge();
    return { ok: true };
  });
}

// Popup mostrou o resultado (aplicado) e/ou a pessoa está vendo a aba (visto).
function fundoMarcar(tipo, job, { aplicado = false, visto = false }) {
  return fundoMudar(tipo, (st) => {
    if (!st || (st.estado !== "pronto" && st.estado !== "erro")) return undefined;
    if (job != null && st.job !== job) return undefined;
    if (job == null && !st.aplicado) return undefined; // "visto" sem job só vale para o que já foi mostrado
    return { ...st, aplicado: st.aplicado || aplicado, visto: st.visto || visto };
  }).then(() => {
    fundoBadge();
    return { ok: true };
  });
}

// Retoma o que ficou "rodando" na sessão e não está na memória (o Chrome
// encerrou o service worker). Continua da fotografia salva.
let fundoRetomada = null;
function fundoRetomar() {
  if (fundoRetomada) return fundoRetomada;
  fundoRetomada = (async () => {
    const bloqueado = await fundoBloqueado();
    for (const tipo of FUNDO_TIPOS) {
      if (fundoJobs[tipo]) continue;
      const st = await fundoLer(tipo);
      if (!st || st.estado !== "rodando" || fundoJobs[tipo]) continue;
      if (bloqueado) {
        await fundoMudar(tipo, (agora) => (agora && agora.job === st.job && agora.estado === "rodando" ? { ...agora, estado: "cancelado", parcial: null } : undefined));
        continue;
      }
      const reg = { job: st.job, cancelado: false, estado: st };
      fundoJobs[tipo] = reg;
      fundoRodar(tipo, reg);
    }
    fundoAtualizarVida();
    fundoBadge();
    return { ok: true };
  })().finally(() => {
    fundoRetomada = null;
  });
  return fundoRetomada;
}

// Kill switch: para tudo o que estiver rodando (na memória e na sessão).
async function fundoPararTudo() {
  loteMemoriaApagar();
  for (const tipo of FUNDO_TIPOS) {
    const reg = fundoJobs[tipo];
    if (reg) reg.cancelado = true;
    fundoJobs[tipo] = null;
    await fundoMudar(tipo, (st) => (st && st.estado === "rodando" ? { ...st, estado: "cancelado", parcial: null, atualizadoEm: Date.now() } : undefined));
  }
  fundoAtualizarVida();
  fundoBadge();
}

// ---- Manter vivo enquanto houver consulta ----
let fundoToque = null;
function fundoAtualizarVida() {
  const algum = FUNDO_TIPOS.some((t) => fundoJobs[t]);
  if (algum) {
    if (!fundoToque) {
      fundoToque = setInterval(() => {
        for (const tipo of FUNDO_TIPOS) {
          const reg = fundoJobs[tipo];
          if (!reg || reg.cancelado) continue;
          reg.estado.atualizadoEm = Date.now();
          fundoGravar(tipo, reg.estado);
        }
      }, FUNDO_TOQUE_MS);
      try {
        chrome.alarms.create(FUNDO_ALARME, { periodInMinutes: 0.5 });
      } catch (e) {
        /* sem alarmes: o popup ainda retoma ao abrir */
      }
    }
  } else {
    if (fundoToque) {
      clearInterval(fundoToque);
      fundoToque = null;
    }
    try {
      const p = chrome.alarms.clear(FUNDO_ALARME);
      if (p && p.catch) p.catch(() => {});
    } catch (e) {
      /* nada a limpar */
    }
  }
}

// ---- Ícone da extensão ----
function fundoAviso(st) {
  if (!st || !FUNDO_TIPOS.includes(st.tipo)) return null;
  const nome = FUNDO_NOME[st.tipo];
  if (st.estado === "rodando") {
    return { texto: "…", cor: FUNDO_COR.rodando, titulo: `Consultando lotes: ${fundoFmt(st.feitos)} de ${fundoFmt(st.total)}` };
  }
  if (st.visto) return null;
  if (st.estado === "erro") {
    const msg = String((st.erro && st.erro.mensagem) || "").split(/(?<=\.)\s/)[0];
    return { texto: "!", cor: FUNDO_COR.alerta, titulo: `${nome}: ${msg}` };
  }
  if (st.estado !== "pronto") return null;
  const r = st.resumo || {};
  const n = Number(r.quantos) || 0;
  const numero = n > 99 ? "99+" : String(n);
  // Parcial nunca parece sucesso (Regra nº 1 do Lote)
  if (r.parcial) return { texto: "!", cor: FUNDO_COR.alerta, titulo: `${nome}: consulta incompleta. Abra a extensão e clique em Tentar de novo.` };
  if (n > 0) return { texto: numero, cor: FUNDO_COR.achou, titulo: `Lote: ${fundoFmt(n)} código(s) sem lote` };
  if (Number(r.invalidos) > 0) return { texto: "!", cor: FUNDO_COR.alerta, titulo: "Lote: há itens inválidos na coleta. Abra a extensão." };
  return { texto: "✓", cor: FUNDO_COR.zero, titulo: "Lote: todos os códigos da coleta estão em lote" };
}

async function fundoAplicarBadge() {
  if (!chrome.action || !chrome.action.setBadgeText) return;
  let aviso = null;
  if (!(await fundoBloqueado())) {
    const estados = (await Promise.all(FUNDO_TIPOS.map(fundoLer))).filter(Boolean);
    const rodando = estados.filter((st) => st.estado === "rodando");
    if (rodando.length) {
      aviso = { texto: "…", cor: FUNDO_COR.rodando, titulo: rodando.map((st) => fundoAviso(st).titulo).join(" · ") };
    } else {
      const ultimo = estados
        .map((st) => ({ st, a: fundoAviso(st) }))
        .filter((x) => x.a)
        .sort((x, y) => (Number(y.st.atualizadoEm) || 0) - (Number(x.st.atualizadoEm) || 0))[0];
      aviso = ultimo ? ultimo.a : null;
    }
  }
  try {
    await chrome.action.setBadgeText({ text: aviso ? aviso.texto : "" });
    if (aviso) await chrome.action.setBadgeBackgroundColor({ color: aviso.cor });
    await chrome.action.setTitle({ title: aviso ? aviso.titulo : chrome.runtime.getManifest().name });
  } catch (e) {
    /* ícone indisponível: a consulta segue */
  }
}

// Várias mudanças seguidas viram uma atualização só, sempre na ordem.
let fundoBadgeFila = Promise.resolve();
let fundoBadgeMarcado = false;
function fundoBadge() {
  if (fundoBadgeMarcado) return fundoBadgeFila;
  fundoBadgeMarcado = true;
  fundoBadgeFila = fundoBadgeFila
    .then(() => {
      fundoBadgeMarcado = false;
      return fundoAplicarBadge();
    })
    .catch(() => {});
  return fundoBadgeFila;
}

// ---- Preencher a Ocorrência (botão "Preencher") ----
// Uma consulta curta, por clique: 3 pedidos ao JMS em sequência, respeitando o
// mesmo bloqueio do Lote/Expedido. A resposta (dados da cliente) volta só para
// o popup: nada é gravado, anotado no diagnóstico ou registrado.
async function fundoPreencher(msg) {
  if (await bloqueadoAgora()) return { ok: false, erro: { tipo: "generico", mensagem: PREENCHER_MSG.generico } };
  const rastreio = rastreioJtValido(msg.rastreio);
  if (!rastreio) return { ok: false, erro: { tipo: "invalido", mensagem: PREENCHER_MSG.invalido } };
  if (jmsBloqueadoAte > Date.now()) return { ok: false, limite: true, ate: jmsBloqueadoAte };
  let aba;
  let token;
  try {
    aba = await acharAbaSistema();
    token = await obterTokenLote(aba);
  } catch (e) {
    return { ok: false, erro: e instanceof ErroLote ? { tipo: e.tipo, mensagem: e.message } : { tipo: "generico", mensagem: PREENCHER_MSG.generico } };
  }
  const pedidos = [
    [PREENCHER_API.pedido, { waybillNo: rastreio, countryId: "1" }],
    [PREENCHER_API.telefone, { waybillNo: rastreio, countryId: "1" }],
    [EXP_API.url, { keywordList: [rastreio], trackingTypeEnum: "WAYBILL", countryId: "1" }],
  ];
  const dados = [];
  for (const [url, corpo] of pedidos) {
    let c = null;
    for (let tentativa = 0; tentativa < 2; tentativa++) {
      await vezJms();
      let r;
      try {
        r = await pedirJmsUnico(aba.id, token, url, corpo);
      } catch (e) {
        r = { status: 0, ok: false, erro: "aba" }; // aba fechada/recarregada no meio
      }
      c = classificarRespostaUnica(r);
      if (c.tipo !== "tentar") break;
    }
    if (c.tipo === "ok") {
      dados.push(c.data);
      continue;
    }
    if (c.tipo === "limite") {
      const ate = Date.now() + EXP_CFG.janelaMs + EXP_CFG.janelaMargemMs;
      avisarBloqueioJms(ate);
      return { ok: false, limite: true, ate: jmsBloqueadoAte };
    }
    if (c.tipo === "auth") return { ok: false, erro: { tipo: "auth", mensagem: LOTE_MSG.auth } };
    return { ok: false, erro: { tipo: "falha", mensagem: c.motivo || PREENCHER_MSG.generico } };
  }
  return { ok: true, rastreio, dados: dadosPreencher(dados[0], dados[1], dados[2]) };
}

// ---- Painel ⚡ dentro do JMS ----
// O painel (content script) pede UMA consulta por vez: só diz o tipo e o
// código (ou a página da lista). A URL e o corpo são fixos aqui, o token nunca
// sai do background e o bloqueio do JMS é o mesmo do Lote e do raio
// (jmsBloqueadoAte).
const PAINEL_ID = "painel-jms";
const PAINEL_SITE = "https://jmsbr.jtjms-br.com/*";
const PAINEL_ARQUIVOS = ["consulta-core.js", "painel-regras.js", "painel-jms.js"];
const PAINEL_MSG = {
  generico: "Não foi possível consultar no JMS. Tente novamente.",
  aba: "Esta aba não é do JMS. Abra o painel dentro do sistema.",
  telaVazia: "Não achei a tabela. Abra a tela de monitoramento (aba Detalhes) ou cole os códigos.",
};

// Lista "Gestão de pedido JMS de entrega" (aba Não entregues): Marca de
// assinatura = Não entregue, Horário de criação de hoje − 8 até ontem (7 dias).
// GET não funciona (o JMS responde "Método de solicitação com anormalidade").
const PAINEL_NE = {
  url: "https://gw.jtjms-br.com/networkmanagement/dispatchWaybill/list",
  dias: 7,
  tamanho: 100,
  paginasMax: 30,
};
const diaISO = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
// De ontem para trás: os de hoje ainda estão em rota (decisão do Edson em 27/11).
function janelaNaoEntregues(agora = new Date()) {
  const ini = new Date(agora.getFullYear(), agora.getMonth(), agora.getDate() - PAINEL_NE.dias - 1);
  const fim = new Date(agora.getFullYear(), agora.getMonth(), agora.getDate() - 1);
  return { inicio: diaISO(ini), fim: diaISO(fim) };
}
// Corpo igual ao que a tela manda (oldParams do componente DispatchWaybill)
function corpoNaoEntregues(pagina, janela) {
  const R = MINHA_REDE;
  return {
    current: pagina,
    size: PAINEL_NE.tamanho,
    oneNetwork: R.financeiro.code,
    twoNetwork: R.franquia.code,
    threeNetwork: { id: R.base.id, code: R.base.code, name: R.base.name },
    isSign: 0, // Não entregue
    mergeWaybill: [],
    orderSourceCodes: [],
    isC2C: 0,
    searchTimeType: 0, // Horário de criação
    startTime: `${janela.inicio} 00:00:00`,
    endTime: `${janela.fim} 23:59:59`,
    isFeeCostZero: 0,
    dispatchFinanceCode: R.financeiro.code,
    dispatchFinanceId: R.financeiro.id,
    franchiseeCode: R.franquia.code,
    franchiseeId: R.franquia.id,
    dispatchNetworkCode: R.base.code,
    dispatchNetworkId: R.base.id,
    countryId: "1",
  };
}
// Cada registro tem ~120 campos, vários com dado da cliente: só estes 4 saem daqui.
const textoCurto = (v, max) => String(v == null ? "" : v).replace(/[\u0000-\u001f]+/g, " ").trim().slice(0, max);
function itensNaoEntregues(data) {
  return data
    .filter((i) => i && typeof i === "object")
    .map((i) => ({
      waybillNo: rastreioJtValido(i.waybillNo),
      dispatchTime: textoCurto(i.dispatchTime, 19),
      createTime: textoCurto(i.createTime, 19),
      dispatchStaffName: textoCurto(i.dispatchStaffName, 60),
    }))
    .filter((i) => i.waybillNo);
}

// Cada tipo vira um pedido fixo. corpo null = GET.
function painelPedido(msg) {
  if (msg.tipo === "rastreio") {
    const codigo = rastreioJtValido(msg.codigo);
    return codigo ? { codigo, url: EXP_API.url, corpo: { keywordList: [codigo], trackingTypeEnum: "WAYBILL", countryId: "1" } } : null;
  }
  if (msg.tipo === "naoEntregues") {
    const pagina = Number(msg.pagina);
    if (!Number.isInteger(pagina) || pagina < 1 || pagina > PAINEL_NE.paginasMax) return null;
    const janela = janelaNaoEntregues();
    return { janela, url: PAINEL_NE.url, corpo: corpoNaoEntregues(pagina, janela) };
  }
  return null;
}

// Eventos do código pedido (mesma regra do Expedido antigo: item de outro
// código ou resposta sem evento é suspeita, nunca "sem rastreio").
function painelEventos(r, codigo) {
  const c = classificarRespostaExp(r, [codigo]);
  if (c.tipo !== "ok") return c;
  const itens = r.json.data.filter((i) => i && typeof i === "object");
  const chave = (i) => String(i.keyword == null ? "" : i.keyword).trim().toUpperCase();
  const alvo = itens.length === 1 && !chave(itens[0]) ? itens[0] : itens.find((i) => chave(i) === codigo);
  return { tipo: "ok", data: alvo.details.filter((ev) => ev && typeof ev === "object") };
}

// Cada recusa = espera os 61 s inteiros (decisão do Edson: tentar antes só piora).
function painelMarcarLimite() {
  avisarBloqueioJms(Date.now() + EXP_CFG.janelaMs + EXP_CFG.janelaMargemMs);
  return jmsBloqueadoAte;
}

let painelFila = Promise.resolve(); // várias abas do JMS: uma consulta por vez no total
function painelConsultar(msg, remetente) {
  const p = painelFila.then(() => painelConsultarAgora(msg, remetente));
  painelFila = p.catch(() => {});
  return p;
}

async function painelConsultarAgora(msg, remetente) {
  if (await bloqueadoAgora()) return { ok: false, erro: { tipo: "bloqueado", mensagem: PAINEL_MSG.generico } };
  const pedido = painelPedido(msg);
  if (!pedido) return { ok: false, erro: { tipo: "invalido", mensagem: PREENCHER_MSG.invalido } };
  const aba = remetente && remetente.tab;
  if (!aba || aba.id == null || !ehDominioJms(hostDaAba(aba))) return { ok: false, erro: { tipo: "aba", mensagem: PAINEL_MSG.aba } };
  if (jmsBloqueadoAte > Date.now()) return { ok: false, limite: true, ate: jmsBloqueadoAte };
  let token;
  try {
    token = await obterTokenLote(aba);
  } catch (e) {
    return { ok: false, erro: e instanceof ErroLote ? { tipo: e.tipo, mensagem: e.message } : { tipo: "generico", mensagem: PAINEL_MSG.generico } };
  }
  let c = null;
  for (let tentativa = 0; tentativa < 2; tentativa++) {
    await vezJms();
    if (jmsBloqueadoAte > Date.now()) return { ok: false, limite: true, ate: jmsBloqueadoAte };
    let r;
    try {
      r = await pedirJmsUnico(aba.id, token, pedido.url, pedido.corpo);
    } catch (e) {
      r = { status: 0, ok: false, erro: "aba" };
    }
    c = msg.tipo === "rastreio" ? painelEventos(r, pedido.codigo) : classificarRespostaUnica(r);
    // Lista: recusa sem cara de login (code ≠ 1) ou resposta sem lista pode
    // ser o bloqueio do JMS — espera e tenta de novo em vez de desistir.
    if (msg.tipo !== "rastreio" && c.tipo === "falha") c = { tipo: "suspeito", motivo: c.motivo };
    if (msg.tipo === "naoEntregues" && c.tipo === "ok" && !Array.isArray(c.data)) c = { tipo: "suspeito", motivo: "a lista não veio" };
    if (c.tipo !== "tentar") break;
  }
  if (c.tipo === "ok" && msg.tipo === "naoEntregues")
    return { ok: true, data: { itens: itensNaoEntregues(c.data), brutos: c.data.length, tamanho: PAINEL_NE.tamanho, inicio: pedido.janela.inicio, fim: pedido.janela.fim } };
  if (c.tipo === "ok") return { ok: true, data: c.data };
  if (c.tipo === "limite") return { ok: false, limite: true, ate: painelMarcarLimite() };
  if (c.tipo === "suspeito" || c.tipo === "tentar") return { ok: false, suspeito: true, motivo: String(c.motivo || "resposta estranha") };
  if (c.tipo === "auth") return { ok: false, erro: { tipo: "auth", mensagem: LOTE_MSG.auth } };
  if (c.tipo === "fatal") return { ok: false, erro: { tipo: "aba", mensagem: c.motivo || LOTE_MSG.abaPerdida } };
  return { ok: false, falha: true, motivo: String(c.motivo || PAINEL_MSG.generico) };
}

// ATENÇÃO: roda DENTRO da página do JMS (mundo da página, para ver o Vue da
// tabela). Não usa nada deste arquivo. Lê TODOS os registros da tela (não só a
// página aberta): pede 1000 por página e ESPERA o JMS responder (ele pode
// levar 20 s ou mais); nunca manda um pedido novo com outro no ar. Só vai
// página por página se, depois de tudo carregado, ainda faltar registro.
// Devolve { codigos, total } (total = "Total N" da tela; 0 se não houver).
async function lerTelaMonitorNaPagina() {
  const dormir = (ms) => new Promise((r) => setTimeout(r, ms));
  let ach = null;
  for (const t of document.querySelectorAll(".el-table")) {
    let vm = t.__vue__;
    let d = 0;
    while (vm && d < 6 && !ach) {
      for (const k of ["tableList", "list"]) {
        const L = vm.$data && vm.$data[k];
        if (Array.isArray(L) && L.length && L[0] && L[0].billcode) {
          ach = { vm, k, el: t };
          break;
        }
      }
      vm = vm.$parent;
      d++;
    }
    if (ach) break;
  }
  if (!ach) return null;
  const lista = () => (ach.vm.$data[ach.k] || []).map((r) => String((r && r.billcode) || ""));
  const assinatura = () => {
    const l = lista();
    return `${l.length}:${l[0] || ""}:${l[l.length - 1] || ""}`;
  };
  const totais = [...document.querySelectorAll(".el-pagination__total")].map((e) => +((e.textContent.match(/\d+/) || [0])[0]));
  const total = Math.max(0, ...totais);
  if (lista().length >= total) return { codigos: lista(), total };

  // "Carregando": máscara de carregamento visível ou um loading = true no Vue da tabela (e pais)
  const mascaraVisivel = () =>
    [...document.querySelectorAll(".el-loading-mask")].some((m) => {
      const s = getComputedStyle(m);
      return s.display !== "none" && s.visibility !== "hidden" && m.offsetParent !== null;
    });
  const vueCarregando = () => {
    let vm = ach.vm;
    for (let d = 0; vm && d < 6; d++, vm = vm.$parent) {
      const dt = vm.$data || {};
      for (const k of Object.keys(dt)) if (/loading/i.test(k) && dt[k] === true) return true;
    }
    return false;
  };
  const carregando = () => mascaraVisivel() || vueCarregando();

  // Espera o pedido feito agora: começar (até 8 s) e terminar (até 180 s), com a
  // lista estável por 1 s. Devolve true se algo carregou/mudou.
  async function esperarCarregar(antes) {
    let comecou = false;
    for (let i = 0; i < 16 && !comecou; i++) {
      await dormir(500);
      comecou = carregando() || assinatura() !== antes;
    }
    if (!comecou) return false;
    const fimMax = Date.now() + 180000;
    let estavel = 0;
    let ult = assinatura();
    while (Date.now() < fimMax) {
      await dormir(500);
      const a = assinatura();
      if (!carregando() && a === ult) {
        if (++estavel >= 2) break;
      } else estavel = 0;
      ult = a;
    }
    return true;
  }

  const paginas = [...document.querySelectorAll(".el-pagination")].map((e) => e.__vue__).filter(Boolean);
  const pg = paginas.find((v) => v.total === total) || paginas.pop();
  if (!pg) return { codigos: lista(), total };

  // 1º: página grande (UM pedido) e espera a resposta
  let antes = assinatura();
  pg.$emit("size-change", 1000);
  let reagiu = await esperarCarregar(antes);
  if (!reagiu) {
    // nada aconteceu: tenta 1 vez o jeito alternativo (v-model da paginação)
    antes = assinatura();
    pg.$emit("update:pageSize", 1000);
    reagiu = await esperarCarregar(antes);
  }
  if (lista().length >= total) return { codigos: lista(), total };

  // 2º: ainda faltou registro: página por página, um pedido por vez, esperando cada um
  const todos = new Set(lista());
  const tam = Math.max(1, lista().length);
  const pags = Math.ceil(total / tam);
  for (let p = 1; p <= pags && todos.size < total; p++) {
    if (p === (pg.internalCurrentPage || pg.currentPage)) {
      lista().forEach((c) => todos.add(c)); // a página que já está aberta não precisa de pedido
      continue;
    }
    antes = assinatura();
    pg.$emit("current-change", p);
    await esperarCarregar(antes);
    lista().forEach((c) => todos.add(c));
  }
  return { codigos: [...todos], total };
}

async function painelLerTela(remetente) {
  if (await bloqueadoAgora()) return { ok: false, mensagem: PAINEL_MSG.generico };
  const aba = remetente && remetente.tab;
  if (!aba || aba.id == null || !ehDominioJms(hostDaAba(aba))) return { ok: false, mensagem: PAINEL_MSG.aba };
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId: aba.id, frameIds: [remetente.frameId || 0] }, world: "MAIN", func: lerTelaMonitorNaPagina });
    const lida = r && r.result && Array.isArray(r.result.codigos) ? r.result : null;
    if (!lida) return { ok: false, mensagem: PAINEL_MSG.telaVazia };
    const lidos = new Set(lida.codigos.map((c) => String(c).replace(/[\s\p{Cf}]+/gu, "").toUpperCase()).filter(Boolean));
    const codigos = [...lidos].filter((c) => /^[0-9A-Z]{6,40}$/.test(c));
    const total = Number.isFinite(lida.total) && lida.total > 0 ? Math.floor(lida.total) : 0;
    return { ok: true, codigos, lidos: lidos.size, total };
  } catch (e) {
    return { ok: false, mensagem: PAINEL_MSG.telaVazia };
  }
}

// Registra o painel no JMS só se a pessoa ligou e a extensão está liberada.
let painelSincFila = Promise.resolve();
function painelSincronizar() {
  painelSincFila = painelSincFila.then(painelSincronizarAgora).catch(() => {});
  return painelSincFila;
}
async function painelSincronizarAgora() {
  if (!chrome.scripting || !chrome.scripting.registerContentScripts) return;
  let querer = false;
  try {
    const r = await chrome.storage.local.get(["painel_jms", PERMISSAO_CACHE_KEY]);
    querer = !!r && r.painel_jms === true && r[PERMISSAO_CACHE_KEY] !== false;
  } catch (e) {
    querer = false;
  }
  const registrados = await chrome.scripting.getRegisteredContentScripts({ ids: [PAINEL_ID] }).catch(() => []);
  if (querer && !registrados.length) {
    await chrome.scripting.registerContentScripts([{ id: PAINEL_ID, matches: [PAINEL_SITE], js: PAINEL_ARQUIVOS, runAt: "document_idle", persistAcrossSessions: true }]);
  } else if (!querer && registrados.length) {
    await chrome.scripting.unregisterContentScripts({ ids: [PAINEL_ID] });
  }
  if (!querer) return; // abas abertas escondem o painel sozinhas (storage.onChanged)
  // Abas do JMS já abertas: injeta onde o painel ainda não está carregado
  const abas = await chrome.tabs.query({ url: PAINEL_SITE }).catch(() => []);
  for (const aba of abas) {
    if (!aba || aba.id == null || aba.discarded) continue;
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId: aba.id }, func: () => !!window.__jtPainelCarregado });
      if (r && r.result) continue;
      await chrome.scripting.executeScript({ target: { tabId: aba.id }, files: PAINEL_ARQUIVOS });
    } catch (e) {
      /* aba carregando ou sem acesso: o registro pega no próximo carregamento */
    }
  }
}

// ---- Pelo cabo (celular no USB) ----
// O popup pede UM comando por vez; o background fala com o programa do PC
// (Native Messaging "com.jtexpress.respostas.usb": jt-usb.ps1 + adb), que manda
// o código ao app da J&T como um coletor (broadcast de leitor). Comandos
// fechados e código conferido aqui e lá. Nada é gravado: o código só passa.
const USB_HOST = "com.jtexpress.respostas.usb";
const USB_CMDS = ["status", "prepararLote", "bipar", "contagem"];
const USB_TEMPO = { status: 180000, prepararLote: 60000, bipar: 20000, contagem: 30000 }; // status pode baixar o adb no 1º uso
const USB_MSG = {
  semHost: "O programa do cabo não está instalado neste PC: rode o atualizar-jt.bat de novo.",
  caiu: "O programa do cabo fechou. Tente de novo.",
  tempo: "O celular não respondeu a tempo. Confira o cabo e tente de novo.",
};
let usbPorta = null;
let usbSeq = 0;
const usbPendentes = new Map(); // id -> resolver

function usbConectar() {
  if (usbPorta) return usbPorta;
  const porta = chrome.runtime.connectNative(USB_HOST);
  porta.onMessage.addListener((m) => {
    const fim = m && usbPendentes.get(m.id);
    if (!fim) return;
    usbPendentes.delete(m.id);
    fim(m);
  });
  porta.onDisconnect.addListener(() => {
    const motivo = String((chrome.runtime.lastError && chrome.runtime.lastError.message) || "");
    if (usbPorta === porta) usbPorta = null;
    const msg = /not found|não encontrado|forbidden/i.test(motivo) ? USB_MSG.semHost : USB_MSG.caiu;
    for (const fim of usbPendentes.values()) fim({ ok: false, erro: /not found|forbidden/i.test(motivo) ? "sem_host" : "caiu", mensagem: msg });
    usbPendentes.clear();
  });
  usbPorta = porta;
  return porta;
}

function usbFechar() {
  if (usbPorta) {
    try {
      usbPorta.disconnect();
    } catch (e) {
      /* já fechada */
    }
  }
  usbPorta = null;
  for (const fim of usbPendentes.values()) fim({ ok: false, erro: "parado", mensagem: "Parado." });
  usbPendentes.clear();
}

let usbFila = Promise.resolve(); // um comando por vez, na ordem
function usbPedir(msg, remetente) {
  const p = usbFila.then(() => usbPedirAgora(msg, remetente));
  usbFila = p.catch(() => {});
  return p;
}

async function usbPedirAgora(msg, remetente) {
  // só páginas da própria extensão (popup ou janela dela), nunca o content
  // script do JMS (que chega com o endereço do site)
  const urlExtensao = chrome.runtime.getURL("");
  if (!remetente || !String(remetente.url || "").startsWith(urlExtensao)) return { ok: false, erro: "origem", mensagem: "Pedido recusado." };
  if (await bloqueadoAgora()) return { ok: false, erro: "bloqueado", mensagem: PAINEL_MSG.generico };
  const cmd = String(msg.cmd || "");
  if (!USB_CMDS.includes(cmd)) return { ok: false, erro: "comando", mensagem: "Comando desconhecido." };
  const pedido = { cmd };
  if (cmd === "bipar") {
    const codigo = String(msg.codigo == null ? "" : msg.codigo).replace(/[\s\p{Cf}]+/gu, "").toUpperCase();
    if (!/^[0-9A-Z]{6,40}$/.test(codigo)) return { ok: false, erro: "invalido", mensagem: "Código inválido." };
    pedido.codigo = codigo;
  }
  let porta;
  try {
    porta = usbConectar();
  } catch (e) {
    return { ok: false, erro: "sem_host", mensagem: USB_MSG.semHost };
  }
  return new Promise((resolver) => {
    const id = ++usbSeq;
    const relogio = setTimeout(() => {
      if (!usbPendentes.has(id)) return;
      usbPendentes.delete(id);
      resolver({ ok: false, erro: "tempo", mensagem: USB_MSG.tempo });
    }, USB_TEMPO[cmd]);
    usbPendentes.set(id, (m) => {
      clearTimeout(relogio);
      const r = m && typeof m === "object" ? m : { ok: false, erro: "caiu", mensagem: USB_MSG.caiu };
      delete r.id;
      resolver(r);
    });
    try {
      porta.postMessage({ id, ...pedido });
    } catch (e) {
      usbPendentes.delete(id);
      clearTimeout(relogio);
      usbPorta = null;
      resolver({ ok: false, erro: "caiu", mensagem: USB_MSG.caiu });
    }
  });
}

// ---- Mensagens do popup e do painel ----
chrome.runtime.onMessage.addListener((msg, remetente, responder) => {
  if (!msg || typeof msg !== "object") return false;
  if (remetente && remetente.id && chrome.runtime.id && remetente.id !== chrome.runtime.id) return false;
  const tipo = msg.tipo;
  let p = null;
  if (msg.acao === "iniciar") p = fundoIniciar(msg);
  else if (msg.acao === "retomar") p = fundoRetomar();
  else if (msg.acao === "preencher") p = fundoPreencher(msg);
  else if (msg.acao === "painel") p = painelConsultar(msg, remetente);
  else if (msg.acao === "painelLerTela") p = painelLerTela(remetente);
  else if (msg.acao === "usb") p = usbPedir(msg, remetente);
  else if (FUNDO_TIPOS.includes(tipo)) {
    if (msg.acao === "cancelar") p = fundoCancelar(tipo, msg.job);
    else if (msg.acao === "limpar") p = fundoLimpar(tipo);
    else if (msg.acao === "aplicado") p = fundoMarcar(tipo, msg.job, { aplicado: true, visto: !!msg.visto });
    else if (msg.acao === "visto") p = fundoMarcar(tipo, null, { visto: true });
  }
  if (!p) return false;
  p.then((r) => responder(r || { ok: true }), () => responder({ ok: false }));
  return true;
});

chrome.alarms.onAlarm.addListener((alarme) => {
  if (alarme && alarme.name === FUNDO_ALARME) fundoRetomar();
  if (alarme && alarme.name === PERMISSAO_ALARME) verificarPermissaoFundo();
});

if (chrome.runtime.onStartup)
  chrome.runtime.onStartup.addListener(() => {
    verificarPermissaoFundo();
    fundoRetomar();
  });

// Travou (pelo popup ou pelo background): para tudo e apaga a sessão inteira
// (campos do raio, listas, lote: tudo temporário).
async function travarTudo() {
  usbFechar();
  await fundoPararTudo();
  try {
    await chrome.storage.session.clear();
  } catch (e) {
    /* sessão indisponível: nada a apagar */
  }
}

chrome.storage.onChanged.addListener((mudancas, area) => {
  if (area !== "local") return;
  const p = mudancas[PERMISSAO_CACHE_KEY];
  if (p && p.newValue === false) travarTudo();
  if (p || mudancas.painel_jms) painelSincronizar();
});

if (chrome.runtime.onInstalled)
  chrome.runtime.onInstalled.addListener(() => {
    verificarPermissaoFundo();
    painelSincronizar();
  });
permissaoAgendar();
painelSincronizar();
