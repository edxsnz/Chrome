// background.js
// Roda a consulta longa do Lote mesmo com o popup fechado, as consultas do
// raio (Preencher) e as do painel ⚡ dentro do JMS.
//
// - Uma consulta do Lote por vez; começar outra cancela a anterior.
// - O andamento fica em chrome.storage.session (FUNDO_CHAVE): números,
//   resultado parcial para retomar e o contexto que o popup precisa para
//   mostrar o resultado. O token NUNCA vai para lá: é lido do JMS a cada
//   início/retomada e fica só na memória.
// - Se o Chrome encerrar este service worker no meio, o alarme (ou o popup
//   abrindo de novo) retoma do que foi salvo, sem repetir o que já terminou.
// - O ícone da extensão mostra o andamento e o resultado ainda não visto.
// - Kill switch (permissao_extensao = false): não começa nada e para tudo.

if (typeof importScripts === "function") importScripts("consulta-core.js");

const FUNDO_TIPOS = ["lote"];
const FUNDO_ALARME = "fundo_manter_vivo";
const FUNDO_TOQUE_MS = 10000; // grava o andamento pelo menos a cada 10 s (esperas longas de 429/backoff)
const FUNDO_COR = { rodando: "#4a4a4a", achou: "#e3191b", zero: "#1f9d55", alerta: "#e08a00" };
const FUNDO_NOME = { lote: "Lote" };

const fundoJobs = { lote: null }; // em memória: { job, cancelado, estado }
let fundoFila = Promise.resolve(); // escritas em ordem (uma leitura-e-escrita nunca atropela outra)

const fundoCopia = (v) => JSON.parse(JSON.stringify(v));
const fundoFmt = (n) => Number(n || 0).toLocaleString("pt-BR");

function fundoEnfileirar(tarefa) {
  const p = fundoFila.then(tarefa);
  fundoFila = p.catch(() => {});
  return p;
}

// Grava uma cópia do estado como está AGORA (não como estará quando a fila andar).
function fundoGravar(tipo, estado) {
  const copia = fundoCopia(estado);
  return fundoEnfileirar(() => chrome.storage.session.set({ [FUNDO_CHAVE[tipo]]: copia })).catch(() => {});
}

async function fundoLerAgora(tipo) {
  try {
    const r = await chrome.storage.session.get(FUNDO_CHAVE[tipo]);
    const st = r && r[FUNDO_CHAVE[tipo]];
    return st && typeof st === "object" ? st : null;
  } catch (e) {
    return null;
  }
}

const fundoLer = (tipo) => fundoEnfileirar(() => fundoLerAgora(tipo)).catch(() => null);

// Lê, muda e grava na mesma vez da fila. fn devolve o estado novo, null para
// apagar a chave ou undefined para não mexer.
function fundoMudar(tipo, fn) {
  return fundoEnfileirar(async () => {
    const st = await fundoLerAgora(tipo);
    const novo = fn(st);
    if (novo === null) await chrome.storage.session.remove(FUNDO_CHAVE[tipo]);
    else if (novo !== undefined) await chrome.storage.session.set({ [FUNDO_CHAVE[tipo]]: fundoCopia(novo) });
  }).catch(() => {});
}

async function fundoBloqueado() {
  try {
    const r = await chrome.storage.local.get("permissao_extensao");
    return !!r && r.permissao_extensao === false;
  } catch (e) {
    return false;
  }
}

// ---- Resultado em formato que cabe no storage (Set → lista, Map → pares) ----
function fundoSerializar(tipo, r) {
  return { encontrados: [...r.encontrados], falhas: [...r.falhas], vazios: [...r.vazios], contagem: [...r.contagem], daMemoria: r.daMemoria ? r.daMemoria.size : 0, conferido: !!r.conferido };
}

// O que o ícone precisa saber do resultado (sem abrir o popup).
// Lote: parcial = algum lote falhou ou não há contagem — nunca vira sucesso.
function fundoResumo(tipo, p, r) {
  const achados = new Set(Array.isArray(p.baseEncontrados) ? p.baseEncontrados : []);
  r.encontrados.forEach((c) => achados.add(c));
  const semLote = (p.coleta || []).filter((c) => !achados.has(c)).length;
  return { quantos: semLote, parcial: r.falhas.size > 0 || !!p.semContagem, invalidos: Number(p.invalidos) || 0 };
}

// ---- Memória dos lotes (Lote) ----
// Uma chave por lote na sessão: { ids, em }. Nunca no storage.local.
const LOTE_MEM_PREFIXO = "lote_mem:";
function loteMemoriaGravar(lote, ids) {
  chrome.storage.session.set({ [LOTE_MEM_PREFIXO + lote]: { ids, em: Date.now() } }).catch(() => {});
}
async function loteMemoriaApagar() {
  try {
    const tudo = await chrome.storage.session.get(null);
    const chaves = Object.keys(tudo || {}).filter((k) => k.startsWith(LOTE_MEM_PREFIXO));
    if (chaves.length) await chrome.storage.session.remove(chaves);
  } catch (e) {
    /* sem memória para apagar */
  }
}
// Lotes que podem vir da memória nesta consulta (Map lote -> ids) ou null.
// memoria = { consultar: [sempre consultar], cheioCom: N (só lotes com N+ pacotes) }
async function loteProntos(p) {
  const m = p.memoria;
  if (!m || typeof m !== "object" || !Array.isArray(p.lotes)) return null;
  const sempre = new Set(Array.isArray(m.consultar) ? m.consultar : []);
  const cheioCom = Number.isFinite(m.cheioCom) ? m.cheioCom : 0;
  let g = {};
  try {
    g = (await chrome.storage.session.get(p.lotes.map((l) => LOTE_MEM_PREFIXO + l))) || {};
  } catch (e) {
    return null;
  }
  const agora = Date.now();
  const prontos = new Map();
  for (const lote of p.lotes) {
    if (sempre.has(lote)) continue;
    const e = g[LOTE_MEM_PREFIXO + lote];
    if (!e || typeof e !== "object" || !Array.isArray(e.ids) || !Number.isFinite(e.em)) continue;
    const idade = agora - e.em;
    const cheio = e.ids.length >= LOTE_TAMANHO;
    if (idade < 0 || idade >= (cheio ? LOTE_CFG.memoriaCheioValidadeMs : LOTE_CFG.memoriaValidadeMs)) continue;
    if (e.ids.length < cheioCom) continue;
    prontos.set(lote, e.ids);
  }
  return prontos;
}

// Lote em duas fases: 1) consulta (com a memória); 2) se deu "tudo em lote"
// usando a memória, confere de novo os lotes que vieram dela. O sucesso
// nunca sai de dado guardado.
async function fundoRodarLote(p, est, tabId, token, ativo, salvar, aoProgresso) {
  const coletaSet = new Set(p.coleta);
  const aoLote = (lote, ids) => {
    if (ativo()) loteMemoriaGravar(lote, ids);
  };
  // Pausa do minuto / bloqueio do JMS: a tela mostra quanto falta
  const aoAguardar = (ate, motivo) => salvar({ aguardandoAte: ate || 0, aguardandoMotivo: ate ? motivo : "" });
  if (est.fase !== 2) {
    const prontos = await loteProntos(p);
    if (!ativo()) return null;
    const r1 = await executarConsultaLotes({ lotes: p.lotes, coletaSet, tabId, token, ativo, aoProgresso, retomar: est.parcial, prontos, aoLote, aoAguardar });
    if (!ativo() || r1.fatal || !r1.daMemoria.size || r1.falhas.size) return r1;
    const antes = new Set(Array.isArray(p.baseEncontrados) ? p.baseEncontrados : []);
    if (!p.coleta.every((c) => r1.encontrados.has(c) || antes.has(c))) return r1;
    salvar({
      fase: 2,
      fase1: { porLote: [...r1.porLote], vazios: [...r1.vazios], contagem: [...r1.contagem], daMemoria: [...r1.daMemoria] },
      feitos: 0,
      total: r1.daMemoria.size,
      parcial: null,
    });
  }
  const f1 = est.fase1 && typeof est.fase1 === "object" ? est.fase1 : {};
  const daMemoria = listaDeTextos(f1.daMemoria);
  const r2 = await executarConsultaLotes({ lotes: daMemoria, coletaSet, tabId, token, ativo, aoProgresso, retomar: est.parcial, aoLote, aoAguardar });
  if (!ativo() || r2.fatal) return r2;
  // Os da memória saem; entra só o que a conferência viu agora.
  const conferir = new Set(daMemoria);
  const porLote = new Map(listaDePares(f1.porLote).filter(([l]) => !conferir.has(l)));
  r2.porLote.forEach((ids, l) => porLote.set(l, ids));
  const contagem = new Map(listaDePares(f1.contagem).filter(([l, n]) => !conferir.has(l) && Number.isFinite(n)));
  r2.contagem.forEach((n, l) => contagem.set(l, n));
  const vazios = new Set(listaDeTextos(f1.vazios).filter((l) => !conferir.has(l)));
  r2.vazios.forEach((l) => vazios.add(l));
  const encontrados = new Set();
  porLote.forEach((ids) => listaDeTextos(ids).forEach((id) => encontrados.add(id)));
  return { encontrados, falhas: r2.falhas, vazios, contagem, fatal: null, porLote, daMemoria: new Set(), conferido: true };
}

// ---- Rodar uma consulta ----
async function fundoRodar(tipo, reg) {
  const ativo = () => !reg.cancelado && fundoJobs[tipo] === reg;
  const est = reg.estado;
  const salvar = (mudancas) => {
    if (!ativo()) return; // cancelada/substituída: nada mais desta consulta vai para a sessão
    Object.assign(est, mudancas, { atualizadoEm: Date.now() });
    fundoGravar(tipo, est);
    fundoBadge();
  };
  const p = est.params || {};
  try {
    const aba = await acharAbaSistema();
    const token = await obterTokenLote(aba); // lido de novo a cada início/retomada; só na memória
    if (!ativo()) return;
    salvar({ preparando: false });
    const aoProgresso = (feitos, total, fotografia) => salvar({ feitos, total, parcial: fotografia });
    const r = await fundoRodarLote(p, est, aba.id, token, ativo, salvar, aoProgresso);
    if (!r) return;
    if (!ativo()) return;
    if (r.fatal) throw r.fatal;
    salvar({ estado: "pronto", parcial: null, resultado: fundoSerializar(tipo, r), resumo: fundoResumo(tipo, p, r) });
  } catch (e) {
    if (!ativo()) return;
    const conhecido = e instanceof ErroLote;
    const mensagem = conhecido ? e.message : LOTE_MSG.generico;
    salvar({ estado: "erro", parcial: null, erro: { tipo: conhecido ? e.tipo : null, mensagem } });
  } finally {
    if (fundoJobs[tipo] === reg) fundoJobs[tipo] = null;
    fundoAtualizarVida();
    fundoBadge();
  }
}

async function fundoIniciar(msg) {
  const tipo = msg.tipo;
  if (!FUNDO_TIPOS.includes(tipo) || typeof msg.job !== "string" || !msg.params || typeof msg.params !== "object") return { ok: false };
  if (await fundoBloqueado()) return { ok: false, bloqueado: true };
  const lista = msg.params.lotes;
  if (!Array.isArray(lista)) return { ok: false };
  const antigo = fundoJobs[tipo];
  if (antigo) antigo.cancelado = true; // uma por aba: a nova substitui a antiga
  const estado = {
    job: msg.job,
    tipo,
    estado: "rodando",
    iniciadoEm: Date.now(), // outra janela sabe que esta consulta é mais nova que a dela
    preparando: true,
    feitos: 0,
    total: lista.length,
    params: msg.params,
    parcial: null,
    contexto: msg.contexto && typeof msg.contexto === "object" ? msg.contexto : {},
    aplicado: false,
    visto: false,
    atualizadoEm: Date.now(),
  };
  const reg = { job: msg.job, cancelado: false, estado };
  fundoJobs[tipo] = reg;
  fundoGravar(tipo, estado);
  fundoAtualizarVida();
  fundoBadge();
  fundoRodar(tipo, reg);
  return { ok: true };
}

function fundoCancelar(tipo, job) {
  const reg = fundoJobs[tipo];
  if (reg && reg.job === job) {
    reg.cancelado = true;
    fundoJobs[tipo] = null;
  }
  fundoAtualizarVida();
  return fundoMudar(tipo, (st) => (st && st.job === job && st.estado === "rodando" ? { ...st, estado: "cancelado", parcial: null, atualizadoEm: Date.now() } : undefined)).then(() => {
    fundoBadge();
    return { ok: true };
  });
}

function fundoLimpar(tipo) {
  if (tipo === "lote") loteMemoriaApagar();
  const reg = fundoJobs[tipo];
  if (reg) reg.cancelado = true;
  fundoJobs[tipo] = null;
  fundoAtualizarVida();
  return fundoMudar(tipo, () => null).then(() => {
    fundoBadge();
    return { ok: true };
  });
}

// Popup mostrou o resultado (aplicado) e/ou a pessoa está vendo a aba (visto).
function fundoMarcar(tipo, job, { aplicado = false, visto = false }) {
  return fundoMudar(tipo, (st) => {
    if (!st || (st.estado !== "pronto" && st.estado !== "erro")) return undefined;
    if (job != null && st.job !== job) return undefined;
    if (job == null && !st.aplicado) return undefined; // "visto" sem job só vale para o que já foi mostrado
    return { ...st, aplicado: st.aplicado || aplicado, visto: st.visto || visto };
  }).then(() => {
    fundoBadge();
    return { ok: true };
  });
}

// Retoma o que ficou "rodando" na sessão e não está na memória (o Chrome
// encerrou o service worker). Continua da fotografia salva.
let fundoRetomada = null;
function fundoRetomar() {
  if (fundoRetomada) return fundoRetomada;
  fundoRetomada = (async () => {
    const bloqueado = await fundoBloqueado();
    for (const tipo of FUNDO_TIPOS) {
      if (fundoJobs[tipo]) continue;
      const st = await fundoLer(tipo);
      if (!st || st.estado !== "rodando" || fundoJobs[tipo]) continue;
      if (bloqueado) {
        await fundoMudar(tipo, (agora) => (agora && agora.job === st.job && agora.estado === "rodando" ? { ...agora, estado: "cancelado", parcial: null } : undefined));
        continue;
      }
      const reg = { job: st.job, cancelado: false, estado: st };
      fundoJobs[tipo] = reg;
      fundoRodar(tipo, reg);
    }
    fundoAtualizarVida();
    fundoBadge();
    return { ok: true };
  })().finally(() => {
    fundoRetomada = null;
  });
  return fundoRetomada;
}

// Kill switch: para tudo o que estiver rodando (na memória e na sessão).
async function fundoPararTudo() {
  loteMemoriaApagar();
  for (const tipo of FUNDO_TIPOS) {
    const reg = fundoJobs[tipo];
    if (reg) reg.cancelado = true;
    fundoJobs[tipo] = null;
    await fundoMudar(tipo, (st) => (st && st.estado === "rodando" ? { ...st, estado: "cancelado", parcial: null, atualizadoEm: Date.now() } : undefined));
  }
  fundoAtualizarVida();
  fundoBadge();
}

// ---- Manter vivo enquanto houver consulta ----
let fundoToque = null;
function fundoAtualizarVida() {
  const algum = FUNDO_TIPOS.some((t) => fundoJobs[t]);
  if (algum) {
    if (!fundoToque) {
      fundoToque = setInterval(() => {
        for (const tipo of FUNDO_TIPOS) {
          const reg = fundoJobs[tipo];
          if (!reg || reg.cancelado) continue;
          reg.estado.atualizadoEm = Date.now();
          fundoGravar(tipo, reg.estado);
        }
      }, FUNDO_TOQUE_MS);
      try {
        chrome.alarms.create(FUNDO_ALARME, { periodInMinutes: 0.5 });
      } catch (e) {
        /* sem alarmes: o popup ainda retoma ao abrir */
      }
    }
  } else {
    if (fundoToque) {
      clearInterval(fundoToque);
      fundoToque = null;
    }
    try {
      const p = chrome.alarms.clear(FUNDO_ALARME);
      if (p && p.catch) p.catch(() => {});
    } catch (e) {
      /* nada a limpar */
    }
  }
}

// ---- Ícone da extensão ----
function fundoAviso(st) {
  if (!st || !FUNDO_TIPOS.includes(st.tipo)) return null;
  const nome = FUNDO_NOME[st.tipo];
  if (st.estado === "rodando") {
    return { texto: "…", cor: FUNDO_COR.rodando, titulo: `Consultando lotes: ${fundoFmt(st.feitos)} de ${fundoFmt(st.total)}` };
  }
  if (st.visto) return null;
  if (st.estado === "erro") {
    const msg = String((st.erro && st.erro.mensagem) || "").split(/(?<=\.)\s/)[0];
    return { texto: "!", cor: FUNDO_COR.alerta, titulo: `${nome}: ${msg}` };
  }
  if (st.estado !== "pronto") return null;
  const r = st.resumo || {};
  const n = Number(r.quantos) || 0;
  const numero = n > 99 ? "99+" : String(n);
  // Parcial nunca parece sucesso (Regra nº 1 do Lote)
  if (r.parcial) return { texto: "!", cor: FUNDO_COR.alerta, titulo: `${nome}: consulta incompleta. Abra a extensão e clique em Tentar de novo.` };
  if (n > 0) return { texto: numero, cor: FUNDO_COR.achou, titulo: `Lote: ${fundoFmt(n)} código(s) sem lote` };
  if (Number(r.invalidos) > 0) return { texto: "!", cor: FUNDO_COR.alerta, titulo: "Lote: há itens inválidos na coleta. Abra a extensão." };
  return { texto: "✓", cor: FUNDO_COR.zero, titulo: "Lote: todos os códigos da coleta estão em lote" };
}

async function fundoAplicarBadge() {
  if (!chrome.action || !chrome.action.setBadgeText) return;
  let aviso = null;
  if (!(await fundoBloqueado())) {
    const estados = (await Promise.all(FUNDO_TIPOS.map(fundoLer))).filter(Boolean);
    const rodando = estados.filter((st) => st.estado === "rodando");
    if (rodando.length) {
      aviso = { texto: "…", cor: FUNDO_COR.rodando, titulo: rodando.map((st) => fundoAviso(st).titulo).join(" · ") };
    } else {
      const ultimo = estados
        .map((st) => ({ st, a: fundoAviso(st) }))
        .filter((x) => x.a)
        .sort((x, y) => (Number(y.st.atualizadoEm) || 0) - (Number(x.st.atualizadoEm) || 0))[0];
      aviso = ultimo ? ultimo.a : null;
    }
  }
  try {
    await chrome.action.setBadgeText({ text: aviso ? aviso.texto : "" });
    if (aviso) await chrome.action.setBadgeBackgroundColor({ color: aviso.cor });
    await chrome.action.setTitle({ title: aviso ? aviso.titulo : chrome.runtime.getManifest().name });
  } catch (e) {
    /* ícone indisponível: a consulta segue */
  }
}

// Várias mudanças seguidas viram uma atualização só, sempre na ordem.
let fundoBadgeFila = Promise.resolve();
let fundoBadgeMarcado = false;
function fundoBadge() {
  if (fundoBadgeMarcado) return fundoBadgeFila;
  fundoBadgeMarcado = true;
  fundoBadgeFila = fundoBadgeFila
    .then(() => {
      fundoBadgeMarcado = false;
      return fundoAplicarBadge();
    })
    .catch(() => {});
  return fundoBadgeFila;
}

// ---- Preencher a Ocorrência (botão "Preencher") ----
// Uma consulta curta, por clique: 3 pedidos ao JMS em sequência, respeitando o
// mesmo bloqueio do Lote/Expedido. A resposta (dados da cliente) volta só para
// o popup: nada é gravado, anotado no diagnóstico ou registrado.
async function fundoPreencher(msg) {
  if (await fundoBloqueado()) return { ok: false, erro: { tipo: "generico", mensagem: PREENCHER_MSG.generico } };
  const rastreio = rastreioJtValido(msg.rastreio);
  if (!rastreio) return { ok: false, erro: { tipo: "invalido", mensagem: PREENCHER_MSG.invalido } };
  if (jmsBloqueadoAte > Date.now()) return { ok: false, limite: true, ate: jmsBloqueadoAte };
  let aba;
  let token;
  try {
    aba = await acharAbaSistema();
    token = await obterTokenLote(aba);
  } catch (e) {
    return { ok: false, erro: e instanceof ErroLote ? { tipo: e.tipo, mensagem: e.message } : { tipo: "generico", mensagem: PREENCHER_MSG.generico } };
  }
  const pedidos = [
    [PREENCHER_API.pedido, { waybillNo: rastreio, countryId: "1" }],
    [PREENCHER_API.telefone, { waybillNo: rastreio, countryId: "1" }],
    [EXP_API.url, { keywordList: [rastreio], trackingTypeEnum: "WAYBILL", countryId: "1" }],
  ];
  const dados = [];
  for (const [url, corpo] of pedidos) {
    let c = null;
    for (let tentativa = 0; tentativa < 2; tentativa++) {
      contarEnvioJms();
      let r;
      try {
        r = await pedirJmsUnico(aba.id, token, url, corpo);
      } catch (e) {
        r = { status: 0, ok: false, erro: "aba" }; // aba fechada/recarregada no meio
      }
      c = classificarRespostaUnica(r);
      if (c.tipo !== "tentar") break;
    }
    if (c.tipo === "ok") {
      dados.push(c.data);
      continue;
    }
    if (c.tipo === "limite") {
      const ate = Date.now() + EXP_CFG.janelaMs + EXP_CFG.janelaMargemMs;
      avisarBloqueioJms(ate);
      return { ok: false, limite: true, ate: jmsBloqueadoAte };
    }
    if (c.tipo === "auth") return { ok: false, erro: { tipo: "auth", mensagem: LOTE_MSG.auth } };
    return { ok: false, erro: { tipo: "falha", mensagem: c.motivo || PREENCHER_MSG.generico } };
  }
  return { ok: true, rastreio, dados: dadosPreencher(dados[0], dados[1], dados[2]) };
}

// ---- Painel ⚡ dentro do JMS ----
// O painel (content script) pede UMA consulta por vez: só diz o tipo e o
// código. A URL é fixa aqui, o token nunca sai do background e o bloqueio do
// JMS é o mesmo do Lote e do raio (jmsBloqueadoAte).
const PAINEL_ID = "painel-jms";
const PAINEL_SITE = "https://jmsbr.jtjms-br.com/*";
const PAINEL_ARQUIVOS = ["consulta-core.js", "painel-regras.js", "painel-jms.js"];
const PAINEL_DETALHE_URL = "https://gw.jtjms-br.com/networkmanagement/omsWaybill/detail?waybillNo=";
const PAINEL_MSG = {
  generico: "Não foi possível consultar no JMS. Tente novamente.",
  aba: "Esta aba não é do JMS. Abra o painel dentro do sistema.",
  telaVazia: "Não achei a tabela. Abra a tela de monitoramento (aba Detalhes) ou cole os códigos.",
};

// Cada tipo vira um pedido fixo. corpo null = GET.
function painelPedido(tipo, codigo) {
  if (tipo === "rastreio") return { url: EXP_API.url, corpo: { keywordList: [codigo], trackingTypeEnum: "WAYBILL", countryId: "1" } };
  if (tipo === "cliente") return { url: PREENCHER_API.telefone, corpo: { waybillNo: codigo, countryId: "1" } };
  if (tipo === "detalhe") return { url: PAINEL_DETALHE_URL + encodeURIComponent(codigo), corpo: null };
  return null;
}

// Eventos do código pedido (mesma regra do Expedido antigo: item de outro
// código ou resposta sem evento é suspeita, nunca "sem rastreio").
function painelEventos(r, codigo) {
  const c = classificarRespostaExp(r, [codigo]);
  if (c.tipo !== "ok") return c;
  const itens = r.json.data.filter((i) => i && typeof i === "object");
  const chave = (i) => String(i.keyword == null ? "" : i.keyword).trim().toUpperCase();
  const alvo = itens.length === 1 && !chave(itens[0]) ? itens[0] : itens.find((i) => chave(i) === codigo);
  return { tipo: "ok", data: alvo.details.filter((ev) => ev && typeof ev === "object") };
}

// 1ª recusa abre a janela de ~1 min; recusa logo depois dela é a sonda (4 s).
let painelRecusaDesde = 0;
function painelMarcarLimite() {
  const agora = Date.now();
  if (!painelRecusaDesde || agora - painelRecusaDesde > EXP_CFG.janelaMs * 3) painelRecusaDesde = agora;
  const fimJanela = painelRecusaDesde + EXP_CFG.janelaMs + EXP_CFG.janelaMargemMs;
  avisarBloqueioJms(agora < fimJanela ? fimJanela : agora + EXP_CFG.sondaMs);
  return jmsBloqueadoAte;
}

let painelFila = Promise.resolve(); // várias abas do JMS: uma consulta por vez no total
function painelConsultar(msg, remetente) {
  const p = painelFila.then(() => painelConsultarAgora(msg, remetente));
  painelFila = p.catch(() => {});
  return p;
}

async function painelConsultarAgora(msg, remetente) {
  if (await fundoBloqueado()) return { ok: false, erro: { tipo: "bloqueado", mensagem: PAINEL_MSG.generico } };
  const codigo = rastreioJtValido(msg.codigo);
  const pedido = codigo ? painelPedido(msg.tipo, codigo) : null;
  if (!pedido) return { ok: false, erro: { tipo: "invalido", mensagem: PREENCHER_MSG.invalido } };
  const aba = remetente && remetente.tab;
  if (!aba || aba.id == null || !ehDominioJms(hostDaAba(aba))) return { ok: false, erro: { tipo: "aba", mensagem: PAINEL_MSG.aba } };
  if (jmsBloqueadoAte > Date.now()) return { ok: false, limite: true, ate: jmsBloqueadoAte };
  let token;
  try {
    token = await obterTokenLote(aba);
  } catch (e) {
    return { ok: false, erro: e instanceof ErroLote ? { tipo: e.tipo, mensagem: e.message } : { tipo: "generico", mensagem: PAINEL_MSG.generico } };
  }
  let c = null;
  for (let tentativa = 0; tentativa < 2; tentativa++) {
    contarEnvioJms();
    let r;
    try {
      r = await pedirJmsUnico(aba.id, token, pedido.url, pedido.corpo);
    } catch (e) {
      r = { status: 0, ok: false, erro: "aba" };
    }
    c = msg.tipo === "rastreio" ? painelEventos(r, codigo) : classificarRespostaUnica(r);
    if (c.tipo !== "tentar") break;
  }
  if (c.tipo === "ok") {
    painelRecusaDesde = 0;
    return { ok: true, data: c.data };
  }
  if (c.tipo === "limite") return { ok: false, limite: true, ate: painelMarcarLimite() };
  if (c.tipo === "suspeito" || c.tipo === "tentar") return { ok: false, suspeito: true, motivo: String(c.motivo || "resposta estranha") };
  if (c.tipo === "auth") return { ok: false, erro: { tipo: "auth", mensagem: LOTE_MSG.auth } };
  if (c.tipo === "fatal") return { ok: false, erro: { tipo: "aba", mensagem: c.motivo || LOTE_MSG.abaPerdida } };
  return { ok: false, falha: true, motivo: String(c.motivo || PAINEL_MSG.generico) };
}

// ATENÇÃO: roda DENTRO da página do JMS (mundo da página, para ver o Vue da
// tabela). Não usa nada deste arquivo. Devolve só os códigos da tabela.
function lerTelaMonitorNaPagina() {
  for (const t of document.querySelectorAll(".el-table")) {
    let vm = t.__vue__;
    let d = 0;
    while (vm && d < 6) {
      const L = vm.$data && (vm.$data.tableList || vm.$data.list);
      if (Array.isArray(L) && L.length && L[0] && L[0].billcode) return L.map((r) => String((r && r.billcode) || ""));
      vm = vm.$parent;
      d++;
    }
  }
  return null;
}

async function painelLerTela(remetente) {
  if (await fundoBloqueado()) return { ok: false, mensagem: PAINEL_MSG.generico };
  const aba = remetente && remetente.tab;
  if (!aba || aba.id == null || !ehDominioJms(hostDaAba(aba))) return { ok: false, mensagem: PAINEL_MSG.aba };
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId: aba.id, frameIds: [remetente.frameId || 0] }, world: "MAIN", func: lerTelaMonitorNaPagina });
    const lista = r && Array.isArray(r.result) ? r.result : null;
    if (!lista) return { ok: false, mensagem: PAINEL_MSG.telaVazia };
    const codigos = [...new Set(lista.map((c) => c.replace(/[\s\p{Cf}]+/gu, "").toUpperCase()).filter((c) => /^[0-9A-Z]{6,40}$/.test(c)))];
    return { ok: true, codigos };
  } catch (e) {
    return { ok: false, mensagem: PAINEL_MSG.telaVazia };
  }
}

// Registra o painel no JMS só se a pessoa ligou e a extensão está liberada.
let painelSincFila = Promise.resolve();
function painelSincronizar() {
  painelSincFila = painelSincFila.then(painelSincronizarAgora).catch(() => {});
  return painelSincFila;
}
async function painelSincronizarAgora() {
  if (!chrome.scripting || !chrome.scripting.registerContentScripts) return;
  let querer = false;
  try {
    const r = await chrome.storage.local.get(["painel_jms", "permissao_extensao"]);
    querer = !!r && r.painel_jms === true && r.permissao_extensao !== false;
  } catch (e) {
    querer = false;
  }
  const registrados = await chrome.scripting.getRegisteredContentScripts({ ids: [PAINEL_ID] }).catch(() => []);
  if (querer && !registrados.length) {
    await chrome.scripting.registerContentScripts([{ id: PAINEL_ID, matches: [PAINEL_SITE], js: PAINEL_ARQUIVOS, runAt: "document_idle", persistAcrossSessions: true }]);
  } else if (!querer && registrados.length) {
    await chrome.scripting.unregisterContentScripts({ ids: [PAINEL_ID] });
  }
  if (!querer) return; // abas abertas escondem o painel sozinhas (storage.onChanged)
  // Abas do JMS já abertas: injeta onde o painel ainda não está carregado
  const abas = await chrome.tabs.query({ url: PAINEL_SITE }).catch(() => []);
  for (const aba of abas) {
    if (!aba || aba.id == null || aba.discarded) continue;
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId: aba.id }, func: () => !!window.__jtPainelCarregado });
      if (r && r.result) continue;
      await chrome.scripting.executeScript({ target: { tabId: aba.id }, files: PAINEL_ARQUIVOS });
    } catch (e) {
      /* aba carregando ou sem acesso: o registro pega no próximo carregamento */
    }
  }
}

// ---- Mensagens do popup e do painel ----
chrome.runtime.onMessage.addListener((msg, remetente, responder) => {
  if (!msg || typeof msg !== "object") return false;
  if (remetente && remetente.id && chrome.runtime.id && remetente.id !== chrome.runtime.id) return false;
  const tipo = msg.tipo;
  let p = null;
  if (msg.acao === "iniciar") p = fundoIniciar(msg);
  else if (msg.acao === "retomar") p = fundoRetomar();
  else if (msg.acao === "preencher") p = fundoPreencher(msg);
  else if (msg.acao === "painel") p = painelConsultar(msg, remetente);
  else if (msg.acao === "painelLerTela") p = painelLerTela(remetente);
  else if (FUNDO_TIPOS.includes(tipo)) {
    if (msg.acao === "cancelar") p = fundoCancelar(tipo, msg.job);
    else if (msg.acao === "limpar") p = fundoLimpar(tipo);
    else if (msg.acao === "aplicado") p = fundoMarcar(tipo, msg.job, { aplicado: true, visto: !!msg.visto });
    else if (msg.acao === "visto") p = fundoMarcar(tipo, null, { visto: true });
  }
  if (!p) return false;
  p.then((r) => responder(r || { ok: true }), () => responder({ ok: false }));
  return true;
});

chrome.alarms.onAlarm.addListener((alarme) => {
  if (alarme && alarme.name === FUNDO_ALARME) fundoRetomar();
});

if (chrome.runtime.onStartup) chrome.runtime.onStartup.addListener(() => fundoRetomar());

chrome.storage.onChanged.addListener((mudancas, area) => {
  if (area === "local" && mudancas.permissao_extensao && mudancas.permissao_extensao.newValue === false) fundoPararTudo();
  if (area === "local" && (mudancas.permissao_extensao || mudancas.painel_jms)) painelSincronizar();
});

if (chrome.runtime.onInstalled) chrome.runtime.onInstalled.addListener(() => painelSincronizar());
painelSincronizar();
