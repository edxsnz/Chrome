// background.js
// Roda as consultas longas (abas Lote e Expedido) mesmo com o popup fechado.
//
// - Uma consulta por aba ("lote" / "exp"); começar outra cancela a anterior.
// - O andamento fica em chrome.storage.session (FUNDO_CHAVE): números,
//   resultado parcial para retomar e o contexto que o popup precisa para
//   mostrar o resultado. O token NUNCA vai para lá: é lido do JMS a cada
//   início/retomada e fica só na memória.
// - Se o Chrome encerrar este service worker no meio, o alarme (ou o popup
//   abrindo de novo) retoma do que foi salvo, sem repetir o que já terminou.
// - O ícone da extensão mostra o andamento e o resultado ainda não visto.
// - Kill switch (permissao_extensao = false): não começa nada e para tudo.

if (typeof importScripts === "function") importScripts("consulta-core.js");

const FUNDO_TIPOS = ["lote", "exp"];
const FUNDO_ALARME = "fundo_manter_vivo";
const FUNDO_TOQUE_MS = 10000; // grava o andamento pelo menos a cada 10 s (esperas longas de 429/backoff)
const FUNDO_COR = { rodando: "#4a4a4a", achou: "#e3191b", zero: "#1f9d55", alerta: "#e08a00" };
const FUNDO_NOME = { lote: "Lote", exp: "Expedido" };

const fundoJobs = { lote: null, exp: null }; // em memória: { job, cancelado, estado }
let fundoFila = Promise.resolve(); // escritas em ordem (uma leitura-e-escrita nunca atropela outra)

const fundoCopia = (v) => JSON.parse(JSON.stringify(v));
const fundoFmt = (n) => Number(n || 0).toLocaleString("pt-BR");

function fundoEnfileirar(tarefa) {
  const p = fundoFila.then(tarefa);
  fundoFila = p.catch(() => {});
  return p;
}

// Grava uma cópia do estado como está AGORA (não como estará quando a fila andar).
function fundoGravar(tipo, estado) {
  const copia = fundoCopia(estado);
  return fundoEnfileirar(() => chrome.storage.session.set({ [FUNDO_CHAVE[tipo]]: copia })).catch(() => {});
}

async function fundoLerAgora(tipo) {
  try {
    const r = await chrome.storage.session.get(FUNDO_CHAVE[tipo]);
    const st = r && r[FUNDO_CHAVE[tipo]];
    return st && typeof st === "object" ? st : null;
  } catch (e) {
    return null;
  }
}

const fundoLer = (tipo) => fundoEnfileirar(() => fundoLerAgora(tipo)).catch(() => null);

// Lê, muda e grava na mesma vez da fila. fn devolve o estado novo, null para
// apagar a chave ou undefined para não mexer.
function fundoMudar(tipo, fn) {
  return fundoEnfileirar(async () => {
    const st = await fundoLerAgora(tipo);
    const novo = fn(st);
    if (novo === null) await chrome.storage.session.remove(FUNDO_CHAVE[tipo]);
    else if (novo !== undefined) await chrome.storage.session.set({ [FUNDO_CHAVE[tipo]]: fundoCopia(novo) });
  }).catch(() => {});
}

async function fundoBloqueado() {
  try {
    const r = await chrome.storage.local.get("permissao_extensao");
    return !!r && r.permissao_extensao === false;
  } catch (e) {
    return false;
  }
}

// ---- Resultado em formato que cabe no storage (Set → lista, Map → pares) ----
function fundoSerializar(tipo, r) {
  if (tipo === "lote") {
    return { encontrados: [...r.encontrados], falhas: [...r.falhas], vazios: [...r.vazios], contagem: [...r.contagem] };
  }
  return { expedidos: [...r.expedidos], outros: [...r.outros], semRastreio: [...r.semRastreio], falhas: [...r.falhas] };
}

// O que o ícone precisa saber do resultado (sem abrir o popup).
// Lote: parcial = algum lote falhou ou não há contagem — nunca vira sucesso.
function fundoResumo(tipo, p, r) {
  if (tipo === "lote") {
    const achados = new Set(Array.isArray(p.baseEncontrados) ? p.baseEncontrados : []);
    r.encontrados.forEach((c) => achados.add(c));
    const semLote = (p.coleta || []).filter((c) => !achados.has(c)).length;
    return { quantos: semLote, parcial: r.falhas.size > 0 || !!p.semContagem, invalidos: Number(p.invalidos) || 0 };
  }
  return { quantos: (Number(p.baseExpedidos) || 0) + r.expedidos.size, parcial: r.falhas.size > 0 };
}

// ---- Rodar uma consulta ----
async function fundoRodar(tipo, reg) {
  const ativo = () => !reg.cancelado && fundoJobs[tipo] === reg;
  const est = reg.estado;
  const salvar = (mudancas) => {
    if (!ativo()) return; // cancelada/substituída: nada mais desta consulta vai para a sessão
    Object.assign(est, mudancas, { atualizadoEm: Date.now() });
    fundoGravar(tipo, est);
    fundoBadge();
  };
  const p = est.params || {};
  try {
    const aba = await acharAbaSistema();
    const token = await obterTokenLote(aba); // lido de novo a cada início/retomada; só na memória
    if (!ativo()) return;
    salvar({ preparando: false });
    const aoProgresso = (feitos, total, fotografia) => salvar({ feitos, total, parcial: fotografia });
    let r;
    if (tipo === "lote") {
      r = await executarConsultaLotes({ lotes: p.lotes, coletaSet: new Set(p.coleta), tabId: aba.id, token, ativo, aoProgresso, retomar: est.parcial });
    } else {
      r = await executarConsultaExp({ codigos: p.codigos, tabId: aba.id, token, ativo, aoProgresso, retomar: est.parcial });
    }
    if (!ativo()) return;
    if (r.fatal) throw r.fatal;
    salvar({ estado: "pronto", parcial: null, resultado: fundoSerializar(tipo, r), resumo: fundoResumo(tipo, p, r) });
  } catch (e) {
    if (!ativo()) return;
    const conhecido = e instanceof ErroLote;
    const mensagem = conhecido ? e.message : tipo === "lote" ? LOTE_MSG.generico : EXP_MSG.generico;
    salvar({ estado: "erro", parcial: null, erro: { tipo: conhecido ? e.tipo : null, mensagem } });
  } finally {
    if (fundoJobs[tipo] === reg) fundoJobs[tipo] = null;
    fundoAtualizarVida();
    fundoBadge();
  }
}

async function fundoIniciar(msg) {
  const tipo = msg.tipo;
  if (!FUNDO_TIPOS.includes(tipo) || typeof msg.job !== "string" || !msg.params || typeof msg.params !== "object") return { ok: false };
  if (await fundoBloqueado()) return { ok: false, bloqueado: true };
  const lista = tipo === "lote" ? msg.params.lotes : msg.params.codigos;
  if (!Array.isArray(lista)) return { ok: false };
  const antigo = fundoJobs[tipo];
  if (antigo) antigo.cancelado = true; // uma por aba: a nova substitui a antiga
  const estado = {
    job: msg.job,
    tipo,
    estado: "rodando",
    preparando: true,
    feitos: 0,
    total: lista.length,
    params: msg.params,
    parcial: null,
    contexto: msg.contexto && typeof msg.contexto === "object" ? msg.contexto : {},
    aplicado: false,
    visto: false,
    atualizadoEm: Date.now(),
  };
  const reg = { job: msg.job, cancelado: false, estado };
  fundoJobs[tipo] = reg;
  fundoGravar(tipo, estado);
  fundoAtualizarVida();
  fundoBadge();
  fundoRodar(tipo, reg);
  return { ok: true };
}

function fundoCancelar(tipo, job) {
  const reg = fundoJobs[tipo];
  if (reg && reg.job === job) {
    reg.cancelado = true;
    fundoJobs[tipo] = null;
  }
  fundoAtualizarVida();
  return fundoMudar(tipo, (st) => (st && st.job === job && st.estado === "rodando" ? { ...st, estado: "cancelado", parcial: null, atualizadoEm: Date.now() } : undefined)).then(() => {
    fundoBadge();
    return { ok: true };
  });
}

function fundoLimpar(tipo) {
  const reg = fundoJobs[tipo];
  if (reg) reg.cancelado = true;
  fundoJobs[tipo] = null;
  fundoAtualizarVida();
  return fundoMudar(tipo, () => null).then(() => {
    fundoBadge();
    return { ok: true };
  });
}

// Popup mostrou o resultado (aplicado) e/ou a pessoa está vendo a aba (visto).
function fundoMarcar(tipo, job, { aplicado = false, visto = false }) {
  return fundoMudar(tipo, (st) => {
    if (!st || (st.estado !== "pronto" && st.estado !== "erro")) return undefined;
    if (job != null && st.job !== job) return undefined;
    if (job == null && !st.aplicado) return undefined; // "visto" sem job só vale para o que já foi mostrado
    return { ...st, aplicado: st.aplicado || aplicado, visto: st.visto || visto };
  }).then(() => {
    fundoBadge();
    return { ok: true };
  });
}

// Retoma o que ficou "rodando" na sessão e não está na memória (o Chrome
// encerrou o service worker). Continua da fotografia salva.
let fundoRetomada = null;
function fundoRetomar() {
  if (fundoRetomada) return fundoRetomada;
  fundoRetomada = (async () => {
    const bloqueado = await fundoBloqueado();
    for (const tipo of FUNDO_TIPOS) {
      if (fundoJobs[tipo]) continue;
      const st = await fundoLer(tipo);
      if (!st || st.estado !== "rodando" || fundoJobs[tipo]) continue;
      if (bloqueado) {
        await fundoMudar(tipo, (agora) => (agora && agora.job === st.job && agora.estado === "rodando" ? { ...agora, estado: "cancelado", parcial: null } : undefined));
        continue;
      }
      const reg = { job: st.job, cancelado: false, estado: st };
      fundoJobs[tipo] = reg;
      fundoRodar(tipo, reg);
    }
    fundoAtualizarVida();
    fundoBadge();
    return { ok: true };
  })().finally(() => {
    fundoRetomada = null;
  });
  return fundoRetomada;
}

// Kill switch: para tudo o que estiver rodando (na memória e na sessão).
async function fundoPararTudo() {
  for (const tipo of FUNDO_TIPOS) {
    const reg = fundoJobs[tipo];
    if (reg) reg.cancelado = true;
    fundoJobs[tipo] = null;
    await fundoMudar(tipo, (st) => (st && st.estado === "rodando" ? { ...st, estado: "cancelado", parcial: null, atualizadoEm: Date.now() } : undefined));
  }
  fundoAtualizarVida();
  fundoBadge();
}

// ---- Manter vivo enquanto houver consulta ----
let fundoToque = null;
function fundoAtualizarVida() {
  const algum = FUNDO_TIPOS.some((t) => fundoJobs[t]);
  if (algum) {
    if (!fundoToque) {
      fundoToque = setInterval(() => {
        for (const tipo of FUNDO_TIPOS) {
          const reg = fundoJobs[tipo];
          if (!reg || reg.cancelado) continue;
          reg.estado.atualizadoEm = Date.now();
          fundoGravar(tipo, reg.estado);
        }
      }, FUNDO_TOQUE_MS);
      try {
        chrome.alarms.create(FUNDO_ALARME, { periodInMinutes: 0.5 });
      } catch (e) {
        /* sem alarmes: o popup ainda retoma ao abrir */
      }
    }
  } else {
    if (fundoToque) {
      clearInterval(fundoToque);
      fundoToque = null;
    }
    try {
      const p = chrome.alarms.clear(FUNDO_ALARME);
      if (p && p.catch) p.catch(() => {});
    } catch (e) {
      /* nada a limpar */
    }
  }
}

// ---- Ícone da extensão ----
function fundoAviso(st) {
  if (!st || !FUNDO_TIPOS.includes(st.tipo)) return null;
  const nome = FUNDO_NOME[st.tipo];
  if (st.estado === "rodando") {
    const oQue = st.tipo === "lote" ? "Consultando lotes" : "Consultando rastreios";
    return { texto: "…", cor: FUNDO_COR.rodando, titulo: `${oQue}: ${fundoFmt(st.feitos)} de ${fundoFmt(st.total)}` };
  }
  if (st.visto) return null;
  if (st.estado === "erro") {
    const msg = String((st.erro && st.erro.mensagem) || "").split(/(?<=\.)\s/)[0];
    return { texto: "!", cor: FUNDO_COR.alerta, titulo: `${nome}: ${msg}` };
  }
  if (st.estado !== "pronto") return null;
  const r = st.resumo || {};
  const n = Number(r.quantos) || 0;
  const numero = n > 99 ? "99+" : String(n);
  // Parcial nunca parece sucesso (Regra nº 1 do Lote)
  if (r.parcial) return { texto: "!", cor: FUNDO_COR.alerta, titulo: `${nome}: consulta incompleta. Abra a extensão e clique em Tentar de novo.` };
  if (st.tipo === "exp") {
    return n > 0
      ? { texto: numero, cor: FUNDO_COR.achou, titulo: `Expedido não chegou: ${fundoFmt(n)}` }
      : { texto: "0", cor: FUNDO_COR.zero, titulo: "Expedido não chegou: nenhum" };
  }
  if (n > 0) return { texto: numero, cor: FUNDO_COR.achou, titulo: `Lote: ${fundoFmt(n)} código(s) sem lote` };
  if (Number(r.invalidos) > 0) return { texto: "!", cor: FUNDO_COR.alerta, titulo: "Lote: há itens inválidos na coleta. Abra a extensão." };
  return { texto: "✓", cor: FUNDO_COR.zero, titulo: "Lote: todos os códigos da coleta estão em lote" };
}

async function fundoAplicarBadge() {
  if (!chrome.action || !chrome.action.setBadgeText) return;
  let aviso = null;
  if (!(await fundoBloqueado())) {
    const estados = (await Promise.all(FUNDO_TIPOS.map(fundoLer))).filter(Boolean);
    const rodando = estados.filter((st) => st.estado === "rodando");
    if (rodando.length) {
      aviso = { texto: "…", cor: FUNDO_COR.rodando, titulo: rodando.map((st) => fundoAviso(st).titulo).join(" · ") };
    } else {
      const ultimo = estados
        .map((st) => ({ st, a: fundoAviso(st) }))
        .filter((x) => x.a)
        .sort((x, y) => (Number(y.st.atualizadoEm) || 0) - (Number(x.st.atualizadoEm) || 0))[0];
      aviso = ultimo ? ultimo.a : null;
    }
  }
  try {
    await chrome.action.setBadgeText({ text: aviso ? aviso.texto : "" });
    if (aviso) await chrome.action.setBadgeBackgroundColor({ color: aviso.cor });
    await chrome.action.setTitle({ title: aviso ? aviso.titulo : chrome.runtime.getManifest().name });
  } catch (e) {
    /* ícone indisponível: a consulta segue */
  }
}

// Várias mudanças seguidas viram uma atualização só, sempre na ordem.
let fundoBadgeFila = Promise.resolve();
let fundoBadgeMarcado = false;
function fundoBadge() {
  if (fundoBadgeMarcado) return fundoBadgeFila;
  fundoBadgeMarcado = true;
  fundoBadgeFila = fundoBadgeFila
    .then(() => {
      fundoBadgeMarcado = false;
      return fundoAplicarBadge();
    })
    .catch(() => {});
  return fundoBadgeFila;
}

// ---- Mensagens do popup ----
chrome.runtime.onMessage.addListener((msg, remetente, responder) => {
  if (!msg || typeof msg !== "object") return false;
  if (remetente && remetente.id && chrome.runtime.id && remetente.id !== chrome.runtime.id) return false;
  const tipo = msg.tipo;
  let p = null;
  if (msg.acao === "iniciar") p = fundoIniciar(msg);
  else if (msg.acao === "retomar") p = fundoRetomar();
  else if (FUNDO_TIPOS.includes(tipo)) {
    if (msg.acao === "cancelar") p = fundoCancelar(tipo, msg.job);
    else if (msg.acao === "limpar") p = fundoLimpar(tipo);
    else if (msg.acao === "aplicado") p = fundoMarcar(tipo, msg.job, { aplicado: true, visto: !!msg.visto });
    else if (msg.acao === "visto") p = fundoMarcar(tipo, null, { visto: true });
  }
  if (!p) return false;
  p.then((r) => responder(r || { ok: true }), () => responder({ ok: false }));
  return true;
});

chrome.alarms.onAlarm.addListener((alarme) => {
  if (alarme && alarme.name === FUNDO_ALARME) fundoRetomar();
});

if (chrome.runtime.onStartup) chrome.runtime.onStartup.addListener(() => fundoRetomar());

chrome.storage.onChanged.addListener((mudancas, area) => {
  if (area === "local" && mudancas.permissao_extensao && mudancas.permissao_extensao.newValue === false) fundoPararTudo();
});
