// painel-regras.js
// Regras do painel ⚡ do JMS (Recebimento, Não entregues, Rastreio): funções
// puras, sem tela nem chrome.*. Carregado depois do consulta-core.js (usa
// MINHA_BASE, ultimoEventoExp e ehExpedidoNaoChegou).
// A aba Planilhas (RETIDOS / SEM MOV / Tentativas) e a aba Cobrar (mensagens)
// foram descontinuadas em 26.11.24.3: a "Não entregues" ficou no lugar.

const PainelRegras = (() => {
  const CFG = {
    base: typeof MINHA_BASE === "string" ? MINHA_BASE : "F MAT-SP",
    origemExpedido: "SP RBP", // expedido não chegou: último bipe = carregada nesta base para a F MAT
  };
  // Motivos de problemático que contam como TRATATIVA (tentativa de entrega)
  const RE_TRATATIVA = /aus[eê]ncia|endere[cç]o|recus|mudou|fechad|desconhecid|n[aã]o localiz|reagend|risco|dif[ií]cil acesso|n[aã]o atend/i;
  // Motivos de problemático que significam que o pacote NÃO chegou fisicamente (expedido não chegou / extravio)
  const RE_NAO_CHEGOU = /expedid|n[aã]o chegou|extravio/i;
  // Bipes administrativos (não provam onde o pacote está). 110 = problemático,
  // 130 = "Concluído" (fecha registro no sistema), 170 = registro de devolução,
  // 190/191 = interceptação.
  const ADM = [110, 130, 190, 191, 170, 172, 180];
  // Códigos de bipe que conhecemos. Código fora daqui = tratado como ADMINISTRATIVO
  // e avisado no Detalhe ("bipe desconhecido – conferir").
  // (conferidos nos 134 rastreios reais de 24/11/2026): 1 carregada, 2 recebida, 10 coleta,
  // 20 recepção, 30/33 inserida/removida do lote, 80 descarga, 91 coleta de chegadas,
  // 94 saída para entrega, 100 assinatura, 120 entrada no galpão, 210 coleta recebida
  // (ponto), 500 expedido hand over; e os administrativos do ADM.
  const CONHECIDOS = new Set([1, 2, 10, 20, 30, 33, 80, 91, 94, 100, 120, 210, 500, ...ADM]);

  // Relógio trocável (testes)
  let relogio = () => new Date();
  const pad = (n) => String(n).padStart(2, "0");
  const agora = () => {
    const d = relogio();
    return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  };
  const hojeISO = () => {
    const d = relogio();
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  };
  const dm = (t) => (t ? `${t.slice(8, 10)}/${t.slice(5, 7)}` : ""); // '2026-11-21 09:10:00' -> '21/11'
  const dmh = (t) => (t ? `${dm(t)} ${t.slice(11, 16)}` : "");
  const hh = (t) => (t ? t.slice(11, 16) : "");
  const diasEntre = (t) => {
    if (!t) return 0;
    const a = new Date(t.slice(0, 10) + "T00:00:00");
    const b = new Date(hojeISO() + "T00:00:00");
    return Math.round((b - a) / 864e5);
  };
  const ehHoje = (t) => !!t && t.slice(0, 10) === hojeISO();
  const codigos = (txt) => [...new Set(String(txt).match(/\b(?:999|888)\d{12}\b/g) || [])];
  const semF = (n) => String(n || "").replace(/^F\s+/i, "").trim();
  const cap = (s) => String(s).toLowerCase().replace(/(^|\s)\S/g, (x) => x.toUpperCase());
  // nomes = { "NOME NO JMS SEM O F": "Apelido" } (cadastrado no painel, nunca no código)
  const primeiroNome = (staff, nomes = {}) => {
    const n = semF(staff).toUpperCase().replace(/\s+/g, " ");
    return (nomes && nomes[n]) || cap(n.split(" ")[0] || "");
  };
  // texto cortado (sem o "]" no fim) também vale: pega até o fim
  const causa = (s) => (((s.waybillTrackingContent || "").match(/causa do problema \[([^\]]+)/) || [])[1] || "").replace(/[一-鿿]+/g, "").replace(/\./g, " ").trim();
  const destino = (s) => (((s.waybillTrackingContent || "").match(/para \[([^\]]+)\]/) || [])[1] || "").trim();

  // Eventos do JMS → formato do painel, do mais antigo ao mais novo.
  // exp = o evento é "expedido mas não chegou" (marcado por outra base ou por nós).
  function normalizar(detalhes) {
    const lista = Array.isArray(detalhes) ? detalhes.filter((s) => s && typeof s === "object") : [];
    const ultimo = typeof ultimoEventoExp === "function" ? ultimoEventoExp(lista) : null;
    return lista
      .map((s) => ({
        t: String(s.scanTime || ""),
        c: s.code,
        tipo: String(s.scanTypeName || ""),
        base: String(s.scanNetworkName || ""),
        por: String(s.scanByName || ""),
        staff: String(s.staffName || ""),
        motivo: causa(s),
        dest: destino(s),
        txt: String(s.waybillTrackingContent || "").slice(0, 300),
        exp: typeof ehExpedidoNaoChegou === "function" ? ehExpedidoNaoChegou(s) : false,
        ultimo: s === ultimo,
      }))
      .sort((a, b) => a.t.localeCompare(b.t));
  }

  const ehSaida = (s) => s.c === 94 || /sa[ií]da para entrega/i.test(s.tipo);
  const ehProb = (s) => s.c === 110 || /problem/i.test(s.tipo);
  const ehAssin = (s) => /assinatura|entregue/i.test(s.tipo);
  const ehInterc = (s) => s.c === 190 || /registro de pacote intercept/i.test(s.tipo);
  const ehDevol = (s) => s.c === 170 || /registro de devolu/i.test(s.tipo);
  const ehCarga = (s) => s.c === 1 || /carregada/i.test(s.tipo);
  const ehLote = (s) => s.c === 30 || /inserid.*lote/i.test(s.tipo);
  // Bipe que NÃO prova onde o pacote está: os administrativos e qualquer
  // código que não conhecemos (melhor conferir à mão do que adivinhar).
  const ehDesconhecido = (s) => !Number.isInteger(s.c) || !CONHECIDOS.has(s.c);
  const ehAdm = (s) => ADM.includes(s.c) || ehDesconhecido(s);
  const juntar = (...partes) => partes.filter(Boolean).join(" · ");

  // ---------- Não entregues (tela "Gestão de pedido JMS de entrega") ----------
  // Foco só nos entregadores. Texto da coluna A da aba "Não entregues" da
  // planilha: NÃO mudar sem avisar o Edson (a planilha pinta procurando
  // "Erro de consulta", "Preso no app", "Problemático e não voltou", "Voltou e não
  // saiu", "Conferir", "Volta pra base" e "Com o entregador").
  const GRUPO = {
    E: "⚠️ Erro de consulta",
    P: "📞 Preso no app – sem bipe desde a saída",
    U: "📞 Problemático e não voltou",
    V: "🟦 Voltou e não saiu",
    Q: "⚠ Conferir",
    H: "↩️ Volta pra base",
    M: "🚚 Com o entregador hoje",
    X: "⬜ Saiu da lista",
  };
  // Blocos da planilha, nesta ordem. "Conferir" (Q) cai no bloco pela data da saída.
  const BLOCOS = [
    { id: "erro", grupos: "E" },
    { id: "antigo", grupos: "PUVQ" },
    { id: "hoje", grupos: "HQM" },
    { id: "saiu", grupos: "X" },
  ];
  const blocoDe = (r) => (r.sec === "E" ? "erro" : r.sec === "X" ? "saiu" : r.sec === "Q" ? (r.hoje ? "hoje" : "antigo") : "PUV".includes(r.sec) ? "antigo" : "hoje");

  // code = rastreio; det = eventos normalizados (null = o JMS não respondeu);
  // item = linha da tela { dispatchTime, dispatchStaffName } (reserva quando o
  // rastreio não tem a saída). A 1ª regra que bater vale. Nenhum código some:
  // ou cai num grupo ou em "Saiu da lista", sempre com o motivo.
  function classificarNaoEntregue(code, det, item = {}, nomes = {}) {
    const it = item && typeof item === "object" ? item : {};
    const R = { code, sec: "X", hoje: false, entregador: String(it.dispatchStaffName || ""), tentTxt: "", saida: "", dias: 0, fazer: "", detalhe: "" };
    const saidaTela = String(it.dispatchTime || "");
    const usarSaida = (t) => {
      R.saida = dmh(t);
      R.dias = t ? diasEntre(t) : 0;
      R.hoje = ehHoje(t);
    };
    if (!det || !det.length) {
      usarSaida(saidaTela);
      R.sec = "E";
      R.fazer = "Rodar de novo – NÃO sai da lista";
      R.detalhe = "Não consegui consultar no JMS";
      return R;
    }
    const fis = det.filter((s) => !ehAdm(s)); // só bipes que provam onde o pacote está
    const last = fis[fis.length - 1] || det[det.length - 1];
    // tentativas: 1 por dia, só problemático NA NOSSA BASE com motivo de tratativa
    const porDia = {};
    det.filter((s) => s.base === CFG.base && ehProb(s) && RE_TRATATIVA.test(s.motivo)).forEach((s) => {
      porDia[s.t.slice(0, 10)] = s;
    });
    const tent = Object.values(porDia).sort((a, b) => a.t.localeCompare(b.t));
    const n = tent.length;
    R.tentTxt = `${Math.min(n, 3)}/3`;
    const historico = n ? `Tentativas: ${tent.map((s) => `${dm(s.t)} ${s.motivo || s.tipo}`).join(" → ")}` : "";
    const lembrete3 = n >= 3 ? "3/3: dar retorno na base antes de devolver" : "";
    const ultSaida = [...det].reverse().find(ehSaida);
    if (ultSaida && ultSaida.staff) R.entregador = ultSaida.staff;
    usarSaida(ultSaida ? ultSaida.t : saidaTela);
    const nome = R.entregador ? primeiroNome(R.entregador, nomes) : "o entregador";
    const desconhecidos = [...new Set(det.filter((s) => s.base === CFG.base && ehDesconhecido(s)).map((s) => s.c))];
    const avisoDesc = desconhecidos.length ? `⚠ bipe desconhecido (código ${desconhecidos.join(", ")}) – conferir` : "";
    const extras = (...p) => juntar(...p, historico, lembrete3, avisoDesc);
    const conferir = (fazer, ...det2) => {
      R.sec = "Q";
      R.fazer = fazer;
      R.detalhe = extras(...det2);
      return R;
    };

    // Entregue (a tela atrasou)
    if (det.some(ehAssin)) {
      R.fazer = `Entregue ${dmh(det.filter(ehAssin).pop().t)}`;
      R.detalhe = "a tela ainda mostra não entregue";
      return R;
    }
    // Saiu da F MAT (carregada daqui) e a próxima base bipou "não chegou": não é
    // coisa de entregador, sai da lista com o motivo escrito.
    const expFora = det.filter((s) => s.base !== CFG.base && ehProb(s) && RE_NAO_CHEGOU.test(s.motivo)).pop();
    if (expFora) {
      const carga = det.filter((s) => s.t < expFora.t && ehCarga(s)).pop();
      if (carga && carga.base === CFG.base && !det.some((s) => s.t > expFora.t && !ehAdm(s) && s.base !== "HQ")) {
        R.fazer = `Saiu da ${CFG.base} ${dm(carga.t)} pra ${carga.dest || expFora.base} e ${expFora.base} bipou não chegou`;
        R.detalhe = `${expFora.motivo} ${dmh(expFora.t)}`;
        return R;
      }
    }
    // Expedido não chegou DE ENTRADA (vinha para nós): não é da base e nunca é "preso"
    const expNC = det.filter((s) => s.base === CFG.base && ehProb(s) && RE_NAO_CHEGOU.test(s.motivo)).pop();
    const devolAntes = expNC && det.some((s) => ehDevol(s) && s.t < expNC.t);
    if (expNC && !devolAntes && !det.some((s) => s.t > expNC.t && !ehAdm(s)))
      return conferir(`Não chegou fisicamente (entrada) – bipado ${dmh(expNC.t)}`, `${expNC.motivo} na ${CFG.base} – não é responsabilidade da base; conferir por que está na tela`);
    // Já saiu da F MAT (outra base ou carregada daqui)
    if (last.base !== CFG.base) {
      R.fazer = `Já saiu da ${CFG.base} – ${last.tipo} em ${last.base} ${dmh(last.t)}`;
      return R;
    }
    if (ehCarga(last)) {
      R.fazer = `Já saiu da ${CFG.base} – carregada pra ${last.dest || "?"} ${dmh(last.t)}`;
      return R;
    }
    // Devolução registrada / interceptado / sem saída no rastreio
    const i190 = det.filter(ehInterc).pop();
    const i191 = det.filter((s) => s.c === 191 || /cancelamento de pacote intercept/i.test(s.tipo)).pop();
    const devol = det.filter(ehDevol).pop();
    if (devol) return conferir(`Devolução registrada ${dm(devol.t)} – conferir se voltou e ensacar`, `Último bipe: ${last.tipo} ${dmh(last.t)}`);
    if (i190 && (!i191 || i191.t < i190.t)) return conferir(`Interceptado ${dm(i190.t)} – tirar a interceptação ou devolver`, `Último bipe: ${last.tipo} ${dmh(last.t)}`);
    if (!ultSaida) return conferir("Sem saída pra entrega no rastreio – conferir", `Último bipe: ${last.tipo} ${dmh(last.t)}`);

    const depois = (s) => s.t > ultSaida.t;
    // Inserido em lote depois da saída (antes do "Voltou": quase sempre é devolução)
    const lote = det.filter((s) => depois(s) && s.base === CFG.base && ehLote(s)).pop();
    if (lote) return conferir(`Inserido em lote ${dmh(lote.t)} – conferir se é devolução`, `Saiu com ${semF(R.entregador) || "o entregador"} ${dmh(ultSaida.t)}`);
    const voltou = fis.find(depois); // 1º bipe físico depois da saída = chegou de volta
    const prob = det.filter((s) => depois(s) && ehProb(s)).pop();
    const motivoProb = prob ? prob.motivo || prob.tipo : "";
    // Problemático que não é motivo de tentativa (ex.: "Insucesso na devolução"):
    // entra no mesmo grupo, mas não soma no n/3 e o Detalhe avisa.
    const naoTent = prob && !RE_TRATATIVA.test(prob.motivo) ? `⚠ "${motivoProb}" não conta como tentativa` : "";
    if (voltou) {
      if (R.hoje) {
        R.sec = "H";
        R.fazer = n >= 3 ? `Já voltou ${hh(voltou.t)} – registrar a devolução (3/3)` : `Já voltou ${hh(voltou.t)}${motivoProb ? ` (${motivoProb.toLowerCase()})` : ""} – mandar pra rota de novo (${R.tentTxt})`;
      } else {
        R.sec = "V";
        R.fazer = n >= 3 ? "Registrar a devolução (3/3) – já está no galpão" : `Mandar pra rota (${n + 1}ª tentativa)`;
      }
      R.detalhe = extras(`Voltou pra base ${dmh(voltou.t)}`, naoTent);
      return R;
    }
    if (prob) {
      if (R.hoje) {
        R.sec = "H";
        R.fazer = `${motivoProb} hoje ${hh(prob.t)} (${R.tentTxt}) – ` + (n >= 3 ? "quando voltar, registrar a devolução" : "voltar e sair de novo");
      } else {
        R.sec = "U";
        R.fazer = `Cobrar ${nome} – ${motivoProb.toLowerCase()} ${dm(prob.t)} e não voltou pra base`;
      }
      R.detalhe = extras(`Saiu ${dmh(ultSaida.t)} – ${motivoProb} ${dmh(prob.t)} e sem bipe de entrada depois`, naoTent);
      return R;
    }
    if (R.hoje) {
      R.sec = "M";
      R.fazer = "Aguardar";
      R.detalhe = extras(`Saiu hoje ${hh(ultSaida.t)}`);
      return R;
    }
    R.sec = "P";
    R.fazer = `Cobrar ${nome} – saiu ${dm(ultSaida.t)} e não teve bipe nenhum (pode ser só falta assinar)`;
    R.detalhe = extras(`Saiu pra entrega ${dmh(ultSaida.t)} e não teve bipe depois`);
    return R;
  }

  // Ordem da planilha: erro → não são de hoje → hoje → saíram; dentro, por grupo;
  // não são de hoje: mais dias primeiro → entregador → código;
  // hoje: entregador → código (ajuda a redistribuir).
  function ordenarNaoEntregues(linhas) {
    const posBloco = (r) => BLOCOS.findIndex((b) => b.id === blocoDe(r));
    const posGrupo = (r) => BLOCOS[posBloco(r)].grupos.indexOf(r.sec);
    return [...linhas].sort(
      (a, b) =>
        posBloco(a) - posBloco(b) ||
        posGrupo(a) - posGrupo(b) ||
        (blocoDe(a) === "antigo" ? +b.dias - +a.dias : 0) ||
        semF(a.entregador).localeCompare(semF(b.entregador)) ||
        a.code.localeCompare(b.code)
    );
  }

  // Quantos em cada grupo (Q separado por bloco: Qa = não são de hoje, Qh = hoje)
  function contarNaoEntregues(linhas) {
    const c = { E: 0, P: 0, U: 0, V: 0, Qa: 0, H: 0, Qh: 0, M: 0, X: 0, antigo: 0, hoje: 0 };
    for (const r of linhas) {
      const b = blocoDe(r);
      if (r.sec === "Q") c[b === "hoje" ? "Qh" : "Qa"]++;
      else c[r.sec]++;
      if (b === "antigo" || b === "hoje") c[b]++;
    }
    return c;
  }

  // tela = { total, inicio, fim } da lista lida ("AAAA-MM-DD")
  function resumoNaoEntregues(linhas, tela = {}) {
    const c = contarNaoEntregues(linhas);
    const dmISO = (d) => (d ? `${String(d).slice(8, 10)}/${String(d).slice(5, 7)}` : "?");
    return (
      `Atualizado em ${agora()}` +
      (c.E ? ` · ⚠ ERRO DE CONSULTA: ${c.E} (rodar de novo)` : "") +
      ` · Tela: ${tela.total == null ? linhas.length : tela.total} não entregues (${dmISO(tela.inicio)}–${dmISO(tela.fim)})` +
      ` · NÃO SÃO DE HOJE: ${c.antigo} (Preso no app ${c.P} · Problemático e não voltou ${c.U} · Voltou e não saiu ${c.V} · Conferir ${c.Qa})` +
      ` · HOJE: ${c.hoje} (Volta pra base ${c.H} · Com o entregador ${c.M} · Conferir ${c.Qh})` +
      ` · Saíram da lista: ${c.X}`
    );
  }

  // TSV para a aba "Não entregues" da planilha "Tickets" (célula A2 + Ctrl+V).
  // Linha em branco entre os grupos; as 150 linhas vazias no fim limpam o que
  // sobrou da rodada anterior.
  const limT = (s) => String(s).replace(/[\t\r\n]+/g, " ");
  const VAZIA = "\t".repeat(7);
  function tsvNaoEntregues(linhas, tela = {}) {
    const corpo = [];
    let ant = null;
    for (const r of ordenarNaoEntregues(linhas)) {
      const chave = blocoDe(r) + r.sec;
      if (ant !== null && chave !== ant) corpo.push(VAZIA);
      ant = chave;
      corpo.push([GRUPO[r.sec], r.code, r.fazer, semF(r.entregador), r.tentTxt, r.saida, r.dias, r.detalhe].map(limT).join("\t"));
    }
    return [
      limT(resumoNaoEntregues(linhas, tela)),
      ["Grupo", "Código", "O que fazer", "Entregador", "Tentativas", "Última saída", "Dias", "Detalhe"].join("\t"),
      ...corpo,
      ...Array(150).fill(VAZIA),
    ].join("\n");
  }

  // ---------- Recebimento (expedido não chegou que mandaram para nós) ----------
  const entraExpedido = (det) => {
    const l = det && det[det.length - 1];
    return !!l && /carregada/i.test(l.tipo) && l.base === CFG.origemExpedido && l.dest === CFG.base;
  };
  // Depois de bipar: o último bipe é problemático "expedido…" na nossa base
  const bipeCerto = (det) => {
    const l = det && det[det.length - 1];
    return !!l && ehProb(l) && /expedi/i.test(l.motivo) && l.base === CFG.base;
  };
  // Uma consulta por código (a repescagem garante a resposta). r: { código: det | null (não consultado) }
  // entra = falta bipar; jaBipados = já tem o bipe "expedido…" da nossa base; fora = não é caso.
  function conferirRecebimento(todos, r) {
    const entra = [];
    const jaBipados = [];
    const naoConsultados = [];
    const fora = [];
    for (const c of todos) {
      const det = r[c];
      if (!det) naoConsultados.push(c);
      else if (entraExpedido(det)) entra.push(c);
      else if (bipeCerto(det)) jaBipados.push(c);
      else fora.push(c);
    }
    return { entra, jaBipados, naoConsultados, fora };
  }
  const descreverUltimo = (det) => {
    const l = det && det[det.length - 1];
    return l ? `${dmh(l.t)} ${l.tipo} – ${l.base}${l.staff ? " (" + semF(l.staff) + ")" : ""}` : "SEM DADOS";
  };

  // ---------- Nomes dos entregadores ("NOME NO JMS = Apelido", uma por linha) ----------
  function lerNomes(texto) {
    const nomes = {};
    for (const linha of String(texto || "").split(/\r?\n/)) {
      const i = linha.indexOf("=");
      if (i < 1) continue;
      const k = semF(linha.slice(0, i)).toUpperCase().replace(/\s+/g, " ");
      const v = linha.slice(i + 1).trim().slice(0, 40);
      if (k && v) nomes[k] = v;
    }
    return nomes;
  }
  const textoNomes = (nomes) =>
    Object.entries(nomes || {})
      .map(([k, v]) => `${k} = ${v}`)
      .join("\n");

  return {
    CFG,
    ADM,
    CONHECIDOS,
    GRUPO,
    BLOCOS,
    definirRelogio: (fn) => {
      relogio = typeof fn === "function" ? fn : () => new Date();
    },
    dm,
    dmh,
    hh,
    semF,
    codigos,
    normalizar,
    classificarNaoEntregue,
    ordenarNaoEntregues,
    contarNaoEntregues,
    resumoNaoEntregues,
    tsvNaoEntregues,
    entraExpedido,
    bipeCerto,
    conferirRecebimento,
    descreverUltimo,
    primeiroNome,
    lerNomes,
    textoNomes,
  };
})();
