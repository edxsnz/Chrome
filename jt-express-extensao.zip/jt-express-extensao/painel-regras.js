// painel-regras.js
// Regras do painel ⚡ do JMS (Recebimento, Planilhas, Rastreio, Cobrar):
// funções puras, sem tela nem chrome.*. Carregado depois do consulta-core.js
// (usa MINHA_BASE, ultimoEventoExp e ehExpedidoNaoChegou). A classificação veio
// do script "JMS Automações" do Edson; a saída da Planilhas é a v2 (24/11/2026).

const PainelRegras = (() => {
  const CFG = {
    base: typeof MINHA_BASE === "string" ? MINHA_BASE : "F MAT-SP",
    origemExpedido: "SP RBP", // expedido não chegou: último bipe = carregada nesta base para a F MAT
    diasAlerta: 3, // preso na base há mais de X dias = alerta
  };
  // Motivos de problemático que contam como TRATATIVA (tentativa de entrega)
  const RE_TRATATIVA = /aus[eê]ncia|endere[cç]o|recus|mudou|fechad|desconhecid|n[aã]o localiz|reagend|risco|dif[ií]cil acesso|n[aã]o atend/i;
  // Motivos de problemático que significam que o pacote NÃO chegou fisicamente (expedido não chegou / extravio)
  const RE_NAO_CHEGOU = /expedid|n[aã]o chegou|extravio/i;
  // Bipes administrativos (não provam que o pacote está aqui). 130 = "Concluído"
  // (fecha registro no sistema). Usada no "expedido não chegou" e na chegada do preso na base.
  const ADM = [110, 130, 190, 191, 170, 172, 180];
  // Códigos de bipe que conhecemos. Código fora daqui = tratado como ADMINISTRATIVO
  // e avisado no Detalhe ("bipe desconhecido – conferir").
  // (conferidos nos 134 rastreios reais de 24/11/2026): 1 carregada, 2 recebida, 10 coleta,
  // 20 recepção, 30/33 inserida/removida do lote, 80 descarga, 91 coleta de chegadas,
  // 94 saída para entrega, 100 assinatura, 120 entrada no galpão, 210 coleta recebida
  // (ponto), 500 expedido hand over; e os administrativos do ADM.
  const CONHECIDOS = new Set([1, 2, 10, 20, 30, 33, 80, 91, 94, 100, 120, 210, 500, ...ADM]);

  // Relógio trocável (testes)
  let relogio = () => new Date();
  const pad = (n) => String(n).padStart(2, "0");
  const agora = () => {
    const d = relogio();
    return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  };
  const hojeISO = () => {
    const d = relogio();
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  };
  const dm = (t) => (t ? `${t.slice(8, 10)}/${t.slice(5, 7)}` : ""); // '2026-11-21 09:10:00' -> '21/11'
  const dmh = (t) => (t ? `${dm(t)} ${t.slice(11, 16)}` : "");
  const hh = (t) => (t ? t.slice(11, 16) : "");
  const diasEntre = (t) => {
    if (!t) return 0;
    const a = new Date(t.slice(0, 10) + "T00:00:00");
    const b = new Date(hojeISO() + "T00:00:00");
    return Math.round((b - a) / 864e5);
  };
  const ehHoje = (t) => !!t && t.slice(0, 10) === hojeISO();
  const codigos = (txt) => [...new Set(String(txt).match(/\b(?:999|888)\d{12}\b/g) || [])];
  const semF = (n) => String(n || "").replace(/^F\s+/i, "").trim();
  const cap = (s) => String(s).toLowerCase().replace(/(^|\s)\S/g, (x) => x.toUpperCase());
  // nomes = { "NOME NO JMS SEM O F": "Apelido" } (cadastrado no painel, nunca no código)
  const primeiroNome = (staff, nomes = {}) => {
    const n = semF(staff).toUpperCase();
    return (nomes && nomes[n]) || cap(n.split(/\s+/)[0] || "");
  };
  // texto cortado (sem o "]" no fim) também vale: pega até o fim
  const causa = (s) => (((s.waybillTrackingContent || "").match(/causa do problema \[([^\]]+)/) || [])[1] || "").replace(/[一-鿿]+/g, "").replace(/\./g, " ").trim();
  const destino = (s) => (((s.waybillTrackingContent || "").match(/para \[([^\]]+)\]/) || [])[1] || "").trim();

  // Eventos do JMS → formato do painel (o mesmo do script), do mais antigo ao mais novo.
  // exp = o evento é "expedido mas não chegou" (marcado por outra base ou por nós).
  function normalizar(detalhes) {
    const lista = Array.isArray(detalhes) ? detalhes.filter((s) => s && typeof s === "object") : [];
    const ultimo = typeof ultimoEventoExp === "function" ? ultimoEventoExp(lista) : null;
    return lista
      .map((s) => ({
        t: String(s.scanTime || ""),
        c: s.code,
        tipo: String(s.scanTypeName || ""),
        base: String(s.scanNetworkName || ""),
        por: String(s.scanByName || ""),
        staff: String(s.staffName || ""),
        motivo: causa(s),
        dest: destino(s),
        txt: String(s.waybillTrackingContent || "").slice(0, 300),
        exp: typeof ehExpedidoNaoChegou === "function" ? ehExpedidoNaoChegou(s) : false,
        ultimo: s === ultimo,
      }))
      .sort((a, b) => a.t.localeCompare(b.t));
  }

  // ---------- Tentativas (v2: lista de tarefas do dia) ----------
  // Texto da coluna A da aba Tentativas. NÃO mudar sem avisar o Edson: a
  // planilha pinta a linha procurando estas palavras.
  const ROT = {
    C: "📞 Cobrar motorista",
    R: "📝 Registrar devolução",
    D: "🟥 Ensacar devolução",
    B: "🟦 Preso na base",
    I: "🟫 Interceptado",
    K: "⬛ Coleta não chegou",
    F: "🟧 Em rota – 2/3",
    A: "🟨 Em rota – 1/3",
    G: "🟨 Voltou – mandar pra rota",
    T: "🚚 Devolução em trânsito",
    E: "⚠️ Erro de consulta",
  };
  // Títulos das seções na tela do painel (N = "não chegou" de entrada, fora da aba Tentativas)
  const SEC = { ...ROT, N: "⬛ Não chegou (entrada) – vai para a aba \"Não chegou\"", X: "⬜ Saiu da lista" };
  const ordemSecoes = "CRDBIKFAGTE";
  const ehSaida = (s) => s.c === 94 || /sa[ií]da para entrega/i.test(s.tipo);
  const ehProb = (s) => s.c === 110 || /problem/i.test(s.tipo);
  const ehAssin = (s) => /assinatura|entregue/i.test(s.tipo);
  const ehInterc = (s) => s.c === 190 || /registro de pacote intercept/i.test(s.tipo);
  const ehDevol = (s) => s.c === 170 || /registro de devolu/i.test(s.tipo);
  // Bipe que NÃO prova que o pacote está fisicamente na base: os administrativos
  // e qualquer código que não conhecemos (melhor conferir à mão do que mandar
  // para "Preso na base" um pacote que não está aqui).
  const ehDesconhecido = (s) => !Number.isInteger(s.c) || !CONHECIDOS.has(s.c);
  const ehAdm = (s) => ADM.includes(s.c) || ehDesconhecido(s);

  function classificar(code, det, nomes = {}) {
    const R = { code, sec: "X", entregador: "", tentTxt: "", ultimo: "", fazer: "", detalhe: "", dias: 0, cobrar: false, tent: [], oque: "" };
    // Sem rastreio = a consulta falhou (ou o código não existe). NUNCA tirar da lista por isso.
    if (!det || !det.length) {
      R.sec = "E";
      R.fazer = "Rodar de novo – NÃO sai da lista";
      R.detalhe = R.oque = "Não consegui consultar no JMS";
      return R;
    }
    const last = det[det.length - 1];
    R.ultimo = dmh(last.t);
    R.dias = diasEntre(last.t);
    const mat = det.filter((s) => s.base === CFG.base);
    // tratativas: 1 por dia, só problemático NA NOSSA BASE com motivo de tentativa
    const porDia = {};
    mat.filter((s) => ehProb(s) && RE_TRATATIVA.test(s.motivo)).forEach((s) => {
      porDia[s.t.slice(0, 10)] = s;
    });
    R.tent = Object.values(porDia).sort((a, b) => a.t.localeCompare(b.t));
    const n = R.tent.length;
    const tentTxt = `${Math.min(n, 3)}/3`;
    // tratativa bipada poucos minutos depois da saída = o entregador nem saiu (suspeita)
    const suspeita = (s) => {
      const sd = det.filter((x) => ehSaida(x) && x.t <= s.t).pop();
      if (!sd) return "";
      const min = (new Date(s.t.replace(" ", "T")) - new Date(sd.t.replace(" ", "T"))) / 60000;
      return min < 5 ? ` (⚠ ${Math.round(min)} min após a saída)` : "";
    };
    const historico = R.tent.map((s) => `${dm(s.t)} ${s.motivo || s.tipo}${suspeita(s)}`).join("  →  ");
    const ultSaida = [...det].reverse().find(ehSaida);
    if (ultSaida) R.entregador = ultSaida.staff || "";
    const nome = R.entregador ? primeiroNome(R.entregador, nomes) : "o entregador";
    const desconhecidos = [...new Set(det.filter((s) => s.base === CFG.base && ehDesconhecido(s)).map((s) => s.c))];
    const avisoDesc = desconhecidos.length ? `⚠ bipe desconhecido (código ${desconhecidos.join(", ")}) – conferir` : "";
    const juntar = (...partes) => partes.filter(Boolean).join(" · ");

    if (det.some(ehAssin)) {
      R.oque = `Entregue ${dmh(det.filter(ehAssin).pop().t)}`;
      return R;
    }

    // EXPEDIDO NÃO CHEGOU / SUSPEITA DE EXTRAVIO (pacote que vinha PARA nós): NÃO está na base.
    // Nunca "preso na base" (isso custa dinheiro). Vai para a aba "Não chegou". Interceptado depois → resolvido.
    const expNC = mat.filter((s) => ehProb(s) && RE_NAO_CHEGOU.test(s.motivo)).pop();
    // Pacote com devolução registrada não aceita bipe de chegada: o "expedido não chegou" depois dela não vale
    const devolAntes = expNC && det.some((s) => ehDevol(s) && s.t < expNC.t);
    if (expNC && !devolAntes) {
      const fisico = det.some((s) => s.t > expNC.t && s.base === CFG.base && !ehAdm(s));
      // só bipe FÍSICO em outra base (o problemático da SP RBP marcando extravio em trânsito NÃO conta)
      const outraBase = det.some((s) => s.t > expNC.t && s.base !== CFG.base && s.base !== "HQ" && !ehAdm(s));
      const intercept = det.some((s) => s.t > expNC.t && ehInterc(s));
      if (intercept && !fisico) {
        R.oque = `${expNC.motivo} ${dm(expNC.t)} e depois interceptado – resolvido`;
        return R;
      }
      if (!fisico && !outraBase) {
        R.sec = "N";
        R.entregador = "";
        R.bipadoT = expNC.t;
        R.ultimo = dmh(expNC.t);
        R.dias = diasEntre(expNC.t);
        R.ultimoDesc = `${dmh(last.t)} ${last.motivo || last.tipo} – ${last.base}`;
        const cg = det.filter((x) => /carregada/i.test(x.tipo) && x.t < expNC.t).pop();
        const recebidaAntes = det.some((s) => s.base === CFG.base && (s.c === 2 || /recebida/i.test(s.tipo)) && s.t < expNC.t && (!cg || s.t > cg.t));
        R.aviso = juntar(recebidaAntes ? `⚠ Consta RECEBIDA na ${CFG.base} antes do expedido não chegou – conferir se está aqui` : "", avisoDesc);
        R.oque = `${expNC.motivo} – bipado ${dmh(expNC.t)} (não chegou fisicamente)`;
        return R;
      }
    }
    // COLETA (ou qualquer pacote) EXPEDIDO DA F MAT QUE NÃO CHEGOU NA PRÓXIMA BASE:
    // nós carregamos para outra base (ex.: SN RAO) e lá biparam "expedido não chegou".
    // Responsabilidade da F MAT: fica na lista, como ação.
    const expFora = det.filter((s) => s.base !== CFG.base && ehProb(s) && RE_NAO_CHEGOU.test(s.motivo)).pop();
    if (expFora && (!expNC || expFora.t > expNC.t)) {
      const carga = det.filter((s) => s.t < expFora.t && /carregada/i.test(s.tipo)).pop();
      if (carga && carga.base === CFG.base) {
        const fisico = det.some((s) => s.t > expFora.t && !ehAdm(s) && s.base !== "HQ");
        const intercept = det.some((s) => s.t > expFora.t && ehInterc(s));
        if (intercept && !fisico) {
          R.oque = `Expedido da ${CFG.base} pra ${expFora.base}, não chegou e depois interceptado – resolvido`;
          return R;
        }
        if (!fisico) {
          const coleta = det.some((s) => s.base === CFG.base && /coleta/i.test(s.tipo));
          const para = carga.dest || expFora.base;
          R.sec = "K";
          R.entregador = "";
          R.ultimo = dmh(expFora.t);
          R.dias = diasEntre(expFora.t);
          R.fazer = `Localizar – saiu daqui ${dm(carga.t)} pra ${para} e não chegou lá`;
          R.detalhe = juntar(`${coleta ? "Coleta " : ""}expedida da ${CFG.base} em ${dmh(carga.t)} pra ${para} – ${expFora.base} bipou "${expFora.motivo}" em ${dmh(expFora.t)} (responsabilidade da F MAT)`, avisoDesc);
          R.oque = R.fazer;
          return R;
        }
      }
    }
    // interceptação ativa
    const i190 = det.filter(ehInterc).pop();
    const i191 = det.filter((s) => s.c === 191 || /cancelamento de pacote intercept/i.test(s.tipo)).pop();
    const devol = det.filter(ehDevol).pop();
    if (i190 && (!i191 || i191.t < i190.t) && !devol) {
      const d = diasEntre(last.t);
      R.sec = "I";
      R.dias = d;
      R.fazer = d > CFG.diasAlerta ? `🔴 Localizar e devolver – parado há ${d} dias` : last.base === CFG.base ? "⚠ Está na base – tirar a interceptação ou devolver" : "Verificar onde está";
      R.detalhe = juntar(`Interceptado em ${dm(i190.t)} – último bipe ${last.tipo} (${last.base}) ${dmh(last.t)}`, avisoDesc);
      R.oque = R.fazer;
      return R;
    }
    if (devol) {
      if (/carregada/i.test(last.tipo) && last.base === CFG.base) {
        // devolução já saiu da base: só acompanhar
        R.sec = "T";
        R.tentTxt = n ? tentTxt : "";
        R.dias = diasEntre(last.t);
        R.fazer = `Nada – saiu ${dmh(last.t)}`;
        R.detalhe = juntar(`Devolução registrada ${dm(devol.t)} – saiu da base ${dmh(last.t)} pra ${last.dest || "SN RAO"} – sai da lista quando chegar em outra base`, historico, avisoDesc);
        R.oque = R.fazer;
      } else if (last.base !== CFG.base) {
        R.oque = `Devolução já saiu (${last.base})`;
      } else {
        const coletaAqui = det.some((x) => x.base === CFG.base && (x.c === 10 || /coleta de encomenda/i.test(x.tipo)));
        const expDepois = expNC && expNC.t > devol.t;
        R.sec = "D";
        R.tentTxt = n ? tentTxt : "";
        R.dias = diasEntre(devol.t);
        R.fazer = coletaAqui ? "Localizar e devolver ao remetente (Matão)" : "Ensacar e enviar pra SN RAO";
        R.detalhe = juntar(
          `Devolução registrada ${dm(devol.t)} (${devol.base})` +
            (expDepois ? ` – voltou pra ${CFG.base} e foi bipado "expedido não chegou" em ${dmh(expNC.t)} porque pacote com devolução NÃO aceita bipe de chegada (o pacote está aqui)` : ""),
          historico,
          avisoDesc
        );
        R.oque = R.fazer;
      }
      return R;
    }
    if (last.base !== CFG.base) {
      R.oque = `Saiu da base – ${last.tipo} em ${last.base}`;
      return R;
    }
    if (/carregada/i.test(last.tipo)) {
      R.oque = `Carregada pra ${last.dest || "?"}`;
      return R;
    }

    const emRota = n >= 3 ? "R" : n === 2 ? "F" : "A";
    R.tentTxt = tentTxt;
    if (ehSaida(last)) {
      if (ehHoje(last.t)) {
        if (n === 0) {
          // 1ª saída hoje, sem nenhuma tratativa: dia a dia normal (se der problema, amanhã aparece)
          R.oque = "Saiu pra entrega hoje, 0 tratativas – normal";
          return R;
        }
        R.sec = emRota;
        R.dias = 0;
        R.fazer = n >= 3 ? "⚠ Já tem 3/3 e saiu de novo – quando voltar, registrar a devolução" : `Aguardar retorno (${n + 1}ª tentativa hoje)`;
        R.detalhe = juntar(`Saiu pra entrega hoje ${hh(last.t)}`, historico, avisoDesc);
      } else {
        R.sec = "C";
        R.cobrar = true;
        R.dias = diasEntre(last.t);
        R.fazer = n === 0 ? `Cobrar ${nome} – saiu ${dm(last.t)} e não voltou (pode ser só falta assinar)` : `Cobrar ${nome} – saiu ${dm(last.t)} e não voltou`;
        R.detalhe = juntar(`Saiu pra entrega ${dmh(last.t)} e não teve bipe depois`, historico, avisoDesc);
      }
      R.oque = R.fazer;
      return R;
    }
    if (ehProb(last) && RE_TRATATIVA.test(last.motivo)) {
      if (ehHoje(last.t)) {
        R.sec = emRota;
        R.dias = 0;
        R.fazer = n >= 3 ? "Quando voltar: registrar a devolução (3/3)" : `Aguardar retorno (${n}ª tentativa hoje)`;
        R.detalhe = juntar(`Tratativa hoje ${hh(last.t)} – ainda não voltou pro galpão`, historico, avisoDesc);
      } else {
        R.sec = "C";
        R.cobrar = true;
        R.dias = diasEntre(last.t);
        R.fazer = `Cobrar ${nome} – ${(last.motivo || "tratativa").toLowerCase()} ${dm(last.t)} e não voltou`;
        R.detalhe = juntar(historico, "sem bipe de entrada depois", avisoDesc);
      }
      R.oque = R.fazer;
      return R;
    }
    // está no galpão
    if (n >= 1) {
      R.dias = diasEntre(last.t);
      if (n >= 3) {
        R.sec = "R";
        R.fazer = "Registrar a devolução (3/3) – já está no galpão";
      } else {
        R.sec = "G";
        R.fazer = `Mandar pra rota (${n + 1}ª tentativa)`;
      }
      R.detalhe = juntar(`Voltou pro galpão ${dmh(last.t)}`, historico, "dar retorno na base antes de pedir devolução", avisoDesc);
      R.oque = R.fazer;
      return R;
    }
    // preso na base: desde a chegada na F MAT
    const ultSaiuBase = [...det].reverse().find((s) => s.base !== CFG.base);
    const chegada =
      det.find((s) => s.base === CFG.base && (!ultSaiuBase || s.t > ultSaiuBase.t) && !ehAdm(s)) ||
      det.find((s) => s.base === CFG.base && (!ultSaiuBase || s.t > ultSaiuBase.t)) ||
      last;
    const dias = diasEntre(chegada.t);
    const coleta = det[0] && det[0].base === CFG.base && /coleta/i.test(det[0].tipo);
    // coleta deixada num ponto (YoYi…): só vale se o pacote chegou fisicamente aqui depois
    const ponto = det.find((x) => x.c === 210 || /bipe de coleta recebida/i.test(x.tipo));
    const pontoChegou = ponto && det.some((s) => s.t > ponto.t && s.base === CFG.base && !ehAdm(s));
    R.sec = "B";
    R.tentTxt = "";
    R.ultimo = dmh(last.t);
    R.dias = dias;
    let oque = `${pontoChegou ? `Coleta de ponto (${ponto.base}) – ` : coleta ? "Coleta – " : ""}Chegou ${dmh(chegada.t)} e não saiu pra rota`;
    if (ultSaida && ultSaida.t > chegada.t) oque = `Saiu com o entregador ${dm(ultSaida.t)} e voltou pro galpão ${dmh(last.t)} sem tratativa (chegou na base ${dm(chegada.t)})`;
    R.fazer = dias > CFG.diasAlerta ? `🔴 Localizar – parado há ${dias} dias (multa diária)` : "Mandar pra rota";
    R.detalhe = juntar(oque, avisoDesc);
    R.oque = R.fazer;
    return R;
  }

  // ---------- Arquivos RETIDOS / SEM MOV (.xlsx / .csv) ----------
  // "AB12" → índice da coluna (A = 0)
  const colIdx = (ref) => {
    const l = String(ref).replace(/\d+/g, "");
    let n = 0;
    for (const ch of l) n = n * 26 + ch.charCodeAt(0) - 64;
    return n - 1;
  };
  const lerCsv = (txt) => String(txt).split(/\r?\n/).map((l) => l.split(/[;,\t]/).map((x) => x.replace(/^"|"$/g, "")));
  // Só as linhas cuja coluna "Base…" é a nossa base (RETIDOS: "Base de Entrega";
  // SEM MOV: "Base Responsável"). NÃO filtrar pela linha inteira: o SEM MOV tem
  // "Próxima Parada", que pode ter F MAT-SP em pacote de outra base.
  function codigosDasLinhas(linhas) {
    const iCab = linhas.findIndex((r) => r.some((x) => /remessa/i.test(x)));
    const cab = iCab >= 0 ? linhas[iCab] : [];
    const colsBase = cab.map((h, i) => (/^base/i.test(String(h).trim()) ? i : -1)).filter((i) => i >= 0);
    const corpo = linhas.slice(iCab + 1);
    const daBase = (r) => (colsBase.length ? colsBase.some((i) => String(r[i] || "").includes(CFG.base) || /F MAT/i.test(r[i] || "")) : r.some((x) => /F MAT/i.test(x)));
    return [...new Set(corpo.filter(daBase).flatMap((r) => codigos(r.join(" "))))];
  }

  // Colagem do backlog (RETIDOS / SEM MOV): só linhas da F MAT; sem coluna de base, pega tudo
  function lerBacklog(txt) {
    const linhas = String(txt).split(/\r?\n/);
    const temBase = linhas.some((l) => /F MAT/i.test(l));
    return [...new Set(linhas.filter((l) => !temBase || /F MAT/i.test(l)).flatMap((l) => codigos(l)))];
  }

  // Nós enviamos e a outra base deu "expedido mas não chegou" (último evento)
  function nosEnviamos(det) {
    if (!det || !det.length) return null;
    const u = det.find((s) => s.ultimo) || det[det.length - 1];
    return u.exp ? u : null;
  }

  // Linha de resumo (A2 da aba Tentativas): ações primeiro, depois o que só se acompanha
  function resumoTentativas(ativos, nNaoChegou = 0) {
    const cont = (k) => ativos.filter((r) => r.sec === k).length;
    const verm = ativos.filter((r) => r.sec === "B" && +r.dias > CFG.diasAlerta).length;
    return (
      `Atualizado em ${agora().slice(0, 16)}` +
      (cont("E") ? ` · ⚠ ERRO DE CONSULTA: ${cont("E")} (rodar de novo)` : "") +
      ` · AÇÃO: Cobrar ${cont("C")} · Registrar devolução ${cont("R")} · Ensacar ${cont("D")} · Preso na base ${cont("B")} (${verm} 🔴) · Interceptados ${cont("I")} · Coleta não chegou ${cont("K")}` +
      ` · ACOMPANHAR: Em rota 2/3: ${cont("F")} · Em rota 1/3: ${cont("A")} · Voltou ${cont("G")} · Em trânsito ${cont("T")} · Não chegou (entrada): ${nNaoChegou} → aba "Não chegou"`
    );
  }
  // Seção → mais dias primeiro (em todas) → entregador → código
  function ordenarAtivos(ativos) {
    return ativos.sort(
      (a, b) => ordemSecoes.indexOf(a.sec) - ordemSecoes.indexOf(b.sec) || +b.dias - +a.dias || semF(a.entregador).localeCompare(semF(b.entregador)) || a.code.localeCompare(b.code)
    );
  }
  // "Não chegou" de entrada: mais antigo primeiro
  const ordenarNaoChegou = (lista) => lista.sort((a, b) => String(a.bipadoT).localeCompare(String(b.bipadoT)) || a.code.localeCompare(b.code));

  // Bloco compacto para colar no Claude (ele atualiza a planilha). Formato v2:
  // o Claude do chat sabe ler pelo "v2" do título.
  function blocoClaude(ativos, sairam, resumo, naoChegou = []) {
    const lim = (s) => String(s).replace(/[\t\n|]/g, " ");
    return (
      `#TENTATIVAS v2 – atualizar a aba Tentativas da planilha Tickets\n#colunas: secao|codigo|oque_fazer|entregador|tentativas|ultimo bipe|dias|detalhe (secao: C=Cobrar R=Registrar devolução D=Ensacar B=Preso na base I=Interceptado K=Coleta não chegou F=Em rota 2/3 A=Em rota 1/3 G=Voltou T=Em trânsito E=Erro)\n#${resumo}\n` +
      ativos.map((r) => [r.sec, r.code, r.fazer, semF(r.entregador), r.tentTxt, r.ultimo, r.dias, r.detalhe].map(lim).join("|")).join("\n") +
      `\n#NAO_CHEGOU ${naoChegou.length}: ${naoChegou.map((r) => `${r.code} ${dm(r.bipadoT)}`).join(";")}` +
      `\n#SAIRAM ${sairam.map((r) => r.code + ":" + lim(r.oque)).join("; ")}`
    );
  }
  // TSV para colar na aba Tentativas da planilha "Tickets" (célula A2 + Ctrl+V).
  // Linha em branco entre as seções; as 150 linhas vazias no fim limpam o que
  // sobrou da rodada anterior.
  const limT = (s) => String(s).replace(/[\t\n]/g, " ");
  function tsvPlanilha(ativos, resumo) {
    const linhas = [];
    let secAnt = null;
    for (const r of ativos) {
      if (secAnt !== null && r.sec !== secAnt) linhas.push("\t".repeat(7));
      secAnt = r.sec;
      linhas.push([ROT[r.sec], r.code, r.fazer, semF(r.entregador), r.tentTxt, r.ultimo, r.dias, r.detalhe].map(limT).join("\t"));
    }
    return [
      limT(resumo),
      ["Seção", "Código", "O que fazer", "Entregador", "Tentativas", "Último bipe", "Dias parado", "Detalhe"].join("\t"),
      ...linhas,
      ...Array(150).fill("\t".repeat(7)),
    ].join("\n");
  }
  // TSV da aba "Não chegou" (célula A2 + Ctrl+V): o que vinha para nós e não chegou
  function tsvNaoChegou(lista) {
    return [
      `Atualizado em ${agora().slice(0, 16)} · ${lista.length} pacotes que vinham para a ${CFG.base} e não chegaram (não é responsabilidade da base) · mais antigo primeiro`,
      ["Código", "Bipado em", "Dias", "Último bipe", "Aviso"].join("\t"),
      ...lista.map((r) => [r.code, r.ultimo, r.dias, r.ultimoDesc || "", r.aviso || ""].map(limT).join("\t")),
      ...Array(150).fill("\t".repeat(4)),
    ].join("\n");
  }

  // ---------- Recebimento (expedido não chegou que mandaram para nós) ----------
  const entraExpedido = (det) => {
    const l = det && det[det.length - 1];
    return !!l && /carregada/i.test(l.tipo) && l.base === CFG.origemExpedido && l.dest === CFG.base;
  };
  // Depois de bipar: o último bipe é problemático "expedido…" na nossa base
  const bipeCerto = (det) => {
    const l = det && det[det.length - 1];
    return !!l && ehProb(l) && /expedi/i.test(l.motivo) && l.base === CFG.base;
  };
  // Uma consulta por código (a repescagem garante a resposta). r: { código: det | null (não consultado) }
  // entra = falta bipar; jaBipados = já tem o bipe "expedido…" da nossa base; fora = não é caso.
  function conferirRecebimento(todos, r) {
    const entra = [];
    const jaBipados = [];
    const naoConsultados = [];
    const fora = [];
    for (const c of todos) {
      const det = r[c];
      if (!det) naoConsultados.push(c);
      else if (entraExpedido(det)) entra.push(c);
      else if (bipeCerto(det)) jaBipados.push(c);
      else fora.push(c);
    }
    return { entra, jaBipados, naoConsultados, fora };
  }
  const descreverUltimo = (det) => {
    const l = det && det[det.length - 1];
    return l ? `${dmh(l.t)} ${l.tipo} – ${l.base}${l.staff ? " (" + semF(l.staff) + ")" : ""}` : "SEM DADOS";
  };

  // ---------- Cobrar ----------
  function montarMsg(staff, g, nomes = {}) {
    const nome = primeiroNome(staff, nomes);
    const semTrat = g.every((p) => !p.trat);
    const comTrat = g.every((p) => p.trat);
    const dia = dm(g[0].said.t);
    let intro;
    if (g.length === 1)
      intro = semTrat
        ? `O pacote abaixo saiu com você no dia ${dia} e até agora não teve nenhuma tratativa (nem entrega, nem ausência, nem retorno pra base).`
        : `O pacote abaixo está com você desde o dia ${dia}. Você bipou ${(g[0].trat.motivo || "tratativa").toLowerCase()}, mas ele não voltou pra base.`;
    else
      intro = semTrat
        ? `Tenho ${g.length} pacotes que saíram com você e até agora não tiveram nenhuma tratativa (nem entrega, nem ausência, nem retorno pra base).`
        : comTrat
          ? `Tenho ${g.length} pacotes que estão com você. Você bipou a tratativa, mas eles não voltaram pra base.`
          : `Tenho ${g.length} pacotes com você que ainda não voltaram pra base:`;
    const blocos = g.map((p) =>
      [
        `📦 ${p.c}`,
        `Saída pra entrega: ${dm(p.said.t)} às ${hh(p.said.t)}`,
        `Tratativa: ${p.trat ? `${p.trat.motivo || p.trat.tipo} – ${dm(p.trat.t)} às ${hh(p.trat.t)}` : "nenhuma"}`,
        `Cliente: ${p.cli.nome || "?"}`,
        `Telefone: ${p.cli.tel || "?"}`,
        `Endereço: ${p.cli.end || "?"}`,
      ].join("\n")
    );
    return `Oi ${nome}, tudo bem?\n\n${intro}\n\n${blocos.join("\n\n")}`;
  }

  // Separa quem cobrar (por entregador) de quem não precisa
  function gruposCobrar(lista, res) {
    const grupos = {};
    const resolvidos = [];
    const naoConsultados = [];
    for (const c of lista) {
      const det = res[c];
      if (!det) {
        naoConsultados.push(c);
        continue;
      }
      const last = det[det.length - 1];
      if (!last || det.some(ehAssin) || last.base !== CFG.base || !(ehSaida(last) || ehProb(last))) {
        resolvidos.push([c, last ? `${dmh(last.t)} ${last.tipo} – ${last.base}` : "SEM DADOS"]);
        continue;
      }
      const said = [...det].reverse().find(ehSaida);
      if (!said) {
        resolvidos.push([c, "Sem saída para entrega"]);
        continue;
      }
      const trat = det.filter((s) => s.t >= said.t && ehProb(s) && s.base === CFG.base).pop();
      (grupos[said.staff] = grupos[said.staff] || []).push({ c, said, trat });
    }
    return { grupos, resolvidos, naoConsultados };
  }

  // Limpa o endereço que o JMS devolve tudo grudado
  function endereco(full, d) {
    full = String(full || "");
    if (!d) return full;
    const bairro = String(d.receiverAreaName || "").trim();
    const cid = String(d.receiverCityName || "").trim();
    const uf = String(d.receiverProvinceName || "").trim();
    const k = bairro + cid + uf;
    const i = bairro ? full.indexOf(k) : -1;
    if (i < 0) return full;
    let rua = full.slice(0, i).trim();
    let resto = full.slice(i + k.length).trim();
    rua = rua.replace(/([^\d\s,])(\d+[A-Za-z]?)$/, "$1, $2");
    const nomeRua = rua.split(",")[0].trim();
    if (resto && resto.toLowerCase().startsWith(nomeRua.toLowerCase())) resto = resto.slice(nomeRua.length).replace(/^[\s,]*\d+[A-Za-z]?[\s,]*/, "").trim();
    else if (resto && /^\d/.test(resto) && !/\d$/.test(rua)) {
      const m = resto.match(/^(\d+[A-Za-z]?)\s*(.*)$/);
      rua += ", " + m[1];
      resto = m[2];
    }
    return `${rua}, ${cap(bairro)}, ${cid}/${uf}` + (resto ? ` (${resto})` : "");
  }

  // ---------- Nomes dos entregadores ("NOME NO JMS = Apelido", uma por linha) ----------
  function lerNomes(texto) {
    const nomes = {};
    for (const linha of String(texto || "").split(/\r?\n/)) {
      const i = linha.indexOf("=");
      if (i < 1) continue;
      const k = semF(linha.slice(0, i)).toUpperCase().replace(/\s+/g, " ");
      const v = linha.slice(i + 1).trim().slice(0, 40);
      if (k && v) nomes[k] = v;
    }
    return nomes;
  }
  const textoNomes = (nomes) =>
    Object.entries(nomes || {})
      .map(([k, v]) => `${k} = ${v}`)
      .join("\n");

  return {
    CFG,
    SEC,
    ROT,
    ADM,
    CONHECIDOS,
    ordemSecoes,
    definirRelogio: (fn) => {
      relogio = typeof fn === "function" ? fn : () => new Date();
    },
    dm,
    dmh,
    hh,
    semF,
    codigos,
    normalizar,
    classificar,
    lerBacklog,
    colIdx,
    lerCsv,
    codigosDasLinhas,
    nosEnviamos,
    resumoTentativas,
    ordenarAtivos,
    blocoClaude,
    tsvPlanilha,
    tsvNaoChegou,
    ordenarNaoChegou,
    entraExpedido,
    bipeCerto,
    conferirRecebimento,
    descreverUltimo,
    primeiroNome,
    montarMsg,
    gruposCobrar,
    endereco,
    lerNomes,
    textoNomes,
  };
})();
