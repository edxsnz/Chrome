// painel-regras.js
// Regras do painel ⚡ do JMS (Recebimento, Planilhas, Rastreio, Cobrar,
// Histórico): funções puras, sem tela nem chrome.*. Carregado depois do
// consulta-core.js (usa MINHA_BASE, ultimoEventoExp e ehExpedidoNaoChegou).
// A lógica de classificação e as mensagens vêm do script "JMS Automações"
// do Edson, sem mudança de regra.

const PainelRegras = (() => {
  const CFG = {
    base: typeof MINHA_BASE === "string" ? MINHA_BASE : "F MAT-SP",
    origemExpedido: "SP RBP", // expedido não chegou: último bipe = carregada nesta base para a F MAT
    cacheMin: 20, // reaproveita rastreio consultado há menos de X min
    diasAlerta: 3, // preso na base há mais de X dias = alerta
    historicoDias: 30, // o histórico apaga sozinho o que passar disso
  };
  // Motivos de problemático que contam como TRATATIVA (tentativa de entrega)
  const RE_TRATATIVA = /aus[eê]ncia|endere[cç]o|recus|mudou|fechad|desconhecid|n[aã]o localiz|reagend|risco|dif[ií]cil acesso|n[aã]o atend/i;
  // Motivos de problemático que significam que o pacote NÃO chegou fisicamente (expedido não chegou / extravio)
  const RE_NAO_CHEGOU = /expedid|n[aã]o chegou|extravio/i;
  // Bipes administrativos (não provam que o pacote está aqui)
  const ADM = [110, 190, 191, 170, 172, 180];

  // Relógio trocável (testes)
  let relogio = () => new Date();
  const pad = (n) => String(n).padStart(2, "0");
  const agora = () => {
    const d = relogio();
    return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  };
  const hojeISO = () => {
    const d = relogio();
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  };
  const dm = (t) => (t ? `${t.slice(8, 10)}/${t.slice(5, 7)}` : ""); // '2026-11-21 09:10:00' -> '21/11'
  const dmh = (t) => (t ? `${dm(t)} ${t.slice(11, 16)}` : "");
  const hh = (t) => (t ? t.slice(11, 16) : "");
  const diasEntre = (t) => {
    if (!t) return 0;
    const a = new Date(t.slice(0, 10) + "T00:00:00");
    const b = new Date(hojeISO() + "T00:00:00");
    return Math.round((b - a) / 864e5);
  };
  const ehHoje = (t) => !!t && t.slice(0, 10) === hojeISO();
  const codigos = (txt) => [...new Set(String(txt).match(/\b(?:999|888)\d{12}\b/g) || [])];
  const semF = (n) => String(n || "").replace(/^F\s+/i, "").trim();
  const cap = (s) => String(s).toLowerCase().replace(/(^|\s)\S/g, (x) => x.toUpperCase());
  // nomes = { "NOME NO JMS SEM O F": "Apelido" } (cadastrado no painel, nunca no código)
  const primeiroNome = (staff, nomes = {}) => {
    const n = semF(staff).toUpperCase();
    return (nomes && nomes[n]) || cap(n.split(/\s+/)[0] || "");
  };
  const causa = (s) => (((s.waybillTrackingContent || "").match(/causa do problema \[([^\]]+)\]/) || [])[1] || "").replace(/[一-鿿]+/g, "").replace(/\./g, " ").trim();
  const destino = (s) => (((s.waybillTrackingContent || "").match(/para \[([^\]]+)\]/) || [])[1] || "").trim();

  // Eventos do JMS → formato do painel (o mesmo do script), do mais antigo ao mais novo.
  // exp = o evento é "expedido mas não chegou" (marcado por outra base ou por nós).
  function normalizar(detalhes) {
    const lista = Array.isArray(detalhes) ? detalhes.filter((s) => s && typeof s === "object") : [];
    const ultimo = typeof ultimoEventoExp === "function" ? ultimoEventoExp(lista) : null;
    return lista
      .map((s) => ({
        t: String(s.scanTime || ""),
        c: s.code,
        tipo: String(s.scanTypeName || ""),
        base: String(s.scanNetworkName || ""),
        por: String(s.scanByName || ""),
        staff: String(s.staffName || ""),
        motivo: causa(s),
        dest: destino(s),
        txt: String(s.waybillTrackingContent || "").slice(0, 300),
        exp: typeof ehExpedidoNaoChegou === "function" ? ehExpedidoNaoChegou(s) : false,
        ultimo: s === ultimo,
      }))
      .sort((a, b) => a.t.localeCompare(b.t));
  }

  // ---------- Tentativas ----------
  const SEC = {
    E: "⚠️ ERRO DE CONSULTA",
    D: "🟥 PODE DEVOLVER (3/3)",
    N: "⬛ NÃO CHEGOU (expedido não chegou / extravio)",
    F: "🟧 FALTA 1 (2/3)",
    A: "🟨 EM ANDAMENTO (1/3)",
    M: "🟪 PRESO COM MOTORISTA",
    B: "🟦 PRESO NA BASE",
    I: "🟫 INTERCEPTADOS",
    X: "⬜ SAIU DA LISTA",
  };
  const ehSaida = (s) => s.c === 94 || /sa[ií]da para entrega/i.test(s.tipo);
  const ehProb = (s) => s.c === 110 || /problem/i.test(s.tipo);
  const ehAssin = (s) => /assinatura|entregue/i.test(s.tipo);
  const ehInterc = (s) => s.c === 190 || /registro de pacote intercept/i.test(s.tipo);
  const ehDevol = (s) => s.c === 170 || /registro de devolu/i.test(s.tipo);

  function classificar(code, det) {
    const R = { code, sec: "X", entregador: "—", trat: "—", ultimo: "", oque: "", dias: "", obs: "", cobrar: false, tent: [] };
    // Sem rastreio = a consulta falhou (ou o código não existe). NUNCA tirar da lista por isso.
    if (!det || !det.length) {
      R.sec = "E";
      R.oque = "Não consegui consultar no JMS";
      R.obs = "⚠ Rodar de novo – NÃO sai da lista";
      return R;
    }
    const last = det[det.length - 1];
    R.ultimo = dmh(last.t);
    R.dias = String(diasEntre(last.t));
    const mat = det.filter((s) => s.base === CFG.base);
    // tratativas: 1 por dia, só problemático na base com motivo de tentativa
    const porDia = {};
    mat.filter((s) => ehProb(s) && RE_TRATATIVA.test(s.motivo)).forEach((s) => {
      porDia[s.t.slice(0, 10)] = s;
    });
    R.tent = Object.values(porDia).sort((a, b) => a.t.localeCompare(b.t));
    const n = R.tent.length;
    // tratativa bipada poucos minutos depois da saída = o entregador nem saiu (suspeita)
    const suspeita = (s) => {
      const sd = det.filter((x) => ehSaida(x) && x.t <= s.t).pop();
      if (!sd) return "";
      const min = (new Date(s.t.replace(" ", "T")) - new Date(sd.t.replace(" ", "T"))) / 60000;
      return min < 5 ? ` (⚠ ${Math.round(min)} min após a saída)` : "";
    };
    if (n) R.trat = R.tent.map((s) => `${dm(s.t)} ${s.motivo || s.tipo}${suspeita(s)}`).join("  →  ");
    const ultSaida = [...det].reverse().find(ehSaida);
    if (ultSaida) R.entregador = ultSaida.staff || "—";

    if (det.some(ehAssin)) {
      R.oque = `Entregue ${dmh(det.filter(ehAssin).pop().t)}`;
      return R;
    }

    // EXPEDIDO NÃO CHEGOU / SUSPEITA DE EXTRAVIO: o pacote NÃO está fisicamente na base.
    // Nunca tratar como "preso na base" (isso custa dinheiro). Se depois veio interceptação, já foi resolvido → sai da lista.
    const expNC = mat.filter((s) => ehProb(s) && RE_NAO_CHEGOU.test(s.motivo)).pop();
    // Pacote com devolução registrada não aceita bipe de chegada: o "expedido não chegou" depois dela não vale
    const devolAntes = expNC && det.some((s) => ehDevol(s) && s.t < expNC.t);
    if (expNC && !devolAntes) {
      const fisico = det.some((s) => s.t > expNC.t && s.base === CFG.base && !ADM.includes(s.c));
      // só bipe FÍSICO em outra base (o problemático da SP RBP marcando extravio em trânsito NÃO conta)
      const outraBase = det.some((s) => s.t > expNC.t && s.base !== CFG.base && s.base !== "HQ" && !ADM.includes(s.c));
      const intercept = det.some((s) => s.t > expNC.t && ehInterc(s));
      if (intercept && !fisico) {
        R.oque = `${expNC.motivo} ${dm(expNC.t)} e depois interceptado – resolvido`;
        return R;
      }
      if (!fisico && !outraBase) {
        R.sec = "N";
        R.entregador = "—";
        R.trat = "—";
        R.ultimo = dmh(expNC.t);
        R.dias = String(diasEntre(expNC.t));
        const marcaFora = det.filter((s) => s.t > expNC.t && s.base !== CFG.base && ehProb(s) && RE_NAO_CHEGOU.test(s.motivo)).pop();
        R.oque = `${expNC.motivo} – bipado ${dmh(expNC.t)} (não chegou fisicamente)` + (marcaFora ? `; ${marcaFora.base} marcou "${marcaFora.motivo}" em ${dmh(marcaFora.t)}` : "");
        const cg = det.filter((x) => /carregada/i.test(x.tipo) && x.t < expNC.t).pop();
        const recebidaAntes = det.some((s) => s.base === CFG.base && (s.c === 2 || /recebida/i.test(s.tipo)) && s.t < expNC.t && (!cg || s.t > cg.t));
        R.obs = recebidaAntes ? `⚠ Consta RECEBIDA na ${CFG.base} antes do expedido não chegou – conferir se está aqui` : "⛔ NÃO está na base – não mandar pra rota; acompanhar";
        return R;
      }
    }
    // COLETA (ou qualquer pacote) EXPEDIDO DA F MAT QUE NÃO CHEGOU NA PRÓXIMA BASE:
    // nós carregamos para outra base (ex.: SN RAO) e lá biparam "expedido não chegou".
    // O pacote não está lá nem aqui → responsabilidade da F MAT (não é "saiu da lista").
    const expFora = det.filter((s) => s.base !== CFG.base && ehProb(s) && RE_NAO_CHEGOU.test(s.motivo)).pop();
    if (expFora && (!expNC || expFora.t > expNC.t)) {
      const carga = det.filter((s) => s.t < expFora.t && /carregada/i.test(s.tipo)).pop();
      if (carga && carga.base === CFG.base) {
        const fisico = det.some((s) => s.t > expFora.t && !ADM.includes(s.c) && s.base !== "HQ");
        const intercept = det.some((s) => s.t > expFora.t && ehInterc(s));
        if (intercept && !fisico) {
          R.oque = `Expedido da ${CFG.base} pra ${expFora.base}, não chegou e depois interceptado – resolvido`;
          return R;
        }
        if (!fisico) {
          const coleta = det.some((s) => s.base === CFG.base && /coleta/i.test(s.tipo));
          R.sec = "N";
          R.entregador = "—";
          R.trat = "—";
          R.ultimo = dmh(expFora.t);
          R.dias = String(diasEntre(expFora.t));
          R.oque = `${coleta ? "Coleta " : ""}expedida da ${CFG.base} em ${dmh(carga.t)} pra ${carga.dest || expFora.base} – ${expFora.base} bipou "${expFora.motivo}" em ${dmh(expFora.t)}`;
          R.obs = "⛔ Saiu daqui e não chegou lá – localizar (responsabilidade da F MAT)";
          return R;
        }
      }
    }
    // interceptação ativa
    const i190 = det.filter(ehInterc).pop();
    const i191 = det.filter((s) => s.c === 191 || /cancelamento de pacote intercept/i.test(s.tipo)).pop();
    const devol = det.filter(ehDevol).pop();
    if (i190 && (!i191 || i191.t < i190.t) && !devol) {
      R.sec = "I";
      R.entregador = "Interceptado";
      R.trat = dm(i190.t);
      R.oque = `Interceptado em ${dm(i190.t)} – último bipe ${last.tipo} (${last.base})`;
      R.obs = last.base === CFG.base ? "⚠ Está na base – tirar a interceptação ou devolver" : "Verificar onde está";
      if (diasEntre(last.t) > CFG.diasAlerta) R.obs = `🔴 Parado há ${diasEntre(last.t)} dias – localizar e devolver`;
      return R;
    }
    if (devol) {
      R.sec = "D";
      if (/carregada/i.test(last.tipo) && last.base === CFG.base) {
        R.oque = `Devolução registrada ${dm(devol.t)} – carregada ${dmh(last.t)} pra ${last.dest || "SN RAO"}`;
        R.obs = "🚚 Saiu – sai da lista quando chegar";
      } else if (last.base !== CFG.base) {
        R.sec = "X";
        R.oque = `Devolução já saiu (${last.base})`;
      } else {
        const coletaAqui = det.some((x) => x.base === CFG.base && (x.c === 10 || /coleta de encomenda/i.test(x.tipo)));
        const expDepois = expNC && expNC.t > devol.t;
        R.oque =
          `Devolução registrada ${dm(devol.t)} (${devol.base})` +
          (expDepois ? ` – voltou pra ${CFG.base} e foi bipado "expedido não chegou" em ${dmh(expNC.t)} porque pacote com devolução NÃO aceita bipe de chegada (o pacote está aqui)` : "");
        R.obs = coletaAqui ? "📦 Coleta daqui – localizar e devolver ao remetente (Matão)" : "📦 Ensacar e enviar pra SN RAO";
      }
      return R;
    }
    if (last.base !== CFG.base) {
      R.oque = `Saiu da base – ${last.tipo} em ${last.base}`;
      return R;
    }
    if (/carregada/i.test(last.tipo)) {
      R.oque = `Carregada pra ${last.dest || "?"}`;
      return R;
    }

    const sufixo = n >= 3 ? "" : ` (${n + 1}ª tentativa)`;
    if (ehSaida(last)) {
      if (ehHoje(last.t)) {
        R.sec = n >= 3 ? "D" : n === 2 ? "F" : "A";
        R.oque = `Saiu para entrega hoje ${hh(last.t)}${sufixo}`;
        R.obs = n >= 3 ? "⚠ Se voltar, REGISTRAR A DEVOLUÇÃO" : "";
      } else if (n === 0) {
        R.sec = "M";
        R.oque = `Saiu para entrega ${dm(last.t)} e não teve bipe depois`;
        R.obs = "📞 COBRAR O MOTORISTA – pode ser só falta assinar";
        R.cobrar = true;
      } else {
        R.sec = n >= 3 ? "D" : n === 2 ? "F" : "A";
        R.oque = `Ainda com o motorista desde ${dm(last.t)}`;
        R.obs = "📞 COBRAR O MOTORISTA";
        R.cobrar = true;
      }
      return R;
    }
    if (ehProb(last) && RE_TRATATIVA.test(last.motivo)) {
      R.sec = n >= 3 ? "D" : n === 2 ? "F" : "A";
      if (ehHoje(last.t)) {
        R.oque = `Tratativa hoje ${hh(last.t)} – ainda não voltou pro galpão`;
        R.obs = n >= 3 ? "Quando voltar: REGISTRAR A DEVOLUÇÃO" : "Aguardar retorno";
      } else {
        R.oque = "Ainda com o motorista (sem bipe de entrada depois)";
        R.obs = `📞 COBRAR O MOTORISTA – está com ele desde ${dm(last.t)}`;
        R.cobrar = true;
      }
      return R;
    }
    // está no galpão
    if (n >= 1) {
      R.sec = n >= 3 ? "D" : n === 2 ? "F" : "A";
      R.oque = `Voltou pro galpão ${dmh(last.t)}`;
      R.obs = n >= 3 ? "📝 REGISTRAR A DEVOLUÇÃO" : `Mandar pra rota${sufixo}`;
      return R;
    }
    // preso na base: desde a chegada na F MAT
    const ultSaiuBase = [...det].reverse().find((s) => s.base !== CFG.base);
    const chegada =
      det.find((s) => s.base === CFG.base && (!ultSaiuBase || s.t > ultSaiuBase.t) && !ADM.includes(s.c)) ||
      det.find((s) => s.base === CFG.base && (!ultSaiuBase || s.t > ultSaiuBase.t)) ||
      last;
    const dias = diasEntre(chegada.t);
    const coleta = det[0] && det[0].base === CFG.base && /coleta/i.test(det[0].tipo);
    const ponto = det.find((x) => x.c === 210 || /bipe de coleta recebida/i.test(x.tipo)); // coleta deixada num ponto (YoYi…)
    R.sec = "B";
    R.ultimo = dmh(last.t);
    R.dias = String(dias);
    R.oque = `${ponto ? `Coleta de ponto (${ponto.base}) – ` : coleta ? "Coleta – " : ""}Chegou ${dmh(chegada.t)} e não saiu pra rota${dias === 2 ? " (2º dia parado)" : ""}`;
    if (ultSaida && ultSaida.t > chegada.t) R.oque = `Saiu com o entregador ${dm(ultSaida.t)} e voltou pro galpão ${dmh(last.t)} sem tratativa (chegou na base ${dm(chegada.t)})`;
    R.obs = dias > CFG.diasAlerta ? "🔴 Mais de 3 dias – verificar onde está (multa diária)" : "Mandar pra rota";
    return R;
  }

  // ---------- Arquivos RETIDOS / SEM MOV (.xlsx / .csv) ----------
  // "AB12" → índice da coluna (A = 0)
  const colIdx = (ref) => {
    const l = String(ref).replace(/\d+/g, "");
    let n = 0;
    for (const ch of l) n = n * 26 + ch.charCodeAt(0) - 64;
    return n - 1;
  };
  const lerCsv = (txt) => String(txt).split(/\r?\n/).map((l) => l.split(/[;,\t]/).map((x) => x.replace(/^"|"$/g, "")));
  // Só as linhas cuja coluna "Base…" é a nossa base (RETIDOS: "Base de Entrega";
  // SEM MOV: "Base Responsável"). NÃO filtrar pela linha inteira: o SEM MOV tem
  // "Próxima Parada", que pode ter F MAT-SP em pacote de outra base.
  function codigosDasLinhas(linhas) {
    const iCab = linhas.findIndex((r) => r.some((x) => /remessa/i.test(x)));
    const cab = iCab >= 0 ? linhas[iCab] : [];
    const colsBase = cab.map((h, i) => (/^base/i.test(String(h).trim()) ? i : -1)).filter((i) => i >= 0);
    const corpo = linhas.slice(iCab + 1);
    const daBase = (r) => (colsBase.length ? colsBase.some((i) => String(r[i] || "").includes(CFG.base) || /F MAT/i.test(r[i] || "")) : r.some((x) => /F MAT/i.test(x)));
    return [...new Set(corpo.filter(daBase).flatMap((r) => codigos(r.join(" "))))];
  }

  // Colagem do backlog (RETIDOS / SEM MOV): só linhas da F MAT; sem coluna de base, pega tudo
  function lerBacklog(txt) {
    const linhas = String(txt).split(/\r?\n/);
    const temBase = linhas.some((l) => /F MAT/i.test(l));
    return [...new Set(linhas.filter((l) => !temBase || /F MAT/i.test(l)).flatMap((l) => codigos(l)))];
  }

  // Nós enviamos e a outra base deu "expedido mas não chegou" (último evento)
  function nosEnviamos(det) {
    if (!det || !det.length) return null;
    const u = det.find((s) => s.ultimo) || det[det.length - 1];
    return u.exp ? u : null;
  }

  const ordemSecoes = "EDFAMBIN";
  function resumoTentativas(ativos) {
    const cont = (k) => ativos.filter((r) => r.sec === k).length;
    return `Atualizado em ${agora().slice(0, 16)} | Pode devolver: ${cont("D")} | Falta 1: ${cont("F")} | Em andamento: ${cont("A")} | Preso c/ motorista: ${cont("M")} | Preso na base: ${cont("B")} (${ativos.filter((r) => r.sec === "B" && +r.dias > CFG.diasAlerta).length} com mais de ${CFG.diasAlerta} dias) | Interceptados: ${cont("I")} | Não chegou: ${cont("N")} |${cont("E") ? ` ⚠ ERRO DE CONSULTA: ${cont("E")} (rodar de novo) |` : ""} Cobrar: ${ativos.filter((r) => r.cobrar).length}`;
  }
  function ordenarAtivos(ativos) {
    return ativos.sort((a, b) => ordemSecoes.indexOf(a.sec) - ordemSecoes.indexOf(b.sec) || (b.sec === "B" ? +b.dias - +a.dias : 0) || a.code.localeCompare(b.code));
  }
  // Bloco compacto para colar no Claude (ele atualiza a planilha). NÃO mudar o
  // formato: o Claude do chat depende dele (igual ao script do Edson).
  function blocoClaude(ativos, sairam, resumo) {
    const lim = (s) => String(s).replace(/[\t\n|]/g, " ");
    return (
      `#TENTATIVAS v1 – atualizar a aba Tentativas da planilha Tickets\n#colunas: secao|codigo|entregador|tratativas|ultimo bipe|o que aconteceu|dias parado|observacao (secao: D=Pode devolver F=Falta 1 A=Em andamento M=Preso c/ motorista B=Preso na base I=Interceptados N=Não chegou)\n#${resumo}\n` +
      ativos.map((r) => [r.sec, r.code, semF(r.entregador), r.trat, r.ultimo, r.oque, r.dias, r.obs].map(lim).join("|")).join("\n") +
      `\n#SAIRAM ${sairam.map((r) => r.code + ":" + lim(r.oque)).join("; ")}`
    );
  }
  // TSV para colar na aba Tentativas da planilha "Tickets" (célula A2 + Ctrl+V).
  // NÃO mudar os textos da seção: a planilha pinta a linha procurando essas palavras.
  // As 150 linhas vazias no fim limpam o que sobrou da rodada anterior.
  const ROT = { E: "⚠️ Erro de consulta", N: "⬛ Não chegou", D: "🟥 Pode devolver", F: "🟧 Falta 1", A: "🟨 Em andamento", M: "🟪 Preso c/ motorista", B: "🟦 Preso na base", I: "🟫 Interceptado" };
  function tsvPlanilha(ativos, resumo) {
    const limT = (s) => String(s).replace(/[\t\n]/g, " ");
    return [
      resumo.replace(/ \| /g, "  ·  "),
      ["Seção", "Código", "Entregador", "Tratativas", "Último bipe", "O que aconteceu", "Dias parado", "Observação"].join("\t"),
      ...ativos.map((r) => [ROT[r.sec], r.code, semF(r.entregador), r.trat, r.ultimo, r.oque, r.dias, r.obs].map(limT).join("\t")),
      ...Array(150).fill("\t\t\t\t\t\t\t"),
    ].join("\n");
  }

  // ---------- Recebimento (expedido não chegou que mandaram para nós) ----------
  const entraExpedido = (det) => {
    const l = det && det[det.length - 1];
    return !!l && /carregada/i.test(l.tipo) && l.base === CFG.origemExpedido && l.dest === CFG.base;
  };
  // Depois de bipar: o último bipe é problemático "expedido…" na nossa base
  const bipeCerto = (det) => {
    const l = det && det[det.length - 1];
    return !!l && ehProb(l) && /expedi/i.test(l.motivo) && l.base === CFG.base;
  };
  // Conferência dupla. r1/r2: { código: det | null (não consultado) }
  function conferirRecebimento(todos, r1, r2) {
    const entra = [];
    const duvida = [];
    const naoConsultados = [];
    const fora = [];
    for (const c of todos) {
      if (!r1[c] || !r2[c]) {
        naoConsultados.push(c);
        continue;
      }
      const a = entraExpedido(r1[c]);
      const b = entraExpedido(r2[c]);
      if (a && b) entra.push(c);
      else if (a !== b) duvida.push(c);
      else fora.push(c);
    }
    return { entra, duvida, naoConsultados, fora };
  }
  const descreverUltimo = (det) => {
    const l = det && det[det.length - 1];
    return l ? `${dmh(l.t)} ${l.tipo} – ${l.base}${l.staff ? " (" + semF(l.staff) + ")" : ""}` : "SEM DADOS";
  };

  // ---------- Cobrar ----------
  function montarMsg(staff, g, nomes = {}) {
    const nome = primeiroNome(staff, nomes);
    const semTrat = g.every((p) => !p.trat);
    const comTrat = g.every((p) => p.trat);
    const dia = dm(g[0].said.t);
    let intro;
    if (g.length === 1)
      intro = semTrat
        ? `O pacote abaixo saiu com você no dia ${dia} e até agora não teve nenhuma tratativa (nem entrega, nem ausência, nem retorno pra base).`
        : `O pacote abaixo está com você desde o dia ${dia}. Você bipou ${(g[0].trat.motivo || "tratativa").toLowerCase()}, mas ele não voltou pra base.`;
    else
      intro = semTrat
        ? `Tenho ${g.length} pacotes que saíram com você e até agora não tiveram nenhuma tratativa (nem entrega, nem ausência, nem retorno pra base).`
        : comTrat
          ? `Tenho ${g.length} pacotes que estão com você. Você bipou a tratativa, mas eles não voltaram pra base.`
          : `Tenho ${g.length} pacotes com você que ainda não voltaram pra base:`;
    const blocos = g.map((p) =>
      [
        `📦 ${p.c}`,
        `Saída pra entrega: ${dm(p.said.t)} às ${hh(p.said.t)}`,
        `Tratativa: ${p.trat ? `${p.trat.motivo || p.trat.tipo} – ${dm(p.trat.t)} às ${hh(p.trat.t)}` : "nenhuma"}`,
        `Cliente: ${p.cli.nome || "?"}`,
        `Telefone: ${p.cli.tel || "?"}`,
        `Endereço: ${p.cli.end || "?"}`,
      ].join("\n")
    );
    return `Oi ${nome}, tudo bem?\n\n${intro}\n\n${blocos.join("\n\n")}`;
  }

  // Separa quem cobrar (por entregador) de quem não precisa
  function gruposCobrar(lista, res) {
    const grupos = {};
    const resolvidos = [];
    const naoConsultados = [];
    for (const c of lista) {
      const det = res[c];
      if (!det) {
        naoConsultados.push(c);
        continue;
      }
      const last = det[det.length - 1];
      if (!last || det.some(ehAssin) || last.base !== CFG.base || !(ehSaida(last) || ehProb(last))) {
        resolvidos.push([c, last ? `${dmh(last.t)} ${last.tipo} – ${last.base}` : "SEM DADOS"]);
        continue;
      }
      const said = [...det].reverse().find(ehSaida);
      if (!said) {
        resolvidos.push([c, "Sem saída para entrega"]);
        continue;
      }
      const trat = det.filter((s) => s.t >= said.t && ehProb(s) && s.base === CFG.base).pop();
      (grupos[said.staff] = grupos[said.staff] || []).push({ c, said, trat });
    }
    return { grupos, resolvidos, naoConsultados };
  }

  // Limpa o endereço que o JMS devolve tudo grudado
  function endereco(full, d) {
    full = String(full || "");
    if (!d) return full;
    const bairro = String(d.receiverAreaName || "").trim();
    const cid = String(d.receiverCityName || "").trim();
    const uf = String(d.receiverProvinceName || "").trim();
    const k = bairro + cid + uf;
    const i = bairro ? full.indexOf(k) : -1;
    if (i < 0) return full;
    let rua = full.slice(0, i).trim();
    let resto = full.slice(i + k.length).trim();
    rua = rua.replace(/([^\d\s,])(\d+[A-Za-z]?)$/, "$1, $2");
    const nomeRua = rua.split(",")[0].trim();
    if (resto && resto.toLowerCase().startsWith(nomeRua.toLowerCase())) resto = resto.slice(nomeRua.length).replace(/^[\s,]*\d+[A-Za-z]?[\s,]*/, "").trim();
    else if (resto && /^\d/.test(resto) && !/\d$/.test(rua)) {
      const m = resto.match(/^(\d+[A-Za-z]?)\s*(.*)$/);
      rua += ", " + m[1];
      resto = m[2];
    }
    return `${rua}, ${cap(bairro)}, ${cid}/${uf}` + (resto ? ` (${resto})` : "");
  }

  // ---------- Nomes dos entregadores ("NOME NO JMS = Apelido", uma por linha) ----------
  function lerNomes(texto) {
    const nomes = {};
    for (const linha of String(texto || "").split(/\r?\n/)) {
      const i = linha.indexOf("=");
      if (i < 1) continue;
      const k = semF(linha.slice(0, i)).toUpperCase().replace(/\s+/g, " ");
      const v = linha.slice(i + 1).trim().slice(0, 40);
      if (k && v) nomes[k] = v;
    }
    return nomes;
  }
  const textoNomes = (nomes) =>
    Object.entries(nomes || {})
      .map(([k, v]) => `${k} = ${v}`)
      .join("\n");

  // ---------- Histórico ----------
  // só a última consulta de cada código no período, para não duplicar
  const ultimas = (arr) =>
    Object.values(
      arr.reduce((m, r) => {
        if (!m[r.code] || m[r.code].em < r.em) m[r.code] = r;
        return m;
      }, {})
    );
  // TSV no formato da planilha "Rastreios JMS – histórico salvo" (colunas A:I)
  function linhasHistorico(lista) {
    const linhas = [];
    for (const r of lista) {
      const em = new Date(r.em);
      const emS = `${pad(em.getDate())}/${pad(em.getMonth() + 1)}/${em.getFullYear()} ${pad(em.getHours())}:${pad(em.getMinutes())}`;
      for (const s of r.det || [])
        linhas.push(
          [emS, r.code, s.t, s.tipo, s.base, s.staff ? `${s.por} → ${s.staff}` : s.por, s.motivo, s.txt, r.origem]
            .map((x) => String(x || "").replace(/[\t\n]/g, " "))
            .join("\t")
        );
    }
    return linhas;
  }

  return {
    CFG,
    SEC,
    ordemSecoes,
    definirRelogio: (fn) => {
      relogio = typeof fn === "function" ? fn : () => new Date();
    },
    dm,
    dmh,
    hh,
    semF,
    codigos,
    normalizar,
    classificar,
    lerBacklog,
    colIdx,
    lerCsv,
    codigosDasLinhas,
    nosEnviamos,
    resumoTentativas,
    ordenarAtivos,
    blocoClaude,
    tsvPlanilha,
    entraExpedido,
    bipeCerto,
    conferirRecebimento,
    descreverUltimo,
    primeiroNome,
    montarMsg,
    gruposCobrar,
    endereco,
    lerNomes,
    textoNomes,
    ultimas,
    linhasHistorico,
  };
})();
