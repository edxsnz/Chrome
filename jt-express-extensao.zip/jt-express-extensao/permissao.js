// permissao.js
// Leitura do version.json do GitHub (aviso de versão + kill switch). Sem DOM:
// carregado pelo popup (antes do update-check.js) e pelo background.js
// (importScripts), que confere o kill switch sozinho mesmo sem o popup abrir.
//
// Kill switch: só trava com um "permissao": false explícito, alguma vez
// confirmado. Sem internet / GitHub fora do ar = vale o último estado salvo.

const PERMISSAO_URL = "https://raw.githubusercontent.com/edxsnz/Chrome/main/version.json";
const PERMISSAO_CACHE_KEY = "permissao_extensao";

// O arquivo tem poucas linhas: algo acima de 16 KB não é o version.json
// (nem chega a ser lido como JSON). Sem resposta em 8 s, desiste.
const VERSAO_MAX_BYTES = 16 * 1024;

// Busca o version.json. Retorna null em qualquer falha (offline, GitHub
// fora do ar, URL errada, JSON inválido) — nunca lança erro pra quem chamou.
function buscarDadosRemotos() {
  const ctl = typeof AbortController === "function" ? new AbortController() : null;
  const timer = ctl ? setTimeout(() => ctl.abort(), 8000) : null;
  return fetch(PERMISSAO_URL, { cache: "no-store", signal: ctl ? ctl.signal : undefined })
    .then((res) => {
      if (!res.ok) return null;
      const tam = Number(res.headers && res.headers.get && res.headers.get("content-length"));
      if (tam > VERSAO_MAX_BYTES) return null;
      if (typeof res.text !== "function") return res.json();
      return res.text().then((t) => (t.length > VERSAO_MAX_BYTES ? null : JSON.parse(t)));
    })
    .catch(() => null)
    .finally(() => timer && clearTimeout(timer));
}

// Aceita true/false, "true"/"false" (com espaços ou maiúsculas) e 1/0,
// já que o arquivo é editado à mão no GitHub e é fácil digitar diferente.
// Retorna null se não reconhecer nada — nesse caso ninguém decide nada.
function interpretarPermissao(valor) {
  if (valor === false || valor === 0) return false;
  if (valor === true || valor === 1) return true;
  if (typeof valor === "string") {
    const normalizado = valor.trim().toLowerCase();
    if (normalizado === "false") return false;
    if (normalizado === "true") return true;
  }
  return null;
}
