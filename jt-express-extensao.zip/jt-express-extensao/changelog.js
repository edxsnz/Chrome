// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "3.11.5",
    data: "27/10/2026",
    titulo: "Lote e Expedido: rajada até o bloqueio",
    itens: [
      "Lote e Expedido: as consultas saem o mais rápido possível até o sistema bloquear. A pausa a cada 60 foi retirada, porque o sistema bloqueava do mesmo jeito.",
      "No bloqueio (erro 405), a extensão espera cerca de 1 minuto, testa o mesmo código ou lote e solta a rajada de novo, sem pular nenhum.",
    ],
  },
  {
    versao: "3.11.4",
    data: "26/10/2026",
    titulo: "Lote no mesmo ritmo do Expedido",
    itens: [
      "Lote: as consultas saem em rajadas de 60 por minuto, como no Expedido. Até 60 lotes terminam em poucos segundos.",
      "Lote: no bloqueio do sistema (erro 405) a extensão espera cerca de 1 minuto e testa o mesmo lote, sem marcar nenhum como não terminado.",
      "Lote e Expedido usam o mesmo limite por minuto: rodando os dois juntos, o sistema não bloqueia.",
    ],
  },
  {
    versao: "3.11.3",
    data: "26/10/2026",
    titulo: "Expedido mais rápido, sem esbarrar no bloqueio",
    itens: [
      "Expedido: as consultas saem em rajadas de 60 por minuto, o máximo que o sistema aceita sem bloquear. Listas de até 60 códigos terminam em poucos segundos.",
      "Expedido: se o sistema bloquear mesmo assim, a extensão espera cerca de 1 minuto, testa o mesmo código e diminui a rajada, sem pular nenhum código.",
      "Expedido: a tela mostra a pausa de cada minuto e a estimativa de tempo ficou mais certa.",
    ],
  },
];
