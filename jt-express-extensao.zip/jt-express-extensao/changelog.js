// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "3.11.0",
    data: "23/10/2026",
    titulo: "Atualização completa: scripts, Guia e Lote mais rápido",
    itens: [
      "Tickets: scripts mais curtos, sem o \"Ler mais\" do WhatsApp, com os dados obrigatórios e as opções oficiais. Mercado Livre no modelo exato da cartilha; TikTok com pedido / remessa, produto e data.",
      "Tickets: nova sub-aba Guia — prazo do ticket (LATAM 22h, TikTok 46h, comum 24h) com a previsão de agilização, e o guia rápido: onde tratar, agilização ou PNR, fechamento, 0800, antes de enviar e pedidos VIP.",
      "Tickets: ao copiar Mercado Livre e TikTok, aparece o lembrete do que não pode.",
      "Lote: Continuar e Criar lote não consultam de novo os lotes terminados nem os conferidos há menos de 10 minutos; antes de dizer que está tudo em lote, confere de novo no sistema.",
      "Lote: Criar lote termina primeiro os lotes começados e só depois usa os vazios.",
      "Lote e Código: Espaço, Enter, ↓ e Page Down passam o código (também com pedal ou passador de slides); segurar a tecla nunca pula códigos.",
      "A aba POD foi removida.",
    ],
  },
  {
    versao: "3.10.2",
    data: "21/10/2026",
    titulo: "Scripts oficiais e respostas prontas; Expedido sem pular código",
    itens: [
      "Tickets: scripts do Mercado Livre e do TikTok no texto oficial dos manuais, e o aviso pede para informar se o pacote chegou lacrado, contar o que aconteceu e mandar fotos.",
      "Tickets: Mercado Livre só copia com a hora da entrega (igual à da baixa).",
      "Tickets: novo botão de respostas — quando a cliente responder o número, toque nele e a continuação certa da conversa já sai copiada.",
      "Expedido: quando o sistema segura as consultas, a extensão espera e tenta de novo o mesmo código até conseguir — nenhum código é pulado.",
      "Expedido: aprende quantas consultas o sistema aceita antes de travar e faz pausas sozinha para não travar de novo.",
      "Expedido: a tela mostra quando está esperando o sistema liberar e quanto falta.",
      "Expedido: botão Copiar diagnóstico, com o registro de cada consulta, para enviar e analisar se algo não sair como esperado.",
    ],
  },
  {
    versao: "3.10.1",
    data: "20/10/2026",
    titulo: "Expedido: velocidade que se ajusta sozinha",
    itens: [
      "Expedido: a velocidade se ajusta sozinha — começa devagar, acelera um pouco quando o sistema responde bem e freia na hora se ele pedir para esperar.",
      "Expedido: se o sistema pedir para esperar, a extensão espera e continua; no fim, refaz sozinha os códigos que deram erro — todos os pacotes são consultados.",
      "Expedido: o tempo que falta é calculado pela velocidade real da consulta.",
    ],
  },
];
