// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "26.11.3.1",
    data: "03/11/2026",
    titulo: "JT Bipe: teste dos avisos do celular",
    itens: [
      "Abrindo o JT-Bipe.exe com dois cliques, a janela de teste agora mostra, com o horário, os avisos que o app da J&T manda quando você bipa (sem mostrar códigos de pedido). Serve para deixar o Autobipe ainda mais rápido.",
    ],
  },
  {
    versao: "26.11.3",
    data: "03/11/2026",
    titulo: "Autobipe mais rápido",
    itens: [
      "Autobipe: nos celulares que avisam a mudança da tela na hora, o código troca logo depois do bipe, sem a espera de 1 segundo da leitura de antes.",
      "O JT Bipe confere sozinho se o seu celular avisa na hora. Se não avisar, ele continua com a leitura de antes, sem você precisar fazer nada.",
    ],
  },
  {
    versao: "26.11.1.1",
    data: "01/11/2026",
    titulo: "Topo vermelho J&T de volta",
    itens: [
      "O topo da extensão voltou ao vermelho padrão da J&T (no lugar do preto), com a marca em branco. O cabeçalho das janelas Novidades e Wi-Fi também ficou vermelho.",
    ],
  },
];
