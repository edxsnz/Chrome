// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "26.10.28.2",
    data: "28/10/2026",
    titulo: "Lixeira na aba Código",
    itens: ["Código: novo botão de lixeira para apagar a lista de uma vez, igual ao das abas Lote e Expedido."],
  },
  {
    versao: "26.10.28.1",
    data: "28/10/2026",
    titulo: "Autobipe abre o JT Bipe sozinho",
    itens: [
      "O JT Bipe agora vem dentro da extensão: ao ligar o Autobipe, ele abre sozinho e escondido, e fecha quando o Autobipe desliga. Não precisa mais abrir o programa.",
      "A linha do Autobipe mostra o que está acontecendo: abrindo o JT Bipe, celular não encontrado, aceitar a depuração USB ou o contador do app.",
      "Na primeira vez em cada computador, rode o atualizar-jt.bat: ele instala a extensão nos Documentos e prepara o Autobipe.",
    ],
  },
  {
    versao: "26.10.28",
    data: "28/10/2026",
    titulo: "Autobipe: o celular passa os códigos sozinho",
    itens: [
      "Novo botão Autobipe na bipagem do Lote e na aba Código: com o programa JT Bipe aberto no PC e o celular no cabo, cada bipe no app passa para o próximo código sozinho.",
      "Se o celular contar mais de um bipe de uma vez, a extensão não passa e avisa para conferir. Repetido e falha não passam.",
      "Quando a estimativa do lote chega a 150, o Autobipe para e avisa para clicar em Criar lote.",
      "O Autobipe começa desligado e o teclado continua funcionando normalmente.",
      "A versão da extensão agora é a data da atualização (ano.mês.dia), como esta: v26.10.28.",
    ],
  },
];
