// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "3.10.1",
    data: "20/10/2026",
    titulo: "Expedido: velocidade que se ajusta sozinha",
    itens: [
      "Expedido: a velocidade se ajusta sozinha — começa devagar, acelera um pouco quando o sistema responde bem e freia na hora se ele pedir para esperar.",
      "Expedido: se o sistema pedir para esperar, a extensão espera e continua; no fim, refaz sozinha os códigos que deram erro — todos os pacotes são consultados.",
      "Expedido: o tempo que falta é calculado pela velocidade real da consulta.",
    ],
  },
  {
    versao: "3.10.0",
    data: "20/10/2026",
    titulo: "Nova aba Expedido e Lote com bipagem contínua",
    itens: [
      "Nova aba Expedido: cole os códigos de rastreio e ela devolve só os que estão com o último status \"Expedido não chegou\". Os que não puderem ser consultados aparecem com aviso e Tentar de novo, nunca somem.",
      "Lote e Expedido: a consulta continua mesmo com a janela da extensão fechada; ao abrir de novo, aparece o progresso ou o resultado.",
      "O ícone da extensão avisa quando a consulta termina e quantos códigos encontrou.",
      "Lote: os códigos sem lote aparecem em uma sequência só, um código de barras por vez, mostrando quantos faltam.",
      "Lote: botão Criar lote — consulta de novo e mostra o código de um lote da sua lista que ainda tem vaga; depois é só clicar em Continuar para voltar aos códigos.",
      "Lote: no fim da lista, Reconsultar para conferir — o que não entrou em lote volta para bipar.",
      "Lote: quando faltar lote, diz quantos criar e deixa colar os lotes novos sem perder o progresso.",
      "Lote: só mostra que terminou quando a consulta confirma que todos os códigos da coleta estão em lote.",
      "Lote: as consultas ao JMS ficaram mais leves, uma por vez e com pausa entre os lotes. Por isso a consulta demora um pouco mais.",
      "Código e Lote: códigos com acento, caractere invisível, aspas ou no formato do Excel (8,88E+14) são limpos ou recusados com aviso, em vez de virar um código de barras errado. Listas separadas por vírgula ou ponto e vírgula também funcionam.",
      "Tickets: telefone com 0 antes do DDD funciona, número de outro país é recusado, e caracteres invisíveis colados junto não vão mais para a mensagem.",
    ],
  },
  {
    versao: "3.9.0",
    data: "19/10/2026",
    titulo: "Lote: vagas e códigos para bipar",
    itens: [
      "Lote: mostra se os lotes têm vagas suficientes ou quantos lotes faltam (150 por lote).",
      "Lote: mostra os lotes que ainda não estão completos.",
      "Lote: códigos de barras na tela para bipar direto com o leitor.",
      "Lote: se algum lote não puder ser consultado, os códigos de barras só aparecem depois de Tentar de novo, para nenhum código ir para o lote errado.",
    ],
  }
];
