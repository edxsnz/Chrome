// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "3.6.0",
    data: "16/10/2026",
    titulo: "Aba Lote e script de acareação por embarcador",
    itens: [
      "Nova aba Lote: cole a lista da coleta e a lista de lotes, e a extensão consulta cada lote no sistema e devolve só os códigos que não foram para nenhum lote, prontos para copiar. Para consultar, mantenha o sistema JMS aberto e com login feito em uma aba do navegador.",
      "Na aba Lote, títulos soltos (como \"Número da saca\") e códigos repetidos são ignorados, o que foi colado continua salvo ao sair para copiar no sistema, e se algum lote falhar dá pra tentar de novo só os que falharam.",
      "Tickets > Ocorrência agora segue o Manual de Scripts de Acareação: escreva a Origem como está no sistema e a extensão usa o texto certo de cada embarcador — Mercado Livre, Via Varejo, TikTok Shop, Shopee, Cainiao, Infracommerce — e o Script J&T para os demais, já com os erros de escrita do manual corrigidos.",
      "Os campos mudam sozinhos conforme o embarcador (Código MELI, ID Via, Código BR26, Código CNBR, ID Infra, nota fiscal e data da entrega), e um selo ao lado de \"Origem\" mostra qual regra está valendo. Também avisa quando a chave da nota fiscal é colada no lugar do número da NF.",
      "Novo campo \"Seu nome\" para os scripts que pedem o nome de quem atende (Mercado Livre e TikTok), lembrado mesmo depois de fechar o navegador.",
      "Arezzo, ZZAB, Motorola (Infracommerce), M. Aguiar & Garcia e Marlon não aceitam acareação por mensagem: a extensão avisa e bloqueia Copiar e WhatsApp, pra evitar extravio.",
      "A prévia (botão do olho) mostra a mensagem como a cliente vai ver no WhatsApp, com o negrito já aplicado. Corrigido um problema em que as abas apareciam por cima da prévia.",
      "Endereço incorreto: \"Seguem as informações do seu pedido\".",
    ],
  },
  {
    versao: "3.5.0",
    data: "02/08/2026",
    titulo: "Suporte ao Mercado Livre e código de barras mais direto",
    itens: [
      "Em Tickets > Ocorrência, ao digitar \"MERCADO\" na Origem, o campo N° pedido vira automaticamente Código MELI (o que já estava digitado passa junto), e a mensagem já se ajusta com o texto correto do Mercado Livre — sem precisar selecionar nada à parte.",
      "Na aba Código, quando sobra só um código, o código de barras é gerado direto, sem perguntar sobre cancelados.",
      "Pequenos ajustes de layout e estabilidade.",
    ],
  },
  {
    versao: "3.4.0",
    data: "02/08/2026",
    titulo: "Ajustes na aba Código",
    itens: [
      "Ao perguntar sobre códigos cancelados, agora dá pra voltar e editar a lista original a qualquer momento, sem perder o que já foi digitado.",
      "A conferência de cancelados agora mostra o resultado (quantos foram removidos, ou se algum não foi encontrado) e pede uma confirmação antes de gerar — antes a tela avançava rápido demais pra dar tempo de ler o aviso.",
      "Códigos duplicados na lista colada agora são removidos automaticamente antes de gerar (evita código de barras repetido e contagem errada ao cancelar).",
      "Diversos ajustes de estabilidade e segurança.",
    ],
  },
];
