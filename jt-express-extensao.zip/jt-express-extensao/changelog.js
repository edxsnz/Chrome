// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.

const CHANGELOG = [
  {
    versao: "3.3.0",
    data: "02/08/2026",
    titulo: "POD Correto/Incorreto",
    itens: [
      "Aba POD agora tem um alternador \"Correto\" / \"Incorreto\". No Incorreto, aparece um campo \"Motivo\" e a mensagem muda de acordo.",
      "Texto do POD Incorreto é um rascunho no mesmo tom do Correto (\"POD INCORRETO, (Nome) — Motivo: (Motivo)\") — ainda não é um texto oficial, avise se quiser mudar a redação.",
      "Auditoria completa de código e segurança: permissão do GitHub restrita só ao repositório (em vez do domínio inteiro), cópia pro clipboard e geração de código de barras agora avisam em vez de falhar em silêncio, checklist de códigos desabilita \"Gerar\" quando nada está marcado, e limpeza de CSS morto/duplicado.",
    ],
  },
  {
    versao: "3.2.0",
    data: "02/08/2026",
    titulo: "Código de barras",
    itens: [
      "Nova aba \"Código\": cole vários códigos de rastreio (um por linha ou separados por espaço) e gera um código de barras Code128 por vez, com Anterior/Próximo pra ir bipando — tudo dentro da extensão, sem depender de internet.",
      "Etapa de conferência antes de gerar: mostra a lista com uma caixinha por código — desmarca o que não deve virar código de barras (ex.: pedido cancelado) e só os marcados são gerados.",
      "No visualizador, botão \"Remover este (cancelado)\" pra tirar o código atual da lista na hora, sem precisar voltar e editar tudo de novo.",
      "Botão \"Quebrar linha\": transforma uma lista colada com espaços em uma lista com um código por linha, e já copia o resultado.",
      "Biblioteca de código de barras (JsBarcode) embutida localmente — corrige os erros que a versão anterior (página HTML separada, carregando de um CDN) apresentava.",
    ],
  },
  {
    versao: "3.1.0",
    data: "02/08/2026",
    titulo: "WhatsApp + qualidade",
    itens: [
      "Novo campo \"Número do cliente\" em Tickets — um por sub-aba (Ocorrência e Endereço incorreto têm o seu próprio; cada Limpar afeta só a sua aba). Não existe no POD.",
      "Botão WhatsApp: abre a conversa do número e copia a mensagem pra área de transferência — é só colar e enviar (preencher direto pela URL quebrava os emojis em alguns casos).",
      "Revisão geral do código: corrigido espaçamento duplicado nas sub-abas e contraste baixo na borda do botão Visualizar no tema claro.",
      "Limpar e Visualizar viraram botões só com ícone pra abrir espaço pro WhatsApp sem quebrar o layout.",
      "Emojis das mensagens trocados por escapes Unicode no código — evita que apareçam corrompidos (ex.: caminhão da Ocorrência) dependendo de como o arquivo é aberto/editado.",
    ],
  },
];
