// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "26.11.22.3",
    data: "22/11/2026",
    titulo: "Planilhas: Não chegou e cópia para a planilha",
    itens: [
      "Nova seção ⬛ Não chegou na aba Planilhas: pacote em que a F MAT-SP bipou \"expedido não chegou\" ou \"extravio\" e que não apareceu na base depois. Ele não está aqui, então não vai mais para \"preso na base\". Se depois foi interceptado, sai da lista.",
      "Novo botão Copiar para a planilha: na aba Tentativas da planilha Tickets, clique na célula A2 e aperte Ctrl+V. As linhas que sobraram da rodada anterior são apagadas sozinhas.",
      "Preso na base: quando o pacote saiu com o entregador e voltou sem nenhuma tratativa, aparece \"saiu com o entregador e voltou pro galpão sem tratativa\". A data de chegada não conta mais bipes que não provam que o pacote está na base.",
    ],
  },
  {
    versao: "26.11.22.2",
    data: "22/11/2026",
    titulo: "Planilhas direto do arquivo",
    itens: [
      "Na aba Planilhas do painel do JMS, clique em Escolher arquivos e selecione o RETIDOS e o SEM MOV (.xlsx) juntos. Não precisa abrir o Excel nem copiar e colar.",
      "Só entram os pacotes em que a coluna da base é a F MAT-SP (Base de Entrega no RETIDOS, Base Responsável no SEM MOV). Pacote de outra base que só passa pela F MAT-SP não entra mais por engano.",
      "Ao lado do botão aparece quantas linhas cada arquivo tem e quantos pacotes são da F MAT-SP. Colar o conteúdo continua funcionando.",
    ],
  },
  {
    versao: "26.11.22.1",
    data: "22/11/2026",
    titulo: "Painel do JMS mais seguro",
    itens: [
      "Recebimento: o Ler tela agora pega todas as páginas do monitoramento, não só a que está aberta. Se não conseguir ler tudo, ele para e avisa (coloque 100 por página e clique de novo), para nenhum pacote ficar sem o bipe.",
      "Planilhas: o texto do Copiar para o Claude voltou a ser exatamente igual ao de antes, com os mesmos símbolos.",
      "Quando o JMS bloqueia por excesso de consultas, a extensão espera 1 minuto inteiro antes de tentar de novo (no painel, no Lote e no raio).",
      "Cobrar: se o JMS travar no meio, os dados da cliente esperam e são buscados de novo, em vez de sair com \"?\".",
    ],
  },
];
