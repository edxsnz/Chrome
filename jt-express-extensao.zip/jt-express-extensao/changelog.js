// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "26.11.20.1",
    data: "20/11/2026",
    titulo: "Raio mais completo e mais seguro",
    itens: [
      "Agora é só colar o rastreio: a busca no JMS começa sozinha. O raio e o Enter continuam funcionando. Colou o rastreio de outro pedido? Os campos do pedido anterior são trocados, com o botão Desfazer.",
      "O raio também traz o Código KW do Kwai, o número da NF quando o sistema manda a chave da nota, e a loja de verdade quando o pedido vem por intermediador (no lugar de \"intelipost\", \"APIJMS\"…). O telefone é sempre o do sistema.",
      "Pacotes do Mercado Livre que aparecem como \"MERCADO CBT\" agora usam o script oficial do Mercado Livre.",
      "Se o remetente ou a loja no sistema for Arezzo, ZZAB, Motorola, M. Aguiar & Garcia ou Marlon, a mensagem fica travada: só acareação física. No Infracommerce, a caixa Remetente MOTOROLA é marcada sozinha.",
      "Avisos antes de mandar: entregue a vizinho ou na portaria, POD inválido, assinado por outra base, conteúdo que veio como código de barras ou genérico (comum na SHEIN) e TikTok sem telefone válido. Clique no aviso para ver todos.",
      "Embaixo do rastreio aparece o último movimento do pacote, com a base e o entregador. A aba Endereço também ganhou o raio.",
    ],
  },
  {
    versao: "26.11.20",
    data: "20/11/2026",
    titulo: "Preencher a Ocorrência pelo rastreio",
    itens: [
      "Novo botão de raio ao lado do Rastreio, na Ocorrência: cole o código J&T e clique no raio (ou aperte Enter). A extensão busca no JMS e preenche telefone, nome, origem, N° do pedido, data da entrega e conteúdo.",
      "Precisa do JMS aberto e logado numa aba do navegador, igual ao Lote e ao Expedido.",
      "Só preenche os campos vazios: o que você já digitou fica. Se o pacote ainda não foi assinado, a data fica em branco e aparece um aviso.",
      "Se o sistema pedir uma pausa, a extensão mostra a contagem e tenta de novo sozinha.",
    ],
  },
  {
    versao: "26.11.18.2",
    data: "18/11/2026",
    titulo: "Mais leve e acertos no visual",
    itens: [
      "Listas grandes no Lote, no Expedido e no Código não travam mais a digitação.",
      "A prévia do WhatsApp só é montada quando você abre ela, o que deixa a digitação em Tickets mais leve.",
      "Sumiu a faixa amarela vazia que aparecia acima dos botões no Lote e no Expedido.",
      "Lista do resultado do Lote sem linha cortada, e tipo do ticket e busca da Guia sem texto cortado.",
    ],
  },
];
