// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "26.11.20",
    data: "20/11/2026",
    titulo: "Preencher a Ocorrência pelo rastreio",
    itens: [
      "Novo botão de raio ao lado do Rastreio, na Ocorrência: cole o código J&T e clique no raio (ou aperte Enter). A extensão busca no JMS e preenche telefone, nome, origem, N° do pedido, data da entrega e conteúdo.",
      "Precisa do JMS aberto e logado numa aba do navegador, igual ao Lote e ao Expedido.",
      "Só preenche os campos vazios: o que você já digitou fica. Se o pacote ainda não foi assinado, a data fica em branco e aparece um aviso.",
      "Se o sistema pedir uma pausa, a extensão mostra a contagem e tenta de novo sozinha.",
    ],
  },
  {
    versao: "26.11.18.2",
    data: "18/11/2026",
    titulo: "Mais leve e acertos no visual",
    itens: [
      "Listas grandes no Lote, no Expedido e no Código não travam mais a digitação.",
      "A prévia do WhatsApp só é montada quando você abre ela, o que deixa a digitação em Tickets mais leve.",
      "Sumiu a faixa amarela vazia que aparecia acima dos botões no Lote e no Expedido.",
      "Lista do resultado do Lote sem linha cortada, e tipo do ticket e busca da Guia sem texto cortado.",
    ],
  },
  {
    versao: "26.11.18.1",
    data: "18/11/2026",
    titulo: "Passar sozinho (bipagem pela câmera)",
    itens: [
      "Novo botão \"Passar sozinho\" na bipagem do Lote e na aba Código: o código de barras troca sozinho no tempo que você digitar, em segundos (de 0,3 a 10; ex.: 1,5).",
      "Como usar: no app do celular, ligue o escaneamento contínuo, deixe a câmera apontada para a tela e clique em Passar sozinho. O celular vai bipando sem você tocar em nada. Para ir mais rápido, diminua também o \"Intervalo de escaneamento\" nas configurações do app.",
      "Para sozinho no fim da lista e quando o lote deve ter chegado a 150. Apertar uma seta, Espaço ou Enter também pausa.",
      "Se algum código não for lido, o Reconsultar mostra e devolve ele para a lista, como sempre.",
    ],
  },
];
