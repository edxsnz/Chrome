// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "26.11.24.2",
    data: "24/11/2026",
    titulo: "Painel do JMS sempre em tempo real",
    itens: [
      "A aba Histórico do painel do JMS saiu. Agora toda consulta (Recebimento, Planilhas, Rastreio e Cobrar) vai ao JMS na hora: nada é reaproveitado de uma consulta de minutos atrás.",
      "O histórico que estava guardado no navegador é apagado sozinho. Os nomes dos entregadores e as listas das abas continuam.",
    ],
  },
  {
    versao: "26.11.24.1",
    data: "24/11/2026",
    titulo: "Lote em maratona e painel do JMS mais claro",
    itens: [
      "Lote em maratona: cole a coleta e os lotes e clique em Criar lote (aqui ele consulta). Depois é só bipar o lote, clicar em Continuar e bipar os códigos dele. Cada lote mostra só os códigos que cabem nele: se faltava 1, aparece 1. Criar lote e Continuar não consultam mais: confira tudo no fim (ou em Reconsultar, quando quiser). O botão Outro lote saiu.",
      "Painel do JMS: o Recebimento consulta cada código 1 vez só e tenta de novo os que não responderam até todos responderem. Toda consulta termina com a etiqueta Pronto (ou Não está pronto, se você parou). Com a janela fechada, o raio fica verde. Rodar de novo depois de bipar mostra Já bipados e Tudo certo.",
      "Aba Planilhas virou a lista de tarefas do dia: em cima o que precisa fazer (Cobrar motorista, Registrar devolução, Ensacar, Preso na base, Interceptado, Coleta não chegou), embaixo o que só acompanha, com a contagem 1/3, 2/3 e 3/3. Os de expedido não chegou que vinham para nós vão para a aba Não chegou, com botão de copiar próprio. Saiu pra entrega hoje sem nenhuma tratativa não entra mais.",
    ],
  },
  {
    versao: "26.11.24",
    data: "24/11/2026",
    titulo: "SAC e endereço da base a um clique",
    itens: [
      "Os scripts do TikTok agora pedem o telefone e o endereço da base. No fim da linha Ocorrência / Endereço / Scripts / Guia há dois botões: o do telefone copia o SAC 0800 055 0050 e o do alfinete copia o endereço da base (Av. Campos Salles, 2386 – Vila Guarani, Matão – SP, 15997-066). Passe o mouse para ver o texto; ao clicar aparece um ✓.",
      "A Guia (TikTok: agilização ou PNR) foi atualizada com a regra nova: telefone = SAC, endereço = endereço da base.",
    ],
  },
];
