// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "26.11.25",
    data: "25/11/2026",
    titulo: "Não entregues: Problemático e não voltou",
    itens: [
      "Na aba Não entregues do painel do JMS, o grupo Ausente e não voltou agora se chama Problemático e não voltou. Ele junta qualquer bipe problemático de dia anterior em que o pacote não voltou para a base (ausência, recusa, endereço e também motivos como Insucesso na devolução), para cobrar o entregador.",
      "A contagem 1/3, 2/3 e 3/3 continua contando só ausência, recusa, endereço e os outros motivos de tentativa. Quando o motivo não conta como tentativa, a coluna Detalhe avisa.",
      "Pacote que voltou para a base e não saiu de novo com o entregador continua aparecendo em Voltou e não saiu.",
    ],
  },
  {
    versao: "26.11.24.3",
    data: "24/11/2026",
    titulo: "Painel do JMS: aba Não entregues",
    itens: [
      "Nova aba Não entregues no painel do JMS: ela lê a tela Gestão de pedido JMS de entrega (Não entregue, últimos 7 dias), confere cada pacote no rastreio e separa o que não é de hoje (Preso no app, Ausente e não voltou, Voltou e não saiu, Conferir) do que é de hoje (Volta pra base, Com o entregador). Cada pacote mostra as tentativas 1/3, 2/3 e 3/3.",
      "O botão Copiar para a planilha leva tudo para a aba Não entregues da planilha Tickets: clique na célula A2 e Ctrl+V. Os nomes dos entregadores agora ficam nesta aba.",
      "As abas Planilhas e Cobrar saíram do painel.",
    ],
  },
  {
    versao: "26.11.24.2",
    data: "24/11/2026",
    titulo: "Painel do JMS sempre em tempo real",
    itens: [
      "A aba Histórico do painel do JMS saiu. Agora toda consulta (Recebimento, Planilhas, Rastreio e Cobrar) vai ao JMS na hora: nada é reaproveitado de uma consulta de minutos atrás.",
      "O histórico que estava guardado no navegador é apagado sozinho. Os nomes dos entregadores e as listas das abas continuam.",
    ],
  },
];
