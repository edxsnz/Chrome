// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "3.7.0",
    data: "16/10/2026",
    titulo: "Scripts de acareação completos",
    itens: [
      "Tickets > Ocorrência: todos os scripts seguem agora o mesmo modelo completo e organizado — apresentação com o seu nome, bloco \"Dados do pedido\" e assinatura no final.",
      "Em todos os embarcadores a mensagem leva código de rastreio, loja, produto e data e hora da entrega, além do que cada manual exige: ID MELI, ID Via, N° do pedido, Código BR26 ou CNBR junto do rastreio, ID Infra e nota fiscal.",
      "As opções de resposta continuam as do manual de cada embarcador, numeradas em negrito, e a mensagem já pede para a cliente informar se o pacote chegou lacrado quando escolher uma opção de problema — como no exemplo do manual.",
      "Os campos \"Seu nome\" e \"Data da entrega\" aparecem para todos os embarcadores.",
      "Copiar e WhatsApp avisam e marcam em vermelho os campos que faltam, para nenhuma mensagem sair incompleta para a cliente.",
    ],
  },
  {
    versao: "3.6.1",
    data: "16/10/2026",
    titulo: "Correção na aba Lote",
    itens: [
      "Corrigido: a aba Lote pedia para abrir o sistema JMS mesmo com ele já aberto. Agora ela reconhece o JMS em qualquer endereço do sistema.",
      "Corrigido: a aba Lote dizia que não achou o login mesmo com o JMS logado. Agora ela encontra o login em qualquer lugar onde o sistema o guarde.",
      "Se a extensão foi atualizada e ainda não foi recarregada no navegador, a aba Lote avisa e mostra um botão Recarregar que resolve na hora.",
    ],
  },
  {
    versao: "3.6.0",
    data: "16/10/2026",
    titulo: "Aba Lote e script de acareação por embarcador",
    itens: [
      "Nova aba Lote: cole a lista da coleta e a lista de lotes, e a extensão consulta cada lote no sistema e devolve só os códigos que não foram para nenhum lote, prontos para copiar. Para consultar, mantenha o sistema JMS aberto e com login feito em uma aba do navegador.",
      "Na aba Lote, títulos soltos (como \"Número da saca\") e códigos repetidos são ignorados, o que foi colado continua salvo ao sair para copiar no sistema, e se algum lote falhar dá pra tentar de novo só os que falharam.",
      "Tickets > Ocorrência agora segue o Manual de Scripts de Acareação: escreva a Origem como está no sistema e a extensão usa o texto certo de cada embarcador — Mercado Livre, Via Varejo, TikTok Shop, Shopee, Cainiao, Infracommerce — e o Script J&T para os demais, já com os erros de escrita do manual corrigidos.",
      "Os campos mudam sozinhos conforme o embarcador (Código MELI, ID Via, Código BR26, Código CNBR, ID Infra, nota fiscal e data da entrega), e um selo ao lado de \"Origem\" mostra qual regra está valendo. Também avisa quando a chave da nota fiscal é colada no lugar do número da NF.",
      "Novo campo \"Seu nome\" para os scripts que pedem o nome de quem atende (Mercado Livre e TikTok), lembrado mesmo depois de fechar o navegador.",
      "Arezzo, ZZAB, Motorola (Infracommerce), M. Aguiar & Garcia e Marlon não aceitam acareação por mensagem: a extensão avisa e bloqueia Copiar e WhatsApp, pra evitar extravio.",
      "A prévia (botão do olho) mostra a mensagem como a cliente vai ver no WhatsApp, com o negrito já aplicado. Corrigido um problema em que as abas apareciam por cima da prévia.",
      "Endereço incorreto: \"Seguem as informações do seu pedido\".",
    ],
  }
];
