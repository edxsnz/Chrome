// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "3.8.2",
    data: "19/10/2026",
    titulo: "N° do pedido em todos os scripts",
    itens: [
      "Tickets > Ocorrência: o campo N° do pedido (o \"N° pedido do cliente\" do sistema) agora aparece para todos os embarcadores e entra na mensagem — inclusive Wepink, Shein e os demais fora do manual.",
      "Nos embarcadores que o manual exige (Mercado Livre, Via Varejo, TikTok Shop, Shopee e Infracommerce) ele continua obrigatório; nos outros aparece como \"se tiver\": se o sistema mostrar \"--\", é só deixar em branco que a linha não entra.",
      "Cainiao e Kwai ganharam um campo próprio para o Código CNBR / Código KW (o \"Número de rastreamento do cliente\"), que vai junto do código J&T, e o N° do pedido fica em linha separada.",
    ],
  },
  {
    versao: "3.8.1",
    data: "19/10/2026",
    titulo: "Kwai em Tickets",
    itens: [
      "Tickets > Ocorrência agora reconhece o Kwai: escreva \"Kwai\" na Origem e aparecem os campos Código KW (o \"Número de rastreamento do cliente\" do sistema, KW...BR) e N° do pedido (P_...).",
      "Na mensagem, o Código KW vai junto do código de rastreio J&T e o N° do pedido em linha própria, para a cliente reconhecer o pedido do Kwai.",
    ],
  },
  {
    versao: "3.8.0",
    data: "17/10/2026",
    titulo: "Visual novo, com a cara da J&T",
    itens: [
      "Extensão toda redesenhada: topo vermelho J&T com o menu em abas, ícones novos para Tickets, POD, Código e Lote, e a versão atual sempre à vista.",
      "Fonte nova, mais fácil de ler, e campos maiores, todos com a mesma altura.",
      "Selo do embarcador mais visível ao lado de \"Origem\", e avisos importantes com destaque lateral em vermelho.",
      "Código de barras em formato de etiqueta, barra de progresso animada na aba Lote e janela de Novidades renovada.",
      "Tema escuro revisado em todas as telas.",
      "Endereço incorreto e POD também avisam e marcam em vermelho o que falta, para nenhuma mensagem sair incompleta.",
      "Clique duplo no WhatsApp não abre mais duas conversas, e um telefone com dígitos a mais (dois números colados juntos) é recusado.",
      "O que você digita logo ao abrir a extensão não é mais apagado pelos dados que estavam salvos.",
      "As setas do teclado não pulam mais o código de barras enquanto você digita em outra aba, e a tecla Esc fecha a prévia e as Novidades.",
    ],
  }
];
