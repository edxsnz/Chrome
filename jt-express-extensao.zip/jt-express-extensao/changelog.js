// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "3.9.0",
    data: "19/10/2026",
    titulo: "Lote: vagas e códigos para bipar",
    itens: [
      "Lote: mostra se os lotes têm vagas suficientes ou quantos lotes faltam (150 por lote).",
      "Lote: mostra os lotes que ainda não estão completos.",
      "Lote: novo botão Gerar códigos de barras, que mostra o código de cada lote e, em seguida, os códigos sem lote que vão nele, para bipar direto da tela.",
      "Lote: plano de bipagem com o que vai em cada lote, que pode ser copiado. Se faltar lote, crie no JMS e consulte de novo.",
      "Lote: se algum lote não puder ser consultado, o botão Gerar só aparece depois de Tentar de novo, para nenhum código ir para o lote errado.",
    ],
  },
  {
    versao: "3.8.2",
    data: "19/10/2026",
    titulo: "N° do pedido em todos os scripts",
    itens: [
      "Tickets > Ocorrência: o campo N° do pedido (o \"N° pedido do cliente\" do sistema) agora aparece para todos os embarcadores e entra na mensagem — inclusive Wepink, Shein e os demais fora do manual.",
      "Nos embarcadores que o manual exige (Mercado Livre, Via Varejo, TikTok Shop, Shopee e Infracommerce) ele continua obrigatório; nos outros aparece como \"se tiver\": se o sistema mostrar \"--\", é só deixar em branco que a linha não entra.",
      "Cainiao e Kwai ganharam um campo próprio para o Código CNBR / Código KW (o \"Número de rastreamento do cliente\"), que vai junto do código J&T, e o N° do pedido fica em linha separada.",
    ],
  },
  {
    versao: "3.8.1",
    data: "19/10/2026",
    titulo: "Kwai em Tickets",
    itens: [
      "Tickets > Ocorrência agora reconhece o Kwai: escreva \"Kwai\" na Origem e aparecem os campos Código KW (o \"Número de rastreamento do cliente\" do sistema, KW...BR) e N° do pedido (P_...).",
      "Na mensagem, o Código KW vai junto do código de rastreio J&T e o N° do pedido em linha própria, para a cliente reconhecer o pedido do Kwai.",
    ],
  }
];
