// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "26.11.18.2",
    data: "18/11/2026",
    titulo: "Mais leve e acertos no visual",
    itens: [
      "Listas grandes no Lote, no Expedido e no Código não travam mais a digitação.",
      "A prévia do WhatsApp só é montada quando você abre ela, o que deixa a digitação em Tickets mais leve.",
      "Sumiu a faixa amarela vazia que aparecia acima dos botões no Lote e no Expedido.",
      "Lista do resultado do Lote sem linha cortada, e tipo do ticket e busca da Guia sem texto cortado.",
    ],
  },
  {
    versao: "26.11.18.1",
    data: "18/11/2026",
    titulo: "Passar sozinho (bipagem pela câmera)",
    itens: [
      "Novo botão \"Passar sozinho\" na bipagem do Lote e na aba Código: o código de barras troca sozinho no tempo que você digitar, em segundos (de 0,3 a 10; ex.: 1,5).",
      "Como usar: no app do celular, ligue o escaneamento contínuo, deixe a câmera apontada para a tela e clique em Passar sozinho. O celular vai bipando sem você tocar em nada. Para ir mais rápido, diminua também o \"Intervalo de escaneamento\" nas configurações do app.",
      "Para sozinho no fim da lista e quando o lote deve ter chegado a 150. Apertar uma seta, Espaço ou Enter também pausa.",
      "Se algum código não for lido, o Reconsultar mostra e devolve ele para a lista, como sempre.",
    ],
  },
  {
    versao: "26.11.18",
    data: "18/11/2026",
    titulo: "Scripts de ticket comum e Guia atualizada",
    itens: [
      "Nova sub-aba Scripts (em Tickets): os 17 scripts de ticket comum da orientação nova (Em rota, Expedido mas não chegou, Erro de triagem, Reentrega, Buscas, Extravio, Avaria…). Escolha o script, coloque a data limite (ou use +3, +5, +7 dias úteis) e copie.",
      "Guia atualizada com os treinamentos novos: qual script usar pelo último bipe, PNR com e sem ativo obrigatório, pedidos VIP KWAI, contestação, POD válido e avaria na base.",
      "Mercado Livre: a acareação online pode ser feita pelo líder ou pelo assistente da base. TikTok: opções com a redação do manual.",
      "Guia: as seções que você abriu continuam abertas (e no mesmo ponto da lista) quando você sai da extensão e volta.",
      "Apagou sem querer? Depois de clicar na lixeira aparece o botão \"Desfazer\" por alguns segundos, em todas as abas.",
      "Código: se você sair no meio da pergunta dos cancelados, ao voltar ela continua de onde parou, com os cancelados que já tinha colado.",
      "Atalhos para trocar de aba: Alt+1 (Tickets), Alt+2 (Código), Alt+3 (Lote) e Alt+4 (Expedido).",
      "Na primeira vez, o tema claro ou escuro segue o do Windows.",
      "O aviso de versão nova diz o que fazer: rodar o atualizar-jt.bat e recarregar a extensão. O atualizador agora mostra a versão antiga e a nova e já deixa o caminho da pasta copiado.",
    ],
  },
];
