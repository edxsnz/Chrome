// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "3.8.0",
    data: "17/10/2026",
    titulo: "Visual novo, com a cara da J&T",
    itens: [
      "Extensão toda redesenhada: topo vermelho J&T com o menu em abas, ícones novos para Tickets, POD, Código e Lote, e a versão atual sempre à vista.",
      "Fonte nova, mais fácil de ler, e campos maiores, todos com a mesma altura.",
      "Selo do embarcador mais visível ao lado de \"Origem\", e avisos importantes com destaque lateral em vermelho.",
      "Código de barras em formato de etiqueta, barra de progresso animada na aba Lote e janela de Novidades renovada.",
      "Tema escuro revisado em todas as telas.",
      "Endereço incorreto e POD também avisam e marcam em vermelho o que falta, para nenhuma mensagem sair incompleta.",
      "Clique duplo no WhatsApp não abre mais duas conversas, e um telefone com dígitos a mais (dois números colados juntos) é recusado.",
      "O que você digita logo ao abrir a extensão não é mais apagado pelos dados que estavam salvos.",
      "As setas do teclado não pulam mais o código de barras enquanto você digita em outra aba, e a tecla Esc fecha a prévia e as Novidades.",
    ],
  },
  {
    versao: "3.7.0",
    data: "16/10/2026",
    titulo: "Scripts de acareação completos",
    itens: [
      "Tickets > Ocorrência: todos os scripts seguem agora o mesmo modelo completo e organizado — apresentação com o seu nome, bloco \"Dados do pedido\" e assinatura no final.",
      "Em todos os embarcadores a mensagem leva código de rastreio, loja, produto e data e hora da entrega, além do que cada manual exige: ID MELI, ID Via, N° do pedido, Código BR26 ou CNBR junto do rastreio, ID Infra e nota fiscal.",
      "As opções de resposta continuam as do manual de cada embarcador, numeradas em negrito, e a mensagem já pede para a cliente informar se o pacote chegou lacrado quando escolher uma opção de problema — como no exemplo do manual.",
      "Os campos \"Seu nome\" e \"Data da entrega\" aparecem para todos os embarcadores.",
      "Copiar e WhatsApp avisam e marcam em vermelho os campos que faltam, para nenhuma mensagem sair incompleta para a cliente.",
    ],
  },
  {
    versao: "3.6.1",
    data: "16/10/2026",
    titulo: "Correção na aba Lote",
    itens: [
      "Corrigido: a aba Lote pedia para abrir o sistema JMS mesmo com ele já aberto. Agora ela reconhece o JMS em qualquer endereço do sistema.",
      "Corrigido: a aba Lote dizia que não achou o login mesmo com o JMS logado. Agora ela encontra o login em qualquer lugar onde o sistema o guarde.",
      "Se a extensão foi atualizada e ainda não foi recarregada no navegador, a aba Lote avisa e mostra um botão Recarregar que resolve na hora.",
    ],
  }
];
