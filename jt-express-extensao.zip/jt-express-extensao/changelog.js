// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "26.11.1.1",
    data: "01/11/2026",
    titulo: "Topo vermelho J&T de volta",
    itens: [
      "O topo da extensão voltou ao vermelho padrão da J&T (no lugar do preto), com a marca em branco. O cabeçalho das janelas Novidades e Wi-Fi também ficou vermelho.",
    ],
  },
  {
    versao: "26.11.1",
    data: "01/11/2026",
    titulo: "Visual novo",
    itens: [
      "Visual novo em todas as abas: topo escuro com a fita vermelha da J&T, letras novas mais legíveis e campos e botões mais firmes, no tema claro e no escuro.",
      "Avisos de atenção agora aparecem todos do mesmo jeito: texto alinhado à esquerda, com uma fita amarela e preta ao lado, mais fácil de ler que o texto vermelho centralizado.",
      "O código de barras aparece como uma etiqueta impressa, com borda preta e a faixa vermelha da J&T.",
      "Os campos vazios agora explicam o que colocar (ex.: \"DDD + número\", \"Cole aqui os pedidos da coleta\") no lugar de telefones e códigos de exemplo.",
    ],
  },
  {
    versao: "26.10.30",
    data: "30/10/2026",
    titulo: "Guia atualizada com os treinamentos novos",
    itens: [
      "Guia: novas seções com o que fazer depois da resposta do cliente (lacrado, proteção interna, ressarcimento), o que preencher na acareação física de cada embarcador, POD do Mercado Livre e como achar a NF e o ID Infra da Infracommerce.",
      "Guia: ticket comum, com o que é agilização e o que é PNR, e o que fazer quando o focal encerra o ticket.",
      "Guia: cenários de discurso do TikTok atualizados (SAC 0800 055 0050 e endereço do pacote 0) e as regras novas de reprovação.",
    ],
  },
];
