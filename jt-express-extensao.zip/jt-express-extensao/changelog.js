// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "26.11.27.2",
    data: "27/11/2026",
    titulo: "Ler tela e consultas sem bloqueio",
    itens: [
      "Recebimento: o Ler tela agora espera o JMS terminar de trazer a lista (mesmo quando ele demora quase 1 minuto) antes de pedir qualquer outra coisa. Antes ele pedia de novo várias vezes e deixava o JMS mais lento.",
      "Consultas ao JMS num ritmo constante: uma a cada 1,1 segundo, desde a primeira. As primeiras não vão mais todas de uma vez, porque isso fazia o JMS bloquear.",
    ],
  },
  {
    versao: "26.11.27.1",
    data: "27/11/2026",
    titulo: "Correção do painel do JMS",
    itens: [
      "O painel do JMS às vezes era carregado duas vezes na mesma aba (principalmente ao recarregar a página ou na tela de login) e aparecia erro na página de extensões. Agora ele carrega uma vez só.",
    ],
  },
  {
    versao: "26.11.27",
    data: "27/11/2026",
    titulo: "Bipar pelo cabo e consultas sem bloqueio",
    itens: [
      "Pelo cabo: com o celular ligado no USB (Depuração USB ativada), ligue a chave Cabo nas abas Código e Lote e cada código vai direto para o app da J&T, sem câmera. No Lote, o botão Mandar pro celular manda o lote (e desliga a Verificação on-line sozinho); depois é só clicar em Passar sozinho. No fim do lote, a extensão confere no próprio app quantos entraram. Rode o atualizar-jt.bat para instalar o que o cabo precisa.",
      "Recebimento: o Ler tela agora espera o JMS trazer os 1000 registros (pode levar 1 minuto), sem mandar o pedido de novo.",
      "Não entregues: consulta de ontem para trás (7 dias). Os pacotes de hoje, que ainda estão em rota, não entram.",
      "Consultas ao JMS num ritmo que não bloqueia: as primeiras vão na hora e depois uma a cada 1,1 segundo. Se o JMS bloquear mesmo assim, a espera é de 61 segundos.",
    ],
  },
];
