// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "3.4.0",
    data: "02/08/2026",
    titulo: "Ajustes na aba Código",
    itens: [
      "Ao perguntar sobre códigos cancelados, agora dá pra voltar e editar a lista original a qualquer momento, sem perder o que já foi digitado.",
      "A conferência de cancelados agora mostra o resultado (quantos foram removidos, ou se algum não foi encontrado) e pede uma confirmação antes de gerar — antes a tela avançava rápido demais pra dar tempo de ler o aviso.",
      "Códigos duplicados na lista colada agora são removidos automaticamente antes de gerar (evita código de barras repetido e contagem errada ao cancelar).",
      "Diversos ajustes de estabilidade e segurança.",
    ],
  },
  {
    versao: "3.3.0",
    data: "02/08/2026",
    titulo: "POD Correto/Incorreto e conferência de cancelados",
    itens: [
      "POD agora tem duas opções: Correto e Incorreto. No Incorreto, basta preencher o motivo e a mensagem já se ajusta.",
      "Na aba Código, antes de gerar, a extensão pergunta se existem códigos cancelados na lista — cole só os cancelados e ela gera automaticamente todos os outros.",
      "Diversos ajustes de estabilidade e segurança.",
    ],
  },
  {
    versao: "3.2.0",
    data: "02/08/2026",
    titulo: "Código de barras",
    itens: [
      "Nova aba Código: cole os códigos de rastreio e gere um código de barras por vez, ideal pra bipar rapidamente, sem precisar de internet.",
      "No visualizador, dá pra remover um código na hora, sem precisar editar a lista toda de novo.",
      "Botão para organizar rapidamente uma lista de códigos colada com espaços em uma lista com um código por linha.",
    ],
  },
];
