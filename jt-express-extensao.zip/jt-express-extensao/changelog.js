// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "26.10.30",
    data: "30/10/2026",
    titulo: "Guia atualizada com os treinamentos novos",
    itens: [
      "Guia: novas seções com o que fazer depois da resposta do cliente (lacrado, proteção interna, ressarcimento), o que preencher na acareação física de cada embarcador, POD do Mercado Livre e como achar a NF e o ID Infra da Infracommerce.",
      "Guia: ticket comum, com o que é agilização e o que é PNR, e o que fazer quando o focal encerra o ticket.",
      "Guia: cenários de discurso do TikTok atualizados (SAC 0800 055 0050 e endereço do pacote 0) e as regras novas de reprovação.",
    ],
  },
  {
    versao: "26.10.29.1",
    data: "29/10/2026",
    titulo: "Autobipe mais firme na tela de bipar",
    itens: [
      "Autobipe: não pede mais para abrir \"Bipar pedido\" quando o celular já está nela. Avisos do app por cima (como \"Pedido duplicado\") e leituras que falham não tiram mais o Autobipe da tela de bipar.",
      "Se o celular não deixar ler a tela por muito tempo, a linha do Autobipe avisa.",
      "Autobipe: corrigido o \"não consigo ler a tela do celular\". Uma leitura presa no celular travava todas as outras; agora o JT Bipe encerra leituras presas ao abrir e ao fechar, cada leitura tem tempo limite e, se travar, ele recomeça sozinho sem perder o bipe.",
    ],
  },
  {
    versao: "26.10.29",
    data: "29/10/2026",
    titulo: "Autobipe pelo Wi-Fi (plano B)",
    itens: [
      "Novo botão Wi-Fi ao lado do Autobipe: com a Depuração por Wi-Fi ligada no celular, o PC acha o celular na rede sozinho (o IP e a porta mudam toda vez, então não precisa digitar). Na 1ª vez, digite só o código de pareamento.",
      "Depois de parear uma vez, é só ligar a Depuração por Wi-Fi no celular: o Autobipe reconecta sozinho. Com o cabo ligado, o cabo tem preferência.",
      "A linha do Autobipe mostra quando o celular está pelo Wi-Fi.",
    ],
  },
];
