// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.

const CHANGELOG = [
  {
    versao: "3.1.0",
    data: "02/08/2026",
    titulo: "WhatsApp + qualidade",
    itens: [
      "Novo campo \"Número do cliente\" em Tickets — um por sub-aba (Ocorrência e Endereço incorreto têm o seu próprio; cada Limpar afeta só a sua aba). Não existe no POD.",
      "Botão WhatsApp: abre a conversa do número e copia a mensagem pra área de transferência — é só colar e enviar (preencher direto pela URL quebrava os emojis em alguns casos).",
      "Revisão geral do código: corrigido espaçamento duplicado nas sub-abas e contraste baixo na borda do botão Visualizar no tema claro.",
      "Limpar e Visualizar viraram botões só com ícone pra abrir espaço pro WhatsApp sem quebrar o layout.",
      "Emojis das mensagens trocados por escapes Unicode no código — evita que apareçam corrompidos (ex.: caminhão da Ocorrência) dependendo de como o arquivo é aberto/editado.",
    ],
  },
  {
    versao: "3.0.0",
    data: "28/07/2026",
    titulo: "Sub-aba, tema e changelog",
    itens: [
      "Nova sub-aba \"Endereço incorreto\" dentro de Tickets, com mensagem própria e apenas 3 campos.",
      "Tema claro/escuro — a preferência agora fica salva mesmo depois de fechar o navegador.",
      "Vermelho ajustado para ficar mais fiel à identidade da marca.",
      "Este painel de novidades, mostrando sempre a versão atual e as 2 anteriores.",
      "Verificação de atualização: 1x por sessão do navegador, comparando com um version.json no GitHub.",
    ],
  },
  {
    versao: "2.1.0",
    data: "20/07/2026",
    titulo: "Novo visual",
    itens: [
      "Layout redesenhado com cards em glassmorphism e paleta vermelho/tinta.",
      "Indicador de aba deslizante com o \"ponto de rota\".",
      "A aba usada fica salva na sessão (volta pra mesma ao reabrir o popup).",
      "Correções de rolagem indesejada, alinhamento da barra de ações e ícone da lixeira.",
    ],
  },
];
