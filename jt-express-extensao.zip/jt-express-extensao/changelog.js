// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "3.5.0",
    data: "02/08/2026",
    titulo: "Suporte ao Mercado Livre e código de barras mais direto",
    itens: [
      "Em Tickets > Ocorrência, ao digitar \"MERCADO\" na Origem, o campo N° pedido vira automaticamente Código MELI (o que já estava digitado passa junto), e a mensagem já se ajusta com o texto correto do Mercado Livre — sem precisar selecionar nada à parte.",
      "Na aba Código, quando sobra só um código, o código de barras é gerado direto, sem perguntar sobre cancelados.",
      "Pequenos ajustes de layout e estabilidade.",
    ],
  },
  {
    versao: "3.4.0",
    data: "02/08/2026",
    titulo: "Ajustes na aba Código",
    itens: [
      "Ao perguntar sobre códigos cancelados, agora dá pra voltar e editar a lista original a qualquer momento, sem perder o que já foi digitado.",
      "A conferência de cancelados agora mostra o resultado (quantos foram removidos, ou se algum não foi encontrado) e pede uma confirmação antes de gerar — antes a tela avançava rápido demais pra dar tempo de ler o aviso.",
      "Códigos duplicados na lista colada agora são removidos automaticamente antes de gerar (evita código de barras repetido e contagem errada ao cancelar).",
      "Diversos ajustes de estabilidade e segurança.",
    ],
  },
  {
    versao: "3.3.0",
    data: "02/08/2026",
    titulo: "POD Correto/Incorreto e conferência de cancelados",
    itens: [
      "POD agora tem duas opções: Correto e Incorreto. No Incorreto, basta preencher o motivo e a mensagem já se ajusta.",
      "Na aba Código, antes de gerar, a extensão pergunta se existem códigos cancelados na lista — cole só os cancelados e ela gera automaticamente todos os outros.",
      "Diversos ajustes de estabilidade e segurança.",
    ],
  },
];
