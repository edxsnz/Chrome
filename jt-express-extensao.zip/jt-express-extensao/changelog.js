// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "26.11.22.5",
    data: "22/11/2026",
    titulo: "Painel do JMS de cara nova",
    itens: [
      "Trocar de aba no painel ⚡ não apaga mais nada: o resultado, os códigos colados e os botões de copiar continuam lá quando você volta. Dá até para usar outra aba enquanto uma consulta roda (a aba que está consultando fica com um pontinho amarelo).",
      "Aba Planilhas com placar: um quadrado por seção com o número de pacotes; clique para ir direto à seção. Cada seção abre e fecha, e as grandes (Preso na base, Não chegou) começam fechadas. O campo de busca acha um código ou um entregador na hora.",
      "Botão ⤢ no topo para abrir a janela larga, boa para ler as tabelas. Barra de progresso durante as consultas (fica listrada de amarelo e preto quando o JMS segura as consultas) e \"✓ Copiado\" aparece no próprio botão.",
    ],
  },
  {
    versao: "26.11.22.4",
    data: "22/11/2026",
    titulo: "Planilhas: nada some sem motivo",
    itens: [
      "Pacote que o JMS não deixou consultar entra na seção ⚠️ Erro de consulta, aparece na planilha e é consultado de novo na próxima rodada. Antes ele sumia da planilha. No fim de cada consulta, o painel também tenta de novo os que falharam (até 3 vezes, esperando 1 minuto).",
      "Coleta nossa que foi carregada para a SN RAO e lá deram \"expedido não chegou\" agora aparece em ⬛ Não chegou: a responsabilidade é da F MAT-SP. Quando outra base marca \"suspeita de extravio\" depois do nosso expedido não chegou, o pacote continua em Não chegou, e a observação mostra quem marcou.",
      "Pacote com devolução registrada que voltou e foi bipado \"expedido não chegou\" vai para Pode devolver (ele está aqui). Também apareceram: aviso quando o pacote consta recebido antes do expedido não chegou, coleta de ponto (YoYi) em Preso na base e tratativa bipada menos de 5 minutos depois da saída.",
    ],
  },
  {
    versao: "26.11.22.3",
    data: "22/11/2026",
    titulo: "Planilhas: Não chegou e cópia para a planilha",
    itens: [
      "Nova seção ⬛ Não chegou na aba Planilhas: pacote em que a F MAT-SP bipou \"expedido não chegou\" ou \"extravio\" e que não apareceu na base depois. Ele não está aqui, então não vai mais para \"preso na base\". Se depois foi interceptado, sai da lista.",
      "Novo botão Copiar para a planilha: na aba Tentativas da planilha Tickets, clique na célula A2 e aperte Ctrl+V. As linhas que sobraram da rodada anterior são apagadas sozinhas.",
      "Preso na base: quando o pacote saiu com o entregador e voltou sem nenhuma tratativa, aparece \"saiu com o entregador e voltou pro galpão sem tratativa\". A data de chegada não conta mais bipes que não provam que o pacote está na base.",
    ],
  },
];
