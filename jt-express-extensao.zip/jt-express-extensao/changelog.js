// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "26.10.29",
    data: "29/10/2026",
    titulo: "Autobipe pelo Wi-Fi (plano B)",
    itens: [
      "Novo botão Wi-Fi ao lado do Autobipe: com a Depuração por Wi-Fi ligada no celular, o PC acha o celular na rede sozinho (o IP e a porta mudam toda vez, então não precisa digitar). Na 1ª vez, digite só o código de pareamento.",
      "Depois de parear uma vez, é só ligar a Depuração por Wi-Fi no celular: o Autobipe reconecta sozinho. Com o cabo ligado, o cabo tem preferência.",
      "A linha do Autobipe mostra quando o celular está pelo Wi-Fi.",
    ],
  },
  {
    versao: "26.10.28.2",
    data: "28/10/2026",
    titulo: "Lixeira na aba Código",
    itens: ["Código: novo botão de lixeira para apagar a lista de uma vez, igual ao das abas Lote e Expedido."],
  },
  {
    versao: "26.10.28.1",
    data: "28/10/2026",
    titulo: "Autobipe abre o JT Bipe sozinho",
    itens: [
      "O JT Bipe agora vem dentro da extensão: ao ligar o Autobipe, ele abre sozinho e escondido, e fecha quando o Autobipe desliga. Não precisa mais abrir o programa.",
      "A linha do Autobipe mostra o que está acontecendo: abrindo o JT Bipe, celular não encontrado, aceitar a depuração USB ou o contador do app.",
      "Na primeira vez em cada computador, rode o atualizar-jt.bat: ele instala a extensão nos Documentos e prepara o Autobipe.",
    ],
  },
];
