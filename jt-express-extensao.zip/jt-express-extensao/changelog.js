// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "26.11.22",
    data: "22/11/2026",
    titulo: "Painel ⚡ dentro do JMS",
    itens: [
      "Novo botão de raio no topo da extensão: ligado, aparece um botão vermelho ⚡ dentro do JMS com o painel de automações. Vem desligado.",
      "Recebimento: lê a tela de monitoramento de recebimento e mostra quais pacotes precisam do bipe \"expedido não chegou\" (carregados na SP RBP para a F MAT-SP e que não chegaram). Cada pacote é conferido 2 vezes, e depois de bipar o botão Conferir bipes mostra se ficou certo. Se não bipar, a base paga os pacotes.",
      "Planilhas: cole o RETIDOS e o SEM MOV de uma vez. O painel mostra o que nós enviamos e a outra base deu \"expedido não chegou\", e separa as tentativas (pode devolver, falta 1, preso com motorista, preso na base…).",
      "Cobrar monta a mensagem de WhatsApp para cada entregador. Os apelidos dos entregadores ficam guardados só no seu navegador.",
      "Rastreio em lote e Histórico (30 dias), pronto para colar na planilha.",
      "A aba Expedido saiu da extensão: tudo isso agora fica no painel do JMS.",
    ],
  },
  {
    versao: "26.11.20.1",
    data: "20/11/2026",
    titulo: "Raio mais completo e mais seguro",
    itens: [
      "Agora é só colar o rastreio: a busca no JMS começa sozinha. O raio e o Enter continuam funcionando. Colou o rastreio de outro pedido? Os campos do pedido anterior são trocados, com o botão Desfazer.",
      "O raio também traz o Código KW do Kwai, o número da NF quando o sistema manda a chave da nota, e a loja de verdade quando o pedido vem por intermediador (no lugar de \"intelipost\", \"APIJMS\"…). O telefone é sempre o do sistema.",
      "Pacotes do Mercado Livre que aparecem como \"MERCADO CBT\" agora usam o script oficial do Mercado Livre.",
      "Se o remetente ou a loja no sistema for Arezzo, ZZAB, Motorola, M. Aguiar & Garcia ou Marlon, a mensagem fica travada: só acareação física. No Infracommerce, a caixa Remetente MOTOROLA é marcada sozinha.",
      "Avisos antes de mandar: entregue a vizinho ou na portaria, POD inválido, assinado por outra base, conteúdo que veio como código de barras ou genérico (comum na SHEIN) e TikTok sem telefone válido. Clique no aviso para ver todos.",
      "Embaixo do rastreio aparece o último movimento do pacote, com a base e o entregador. A aba Endereço também ganhou o raio.",
    ],
  },
  {
    versao: "26.11.20",
    data: "20/11/2026",
    titulo: "Preencher a Ocorrência pelo rastreio",
    itens: [
      "Novo botão de raio ao lado do Rastreio, na Ocorrência: cole o código J&T e clique no raio (ou aperte Enter). A extensão busca no JMS e preenche telefone, nome, origem, N° do pedido, data da entrega e conteúdo.",
      "Precisa do JMS aberto e logado numa aba do navegador, igual ao Lote e ao Expedido.",
      "Só preenche os campos vazios: o que você já digitou fica. Se o pacote ainda não foi assinado, a data fica em branco e aparece um aviso.",
      "Se o sistema pedir uma pausa, a extensão mostra a contagem e tenta de novo sozinha.",
    ],
  },
];
