// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "26.11.18.1",
    data: "18/11/2026",
    titulo: "Passar sozinho (bipagem pela câmera)",
    itens: [
      "Novo botão \"Passar sozinho\" na bipagem do Lote e na aba Código: o código de barras troca sozinho a cada 0,5 a 3 segundos (você escolhe).",
      "Como usar: no app do celular, ligue o escaneamento contínuo, deixe a câmera apontada para a tela e clique em Passar sozinho. O celular vai bipando sem você tocar em nada. Para ir mais rápido, diminua também o \"Intervalo de escaneamento\" nas configurações do app.",
      "Para sozinho no fim da lista e quando o lote deve ter chegado a 150. Apertar uma seta, Espaço ou Enter também pausa.",
      "Se algum código não for lido, o Reconsultar mostra e devolve ele para a lista, como sempre.",
    ],
  },
  {
    versao: "26.11.18",
    data: "18/11/2026",
    titulo: "Scripts de ticket comum e Guia atualizada",
    itens: [
      "Nova sub-aba Scripts (em Tickets): os 17 scripts de ticket comum da orientação nova (Em rota, Expedido mas não chegou, Erro de triagem, Reentrega, Buscas, Extravio, Avaria…). Escolha o script, coloque a data limite (ou use +3, +5, +7 dias úteis) e copie.",
      "Guia atualizada com os treinamentos novos: qual script usar pelo último bipe, PNR com e sem ativo obrigatório, pedidos VIP KWAI, contestação, POD válido e avaria na base.",
      "Mercado Livre: a acareação online pode ser feita pelo líder ou pelo assistente da base. TikTok: opções com a redação do manual.",
      "Guia: as seções que você abriu continuam abertas (e no mesmo ponto da lista) quando você sai da extensão e volta.",
      "Apagou sem querer? Depois de clicar na lixeira aparece o botão \"Desfazer\" por alguns segundos, em todas as abas.",
      "Código: se você sair no meio da pergunta dos cancelados, ao voltar ela continua de onde parou, com os cancelados que já tinha colado.",
      "Atalhos para trocar de aba: Alt+1 (Tickets), Alt+2 (Código), Alt+3 (Lote) e Alt+4 (Expedido).",
      "Na primeira vez, o tema claro ou escuro segue o do Windows.",
      "O aviso de versão nova diz o que fazer: rodar o atualizar-jt.bat e recarregar a extensão. O atualizador agora mostra a versão antiga e a nova e já deixa o caminho da pasta copiado.",
    ],
  },
  {
    versao: "26.11.13",
    data: "13/11/2026",
    titulo: "Autobipe removido e revisão geral",
    itens: [
      "O Autobipe (celular passando o código sozinho) foi descontinuado e saiu da extensão, junto com o programa JT Bipe. A bipagem continua pelo teclado: Espaço, Enter ou → passam; ← volta.",
      "Duas janelas da extensão abertas ao mesmo tempo não se atrapalham mais: uma consulta nova numa janela avisa e para a da outra (antes ela ficava presa em \"Consultando…\"), e fechar uma janela não grava a lista velha por cima da nova.",
      "Lote e Expedido consultando juntos respeitam o mesmo bloqueio do sistema (um não continua mandando enquanto o outro está bloqueado).",
      "O diagnóstico do Expedido copia os códigos de pedido mascarados (só o começo e o fim).",
      "O atualizar-jt.bat agora só apaga a extensão antiga depois de conferir a nova, e remove o JT Bipe de instalações antigas.",
    ],
  },
];
