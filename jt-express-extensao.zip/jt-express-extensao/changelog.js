// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.

const CHANGELOG = [
  {
    versao: "3.0.0",
    data: "01/08/2026",
    titulo: "Sub-aba, tema e changelog",
    itens: [
      "Nova sub-aba \"Endereço incorreto\" dentro de Tickets, com mensagem própria e apenas 3 campos.",
      "Tema claro/escuro — a preferência agora fica salva mesmo depois de fechar o navegador.",
      "Vermelho ajustado para ficar mais fiel à identidade da marca.",
      "Este painel de novidades, mostrando sempre a versão atual e as 2 anteriores.",
      "Verificação de atualização: 1x por sessão do navegador, comparando com um version.json no GitHub.",
    ],
  },
  {
    versao: "2.1.0",
    data: "01/08/2026",
    titulo: "Novo visual",
    itens: [
      "Layout redesenhado com cards em glassmorphism e paleta vermelho/tinta.",
      "Indicador de aba deslizante com o \"ponto de rota\".",
      "A aba usada fica salva na sessão (volta pra mesma ao reabrir o popup).",
      "Correções de rolagem indesejada, alinhamento da barra de ações e ícone da lixeira.",
    ],
  },
  {
    versao: "2.0.0",
    data: "01/08/2026",
    titulo: "Versão base",
    itens: [
      "Estrutura inicial com as abas Reclamação e POD.",
      "Mensagens padronizadas com preenchimento automático dos campos.",
      "Sessão temporária: os dados somem ao fechar o navegador por completo.",
    ],
  },
];
