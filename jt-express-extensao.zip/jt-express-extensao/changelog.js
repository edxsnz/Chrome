// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "26.11.13",
    data: "13/11/2026",
    titulo: "Autobipe removido e revisão geral",
    itens: [
      "O Autobipe (celular passando o código sozinho) foi descontinuado e saiu da extensão, junto com o programa JT Bipe. A bipagem continua pelo teclado: Espaço, Enter ou → passam; ← volta.",
      "Duas janelas da extensão abertas ao mesmo tempo não se atrapalham mais: uma consulta nova numa janela avisa e para a da outra (antes ela ficava presa em \"Consultando…\"), e fechar uma janela não grava a lista velha por cima da nova.",
      "Lote e Expedido consultando juntos respeitam o mesmo bloqueio do sistema (um não continua mandando enquanto o outro está bloqueado).",
      "O diagnóstico do Expedido copia os códigos de pedido mascarados (só o começo e o fim).",
      "O atualizar-jt.bat agora só apaga a extensão antiga depois de conferir a nova, e remove o JT Bipe de instalações antigas.",
    ],
  },
  {
    versao: "26.11.1.1",
    data: "01/11/2026",
    titulo: "Topo vermelho J&T de volta",
    itens: [
      "O topo da extensão voltou ao vermelho padrão da J&T (no lugar do preto), com a marca em branco. O cabeçalho das janelas Novidades e Wi-Fi também ficou vermelho.",
    ],
  },
  {
    versao: "26.11.1",
    data: "01/11/2026",
    titulo: "Visual novo",
    itens: [
      "Visual novo em todas as abas: topo escuro com a fita vermelha da J&T, letras novas mais legíveis e campos e botões mais firmes, no tema claro e no escuro.",
      "Avisos de atenção agora aparecem todos do mesmo jeito: texto alinhado à esquerda, com uma fita amarela e preta ao lado, mais fácil de ler que o texto vermelho centralizado.",
      "O código de barras aparece como uma etiqueta impressa, com borda preta e a faixa vermelha da J&T.",
      "Os campos vazios agora explicam o que colocar (ex.: \"DDD + número\", \"Cole aqui os pedidos da coleta\") no lugar de telefones e códigos de exemplo.",
    ],
  },
];
