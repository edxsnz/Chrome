// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "26.11.24.1",
    data: "24/11/2026",
    titulo: "Lote em maratona e painel do JMS mais claro",
    itens: [
      "Lote em maratona: cole a coleta e os lotes e clique em Criar lote (aqui ele consulta). Depois é só bipar o lote, clicar em Continuar e bipar os códigos dele. Cada lote mostra só os códigos que cabem nele: se faltava 1, aparece 1. Criar lote e Continuar não consultam mais: confira tudo no fim (ou em Reconsultar, quando quiser). O botão Outro lote saiu.",
      "Painel do JMS: o Recebimento consulta cada código 1 vez só e tenta de novo os que não responderam até todos responderem. Toda consulta termina com a etiqueta Pronto (ou Não está pronto, se você parou). Com a janela fechada, o raio fica verde. Rodar de novo depois de bipar mostra Já bipados e Tudo certo.",
      "Aba Planilhas virou a lista de tarefas do dia: em cima o que precisa fazer (Cobrar motorista, Registrar devolução, Ensacar, Preso na base, Interceptado, Coleta não chegou), embaixo o que só acompanha, com a contagem 1/3, 2/3 e 3/3. Os de expedido não chegou que vinham para nós vão para a aba Não chegou, com botão de copiar próprio. Saiu pra entrega hoje sem nenhuma tratativa não entra mais.",
    ],
  },
  {
    versao: "26.11.24",
    data: "24/11/2026",
    titulo: "SAC e endereço da base a um clique",
    itens: [
      "Os scripts do TikTok agora pedem o telefone e o endereço da base. No fim da linha Ocorrência / Endereço / Scripts / Guia há dois botões: o do telefone copia o SAC 0800 055 0050 e o do alfinete copia o endereço da base (Av. Campos Salles, 2386 – Vila Guarani, Matão – SP, 15997-066). Passe o mouse para ver o texto; ao clicar aparece um ✓.",
      "A Guia (TikTok: agilização ou PNR) foi atualizada com a regra nova: telefone = SAC, endereço = endereço da base.",
    ],
  },
  {
    versao: "26.11.22.5",
    data: "22/11/2026",
    titulo: "Painel do JMS de cara nova",
    itens: [
      "Trocar de aba no painel ⚡ não apaga mais nada: o resultado, os códigos colados e os botões de copiar continuam lá quando você volta. Dá até para usar outra aba enquanto uma consulta roda (a aba que está consultando fica com um pontinho amarelo).",
      "Aba Planilhas com placar: um quadrado por seção com o número de pacotes; clique para ir direto à seção. Cada seção abre e fecha, e as grandes (Preso na base, Não chegou) começam fechadas. O campo de busca acha um código ou um entregador na hora.",
      "Botão ⤢ no topo para abrir a janela larga, boa para ler as tabelas. Barra de progresso durante as consultas (fica listrada de amarelo e preto quando o JMS segura as consultas) e \"✓ Copiado\" aparece no próprio botão.",
    ],
  },
];
