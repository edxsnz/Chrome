// changelog.js
// Histórico de versões. Mantém sempre a versão atual + as 2 anteriores
// (3 entradas no total). Ao publicar uma nova versão: adiciona uma
// entrada no topo e remove a mais antiga.
//
// Importante: os textos abaixo são notas de versão para quem usa a
// extensão (atendentes) — devem ser diretos e descrever o que mudou,
// sem comentários de desenvolvedor ou observações dirigidas a quem
// mantém o código.

const CHANGELOG = [
  {
    versao: "26.11.22.2",
    data: "22/11/2026",
    titulo: "Planilhas direto do arquivo",
    itens: [
      "Na aba Planilhas do painel do JMS, clique em Escolher arquivos e selecione o RETIDOS e o SEM MOV (.xlsx) juntos. Não precisa abrir o Excel nem copiar e colar.",
      "Só entram os pacotes em que a coluna da base é a F MAT-SP (Base de Entrega no RETIDOS, Base Responsável no SEM MOV). Pacote de outra base que só passa pela F MAT-SP não entra mais por engano.",
      "Ao lado do botão aparece quantas linhas cada arquivo tem e quantos pacotes são da F MAT-SP. Colar o conteúdo continua funcionando.",
    ],
  },
  {
    versao: "26.11.22.1",
    data: "22/11/2026",
    titulo: "Painel do JMS mais seguro",
    itens: [
      "Recebimento: o Ler tela agora pega todas as páginas do monitoramento, não só a que está aberta. Se não conseguir ler tudo, ele para e avisa (coloque 100 por página e clique de novo), para nenhum pacote ficar sem o bipe.",
      "Planilhas: o texto do Copiar para o Claude voltou a ser exatamente igual ao de antes, com os mesmos símbolos.",
      "Quando o JMS bloqueia por excesso de consultas, a extensão espera 1 minuto inteiro antes de tentar de novo (no painel, no Lote e no raio).",
      "Cobrar: se o JMS travar no meio, os dados da cliente esperam e são buscados de novo, em vez de sair com \"?\".",
    ],
  },
  {
    versao: "26.11.22",
    data: "22/11/2026",
    titulo: "Painel ⚡ dentro do JMS",
    itens: [
      "Novo botão de raio no topo da extensão: ligado, aparece um botão vermelho ⚡ dentro do JMS com o painel de automações. Vem desligado.",
      "Recebimento: lê a tela de monitoramento de recebimento e mostra quais pacotes precisam do bipe \"expedido não chegou\" (carregados na SP RBP para a F MAT-SP e que não chegaram). Cada pacote é conferido 2 vezes, e depois de bipar o botão Conferir bipes mostra se ficou certo. Se não bipar, a base paga os pacotes.",
      "Planilhas: cole o RETIDOS e o SEM MOV de uma vez. O painel mostra o que nós enviamos e a outra base deu \"expedido não chegou\", e separa as tentativas (pode devolver, falta 1, preso com motorista, preso na base…).",
      "Cobrar monta a mensagem de WhatsApp para cada entregador. Os apelidos dos entregadores ficam guardados só no seu navegador.",
      "Rastreio em lote e Histórico (30 dias), pronto para colar na planilha.",
      "A aba Expedido saiu da extensão: tudo isso agora fica no painel do JMS.",
    ],
  },
];
