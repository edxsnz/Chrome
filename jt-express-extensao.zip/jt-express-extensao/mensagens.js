// mensagens.js
// TODOS os textos que vão para a cliente ficam aqui: scripts de acareação de
// cada embarcador, as respostas por opção e a mensagem de endereço incorreto.
// Para mudar um texto, é só mexer neste arquivo (a lógica fica no popup.js).
//
// Regras:
// - *asteriscos* viram negrito no WhatsApp;
// - nada de dado real (telefone, pedido, nome): o repositório é público;
// - embarcador novo: entra em EMBARCADORES (os "só física" vêm primeiro).
// Carregado antes do popup.js (ver popup.html).

const SORRISO = "\u{1F60A}";
const CAMINHAO = "\u{1F69A}";
const PACOTE = "\u{1F4E6}";
const DEDO = "\u{1F447}";

// Opções de resposta de cada manual (texto do manual, só com a pontuação
// padronizada).
// "resposta" = qual mensagem de continuação usar quando o cliente escolhe a
// opção (Cartilha de Continuidade do Mercado Livre + tratativa por opção do
// Manual de Scripts).
const OPCOES_JT = [
  { texto: "Recebi o produto.", resposta: "recebi" },
  { texto: "Não recebi o produto.", resposta: "naoRecebi" },
  { texto: "Recebi o pacote com produtos faltantes.", resposta: "faltante" },
  { texto: "Recebi o produto com defeito.", resposta: "defeito" },
  { texto: "Recebi um produto diferente do comprado.", resposta: "diferente" },
  { texto: "Recebi o produto danificado.", resposta: "danificado" },
];
const OPCOES_ML = OPCOES_JT.slice(0, 5); // modelo do Mercado Livre: 5 opções
// Redação do Manual de Scripts de Acareação (out/2026), só com a pontuação
// padronizada
const OPCOES_TIKTOK = [
  { texto: "Recebi o produto.", resposta: "recebi" },
  { texto: "Recebi o produto corretamente, lacrado e embalado.", resposta: "recebiLacrado" },
  { texto: "Não recebi o produto.", resposta: "naoRecebi" },
  { texto: "Recebi o produto com itens faltantes.", resposta: "faltante" },
  { texto: "Recebi o produto com a embalagem externa em más condições.", resposta: "embalagem" },
  { texto: "Recebi um produto diferente do que comprei.", resposta: "diferente" },
  { texto: "Recebi o produto com defeito.", resposta: "defeito" },
];

// Modelo único para todos os embarcadores, completo (como na 3.10.2, a
// pedido do usuário): saudação, apresentação, todos os dados do pedido num
// bloco, as opções de cada manual e a assinatura. O pedido de lacre/fotos
// fica para a continuação (botão de respostas), depois que a cliente
// escolhe o número. Os *asteriscos* viram negrito no WhatsApp.
function montarScript(v, cfg) {
  const abertura = cfg.abertura || [
    `Olá, ${v.nome}! Tudo bem? ${SORRISO}`,
    "",
    `Me chamo *${v.seuNome}* e sou da *Transportadora J&T Express*, ${cfg.apresentacao}.`,
    "",
    `Verificamos que foi aberta uma reclamação referente ao seu pedido. ${cfg.objetivo || OBJETIVO_PADRAO}`,
  ];
  const dados = cfg.dados ? ["", `${PACOTE} *Dados do pedido*`, ...cfg.dados.map(([rotulo, valor]) => `*${rotulo}:* ${valor}`)] : [];
  if (cfg.dados && !cfg.semData) dados.push(`*Entregue em:* ${v.data}`); // data e hora da entrega: em TODOS os scripts
  return [
    ...abertura,
    ...dados,
    "",
    cfg.chamada || `Para que possamos te ajudar, responda apenas com o *número* da opção correspondente ${DEDO}`,
    "",
    ...cfg.opcoes.map((o, i) => `*${i + 1}* – ${o.texto}`),
    "",
    "Atenciosamente,",
    `${v.seuNome} – J&T Express ${CAMINHAO}`,
  ].join("\n");
}

const OBJETIVO_PADRAO = "Seguem as informações:";

// Script J&T (demais embarcadores) e Script Digital (embarcadores com código
// próprio). O sistema tem dois campos que identificam o pedido para a cliente:
//  - "N° pedido do cliente" (v.pedido): vai em linha própria — exceto na
//    Shopee, em que ele É o BR26 e o manual pede junto do código J&T;
//  - "Número de rastreamento do cliente" (v.rastreioCliente): CNBR da Cainiao
//    e KW do Kwai — o manual pede junto do código J&T, separado por barra.
// Pedido em branco (ou "--", como o sistema mostra quando não tem) não entra.
function scriptJT(v, extras = {}) {
  let codigo = v.rastreio;
  if (extras.pedidoJuntoDoCodigo) codigo = `${v.rastreio} / ${v.pedido}`;
  else if (extras.rastreioCliente) codigo = `${v.rastreio} / ${v.rastreioCliente}`;
  const dados = [["Código de rastreio", codigo]];
  if (!extras.pedidoJuntoDoCodigo && v.pedido) dados.push([extras.rotuloPedido || "N° do pedido", v.pedido]);
  // lojaReal: a loja que a cliente conhece (vinda do JMS pelo raio), no lugar
  // de "intelipost", "APIJMS"… Sem ela, a Origem do sistema.
  dados.push(["Loja", extras.loja || (extras.lojaReal && v.loja) || v.origem], ["Produto", v.conteudo]);
  if (extras.nf) dados.push(["Nota fiscal", v.nf]);
  return montarScript(v, {
    apresentacao: extras.apresentacao || "responsável pela entrega do seu pedido",
    dados,
    opcoes: OPCOES_JT,
  });
}

// N° do pedido opcional (embarcadores fora do manual): mostra "(se tiver)".
const PEDIDO_OPCIONAL = { rotulo: "N° do pedido", exemplo: "Como está no sistema", obrigatorio: false };

// Cada embarcador: como reconhecer a Origem (já normalizada: sem acento,
// maiúsculas, só letras e números), quais campos extras pede e o texto.
// A ordem importa: os que exigem acareação física vêm primeiro.
// codigosJms: código da origem no JMS (orderSourceCode), mais estável que o
// nome. Vem pelo raio; nunca tira um pacote da regra "só física".
const EMBARCADORES = [
  { id: "arezzo", nome: "Arezzo", soFisica: true, reconhece: (n, tem) => tem("AREZZO") },
  { id: "zzab", nome: "ZZAB", soFisica: true, reconhece: (n, tem) => tem("ZZAB") },
  { id: "motorola", nome: "Motorola", soFisica: true, reconhece: (n, tem) => tem("MOTOROLA") },
  { id: "aguiar", nome: "M. Aguiar & Garcia", soFisica: true, reconhece: (n, tem) => tem("AGUIAR") && tem("GARCIA") },
  { id: "marlon", nome: "Marlon", soFisica: true, reconhece: (n, tem) => tem("MARLON") },
  {
    id: "mercadolivre",
    nome: "Mercado Livre",
    // "MERCADO" sozinho ou no começo ("MERCADO CBT"), ou as palavras MERCADO e
    // LIVRE inteiras em qualquer posição
    reconhece: (n, tem, palavras) => n === "MERCADO" || tem("MERCADOLIVRE") || (!!palavras && palavras[0] === "MERCADO"),
    codigosJms: ["D883", "D4125"], // MERCADO e MERCADO CBT
    pedido: { rotulo: "Código MELI", exemplo: "ID do Mercado Livre", obrigatorio: true },
    // Frases oficiais da Cartilha (apresentação "Me chamo … e sou da
    // Transportadora J&T Express, parceira de entregas do Mercado Livre" —
    // outra apresentação = extravio; produto, ID + código J&T e data/hora
    // iguais aos da baixa), no formato completo dos demais scripts.
    montar: (v) =>
      montarScript(v, {
        abertura: [
          `Olá, ${v.nome}! Tudo bem? ${SORRISO}`,
          "",
          `Me chamo *${v.seuNome}* e sou da *Transportadora J&T Express*, parceira de entregas do *Mercado Livre*.`,
          "",
          `Verificamos que você abriu uma reclamação referente ao produto *${v.conteudo}*, ID *${v.pedido}* / *${v.rastreio}*, entregue dia *${v.data}*.`,
        ],
        chamada: `Para que possamos auxiliar, escolha uma opção e responda apenas com o *número* ${DEDO}`,
        opcoes: OPCOES_ML,
      }),
  },
  {
    id: "viavarejo",
    nome: "Via Varejo",
    reconhece: (n, tem) => tem("VIAVAREJO"),
    pedido: { rotulo: "ID Via", exemplo: "ID do pedido", obrigatorio: true },
    nf: { dica: "" },
    montar: (v) =>
      montarScript(v, {
        apresentacao: "prestadora de serviços de transporte da *Via Varejo*",
        objetivo: "Gostaríamos de confirmar o recebimento. Seguem as informações:",
        dados: [
          ["Código de rastreio", v.rastreio],
          ["Pedido (ID Via)", v.pedido],
          ["Loja", "Via Varejo"],
          ["Produto", v.conteudo],
          ["Nota fiscal", v.nf],
        ],
        opcoes: OPCOES_JT,
      }),
  },
  {
    id: "tiktok",
    nome: "TikTok Shop",
    reconhece: (n, tem) => tem("TIKTOK"),
    codigosJms: ["D67"],
    pedido: { rotulo: "N° do pedido", exemplo: "Pedido do TikTok", obrigatorio: true },
    // Formato dos manuais (Tratativa TikTok + Manual de Scripts): um parágrafo
    // só, com o N° do pedido / remessa (código J&T 999…), o produto e a data e
    // hora da entrega (obrigatórios em toda acareação) e "responda apenas com o n°:".
    montar: (v) =>
      montarScript(v, {
        abertura: [
          `Olá, ${v.nome}! ${SORRISO}`,
          "",
          `Meu nome é *${v.seuNome}*, sou representante da transportadora *J&T Express*. Verificamos que você abriu uma reclamação referente ao pedido *${v.pedido}* / *${v.rastreio}*, referente ao produto *${v.conteudo}*, entregue dia *${v.data}*, realizado no *TikTok Shop*.`,
        ],
        chamada: "Para que possamos auxiliar, escolha uma das opções abaixo e responda apenas com o n°:",
        opcoes: OPCOES_TIKTOK,
      }),
  },
  {
    id: "shopee",
    nome: "Shopee",
    reconhece: (n, tem) => tem("SHOPEE"),
    pedido: { rotulo: "Código BR26", exemplo: "Começa com BR26", obrigatorio: true },
    montar: (v) => scriptJT(v, { pedidoJuntoDoCodigo: true }),
  },
  {
    id: "cainiao",
    nome: "Cainiao",
    reconhece: (n, tem) => tem("CAINIAO"),
    codigosJms: ["D882"], // Cainiao3PL (TEMU LM, D831, segue o padrão J&T)
    pedido: PEDIDO_OPCIONAL,
    rastreioCliente: { rotulo: "Código CNBR", exemplo: "Começa com CNBR" },
    montar: (v) => scriptJT(v, { rastreioCliente: true, lojaReal: true }),
  },
  {
    // Kwai não está no manual. O "Número de rastreamento do cliente" (KW...BR)
    // fica no mesmo campo do sistema que o CNBR da Cainiao, então segue a mesma
    // regra: vai junto do código J&T.
    id: "kwai",
    nome: "Kwai",
    reconhece: (n, tem) => tem("KWAI"),
    codigosJms: ["D170"],
    pedido: PEDIDO_OPCIONAL,
    rastreioCliente: { rotulo: "Código KW", exemplo: "Começa com KW" },
    montar: (v) =>
      scriptJT(v, { rastreioCliente: true, loja: "Kwai", apresentacao: "responsável pela entrega do seu pedido feito no *Kwai*" }),
  },
  {
    id: "infracommerce",
    nome: "Infracommerce",
    reconhece: (n, tem) => tem("INFRACOMMERCE"),
    pedido: { rotulo: "ID Infra", exemplo: "ID Infra do sistema", obrigatorio: true },
    nf: { dica: "(6 dígitos)" },
    motorola: true,
    montar: (v) => scriptJT(v, { rotuloPedido: "ID Infra", nf: true, lojaReal: true }),
  },
];

const EMBARCADOR_PADRAO = { id: "padrao", nome: "", pedido: PEDIDO_OPCIONAL, montar: (v) => scriptJT(v, { lojaReal: true }) };

const MOTOROLA = EMBARCADORES.find((e) => e.id === "motorola");

// ---------- Respostas depois que a cliente escolhe a opção ----------
const CAMERA = "\u{1F4F8}";

const PERGUNTA_LACRE = "O pacote estava *lacrado* ou apresentava *sinais de violação*?";
const RESPOSTAS = {
  recebi: () => ["Registramos que você *recebeu o produto*. A sua reclamação será encerrada.", "", "Se precisar de algo, é só chamar por aqui."],
  recebiLacrado: () => [
    "Registramos que você *recebeu o produto, corretamente lacrado e embalado*. A sua reclamação será encerrada.",
    "",
    "Se precisar de algo, é só chamar por aqui.",
  ],
  naoRecebi: () => [
    "Vamos verificar a entrega. Vou te enviar a *foto do comprovante de entrega*, com o local e quem recebeu.",
    "",
    "Por favor, responda:",
    "*1* – Você *reconhece o local* da foto?",
    "*2* – Conhece *quem recebeu*, ou alguém do endereço pode ter recebido?",
    "",
    "Com isso, conseguimos localizar o seu pedido o quanto antes.",
  ],
  faltante: () => [
    "Para verificarmos o ocorrido, poderia nos informar:",
    "*1* – Qual *produto está faltando*?",
    `*2* – ${PERGUNTA_LACRE}`,
    "",
    `${CAMERA} Envie *fotos do pacote e dos produtos recebidos*. As fotos são obrigatórias para a avaliação do caso.`,
  ],
  defeito: () => [
    "Para verificarmos o ocorrido, poderia nos informar:",
    "*1* – Qual *defeito* o produto apresenta?",
    `*2* – ${PERGUNTA_LACRE}`,
    "*3* – A embalagem estava *intacta* ou *danificada*? Era adequada para proteger o produto (fita *frágil*, plástico-bolha, isopor ou outra proteção interna)?",
    "",
    `${CAMERA} Envie *fotos do produto e da embalagem*. As fotos são necessárias para a avaliação do caso.`,
  ],
  danificado: () => [
    "Para verificarmos o ocorrido, poderia nos informar:",
    "*1* – Qual *dano* o produto apresenta?",
    `*2* – ${PERGUNTA_LACRE}`,
    "*3* – A embalagem estava *intacta* ou *danificada*? Tinha fita *frágil* e proteção interna (plástico-bolha, isopor, papelão)?",
    "",
    `${CAMERA} Envie *fotos do produto e da embalagem*. As fotos são necessárias para a avaliação do caso.`,
  ],
  embalagem: () => [
    "Para verificarmos o ocorrido, poderia nos informar:",
    "*1* – Como estava a *embalagem externa* (rasgada, amassada, molhada ou aberta)?",
    `*2* – ${PERGUNTA_LACRE}`,
    "*3* – O *produto* sofreu algum dano?",
    "",
    `${CAMERA} Envie *fotos da embalagem e do produto*. As fotos são necessárias para a avaliação do caso.`,
  ],
  diferente: () => [
    "Para verificarmos o ocorrido, poderia nos informar:",
    "*1* – Qual produto você *comprou* e qual *recebeu*?",
    `*2* – ${PERGUNTA_LACRE}`,
    "*3* – Você percebeu alguma *etiqueta duplicada* (uma colada sobre a outra) na embalagem?",
    "",
    `${CAMERA} Envie *fotos do produto recebido e da embalagem*. As fotos são necessárias para a avaliação do caso.`,
  ],
};

function opcoesDoEmbarcador(e) {
  if (e.id === "mercadolivre") return OPCOES_ML;
  if (e.id === "tiktok") return OPCOES_TIKTOK;
  return OPCOES_JT;
}

// Função pura: a mensagem de continuação para a opção escolhida
function montarResposta(v, opcao, e) {
  const corpo = (RESPOSTAS[opcao.resposta] || RESPOSTAS.recebi)();
  const ref = e.id === "mercadolivre" ? `${v.pedido} / ${v.rastreio}` : v.rastreio;
  return [
    `Obrigado pelo retorno, ${v.nome}! ${SORRISO}`,
    "",
    `Sobre o pedido *${ref}* (${v.conteudo}):`,
    "",
    ...corpo,
    "",
    "Atenciosamente,",
    `${v.seuNome} – J&T Express ${CAMINHAO}`,
  ].join("\n");
}

// Endereço incorreto: { rastreio, origem, conteudo } já limpos.
function textoEndereco({ rastreio, origem, conteudo }) {
  return `Olá!

Seguem as informações do seu pedido:

\u{1F4E6} Código do pacote: ${rastreio}
\u{1F3EA} Loja: ${origem}
\u{1F4E6} Produto: ${conteudo}

Verificamos que foi realizada uma tentativa de entrega no seu endereço, porém não foi possível concluir a entrega, pois o endereço se encontra incorreto.

Pedimos, por gentileza, que nos informe o endereço correto para prosseguirmos com a entrega.

Agradecemos pela compreensão.`;
}

// ---------- Scripts de ticket comum (resposta no próprio ticket) ----------
// "Orientação dos Tickets Comuns" (Qualidade e Atendimento MG + SPN): o script
// certo depende do ÚLTIMO BIPE da trajetória e da descrição do item
// problemático. {data} = "aguarde até" (DD/MM), escolhida na tela.
const SCRIPTS_TICKET = [
  {
    grupo: "Atraso e trânsito",
    itens: [
      {
        id: "rota",
        nome: "Em rota de entrega",
        quando: "Último bipe: saída para entrega.",
        texto: "Olá! Esperamos que esteja bem. A base responsável já está atuando para a finalização da entrega ser realizada o quanto antes. Pedimos, por gentileza, que aguarde até 3 dias úteis.",
      },
      {
        id: "agilizacao",
        nome: "Agilização (atraso em transferência)",
        quando: "Pacote em transferência e em atraso: informe a data limite.",
        texto: "Olá! Esperamos que esteja bem. Verificamos em nosso sistema que o seu pacote está em atraso. No momento, ele se encontra em transferência. A base responsável já está atuando para a finalização da entrega o quanto antes. Pedimos, por gentileza, que aguarde até {data}. Em caso de dúvidas, estamos à disposição.",
      },
      {
        id: "expedido",
        nome: "Expedido mas não chegou",
        quando: "Último bipe: expedido, mas não chegou. Já saiu do CD: informe a data limite.",
        texto: "Olá! Esperamos que esteja bem. Verificamos que o seu pedido já foi expedido, ou seja, já saiu do nosso centro de distribuição, mas ainda não chegou ao destino final. Já acionamos a transportadora para agilizar a entrega. Solicitamos que aguarde até {data}. Pedimos desculpas pela demora.",
      },
      {
        id: "triagem",
        nome: "Erro de triagem",
        quando: "Erro de triagem: normalização em até 10 dias, com prioridade na base de entrega.",
        texto: "Olá! Esperamos que esteja bem. Infelizmente, ocorreu um erro de triagem com este pacote, e a normalização deve ocorrer em até 10 dias. Assim que o pacote for recebido na base de entrega, solicitaremos total prioridade para o seu encaminhamento. Em caso de dúvidas, estamos à disposição.",
      },
    ],
  },
  {
    grupo: "Endereço e reentrega",
    itens: [
      {
        id: "ausencia",
        nome: "Reentrega – ausência do destinatário",
        quando: "Bipe de ausência do destinatário: nova tentativa com prioridade.",
        texto: "Olá! Esperamos que esteja bem. Seu pedido saiu para entrega, mas constou no sistema como “ausência do destinatário”. Já repassamos a informação à base responsável. Uma nova tentativa será feita com prioridade; pedimos que aguarde até {data}. Seguimos à disposição!",
      },
      {
        id: "reentregaEndereco",
        nome: "Reentrega – endereço incorreto (com complemento)",
        quando: "Endereço incorreto e o cliente deixou o endereço/complemento na descrição do item problemático.",
        texto: "Olá! Esperamos que esteja bem. Seu pedido saiu para entrega, mas constou no sistema como “endereço incorreto”. Já repassamos a informação à base responsável. Uma nova tentativa será feita com prioridade; pedimos que aguarde até {data}. Seguimos à disposição!",
      },
      {
        id: "confirmarEndereco",
        nome: "Endereço incorreto – confirmação de dados",
        quando: "Endereço incorreto SEM complemento na descrição do item problemático.",
        texto: "Olá! Esperamos que esteja bem. Seu pedido saiu para entrega, mas constou no sistema como “endereço incorreto”. Para agilizar a nova tentativa, poderia confirmar o endereço completo (número, complemento, ponto de referência e CEP)? Assim que confirmar, seguimos com o próximo passo. Agradecemos a atenção!",
      },
      {
        id: "alteracaoEndereco",
        nome: "Alteração de endereço",
        quando: "Pedido de troca de endereço: não alteramos depois da compra.",
        texto: "Olá! Esperamos que esteja bem. Conforme nossa política, não realizamos alterações no endereço de entrega após a finalização da compra. Caso não seja possível receber o pedido no endereço cadastrado, ele será devolvido. Agradecemos a compreensão e ficamos à disposição.",
      },
    ],
  },
  {
    grupo: "Interceptação e devolução",
    itens: [
      {
        id: "barrado",
        nome: "Pacote barrado / interceptado",
        quando: "Bipe de interceptação: devolução repassada à base, retorno em até 30 dias.",
        texto: "Olá! Esperamos que esteja bem. Conforme solicitado, o pacote está interceptado. Repassamos a solicitação para que a base possa solicitar a devolução do pacote. Prazo de retorno de 30 dias.",
      },
      {
        id: "devolucao",
        nome: "Devolução (em processo)",
        quando: "Pedido já segue em fluxo de devolução.",
        texto: "Olá! Esperamos que esteja bem. Conforme sistema, o pedido segue em fluxo de devolução. Em caso de dúvidas, estamos à disposição.",
      },
      {
        id: "devolucaoRota",
        nome: "Devolução – pedido em rota de entrega",
        quando: "Pediram barragem, mas o pedido já está em rota: o cliente final deve recusar.",
        texto: "Olá! Esperamos que esteja bem. O pedido está em rota de entrega, não sendo possível seguir com a barragem. Orientar o cliente final a recusar o pedido. Em caso de dúvidas, estamos à disposição.",
      },
      {
        id: "solicitarDevolucao",
        nome: "Solicitação de devolução",
        quando: "Pedido sem movimentação há mais de 10 dias.",
        texto: "Olá! Esperamos que esteja bem. Verificamos que o pedido está sem movimentação há mais de 10 dias. Podemos realizar a intercalação para retorno à origem, caso tenha interesse. Pedimos que nos informe sua decisão o quanto antes para darmos andamento dentro do prazo operacional.",
      },
    ],
  },
  {
    grupo: "Buscas, recusa e ressarcimento",
    itens: [
      {
        id: "buscas",
        nome: "Buscas",
        quando: "Suspeita de extravio, ou pacote de outra base sem bipe de “assinatura de encomenda”: até 5 dias úteis.",
        texto: "Olá! Esperamos que esteja bem. Solicitamos as buscas e pedimos, por gentileza, que aguarde o prazo de até 5 dias úteis para a tratativa. Em caso de dúvidas, estamos à disposição.",
      },
      {
        id: "recusado",
        nome: "Pacote recusado",
        quando: "Bipe de recusa pelo destinatário: pedir confirmação da informação.",
        texto: "Olá! Esperamos que esteja bem. Prezados, tentativa de entrega realizada, pedido recusado pelo destinatário. Poderiam confirmar essa informação? Em caso de dúvidas, estamos à disposição.",
      },
      {
        id: "acareacaoEntregue",
        nome: "Acareação – pedido entregue",
        quando: "Cliente confirmou o recebimento na acareação: anexe o comprovante.",
        texto: "Olá! Esperamos que esteja bem. Após análise de acareação junto à base responsável, o cliente confirmou o recebimento do pacote. Segue em anexo o comprovante da acareação. Em caso de dúvidas, estamos à disposição.",
      },
      {
        id: "extravio",
        nome: "Extravio",
        quando: "Extravio identificado: segue para ressarcimento.",
        texto: "Olá! Após uma análise interna, foi identificado o extravio desse pacote; seguiremos com o ressarcimento. Pedimos, por gentileza, que atenda o cliente com o reembolso, e lamentamos pelo ocorrido. Em caso de dúvidas, estamos à disposição.",
      },
      {
        id: "avaria",
        nome: "Avaria",
        quando: "Avaria: vai para o time de Ressarcimento (relação semanal).",
        texto: "Olá! Esperamos que esteja bem. Identificamos que o pedido apresentou avaria e, conforme procedimento interno, deve ser direcionado ao time de Ressarcimento para análise. Solicitamos que seja incluído na relação semanal do time responsável, que confirmará a procedência da indenização.",
      },
    ],
  },
];
