// painel-jms.js
// Painel ⚡ dentro do JMS (content script). Só aparece com "Painel no JMS"
// ligado no popup e com a extensão liberada (kill switch).
// - As consultas vão pelo background.js, uma por vez: o painel só diz o tipo
//   e o código; o token nunca passa por aqui. O bloqueio do JMS é o mesmo do
//   Lote e do raio.
// - Telas montadas só com nós e textContent (nada de innerHTML), dentro de um
//   shadow DOM fechado (o CSS do JMS não interfere).
// - Guardado na origem do JMS (igual ao script original): histórico no
//   IndexedDB "jmsAuto" (30 dias) e listas/nomes no localStorage "jmsAuto.*".
//   Telefone e endereço da cliente (Cobrar) ficam só na tela.

(() => {
  if (window.__jtPainelCarregado) return;
  window.__jtPainelCarregado = true;

  const R = PainelRegras;
  const CFG = R.CFG;
  const FALHA = Symbol("falha"); // código que não foi consultado (erro/bloqueio)

  class ErroPainel extends Error {}
  class Parado extends Error {}

  // ===================== Tela: helper de nós =====================
  function el(tag, props, ...filhos) {
    const e = document.createElement(tag);
    if (props) {
      for (const [k, v] of Object.entries(props)) {
        if (v == null || v === false) continue;
        if (k === "class") e.className = v;
        else if (k === "text") e.textContent = v;
        else if (k === "on") Object.entries(v).forEach(([ev, fn]) => e.addEventListener(ev, fn));
        else if (k === "style") e.style.cssText = v;
        else if (k in e && typeof e[k] !== "function" && !k.startsWith("aria") && !k.startsWith("data")) e[k] = v;
        else e.setAttribute(k, v === true ? "" : String(v));
      }
    }
    for (const f of filhos.flat(Infinity)) {
      if (f == null || f === false) continue;
      e.append(f instanceof Node ? f : String(f));
    }
    return e;
  }
  const tabela = (cab, linhas) =>
    el(
      "div",
      { class: "tabela" },
      el("table", null, cab ? el("thead", null, el("tr", null, cab.map((c) => el("th", { text: c })))) : null, el("tbody", null, linhas.map((l) => el("tr", null, l.map((c) => el("td", null, c))))))
    );
  const fita = (...filhos) => el("div", { class: "fita" }, ...filhos);
  // Troca o conteúdo (aceita listas aninhadas e ignora vazios)
  const encher = (nodo, ...filhos) => nodo.replaceChildren(...filhos.flat(Infinity).filter((f) => f != null && f !== false));

  // ===================== Guardado na origem do JMS =====================
  const salvo = (k, v) => {
    try {
      if (v === undefined) return JSON.parse(localStorage.getItem("jmsAuto." + k) || "null");
      localStorage.setItem("jmsAuto." + k, JSON.stringify(v));
    } catch (e) {
      return null;
    }
    return v;
  };

  const DB = (() => {
    let dbp;
    const abrir = () =>
      dbp ||
      (dbp = new Promise((res, rej) => {
        const q = indexedDB.open("jmsAuto", 1);
        q.onupgradeneeded = () => {
          const s = q.result.createObjectStore("consultas", { autoIncrement: true });
          s.createIndex("code", "code");
          s.createIndex("em", "em");
        };
        q.onsuccess = () => res(q.result);
        q.onerror = () => rej(q.error);
      }));
    const tx = async (modo, fn) => {
      const db = await abrir();
      return new Promise((res, rej) => {
        const t = db.transaction("consultas", modo);
        const r = fn(t.objectStore("consultas"));
        t.oncomplete = () => res(r && r.result);
        t.onerror = () => rej(t.error);
      });
    };
    return {
      add: (rec) => tx("readwrite", (s) => s.add(rec)),
      ultima: (code) => tx("readonly", (s) => s.index("code").getAll(code)).then((a) => (a || []).sort((x, y) => y.em - x.em)[0]),
      desde: (ms) => tx("readonly", (s) => s.index("em").getAll(IDBKeyRange.lowerBound(ms))),
      limpar: () => tx("readwrite", (s) => s.clear()),
      // apaga o que passou do prazo do histórico
      podar: (antesDe) =>
        tx("readwrite", (s) => {
          const q = s.index("em").openCursor(IDBKeyRange.upperBound(antesDe, true));
          q.onsuccess = () => {
            const c = q.result;
            if (c) {
              c.delete();
              c.continue();
            }
          };
        }),
    };
  })();
  const podarHistorico = () => DB.podar(Date.now() - CFG.historicoDias * 864e5).catch(() => {});

  // ===================== Consultas (pelo background) =====================
  const dormir = (ms) => new Promise((r) => setTimeout(r, ms));
  let ctl = null; // { parado } da consulta em andamento
  let progresso = "";

  async function esperarAte(ate, rotulo) {
    while (Date.now() < ate) {
      if (ctl && ctl.parado) throw new Parado();
      const s = Math.ceil((ate - Date.now()) / 1000);
      status(`${progresso ? progresso + " · " : ""}${rotulo} ${s} s…`, true);
      await dormir(Math.min(1000, ate - Date.now()));
    }
    status(progresso);
  }

  async function pedir(msg) {
    if (!chrome.runtime || !chrome.runtime.id) throw new ErroPainel("A extensão foi atualizada. Atualize a página do JMS (F5) para usar o painel.");
    try {
      const r = await chrome.runtime.sendMessage(msg);
      return r && typeof r === "object" ? r : { ok: false, suspeito: true };
    } catch (e) {
      if (!chrome.runtime || !chrome.runtime.id) throw new ErroPainel("A extensão foi atualizada. Atualize a página do JMS (F5) para usar o painel.");
      return { ok: false, suspeito: true };
    }
  }

  // Uma consulta. Bloqueio: espera e tenta o MESMO código (não gasta tentativa).
  // Resposta estranha: espera e tenta de novo; depois disso = FALHA (não consultado).
  async function consultar(tipo, codigo) {
    const inicio = Date.now();
    let suspeitas = 0;
    for (;;) {
      if (ctl && ctl.parado) throw new Parado();
      const r = await pedir({ acao: "painel", tipo, codigo });
      if (r.ok) return r.data;
      if (r.limite) {
        if (Date.now() - inicio > EXP_CFG.limiteTetoMs) return FALHA;
        await esperarAte(Number(r.ate) || Date.now() + EXP_CFG.sondaMs, "O JMS bloqueou (limite de consultas). Tentando de novo em");
        continue;
      }
      if (r.suspeito) {
        if (++suspeitas > EXP_CFG.suspeitasMax) return FALHA;
        const esp = EXP_CFG.esperasSuspeitaMs;
        await esperarAte(Date.now() + esp[Math.min(suspeitas - 1, esp.length - 1)], "Resposta estranha do sistema. Tentando de novo em");
        continue;
      }
      if (r.erro && r.erro.tipo !== "invalido") throw new ErroPainel(r.erro.mensagem || "Não foi possível consultar no JMS.");
      return FALHA;
    }
  }

  const pausaEntre = () => dormir(EXP_CFG.pausaMinMs + Math.random() * (EXP_CFG.pausaMaxMs - EXP_CFG.pausaMinMs));

  // Rastreia 1 código (usa o histórico recente); salva no histórico. null = não consultado.
  async function rastrear(code, origem, forcar = false) {
    if (!forcar) {
      const u = await DB.ultima(code).catch(() => null);
      if (u && u.v === 2 && Date.now() - u.em < CFG.cacheMin * 60000) return u.det;
    }
    const data = await consultar("rastreio", code);
    await pausaEntre();
    if (data === FALHA) return null;
    const det = R.normalizar(data);
    await DB.add({ code, em: Date.now(), origem, det, v: 2 }).catch(() => {});
    return det;
  }
  async function rastrearLista(lista, origem, rotulo, forcar = false) {
    const out = {};
    for (let i = 0; i < lista.length; i++) {
      progresso = `${rotulo}: ${i + 1}/${lista.length}`;
      status(progresso);
      out[lista[i]] = await rastrear(lista[i], origem, forcar);
    }
    progresso = "";
    return out;
  }
  async function cliente(code) {
    const p = await consultar("cliente", code);
    if (p === FALHA || !p) return { nome: "", tel: "", end: "" };
    await pausaEntre();
    let d = await consultar("detalhe", code);
    if (d === FALHA) d = null;
    await pausaEntre();
    return { nome: String(p.receiverName || "").trim(), tel: String(p.receiverMobilePhone || "").trim(), end: R.endereco(p.receiverFullAddress || "", d) };
  }

  // ===================== Montagem =====================
  let host = null;
  let raiz = null;
  let painel = null;
  let corpo = null;
  let abaAtual = 0;
  let ocupado = false;

  function aplicarTema(tema) {
    if (!painel) return;
    let t = tema;
    if (t !== "dark" && t !== "light") t = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
    host.setAttribute("data-theme", t);
  }

  function carregarFonte() {
    try {
      if ([...document.fonts].some((f) => f.family === "JT Archivo")) return;
      const f = new FontFace("JT Archivo", `url("${chrome.runtime.getURL("fonts/archivo-latin-wdth-wght.woff2")}") format("woff2")`, { weight: "100 900", stretch: "62% 125%" });
      document.fonts.add(f);
      f.load().catch(() => {});
    } catch (e) {
      /* sem a fonte: usa a do sistema */
    }
  }

  const ABAS = [
    ["Recebimento", abaRecebimento],
    ["Planilhas", abaPlanilhas],
    ["Rastreio", abaRastreio],
    ["Cobrar", abaCobrar],
    ["Histórico", abaHistorico],
  ];

  function montar() {
    if (host) return;
    carregarFonte();
    host = el("div", { id: "jt-painel-host" });
    raiz = host.attachShadow({ mode: "closed" });
    const css = el("link", { rel: "stylesheet", href: chrome.runtime.getURL("painel-jms.css") });
    const fab = el("button", { class: "fab", type: "button", title: "Automações JMS (J&T Respostas Rápidas)", "aria-label": "Automações JMS", on: { click: alternar } }, iconeRaio());
    const nav = el(
      "nav",
      { class: "abas", role: "tablist" },
      ABAS.map(([nome], i) => el("button", { type: "button", class: "aba", role: "tab", "data-i": i, text: nome, on: { click: () => trocarAba(i) } }))
    );
    corpo = el("div", { class: "corpo" });
    painel = el(
      "section",
      { class: "painel", "aria-label": "Automações JMS" },
      el("header", { class: "topo" }, el("span", { class: "marca" }, iconeRaio(), ` Automações JMS – ${CFG.base}`), el("button", { type: "button", class: "fechar", "aria-label": "Fechar", text: "✕", on: { click: alternar } })),
      nav,
      corpo
    );
    raiz.append(css, fab, painel);
    document.documentElement.append(host);
    chrome.storage.local.get("tema", (r) => aplicarTema(r && r.tema));
    podarHistorico();
    const salva = Number(salvo("aba"));
    trocarAba(Number.isInteger(salva) && salva >= 0 && salva < ABAS.length ? salva : 0);
  }

  function desmontar() {
    if (ctl) ctl.parado = true;
    if (host) host.remove();
    host = raiz = painel = corpo = null;
    ocupado = false;
  }

  function iconeRaio() {
    const ns = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(ns, "svg");
    svg.setAttribute("viewBox", "0 0 20 20");
    svg.setAttribute("aria-hidden", "true");
    const p = document.createElementNS(ns, "path");
    p.setAttribute("d", "M11.2 1.8 4.2 11.2h5l-1 7 7-9.4h-5l1-7Z");
    svg.append(p);
    return svg;
  }

  const alternar = () => painel && painel.classList.toggle("aberto");

  function trocarAba(i) {
    if (ocupado) return toast("Espere a consulta terminar (ou clique em Parar)");
    abaAtual = i;
    salvo("aba", i);
    raiz.querySelectorAll(".aba").forEach((b, j) => {
      b.classList.toggle("ativa", j === i);
      b.setAttribute("aria-selected", j === i ? "true" : "false");
    });
    corpo.replaceChildren();
    ABAS[i][1]();
  }

  // ===================== Peças comuns =====================
  function toast(m) {
    if (!raiz) return;
    const t = el("div", { class: "toast", text: m });
    raiz.append(t);
    setTimeout(() => t.remove(), 1600);
  }
  async function copiar(txt) {
    try {
      await navigator.clipboard.writeText(txt);
    } catch (e) {
      const ta = el("textarea", { value: txt });
      raiz.append(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
    toast("Copiado!");
  }
  function status(m, espera = false) {
    const e = corpo && corpo.querySelector(".status");
    if (!e) return;
    e.textContent = m || "";
    e.classList.toggle("espera", !!espera);
  }
  const botao = (texto, fn, classe = "bt") => el("button", { type: "button", class: classe, text: texto, on: { click: fn } });
  const linhaBotoes = (...b) => el("div", { class: "botoes" }, ...b);
  const blocoStatus = () => [el("div", { class: "status", "aria-live": "polite" }), botao("Parar", () => ctl && (ctl.parado = true), "bt parar")];

  async function rodar(fn) {
    if (ocupado) return toast("Já tem uma consulta rodando");
    ocupado = true;
    ctl = { parado: false };
    const meu = ctl;
    corpo.classList.add("rodando");
    try {
      await fn();
    } catch (e) {
      progresso = "";
      if (e instanceof Parado) status("Consulta parada.");
      else status(e instanceof ErroPainel ? e.message : "Erro: " + (e && e.message ? e.message : "inesperado"));
    }
    if (ctl === meu) ctl = null;
    ocupado = false;
    if (corpo) corpo.classList.remove("rodando");
  }
  const saida = () => corpo.querySelector(".saida");
  const listaMono = (itens) => el("pre", { class: "mono", text: itens.join("\n") || "Nenhum" });

  // ===================== Recebimento (mandaram para nós e não chegou) =====================
  function abaRecebimento() {
    const ta = el("textarea", { class: "mono", placeholder: "(opcional) cole os códigos aqui", spellcheck: false });
    corpo.append(
      el(
        "p",
        null,
        "Pacotes que vieram ",
        el("b", { text: `carregados da ${CFG.origemExpedido} para a ${CFG.base}` }),
        " e não chegaram. Abra ",
        el("b", { text: "Monitoramento de tipagem de recebimento (novo)" }),
        ", filtre e clique em Ler tela. Ou cole os códigos."
      ),
      fita(el("b", { text: "Atenção: " }), "nesses pacotes é preciso bipar ", el("b", { text: "expedido não chegou" }), ". Se não bipar, a base paga os pacotes. Cada código é consultado 2 vezes."),
      ta,
      linhaBotoes(botao("Ler tela e conferir", () => rodar(() => recebimentoConferir(ta))), botao("Conferir bipes (depois de bipar)", () => rodar(() => recebimentoBipes(ta)), "bt s")),
      ...blocoStatus(),
      el("div", { class: "saida" })
    );
  }

  async function recebimentoConferir(ta) {
    let todos = R.codigos(ta.value);
    let br = 0;
    let estranhos = [];
    let lidos = 0;
    if (!todos.length) {
      status("Lendo a tela (pode levar alguns segundos)…");
      const r = await pedir({ acao: "painelLerTela" });
      if (!r.ok) return status(r.mensagem || "Não achei a tabela.");
      const tela = r.codigos || [];
      lidos = Number(r.lidos) || tela.length;
      // Nunca segue com a lista incompleta: pacote fora da lista = base paga
      if (r.total && lidos < r.total) return status(`Só consegui ler ${lidos} de ${r.total} registros da tela. Coloque 100 por página no JMS e clique de novo.`);
      br = tela.filter((c) => /^BR/i.test(c)).length;
      const pacotes = tela.filter((c) => !/^BR/i.test(c));
      todos = pacotes.filter((c) => /^(?:888|999)\d{12}$/.test(c));
      estranhos = pacotes.filter((c) => !/^(?:888|999)\d{12}$/.test(c));
      status(`Li ${lidos} registros da tela (${br} sacas BR, ${pacotes.length} pacotes)`);
    }
    if (!todos.length && !estranhos.length) return status("Nenhum código encontrado.");
    const r1 = await rastrearLista(todos, "Expedido não chegou", "1ª conferência", true);
    const r2 = await rastrearLista(todos, "Expedido não chegou (2ª)", "2ª conferência", true);
    const c = R.conferirRecebimento(todos, r1, r2);
    salvo("expedido", { em: Date.now(), entra: c.entra });
    status(`${lidos ? `${lidos} registros lidos · ${br} sacas BR ignoradas · ` : ""}${todos.length} pacotes conferidos 2×`);
    encher(saida(), 
      el("h4", { class: c.entra.length ? "destaque" : "ok", text: `Bipar expedido não chegou: ${c.entra.length}` }),
      listaMono(c.entra),
      c.entra.length ? botao("Copiar códigos", () => copiar(c.entra.join("\n"))) : null,
      c.duvida.length ? fita(el("b", { text: `${c.duvida.length} mudaram entre as conferências: confira à mão no JMS.` }), listaMono(c.duvida)) : null,
      c.naoConsultados.length ? fita(el("b", { text: `${c.naoConsultados.length} não foram consultados (erro ou bloqueio): rode de novo antes de bipar.` }), listaMono(c.naoConsultados)) : null,
      estranhos.length ? fita(el("b", { text: `${estranhos.length} com formato que não reconheci: confira à mão.` }), listaMono(estranhos)) : null,
      el("h4", { text: `Não entram (${c.fora.length})` }),
      tabela(null, c.fora.map((x) => [x, R.descreverUltimo(r2[x])]))
    );
  }

  async function recebimentoBipes(ta) {
    const s = salvo("expedido");
    const coladas = R.codigos(ta.value);
    const lista = coladas.length ? coladas : (s && Array.isArray(s.entra) && s.entra) || [];
    if (!lista.length) return status("Nada para conferir: rode Ler tela e conferir antes, ou cole os códigos.");
    const r = await rastrearLista(lista, "Conferência expedido", "Conferindo", true);
    const linhas = lista.map((c) => {
      const det = r[c];
      if (!det) return [c, "⚠", "não consultado (erro ou bloqueio): confira de novo"];
      const l = det[det.length - 1];
      return [c, R.bipeCerto(det) ? "✅" : "❌", l ? `${R.dmh(l.t)} ${l.tipo} ${l.motivo} – ${l.por}` : "SEM DADOS"];
    });
    const ok = linhas.filter((x) => x[1] === "✅").length;
    status("");
    encher(saida(), 
      el("h4", { class: ok === lista.length ? "ok" : "destaque", text: `${ok}/${lista.length} com o bipe certo` }),
      ok === lista.length ? null : fita(el("b", { text: `Faltam ${lista.length - ok}: ` }), "bipe expedido não chegou nesses antes de fechar o dia."),
      tabela(null, linhas)
    );
  }

  // ===================== Leitor de Excel (.xlsx) sem biblioteca =====================
  // .xlsx = ZIP com XMLs dentro: lê o índice do ZIP na mão e descompacta com
  // DecompressionStream (nativo). O XML é só lido (DOMParser), nunca vira tela.
  async function lerZip(buf) {
    const dv = new DataView(buf);
    const u8 = new Uint8Array(buf);
    const dec = new TextDecoder();
    let eocd = -1;
    for (let i = buf.byteLength - 22; i >= Math.max(0, buf.byteLength - 70000); i--)
      if (dv.getUint32(i, true) === 0x06054b50) {
        eocd = i;
        break;
      }
    if (eocd < 0) throw new Error("Arquivo não é .xlsx válido");
    const n = dv.getUint16(eocd + 10, true);
    let p = dv.getUint32(eocd + 16, true);
    const arquivos = {};
    for (let k = 0; k < n; k++) {
      const metodo = dv.getUint16(p + 10, true);
      const tam = dv.getUint32(p + 20, true);
      const lenNome = dv.getUint16(p + 28, true);
      const lenExtra = dv.getUint16(p + 30, true);
      const lenCom = dv.getUint16(p + 32, true);
      const off = dv.getUint32(p + 42, true);
      const nome = dec.decode(u8.subarray(p + 46, p + 46 + lenNome));
      arquivos[nome] = { metodo, tam, off };
      p += 46 + lenNome + lenExtra + lenCom;
    }
    return async (nome) => {
      const a = arquivos[nome];
      if (!a) return null;
      const ini = a.off + 30 + dv.getUint16(a.off + 26, true) + dv.getUint16(a.off + 28, true);
      const dados = u8.slice(ini, ini + a.tam);
      if (a.metodo === 0) return dec.decode(dados);
      const s = new Blob([dados]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
      return await new Response(s).text();
    };
  }
  // Os arquivos do Feishu usam prefixo (<x:row>), têm BOM e não têm "r" nas
  // células: por isso getElementsByTagNameNS('*') e colunas em sequência.
  // NÃO trocar por getElementsByTagName('row') (não acha nada no Feishu).
  async function lerXlsx(buf) {
    const abrir = await lerZip(buf);
    const xml = (s) => new DOMParser().parseFromString(s, "application/xml");
    const tags = (e, tag) => [...e.getElementsByTagNameNS("*", tag)];
    const tagTxt = (e, tag) => tags(e, tag).map((t) => t.textContent).join("");
    const ss = await abrir("xl/sharedStrings.xml");
    const strings = ss ? tags(xml(ss), "si").map((si) => tagTxt(si, "t")) : [];
    let sheet = await abrir("xl/worksheets/sheet1.xml");
    if (!sheet) for (let i = 2; i < 10 && !sheet; i++) sheet = await abrir(`xl/worksheets/sheet${i}.xml`);
    if (!sheet) throw new Error("Não achei a planilha dentro do arquivo");
    const linhas = [];
    for (const row of tags(xml(sheet.replace(/^﻿/, "")), "row")) {
      const r = [];
      let seq = 0;
      for (const c of tags(row, "c")) {
        const t = c.getAttribute("t");
        const v = tags(c, "v")[0];
        let val = t === "s" ? strings[+(v && v.textContent)] : t === "inlineStr" ? tagTxt(c, "t") : v ? v.textContent : "";
        if (/^\d(\.\d+)?E\+\d+$/i.test(val || "")) val = Number(val).toFixed(0); // 9.99882713626169E+14
        const ref = c.getAttribute("r");
        const ci = ref ? R.colIdx(ref) : seq;
        seq = ci + 1;
        r[ci] = val ?? "";
      }
      linhas.push(Array.from(r, (x) => x ?? ""));
    }
    return linhas;
  }

  // ===================== Planilhas (Tentativas + nós enviamos e não chegou) =====================
  function abaPlanilhas() {
    const ant = salvo("tentativas");
    const ta = el("textarea", { class: "mono", placeholder: "(ou) cole o conteúdo das planilhas", spellcheck: false });
    const arqStatus = el("span", { class: "nota" });
    const doArquivo = { codigos: [] };
    const arq = el("input", {
      type: "file",
      multiple: true,
      accept: ".xlsx,.csv",
      on: {
        change: async (e) => {
          doArquivo.codigos = [];
          const info = [];
          for (const f of e.target.files) {
            try {
              if (/\.xls$/i.test(f.name)) {
                info.push(`${f.name}: formato .xls antigo – salve como .xlsx`);
                continue;
              }
              const linhas = /\.csv$/i.test(f.name) ? R.lerCsv(await f.text()) : await lerXlsx(await f.arrayBuffer());
              const cs = R.codigosDasLinhas(linhas);
              doArquivo.codigos.push(...cs);
              info.push(`${f.name}: ${linhas.length - 1} linhas, ${cs.length} da ${CFG.base}`);
            } catch (err) {
              info.push(`${f.name}: erro – ${err && err.message ? err.message : "não consegui ler"}`);
            }
          }
          doArquivo.codigos = [...new Set(doArquivo.codigos)];
          arqStatus.textContent = info.join(" · ") + ` → ${doArquivo.codigos.length} códigos`;
        },
      },
    });
    corpo.append(
      el("p", null, el("b", { text: "Escolha os arquivos RETIDOS e SEM MOV" }), ` (.xlsx, pode escolher os dois juntos), ou cole o conteúdo abaixo. Só entram as linhas da ${CFG.base}. Os códigos da última rodada que ainda não saíram também entram.`),
      el("div", { class: "arquivos" }, arq, arqStatus),
      ta,
      linhaBotoes(
        botao("Consultar e classificar", () => rodar(() => planilhasConsultar(ta, ant, doArquivo.codigos))),
        ant && Array.isArray(ant.codes) ? el("span", { class: "nota", text: `última: ${new Date(ant.em).toLocaleString("pt-BR")} (${ant.codes.length} códigos)` }) : null
      ),
      ...blocoStatus(),
      el("div", { class: "saida" })
    );
  }

  async function planilhasConsultar(ta, ant, doArquivo = []) {
    const hoje = [...new Set([...doArquivo, ...R.lerBacklog(ta.value)])];
    const antigos = ant && Array.isArray(ant.codes) ? ant.codes.filter((c) => !hoje.includes(c)) : [];
    const lista = [...hoje, ...antigos];
    if (!lista.length) return status("Nenhum código encontrado.");
    const res = await rastrearLista(lista, "Tentativas (backlog)", "Consultando", false);
    const naoConsultados = lista.filter((c) => !res[c]);
    const consultados = lista.filter((c) => res[c]);
    const rows = consultados.map((c) => R.classificar(c, res[c]));
    const ativos = R.ordenarAtivos(rows.filter((r) => r.sec !== "X"));
    const sairam = rows.filter((r) => r.sec === "X");
    const expedidos = consultados
      .map((c) => {
        const u = R.nosEnviamos(res[c]);
        return u ? { code: c, base: u.base, t: u.t, por: u.por } : null;
      })
      .filter(Boolean);
    // Os não consultados continuam na próxima rodada (nunca "saem da lista" por erro)
    salvo("tentativas", { em: Date.now(), codes: [...ativos.map((r) => r.code), ...naoConsultados] });
    salvo("cobrar", ativos.filter((r) => r.cobrar).map((r) => r.code));
    const resumo = R.resumoTentativas(ativos);
    const bloco = R.blocoClaude(ativos, sairam, resumo);
    const tsv = R.tsvPlanilha(ativos, resumo);
    status("");
    const nCobrar = ativos.filter((r) => r.cobrar).length;
    encher(saida(), 
      el("h4", { class: expedidos.length ? "destaque" : "ok", text: `Deram expedido não chegou (nós enviamos): ${expedidos.length}` }),
      expedidos.length
        ? [tabela(["Código", "Base que marcou", "Quando", "Quem"], expedidos.map((x) => [x.code, x.base, R.dmh(x.t), x.por])), botao("Copiar códigos", () => copiar(expedidos.map((x) => x.code).join("\n")), "bt s")]
        : null,
      naoConsultados.length ? fita(el("b", { text: `${naoConsultados.length} não foram consultados (erro ou bloqueio): ficam para a próxima rodada.` }), listaMono(naoConsultados)) : null,
      el("div", { class: "msg", text: resumo }),
      linhaBotoes(
        botao("Copiar para a planilha", () => copiar(tsv)),
        el("span", { class: "nota" }, "→ na aba Tentativas, clique na célula ", el("b", { text: "A2" }), " e Ctrl+V")
      ),
      linhaBotoes(
        botao("Copiar para o Claude", () => copiar(bloco), "bt s"),
        botao(`Ir para Cobrar (${nCobrar})`, () => trocarAba(3), "bt s")
      ),
      R.ordemSecoes.split("").map((k) => {
        const g = ativos.filter((r) => r.sec === k);
        if (!g.length) return null;
        return [
          el("h4", { class: `sec sec-${k}`, text: `${R.SEC[k]} (${g.length})` }),
          tabela(
            ["Código", "Entregador", "Tratativas", "Último", "O que aconteceu", "Dias", "Obs"],
            g.map((r) => [r.code, R.semF(r.entregador), r.trat, r.ultimo, r.oque, r.dias, r.obs])
          ),
        ];
      }),
      el("h4", { class: "apagado", text: `Saíram da lista (${sairam.length})` }),
      tabela(null, sairam.map((r) => [r.code, r.oque]))
    );
  }

  // ===================== Rastreio em lote =====================
  function abaRastreio() {
    const ta = el("textarea", { class: "mono", placeholder: "999..., 888...", spellcheck: false });
    const forcar = el("input", { type: "checkbox" });
    corpo.append(
      el("p", { text: "Cole os códigos (qualquer formato). Consulta respeitando o limite do JMS e salva no histórico." }),
      ta,
      linhaBotoes(botao("Rastrear", () => rodar(() => rastreioLote(ta, forcar.checked))), el("label", { class: "nota" }, forcar, " ignorar histórico recente")),
      ...blocoStatus(),
      el("div", { class: "saida" })
    );
  }

  async function rastreioLote(ta, forcar) {
    const lista = R.codigos(ta.value);
    if (!lista.length) return status("Nenhum código 999/888 encontrado.");
    const res = await rastrearLista(lista, "Rastreio em lote", "Rastreando", forcar);
    const linhas = lista.map((c) => {
      const d = res[c];
      if (!d) return [c, "", "NÃO CONSULTADO (erro ou bloqueio)", "", "", ""];
      const l = d[d.length - 1];
      if (!l) return [c, "", "SEM DADOS", "", "", ""];
      return [c, R.dmh(l.t), l.tipo + (l.exp ? " (expedido não chegou)" : ""), l.base, l.staff || l.por, l.motivo];
    });
    const tsv = linhas.map((r) => r.join("\t")).join("\n");
    status(`${lista.length} códigos`);
    encher(saida(), botao("Copiar resultado", () => copiar(tsv), "bt s"), tabela(["Código", "Último bipe", "Tipo", "Base", "Quem", "Motivo"], linhas));
  }

  // ===================== Cobrar entregadores =====================
  function abaCobrar() {
    const ult = salvo("cobrar") || [];
    const ta = el("textarea", { class: "mono", placeholder: "999..., 888...", spellcheck: false, value: Array.isArray(ult) ? ult.join("\n") : "" });
    const nomes = el("textarea", { class: "mono nomes", spellcheck: false, placeholder: "NOME NO JMS = como chamar\n(uma pessoa por linha)", value: R.textoNomes(salvo("nomes") || {}) });
    corpo.append(
      el("p", { text: `Cole os códigos para cobrar, ou use os que a aba Planilhas marcou como cobrar (${Array.isArray(ult) ? ult.length : 0}). Monta a mensagem com tratativas e dados da cliente.` }),
      ta,
      linhaBotoes(botao("Montar mensagens", () => rodar(() => cobrarMontar(ta)))),
      el(
        "details",
        { class: "nomes-box" },
        el("summary", { text: "Nomes dos entregadores" }),
        el("p", { class: "nota", text: "Como chamar cada entregador na mensagem. Fica só neste navegador. Sem nome aqui, vai o primeiro nome do JMS." }),
        nomes,
        botao(
          "Salvar nomes",
          () => {
            salvo("nomes", R.lerNomes(nomes.value));
            nomes.value = R.textoNomes(salvo("nomes") || {});
            toast("Nomes salvos");
          },
          "bt s"
        )
      ),
      ...blocoStatus(),
      el("div", { class: "saida" })
    );
  }

  async function cobrarMontar(ta) {
    const lista = R.codigos(ta.value);
    if (!lista.length) return status("Nenhum código.");
    const res = await rastrearLista(lista, "Cobrar entregadores", "Rastreando", true);
    const { grupos, resolvidos, naoConsultados } = R.gruposCobrar(lista, res);
    const tot = Object.values(grupos).flat().length;
    let i = 0;
    for (const g of Object.values(grupos))
      for (const p of g) {
        progresso = `Dados da cliente ${++i}/${tot}`;
        status(progresso);
        p.cli = await cliente(p.c);
      }
    progresso = "";
    const nomes = salvo("nomes") || {};
    const msgs = Object.entries(grupos).map(([staff, g]) => [staff, R.montarMsg(staff, g, nomes)]);
    status(`${msgs.length} mensagens prontas`);
    encher(saida(), 
      msgs.map(([s, m]) => [el("h4", { text: R.semF(s) || "(sem entregador)" }), el("div", { class: "msg", text: m }), botao("Copiar", () => copiar(m))]),
      naoConsultados.length ? fita(el("b", { text: `${naoConsultados.length} não foram consultados (erro ou bloqueio):` }), listaMono(naoConsultados)) : null,
      resolvidos.length ? [el("h4", { class: "apagado", text: `Não precisa cobrar (${resolvidos.length})` }), tabela(null, resolvidos)] : null
    );
  }

  // ===================== Histórico =====================
  function abaHistorico() {
    corpo.append(
      el(
        "p",
        null,
        "Tudo que foi consultado fica salvo aqui no navegador por ",
        el("b", { text: `${CFG.historicoDias} dias` }),
        ". Copie e cole direto na planilha ",
        el("b", { text: "Rastreios JMS – histórico salvo" }),
        " (na primeira linha vazia da coluna A)."
      ),
      linhaBotoes(
        botao("Copiar de hoje", async () => {
          const d = new Date();
          d.setHours(0, 0, 0, 0);
          exportar(R.ultimas(await DB.desde(d.getTime())), true);
        }),
        botao("Copiar ainda não exportado", async () => exportar(R.ultimas(await DB.desde((Number(salvo("exportadoAte")) || 0) + 1)), true), "bt s"),
        botao(
          "Limpar histórico",
          async () => {
            if (confirm("Apagar todo o histórico salvo no navegador?")) {
              await DB.limpar();
              status("Histórico apagado");
            }
          },
          "bt s"
        )
      ),
      el("div", { class: "status", "aria-live": "polite" })
    );
  }
  async function exportar(lista, marcar) {
    const linhas = R.linhasHistorico(lista);
    if (!linhas.length) return status("Nada para copiar");
    await copiar(linhas.join("\n"));
    if (marcar) salvo("exportadoAte", Date.now());
    status(`${linhas.length} linhas de ${lista.length} consultas copiadas`);
  }

  // ===================== Liga/desliga =====================
  function conferirLigado() {
    chrome.storage.local.get(["painel_jms", "permissao_extensao"], (r) => {
      const ligado = !!r && r.painel_jms === true && r.permissao_extensao !== false;
      if (ligado) montar();
      else desmontar();
    });
  }
  chrome.storage.onChanged.addListener((m, area) => {
    if (area !== "local") return;
    if (m.painel_jms || m.permissao_extensao) conferirLigado();
    if (m.tema) aplicarTema(m.tema.newValue);
  });
  conferirLigado();
})();
