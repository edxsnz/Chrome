// painel-jms.js
// Painel ⚡ dentro do JMS (content script). Só aparece com "Painel no JMS"
// ligado no popup e com a extensão liberada (kill switch).
// - As consultas vão pelo background.js, uma por vez: o painel só diz o tipo
//   e o código; o token nunca passa por aqui. O bloqueio do JMS é o mesmo do
//   Lote e do raio.
// - Telas montadas só com nós e textContent (nada de innerHTML), dentro de um
//   shadow DOM fechado (o CSS do JMS não interfere).
// - Guardado na origem do JMS (igual ao script original): histórico no
//   IndexedDB "jmsAuto" (30 dias) e listas/nomes no localStorage "jmsAuto.*".
//   Telefone e endereço da cliente (Cobrar) ficam só na tela.

(() => {
  if (window.__jtPainelCarregado) return;
  window.__jtPainelCarregado = true;

  const R = PainelRegras;
  const CFG = R.CFG;
  const FALHA = Symbol("falha"); // código que não foi consultado (erro/bloqueio)

  class ErroPainel extends Error {}
  class Parado extends Error {}

  // ===================== Tela: helper de nós =====================
  function el(tag, props, ...filhos) {
    const e = document.createElement(tag);
    if (props) {
      for (const [k, v] of Object.entries(props)) {
        if (v == null || v === false) continue;
        if (k === "class") e.className = v;
        else if (k === "text") e.textContent = v;
        else if (k === "on") Object.entries(v).forEach(([ev, fn]) => e.addEventListener(ev, fn));
        else if (k === "style") e.style.cssText = v;
        else if (k in e && typeof e[k] !== "function" && !k.startsWith("aria") && !k.startsWith("data")) e[k] = v;
        else e.setAttribute(k, v === true ? "" : String(v));
      }
    }
    for (const f of filhos.flat(Infinity)) {
      if (f == null || f === false) continue;
      e.append(f instanceof Node ? f : String(f));
    }
    return e;
  }
  const tabela = (cab, linhas) =>
    el(
      "div",
      { class: "tabela" },
      el("table", null, cab ? el("thead", null, el("tr", null, cab.map((c) => el("th", { text: c })))) : null, el("tbody", null, linhas.map((l) => el("tr", null, l.map((c) => el("td", null, c))))))
    );
  const fita = (...filhos) => el("div", { class: "fita" }, ...filhos);
  // Troca o conteúdo (aceita listas aninhadas e ignora vazios)
  const encher = (nodo, ...filhos) => nodo.replaceChildren(...filhos.flat(Infinity).filter((f) => f != null && f !== false));

  // ===================== Guardado na origem do JMS =====================
  const salvo = (k, v) => {
    try {
      if (v === undefined) return JSON.parse(localStorage.getItem("jmsAuto." + k) || "null");
      localStorage.setItem("jmsAuto." + k, JSON.stringify(v));
    } catch (e) {
      return null;
    }
    return v;
  };

  const DB = (() => {
    let dbp;
    const abrir = () =>
      dbp ||
      (dbp = new Promise((res, rej) => {
        const q = indexedDB.open("jmsAuto", 1);
        q.onupgradeneeded = () => {
          const s = q.result.createObjectStore("consultas", { autoIncrement: true });
          s.createIndex("code", "code");
          s.createIndex("em", "em");
        };
        q.onsuccess = () => res(q.result);
        q.onerror = () => rej(q.error);
      }));
    const tx = async (modo, fn) => {
      const db = await abrir();
      return new Promise((res, rej) => {
        const t = db.transaction("consultas", modo);
        const r = fn(t.objectStore("consultas"));
        t.oncomplete = () => res(r && r.result);
        t.onerror = () => rej(t.error);
      });
    };
    return {
      add: (rec) => tx("readwrite", (s) => s.add(rec)),
      ultima: (code) => tx("readonly", (s) => s.index("code").getAll(code)).then((a) => (a || []).sort((x, y) => y.em - x.em)[0]),
      desde: (ms) => tx("readonly", (s) => s.index("em").getAll(IDBKeyRange.lowerBound(ms))),
      limpar: () => tx("readwrite", (s) => s.clear()),
      // apaga o que passou do prazo do histórico
      podar: (antesDe) =>
        tx("readwrite", (s) => {
          const q = s.index("em").openCursor(IDBKeyRange.upperBound(antesDe, true));
          q.onsuccess = () => {
            const c = q.result;
            if (c) {
              c.delete();
              c.continue();
            }
          };
        }),
    };
  })();
  const podarHistorico = () => DB.podar(Date.now() - CFG.historicoDias * 864e5).catch(() => {});

  // ===================== Consultas (pelo background) =====================
  const dormir = (ms) => new Promise((r) => setTimeout(r, ms));
  let ctl = null; // { parado } da consulta em andamento

  // Espera com contagem regressiva na barra (fita zebrada = JMS segurando)
  async function esperarAte(ate, rotulo) {
    const ini = Date.now();
    const tot = Math.max(1, ate - ini);
    while (Date.now() < ate) {
      if (ctl && ctl.parado) throw new Parado();
      esperaBarra(Math.ceil((ate - Date.now()) / 1000), (Date.now() - ini) / tot, rotulo);
      await dormir(Math.min(1000, ate - Date.now()));
    }
    voltarBarra();
  }

  async function pedir(msg) {
    if (!chrome.runtime || !chrome.runtime.id) throw new ErroPainel("A extensão foi atualizada. Atualize a página do JMS (F5) para usar o painel.");
    try {
      const r = await chrome.runtime.sendMessage(msg);
      return r && typeof r === "object" ? r : { ok: false, suspeito: true };
    } catch (e) {
      if (!chrome.runtime || !chrome.runtime.id) throw new ErroPainel("A extensão foi atualizada. Atualize a página do JMS (F5) para usar o painel.");
      return { ok: false, suspeito: true };
    }
  }

  // Uma consulta. Bloqueio: espera e tenta o MESMO código (não gasta tentativa).
  // Resposta estranha: espera e tenta de novo; depois disso = FALHA (não consultado).
  async function consultar(tipo, codigo) {
    const inicio = Date.now();
    let suspeitas = 0;
    for (;;) {
      if (ctl && ctl.parado) throw new Parado();
      const r = await pedir({ acao: "painel", tipo, codigo });
      if (r.ok) return r.data;
      if (r.limite) {
        if (Date.now() - inicio > EXP_CFG.limiteTetoMs) return FALHA;
        await esperarAte(Number(r.ate) || Date.now() + EXP_CFG.sondaMs, "O JMS bloqueou (limite de consultas). Tentando de novo em");
        continue;
      }
      if (r.suspeito) {
        if (++suspeitas > EXP_CFG.suspeitasMax) return FALHA;
        const esp = EXP_CFG.esperasSuspeitaMs;
        await esperarAte(Date.now() + esp[Math.min(suspeitas - 1, esp.length - 1)], "Resposta estranha do sistema. Tentando de novo em");
        continue;
      }
      if (r.erro && r.erro.tipo !== "invalido") throw new ErroPainel(r.erro.mensagem || "Não foi possível consultar no JMS.");
      return FALHA;
    }
  }

  const pausaEntre = () => dormir(EXP_CFG.pausaMinMs + Math.random() * (EXP_CFG.pausaMaxMs - EXP_CFG.pausaMinMs));

  // Rastreia 1 código (usa o histórico recente); salva no histórico. null = não consultado.
  async function rastrear(code, origem, forcar = false) {
    if (!forcar) {
      const u = await DB.ultima(code).catch(() => null);
      if (u && u.v === 2 && Date.now() - u.em < CFG.cacheMin * 60000) return u.det;
    }
    const data = await consultar("rastreio", code);
    await pausaEntre();
    if (data === FALHA) return null;
    const det = R.normalizar(data);
    await DB.add({ code, em: Date.now(), origem, det, v: 2 }).catch(() => {});
    return det;
  }
  // Cada código é consultado UMA vez. Quem não respondeu (bloqueio / resposta
  // estranha) é consultado de novo no fim, volta após volta, até TODOS
  // responderem: só então a consulta está pronta. O Parar continua valendo.
  async function rastrearLista(lista, origem, rotulo, forcar = false) {
    const out = {};
    for (let i = 0; i < lista.length; i++) {
      progressoBarra(i + 1, lista.length, rotulo);
      out[lista[i]] = await rastrear(lista[i], origem, forcar);
    }
    for (let volta = 1; ; volta++) {
      const falhos = lista.filter((c) => !out[c]);
      if (!falhos.length) break;
      await esperarAte(Date.now() + EXP_CFG.sondaMs, `${falhos.length} sem resposta do JMS. Volta ${volta} em`);
      for (let i = 0; i < falhos.length; i++) {
        progressoBarra(i + 1, falhos.length, `${rotulo} · ${falhos.length} sem resposta, volta ${volta}`);
        out[falhos[i]] = await rastrear(falhos[i], origem, forcar);
      }
    }
    if (ctl) ctl.total = (ctl.total || 0) + lista.length;
    return out;
  }
  async function cliente(code) {
    const p = await consultar("cliente", code);
    if (p === FALHA || !p) {
      if (ctl) ctl.semDados = (ctl.semDados || 0) + 1;
      return { nome: "", tel: "", end: "" };
    }
    await pausaEntre();
    let d = await consultar("detalhe", code);
    if (d === FALHA) {
      d = null;
      if (ctl) ctl.semDados = (ctl.semDados || 0) + 1;
    }
    await pausaEntre();
    return { nome: String(p.receiverName || "").trim(), tel: String(p.receiverMobilePhone || "").trim(), end: R.endereco(p.receiverFullAddress || "", d) };
  }

  // ===================== Montagem =====================
  let host = null;
  let raiz = null;
  let painel = null;
  let palco = null; // onde ficam as abas
  let fab = null;
  // Cada aba é montada na primeira visita e depois só escondida/mostrada:
  // trocar de aba não apaga nada (o F5 limpa, nada vai para o disco).
  let paineis = [];
  let corpo = null; // aba aberta
  let corpoRodando = null; // aba que está consultando (pode não ser a aberta)
  let abaAtual = 0;
  let ocupado = false;

  function aplicarTema(tema) {
    if (!painel) return;
    let t = tema;
    if (t !== "dark" && t !== "light") t = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
    host.setAttribute("data-theme", t);
  }

  function carregarFonte() {
    try {
      if ([...document.fonts].some((f) => f.family === "JT Archivo")) return;
      const f = new FontFace("JT Archivo", `url("${chrome.runtime.getURL("fonts/archivo-latin-wdth-wght.woff2")}") format("woff2")`, { weight: "100 900", stretch: "62% 125%" });
      document.fonts.add(f);
      f.load().catch(() => {});
    } catch (e) {
      /* sem a fonte: usa a do sistema */
    }
  }

  const ABAS = [
    ["Recebimento", abaRecebimento],
    ["Planilhas", abaPlanilhas],
    ["Rastreio", abaRastreio],
    ["Cobrar", abaCobrar],
    ["Histórico", abaHistorico],
  ];

  function montar() {
    if (host) return;
    carregarFonte();
    host = el("div", { id: "jt-painel-host" });
    raiz = host.attachShadow({ mode: "closed" });
    const css = el("link", { rel: "stylesheet", href: chrome.runtime.getURL("painel-jms.css") });
    fab = el("button", { class: "fab", type: "button", title: "Automações JMS (J&T Respostas Rápidas)", "aria-label": "Automações JMS", on: { click: alternar } }, iconeRaio());
    const nav = el(
      "nav",
      { class: "abas", role: "tablist" },
      ABAS.map(([nome], i) => el("button", { type: "button", class: "aba", role: "tab", "data-i": i, text: nome, on: { click: () => trocarAba(i) } })),
      el("span", { class: "aba-traco", "aria-hidden": "true" })
    );
    const expandir = el("button", { type: "button", class: "topo-bt expandir", on: { click: () => alternarLargo() } });
    palco = el("div", { class: "palco" });
    paineis = ABAS.map(() => null);
    painel = el(
      "section",
      { class: "painel", "aria-label": "Automações JMS" },
      el(
        "header",
        { class: "topo" },
        el("span", { class: "marca" }, iconeRaio(), " Automações JMS", el("span", { class: "marca-base", text: CFG.base })),
        el("span", { class: "topo-acoes" }, expandir, el("button", { type: "button", class: "topo-bt", title: "Fechar", "aria-label": "Fechar", text: "✕", on: { click: alternar } }))
      ),
      nav,
      palco
    );
    raiz.append(css, painel, fab);
    document.documentElement.append(host);
    chrome.storage.local.get("tema", (r) => aplicarTema(r && r.tema));
    podarHistorico();
    alternarLargo(salvo("largo") === true);
    window.addEventListener("resize", moverTraco);
    const salva = Number(salvo("aba"));
    trocarAba(Number.isInteger(salva) && salva >= 0 && salva < ABAS.length ? salva : 0);
  }

  function desmontar() {
    if (ctl) ctl.parado = true;
    if (host) host.remove();
    host = raiz = painel = palco = fab = corpo = corpoRodando = null;
    paineis = [];
    ocupado = false;
  }

  function iconeRaio() {
    const ns = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(ns, "svg");
    svg.setAttribute("viewBox", "0 0 20 20");
    svg.setAttribute("aria-hidden", "true");
    const p = document.createElementNS(ns, "path");
    p.setAttribute("d", "M11.2 1.8 4.2 11.2h5l-1 7 7-9.4h-5l1-7Z");
    svg.append(p);
    return svg;
  }

  function alternar() {
    if (!painel) return;
    const abrir = !painel.classList.contains("aberto");
    painel.classList.toggle("aberto", abrir);
    if (abrir) {
      if (fab) fab.classList.remove("pronto", "falhou");
      requestAnimationFrame(moverTraco);
    }
  }

  // Janela larga (para as tabelas) ou no canto. Preferência de tela, não é dado de cliente.
  function alternarLargo(forcar) {
    if (!painel) return;
    const largo = typeof forcar === "boolean" ? forcar : !painel.classList.contains("largo");
    painel.classList.toggle("largo", largo);
    salvo("largo", largo);
    setTimeout(moverTraco, 260);
    const b = raiz.querySelector(".expandir");
    if (b) {
      b.textContent = largo ? "⤡" : "⤢";
      b.title = largo ? "Voltar para o canto" : "Expandir a janela";
      b.setAttribute("aria-label", b.title);
    }
  }

  const botaoAba = (i) => raiz && raiz.querySelectorAll(".aba")[i];
  // Traço vermelho sob a aba ativa (desliza ao trocar)
  function moverTraco() {
    const b = botaoAba(abaAtual);
    const t = raiz && raiz.querySelector(".aba-traco");
    if (!b || !t || !b.offsetWidth) return;
    t.style.width = `${b.offsetWidth - 24}px`;
    t.style.transform = `translateX(${b.offsetLeft + 12}px)`;
  }

  function trocarAba(i) {
    if (!palco) return;
    abaAtual = i;
    salvo("aba", i);
    raiz.querySelectorAll(".aba").forEach((b, j) => {
      b.classList.toggle("ativa", j === i);
      b.setAttribute("aria-selected", j === i ? "true" : "false");
    });
    paineis.forEach((p, j) => {
      if (p) p.hidden = j !== i;
    });
    moverTraco();
    if (!paineis[i]) {
      corpo = el("div", { class: "corpo", role: "tabpanel" });
      paineis[i] = corpo;
      palco.append(corpo);
      ABAS[i][1]();
    } else corpo = paineis[i];
  }

  // Joga fora uma aba já montada (é montada de novo na próxima visita, ou já, se estiver aberta)
  function descartarAba(i) {
    const p = paineis[i];
    if (!p || p === corpoRodando) return;
    p.remove();
    paineis[i] = null;
    if (i === abaAtual) trocarAba(i);
  }

  // ===================== Peças comuns =====================
  function toast(m) {
    if (!painel) return;
    painel.querySelectorAll(".toast").forEach((t) => t.remove());
    const t = el("div", { class: "toast", role: "status", text: m });
    painel.append(t);
    setTimeout(() => t.remove(), 1800);
  }
  async function copiar(txt, botaoEl) {
    try {
      await navigator.clipboard.writeText(txt);
    } catch (e) {
      const ta = el("textarea", { value: txt });
      raiz.append(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
    if (botaoEl && botaoEl.isConnected) {
      // confirmação no próprio botão
      if (!botaoEl.dataset.texto) botaoEl.dataset.texto = botaoEl.textContent;
      clearTimeout(botaoEl.__tCopiado);
      botaoEl.textContent = "✓ Copiado";
      botaoEl.classList.add("copiado");
      botaoEl.__tCopiado = setTimeout(() => {
        botaoEl.textContent = botaoEl.dataset.texto;
        botaoEl.classList.remove("copiado");
      }, 1500);
    } else toast("Copiado!");
  }
  const alvo = () => corpoRodando || corpo;
  function status(m) {
    const a = alvo();
    const e = a && a.querySelector(".status");
    if (e) e.textContent = m || "";
  }
  const botao = (texto, fn, classe = "bt") => el("button", { type: "button", class: classe, text: texto, on: { click: fn } });
  // Botão que copia; o texto vem de uma função (montado na hora do clique)
  const botaoCopiar = (texto, pegar, classe = "bt") => el("button", { type: "button", class: classe, text: texto, on: { click: (e) => copiar(pegar(), e.currentTarget) } });
  const linhaBotoes = (...b) => el("div", { class: "botoes" }, ...b);
  const cartao = (classe, ...filhos) => el("div", { class: "cartao" + (classe ? " " + classe : "") }, ...filhos);
  const tituloCartao = (texto, nota) => el("div", { class: "cartao-tit" }, el("span", { text: texto }), nota ? el("span", { class: "nota", text: nota }) : null);

  // Barra de progresso (só aparece com a aba consultando) + linha de status
  const blocoProgresso = () => [
    el(
      "div",
      { class: "progresso", "aria-live": "polite" },
      el("div", { class: "prog-linha" }, el("span", { class: "prog-texto" }), botao("Parar", () => ctl && (ctl.parado = true), "bt parar")),
      el("div", { class: "barra" }, el("div", { class: "enchido" }))
    ),
    el("div", { class: "status", "aria-live": "polite" }),
  ];
  let ultBarra = null;
  function pegarBarra() {
    const a = alvo();
    return a && a.querySelector(".progresso");
  }
  function progressoBarra(i, n, rotulo) {
    ultBarra = [i, n, rotulo];
    const p = pegarBarra();
    if (!p) return;
    p.classList.remove("bloqueio");
    p.classList.toggle("indefinido", !n);
    p.querySelector(".prog-texto").textContent = n ? `${rotulo} · ${i}/${n}` : rotulo;
    p.querySelector(".enchido").style.width = n ? `${Math.max(2, Math.round((i / n) * 100))}%` : "100%";
  }
  function esperaBarra(seg, frac, rotulo) {
    const p = pegarBarra();
    if (!p) return;
    p.classList.add("bloqueio");
    p.classList.remove("indefinido");
    p.querySelector(".prog-texto").textContent = `${rotulo} ${seg} s`;
    p.querySelector(".enchido").style.width = `${Math.min(100, Math.max(2, Math.round(frac * 100)))}%`;
  }
  const voltarBarra = () => (ultBarra ? progressoBarra(...ultBarra) : progressoBarra(0, 0, "Consultando…"));

  async function rodar(fn) {
    if (ocupado) return toast("Já tem uma consulta rodando");
    ocupado = true;
    ctl = { parado: false };
    const meu = ctl;
    const aqui = corpo;
    const iAba = abaAtual;
    corpoRodando = aqui;
    ultBarra = null;
    aqui.classList.add("rodando");
    const ba = botaoAba(iAba);
    if (ba) ba.classList.add("consultando");
    if (fab) fab.classList.add("consultando");
    status("");
    // resultado da rodada anterior sai: o que aparecer depois é sempre desta consulta
    const outAnt = aqui.querySelector(".saida");
    if (outAnt) outAnt.replaceChildren();
    progressoBarra(0, 0, "Começando…");
    let problema = null;
    try {
      await fn();
    } catch (e) {
      if (e instanceof Parado) problema = "Você parou a consulta antes do fim.";
      else problema = e instanceof ErroPainel ? e.message : "Erro: " + (e && e.message ? e.message : "inesperado");
      status(problema);
    }
    avisarFim(aqui, meu, problema);
    if (ctl === meu) ctl = null;
    ocupado = false;
    corpoRodando = null;
    aqui.classList.remove("rodando");
    if (ba) ba.classList.remove("consultando");
    if (fab) fab.classList.remove("consultando");
  }
  const saida = () => alvo().querySelector(".saida");

  // Fim de toda consulta: etiqueta "Pronto" (todos responderam) ou "Não está
  // pronto". Fora da tela: ⚡ verde (ou com "!") e o título da aba do navegador.
  const TITULO_PRONTO = "✅ Pronto · ";
  const TITULO_FALHOU = "⚠ Não terminou · ";
  function iconeCheck() {
    const ns = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(ns, "svg");
    svg.setAttribute("viewBox", "0 0 40 40");
    svg.setAttribute("aria-hidden", "true");
    const c = document.createElementNS(ns, "circle");
    c.setAttribute("cx", "20");
    c.setAttribute("cy", "20");
    c.setAttribute("r", "17");
    const p = document.createElementNS(ns, "path");
    p.setAttribute("d", "M12 20.5l5.5 5.5L28.5 14");
    svg.append(c, p);
    return svg;
  }
  function avisarFim(onde, meu, problema) {
    const out = onde && onde.querySelector(".saida");
    if (!out) return;
    out.querySelectorAll(".pronto").forEach((x) => x.remove());
    const hora = new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
    const n = meu.total || 0;
    const semDados = meu.semDados || 0;
    const ok = !problema && !semDados;
    let detalhe;
    if (problema) detalhe = `${problema} O resultado abaixo pode estar incompleto: rode de novo.`;
    else if (semDados) detalhe = `${n} de ${n} rastreios responderam, mas ${semDados} dado(s) da cliente não vieram. Confira esses antes de mandar.`;
    else detalhe = n ? `${n} de ${n} consultados, todos responderam · ${hora}` : `Feito · ${hora}`;
    const etiqueta = el(
      "div",
      { class: "pronto" + (ok ? "" : " nao"), role: "status" },
      ok ? iconeCheck() : el("span", { class: "pronto-alerta", text: "!" }),
      el("div", { class: "pronto-txt" }, el("b", { text: ok ? "Pronto" : "Não está pronto" }), el("span", { text: detalhe })),
      ok ? el("span", { class: "carimbo", "aria-hidden": "true", text: "Conferido" }) : null
    );
    out.prepend(etiqueta);
    if (fab && !painel.classList.contains("aberto")) {
      fab.classList.remove("pronto", "falhou");
      fab.classList.add(ok ? "pronto" : "falhou");
    }
    if (document.hidden) {
      const base = document.title.replace(TITULO_PRONTO, "").replace(TITULO_FALHOU, "");
      document.title = (ok ? TITULO_PRONTO : TITULO_FALHOU) + base;
    }
  }
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden && (document.title.startsWith(TITULO_PRONTO) || document.title.startsWith(TITULO_FALHOU)))
      document.title = document.title.replace(TITULO_PRONTO, "").replace(TITULO_FALHOU, "");
  });
  const listaMono = (itens) => el("pre", { class: "mono", text: itens.join("\n") || "Nenhum" });

  // Seção que abre e fecha (cartão com faixa colorida e selo com o número)
  function secao(classe, titulo, n, aberta, ...conteudo) {
    return el(
      "details",
      { class: "secao" + (classe ? " " + classe : ""), open: !!aberta, "data-total": n },
      el("summary", null, el("span", { class: "secao-tit", text: titulo }), el("span", { class: "selo", text: String(n) })),
      el("div", { class: "secao-corpo" }, ...conteudo)
    );
  }
  // Campo de busca: filtra as linhas das tabelas e os itens das seções dentro de "onde"
  function campoBusca(onde, placeholder = "Buscar código ou entregador") {
    const inp = el("input", { type: "search", class: "busca", placeholder, spellcheck: false, "aria-label": placeholder });
    const aplicar = () => {
      const q = inp.value.trim().toLowerCase();
      onde.querySelectorAll("details.secao").forEach((d) => {
        const itens = d.querySelectorAll("tbody tr, .item");
        let vis = 0;
        itens.forEach((it) => {
          const ok = !q || it.textContent.toLowerCase().includes(q);
          it.hidden = !ok;
          if (ok) vis++;
        });
        const selo = d.querySelector(".selo");
        if (selo) selo.textContent = q ? `${vis} de ${d.dataset.total}` : d.dataset.total;
        d.classList.toggle("vazia-busca", !!q && !vis);
        if (q) {
          // durante a busca: abre as que têm resultado e fecha as vazias (o Esc devolve como estava)
          if (!d.dataset.abertaAntes) d.dataset.abertaAntes = d.open ? "1" : "0";
          d.open = vis > 0;
        } else if (d.dataset.abertaAntes) {
          d.open = d.dataset.abertaAntes === "1";
          delete d.dataset.abertaAntes;
        }
      });
    };
    inp.addEventListener("input", aplicar);
    inp.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        inp.value = "";
        aplicar();
      }
    });
    return el("div", { class: "busca-linha" }, inp);
  }

  // ===================== Recebimento (mandaram para nós e não chegou) =====================
  function abaRecebimento() {
    const ta = el("textarea", { class: "mono", placeholder: "(opcional) cole os códigos aqui", spellcheck: false });
    corpo.append(
      cartao(
        "entrada",
        tituloCartao("Expedido não chegou (recebimento)"),
        el(
          "p",
          { class: "nota" },
          "Pacotes ",
          el("b", { text: `carregados da ${CFG.origemExpedido} para a ${CFG.base}` }),
          " que não chegaram. Abra ",
          el("b", { text: "Monitoramento de tipagem de recebimento (novo)" }),
          ", filtre e clique em Ler tela. Ou cole os códigos."
        ),
        fita(el("b", { text: "Atenção: " }), "bipe ", el("b", { text: "expedido não chegou" }), " nesses pacotes. Se não bipar, a base paga. Cada código é consultado 1 vez; quem não responder é consultado de novo até responder."),
        ta,
        linhaBotoes(botao("Ler tela e conferir", () => rodar(() => recebimentoConferir(ta))), botao("Conferir bipes (depois de bipar)", () => rodar(() => recebimentoBipes(ta)), "bt s")),
        ...blocoProgresso()
      ),
      el("div", { class: "saida" })
    );
  }

  async function recebimentoConferir(ta) {
    let todos = R.codigos(ta.value);
    let br = 0;
    let estranhos = [];
    let lidos = 0;
    if (!todos.length) {
      progressoBarra(0, 0, "Lendo a tela (pode levar alguns segundos)…");
      const r = await pedir({ acao: "painelLerTela" });
      if (!r.ok) return status(r.mensagem || "Não achei a tabela.");
      const tela = r.codigos || [];
      lidos = Number(r.lidos) || tela.length;
      // Nunca segue com a lista incompleta: pacote fora da lista = base paga
      if (r.total && lidos < r.total) return status(`Só consegui ler ${lidos} de ${r.total} registros da tela. Coloque 100 por página no JMS e clique de novo.`);
      br = tela.filter((c) => /^BR/i.test(c)).length;
      const pacotes = tela.filter((c) => !/^BR/i.test(c));
      todos = pacotes.filter((c) => /^(?:888|999)\d{12}$/.test(c));
      estranhos = pacotes.filter((c) => !/^(?:888|999)\d{12}$/.test(c));
      status(`Li ${lidos} registros da tela (${br} sacas BR, ${pacotes.length} pacotes)`);
    }
    if (!todos.length && !estranhos.length) return status("Nenhum código encontrado.");
    const r = await rastrearLista(todos, "Expedido não chegou", "Conferindo", true);
    const c = R.conferirRecebimento(todos, r);
    salvo("expedido", { em: Date.now(), entra: c.entra });
    status(`${lidos ? `${lidos} registros lidos · ${br} sacas BR ignoradas · ` : ""}${todos.length} pacotes conferidos`);
    const tudoCerto = !c.entra.length && !c.naoConsultados.length && !estranhos.length;
    const res = el("div", { class: "resultado" });
    encher(
      res,
      tudoCerto
        ? cartao(
            "tudo-certo",
            el("div", { class: "tudo-certo-tit", text: "Tudo certo – nada para bipar" }),
            el("p", { class: "nota", text: c.jaBipados.length ? `${c.jaBipados.length} pacote(s) já estão com o bipe "expedido não chegou" da ${CFG.base}.` : "Nenhum pacote carregado para nós ficou sem chegar." })
          )
        : cartao(
            c.entra.length ? "destaque" : "ok",
            tituloCartao(`Bipar expedido não chegou: ${c.entra.length}`),
            listaMono(c.entra),
            c.entra.length ? linhaBotoes(botaoCopiar("Copiar códigos", () => c.entra.join("\n"))) : null
          ),
      c.naoConsultados.length ? fita(el("b", { text: `${c.naoConsultados.length} não foram consultados: rode de novo antes de bipar.` }), listaMono(c.naoConsultados)) : null,
      estranhos.length ? fita(el("b", { text: `${estranhos.length} com formato que não reconheci: confira à mão.` }), listaMono(estranhos)) : null,
      c.jaBipados.length || c.fora.length ? campoBusca(res, "Buscar código") : null,
      c.jaBipados.length ? secao("ja-bipados", "✅ Já bipados", c.jaBipados.length, false, tabela(null, c.jaBipados.map((x) => [x, R.descreverUltimo(r[x])]))) : null,
      c.fora.length ? secao("apagada", "Não entram", c.fora.length, false, tabela(null, c.fora.map((x) => [x, R.descreverUltimo(r[x])]))) : null
    );
    encher(saida(), res);
  }

  async function recebimentoBipes(ta) {
    const s = salvo("expedido");
    const coladas = R.codigos(ta.value);
    const lista = coladas.length ? coladas : (s && Array.isArray(s.entra) && s.entra) || [];
    if (!lista.length) return status("Nada para conferir: rode Ler tela e conferir antes, ou cole os códigos.");
    const r = await rastrearLista(lista, "Conferência expedido", "Conferindo", true);
    const linhas = lista.map((c) => {
      const det = r[c];
      if (!det) return [c, "⚠", "não consultado (erro ou bloqueio): confira de novo"];
      const l = det[det.length - 1];
      return [c, R.bipeCerto(det) ? "✅" : "❌", l ? `${R.dmh(l.t)} ${l.tipo} ${l.motivo} – ${l.por}` : "SEM DADOS"];
    });
    const ok = linhas.filter((x) => x[1] === "✅").length;
    status("");
    encher(
      saida(),
      cartao(
        ok === lista.length ? "ok" : "destaque",
        tituloCartao(`${ok}/${lista.length} com o bipe certo`),
        ok === lista.length ? null : fita(el("b", { text: `Faltam ${lista.length - ok}: ` }), "bipe expedido não chegou nesses antes de fechar o dia."),
        tabela(null, linhas)
      )
    );
  }

  // ===================== Leitor de Excel (.xlsx) sem biblioteca =====================
  // .xlsx = ZIP com XMLs dentro: lê o índice do ZIP na mão e descompacta com
  // DecompressionStream (nativo). O XML é só lido (DOMParser), nunca vira tela.
  async function lerZip(buf) {
    const dv = new DataView(buf);
    const u8 = new Uint8Array(buf);
    const dec = new TextDecoder();
    let eocd = -1;
    for (let i = buf.byteLength - 22; i >= Math.max(0, buf.byteLength - 70000); i--)
      if (dv.getUint32(i, true) === 0x06054b50) {
        eocd = i;
        break;
      }
    if (eocd < 0) throw new Error("Arquivo não é .xlsx válido");
    const n = dv.getUint16(eocd + 10, true);
    let p = dv.getUint32(eocd + 16, true);
    const arquivos = {};
    for (let k = 0; k < n; k++) {
      const metodo = dv.getUint16(p + 10, true);
      const tam = dv.getUint32(p + 20, true);
      const lenNome = dv.getUint16(p + 28, true);
      const lenExtra = dv.getUint16(p + 30, true);
      const lenCom = dv.getUint16(p + 32, true);
      const off = dv.getUint32(p + 42, true);
      const nome = dec.decode(u8.subarray(p + 46, p + 46 + lenNome));
      arquivos[nome] = { metodo, tam, off };
      p += 46 + lenNome + lenExtra + lenCom;
    }
    return async (nome) => {
      const a = arquivos[nome];
      if (!a) return null;
      const ini = a.off + 30 + dv.getUint16(a.off + 26, true) + dv.getUint16(a.off + 28, true);
      const dados = u8.slice(ini, ini + a.tam);
      if (a.metodo === 0) return dec.decode(dados);
      const s = new Blob([dados]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
      return await new Response(s).text();
    };
  }
  // Os arquivos do Feishu usam prefixo (<x:row>), têm BOM e não têm "r" nas
  // células: por isso getElementsByTagNameNS('*') e colunas em sequência.
  // NÃO trocar por getElementsByTagName('row') (não acha nada no Feishu).
  async function lerXlsx(buf) {
    const abrir = await lerZip(buf);
    const xml = (s) => new DOMParser().parseFromString(s, "application/xml");
    const tags = (e, tag) => [...e.getElementsByTagNameNS("*", tag)];
    const tagTxt = (e, tag) => tags(e, tag).map((t) => t.textContent).join("");
    const ss = await abrir("xl/sharedStrings.xml");
    const strings = ss ? tags(xml(ss), "si").map((si) => tagTxt(si, "t")) : [];
    let sheet = await abrir("xl/worksheets/sheet1.xml");
    if (!sheet) for (let i = 2; i < 10 && !sheet; i++) sheet = await abrir(`xl/worksheets/sheet${i}.xml`);
    if (!sheet) throw new Error("Não achei a planilha dentro do arquivo");
    const linhas = [];
    for (const row of tags(xml(sheet.replace(/^﻿/, "")), "row")) {
      const r = [];
      let seq = 0;
      for (const c of tags(row, "c")) {
        const t = c.getAttribute("t");
        const v = tags(c, "v")[0];
        let val = t === "s" ? strings[+(v && v.textContent)] : t === "inlineStr" ? tagTxt(c, "t") : v ? v.textContent : "";
        if (/^\d(\.\d+)?E\+\d+$/i.test(val || "")) val = Number(val).toFixed(0); // 9.99882713626169E+14
        const ref = c.getAttribute("r");
        const ci = ref ? R.colIdx(ref) : seq;
        seq = ci + 1;
        r[ci] = val ?? "";
      }
      linhas.push(Array.from(r, (x) => x ?? ""));
    }
    return linhas;
  }

  // ===================== Planilhas (Tentativas + nós enviamos e não chegou) =====================
  const NOME_CURTO = { C: "Cobrar", R: "Registrar devolução", D: "Ensacar", B: "Preso na base", I: "Interceptados", K: "Coleta não chegou", F: "Em rota 2/3", A: "Em rota 1/3", G: "Voltou", T: "Em trânsito", E: "Erro de consulta" };
  const SECOES_ABERTAS = "CRDBIKE"; // o que pede ação começa aberto; o que só se acompanha, fechado

  function abaPlanilhas() {
    const ant = salvo("tentativas");
    const ta = el("textarea", { class: "mono curta", placeholder: "(ou) cole aqui o conteúdo das planilhas", spellcheck: false });
    const etiquetas = el("div", { class: "etiquetas" });
    const doArquivo = { codigos: [] };
    const arq = el("input", {
      type: "file",
      multiple: true,
      accept: ".xlsx,.csv",
      hidden: true,
      on: {
        change: async (e) => {
          doArquivo.codigos = [];
          const chips = [];
          for (const f of e.target.files) {
            try {
              if (/\.xls$/i.test(f.name)) {
                chips.push(el("span", { class: "etiqueta erro", text: `${f.name}: formato .xls antigo – salve como .xlsx` }));
                continue;
              }
              const linhas = /\.csv$/i.test(f.name) ? R.lerCsv(await f.text()) : await lerXlsx(await f.arrayBuffer());
              const cs = R.codigosDasLinhas(linhas);
              doArquivo.codigos.push(...cs);
              chips.push(el("span", { class: "etiqueta", title: `${linhas.length - 1} linhas no arquivo` }, el("b", { text: f.name }), ` · ${cs.length} da ${CFG.base}`));
            } catch (err) {
              chips.push(el("span", { class: "etiqueta erro", text: `${f.name}: erro – ${err && err.message ? err.message : "não consegui ler"}` }));
            }
          }
          doArquivo.codigos = [...new Set(doArquivo.codigos)];
          encher(etiquetas, chips, chips.length ? el("span", { class: "etiqueta total", text: `→ ${doArquivo.codigos.length} códigos` }) : null);
          arq.value = "";
        },
      },
    });
    corpo.append(
      cartao(
        "entrada",
        tituloCartao("Tentativas do dia", `só a ${CFG.base}`),
        el("p", { class: "nota" }, "Escolha o ", el("b", { text: "RETIDOS" }), " e o ", el("b", { text: "SEM MOV" }), " (.xlsx, os dois juntos) ou cole o conteúdo. Os da última rodada que não saíram também entram."),
        el("div", { class: "arquivos" }, arq, botao("Escolher RETIDOS e SEM MOV", () => arq.click(), "bt s arquivo"), etiquetas),
        ta,
        linhaBotoes(
          botao("Consultar e classificar", () => rodar(() => planilhasConsultar(ta, ant, doArquivo.codigos))),
          ant && Array.isArray(ant.codes) ? el("span", { class: "nota", text: `última rodada: ${new Date(ant.em).toLocaleString("pt-BR")} (${ant.codes.length} códigos)` }) : null
        ),
        ...blocoProgresso()
      ),
      el("div", { class: "saida" })
    );
  }

  // Número do placar sobe até o total (uma vez, quando o resultado aparece)
  function contarAte(nodo, n) {
    const calmo = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (calmo || n < 2) return nodo;
    const ini = performance.now();
    const passo = (t) => {
      const f = Math.min(1, (t - ini) / 550);
      nodo.textContent = String(Math.round(n * (1 - Math.pow(1 - f, 3))));
      if (f < 1) requestAnimationFrame(passo);
    };
    nodo.textContent = "0";
    requestAnimationFrame(passo);
    return nodo;
  }
  function placar(ativos, irPara) {
    const cont = (k) => ativos.filter((r) => r.sec === k).length;
    return el(
      "div",
      { class: "placar" },
      R.ordemSecoes.split("").map((k) => {
        const n = cont(k);
        return el(
          "button",
          { type: "button", class: `quadro q-${k}${n ? "" : " zero"}`, disabled: !n, title: n ? `Ver ${NOME_CURTO[k]}` : null, on: { click: () => irPara(k) } },
          contarAte(el("span", { class: "q-num", text: String(n) }), n),
          el("span", { class: "q-nome", text: NOME_CURTO[k] })
        );
      })
    );
  }

  async function planilhasConsultar(ta, ant, doArquivo = []) {
    const hoje = [...new Set([...doArquivo, ...R.lerBacklog(ta.value)])];
    const antigos = ant && Array.isArray(ant.codes) ? ant.codes.filter((c) => !hoje.includes(c)) : [];
    const lista = [...hoje, ...antigos];
    if (!lista.length) return status("Nenhum código encontrado.");
    const res = await rastrearLista(lista, "Tentativas (backlog)", "Consultando", false);
    const consultados = lista.filter((c) => res[c]);
    // Os não consultados viram "Erro de consulta" (seção E): continuam na planilha e na próxima rodada
    const nomes = salvo("nomes") || {};
    const rows = lista.map((c) => R.classificar(c, res[c], nomes));
    const ativos = R.ordenarAtivos(rows.filter((r) => r.sec !== "X" && r.sec !== "N"));
    const naoChegou = R.ordenarNaoChegou(rows.filter((r) => r.sec === "N"));
    const sairam = rows.filter((r) => r.sec === "X");
    const expedidos = consultados
      .map((c) => {
        const u = R.nosEnviamos(res[c]);
        return u ? { code: c, base: u.base, t: u.t, por: u.por } : null;
      })
      .filter(Boolean);
    // os "não chegou" também voltam na próxima rodada (se chegarem, entram na lista normal)
    salvo("tentativas", { em: Date.now(), codes: ativos.concat(naoChegou).map((r) => r.code) });
    salvo("cobrar", ativos.filter((r) => r.cobrar).map((r) => r.code));
    descartarAba(3); // o Cobrar mostra a lista nova na próxima visita
    const resumo = R.resumoTentativas(ativos, naoChegou.length);
    const bloco = R.blocoClaude(ativos, sairam, resumo, naoChegou);
    const tsv = R.tsvPlanilha(ativos, resumo);
    const tsvNC = R.tsvNaoChegou(naoChegou);
    status("");
    const nCobrar = ativos.filter((r) => r.cobrar).length;
    const nBase3 = ativos.filter((r) => r.sec === "B" && +r.dias > CFG.diasAlerta).length;
    const agoraTxt = new Date().toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
    const res2 = el("div", { class: "resultado" });
    const secoes = {};
    const irPara = (k) => {
      const d = secoes[k];
      if (!d) return;
      d.open = true;
      d.scrollIntoView({ block: "start", behavior: "smooth" });
    };
    encher(
      res2,
      cartao(
        "placar-cartao",
        tituloCartao(`${ativos.length} pacotes na lista`, `atualizado ${agoraTxt}`),
        placar(ativos, irPara),
        el(
          "div",
          { class: "placar-meta" },
          el("span", null, `Preso na base há mais de ${CFG.diasAlerta} dias: `, el("b", { text: String(nBase3) })),
          el("span", null, "Não chegou (entrada): ", el("b", { text: String(naoChegou.length) })),
          el("span", null, "Saíram da lista: ", el("b", { text: String(sairam.length) }))
        ),
        linhaBotoes(
          botaoCopiar("Copiar para a planilha", () => tsv),
          el("span", { class: "nota" }, "aba Tentativas, célula ", el("b", { text: "A2" }), " e Ctrl+V")
        ),
        linhaBotoes(
          botaoCopiar(`Copiar "Não chegou" (${naoChegou.length})`, () => tsvNC, "bt s"),
          el("span", { class: "nota" }, "aba Não chegou, célula ", el("b", { text: "A2" }))
        ),
        linhaBotoes(botaoCopiar("Copiar para o Claude", () => bloco, "bt s"), botao(`Ir para Cobrar (${nCobrar})`, () => trocarAba(3), "bt s"))
      ),
      expedidos.length
        ? secao(
            "destaque",
            "Deram expedido não chegou (nós enviamos)",
            expedidos.length,
            true,
            tabela(["Código", "Base que marcou", "Quando", "Quem"], expedidos.map((x) => [x.code, x.base, R.dmh(x.t), x.por])),
            linhaBotoes(botaoCopiar("Copiar códigos", () => expedidos.map((x) => x.code).join("\n"), "bt s"))
          )
        : null,
      campoBusca(res2),
      R.ordemSecoes.split("").map((k) => {
        const g = ativos.filter((r) => r.sec === k);
        if (!g.length) return null;
        const d = secao(
          `sec-${k}`,
          R.SEC[k],
          g.length,
          SECOES_ABERTAS.includes(k),
          el(
            "div",
            { class: "tabela-tent" },
            tabela(
              ["Código", "O que fazer", "Entregador", "Tent.", "Último bipe", "Dias", "Detalhe"],
              g.map((r) => [r.code, r.fazer, R.semF(r.entregador), r.tentTxt, r.ultimo, String(r.dias), r.detalhe])
            )
          )
        );
        secoes[k] = d;
        return d;
      }),
      naoChegou.length
        ? secao(
            "sec-N",
            R.SEC.N,
            naoChegou.length,
            false,
            tabela(["Código", "Bipado em", "Dias", "Último bipe", "Aviso"], naoChegou.map((r) => [r.code, r.ultimo, String(r.dias), r.ultimoDesc, r.aviso]))
          )
        : null,
      secao("apagada", R.SEC.X, sairam.length, false, tabela(null, sairam.map((r) => [r.code, r.oque])))
    );
    encher(saida(), res2);
  }

  // ===================== Rastreio em lote =====================
  function abaRastreio() {
    const ta = el("textarea", { class: "mono", placeholder: "999..., 888...", spellcheck: false });
    const forcar = el("input", { type: "checkbox" });
    corpo.append(
      cartao(
        "entrada",
        tituloCartao("Rastreio em lote"),
        el("p", { class: "nota", text: "Cole os códigos em qualquer formato. Tudo fica salvo no Histórico." }),
        ta,
        linhaBotoes(botao("Rastrear", () => rodar(() => rastreioLote(ta, forcar.checked))), el("label", { class: "nota" }, forcar, " ignorar o que foi consultado há pouco")),
        ...blocoProgresso()
      ),
      el("div", { class: "saida" })
    );
  }

  async function rastreioLote(ta, forcar) {
    const lista = R.codigos(ta.value);
    if (!lista.length) return status("Nenhum código 999/888 encontrado.");
    const res = await rastrearLista(lista, "Rastreio em lote", "Rastreando", forcar);
    const linhas = lista.map((c) => {
      const d = res[c];
      if (!d) return [c, "", "NÃO CONSULTADO (erro ou bloqueio)", "", "", ""];
      const l = d[d.length - 1];
      if (!l) return [c, "", "SEM DADOS", "", "", ""];
      return [c, R.dmh(l.t), l.tipo + (l.exp ? " (expedido não chegou)" : ""), l.base, l.staff || l.por, l.motivo];
    });
    const tsv = linhas.map((r) => r.join("\t")).join("\n");
    status("");
    const res2 = el("div", { class: "resultado" });
    encher(
      res2,
      linhaBotoes(botaoCopiar("Copiar resultado", () => tsv)),
      campoBusca(res2, "Buscar código, base ou entregador"),
      secao("", "Último bipe de cada código", lista.length, true, tabela(["Código", "Último bipe", "Tipo", "Base", "Quem", "Motivo"], linhas))
    );
    encher(saida(), res2);
  }

  // ===================== Cobrar entregadores =====================
  function abaCobrar() {
    const ult = salvo("cobrar") || [];
    const ta = el("textarea", { class: "mono", placeholder: "999..., 888...", spellcheck: false, value: Array.isArray(ult) ? ult.join("\n") : "" });
    const nomes = el("textarea", { class: "mono nomes", spellcheck: false, placeholder: "NOME NO JMS = como chamar\n(uma pessoa por linha)", value: R.textoNomes(salvo("nomes") || {}) });
    corpo.append(
      cartao(
        "entrada",
        tituloCartao("Cobrar entregadores", Array.isArray(ult) && ult.length ? `${ult.length} vieram da Planilhas` : null),
        el("p", { class: "nota", text: "Cole os códigos ou use os que a Planilhas marcou. Monta uma mensagem por entregador, com as tratativas e os dados da cliente." }),
        ta,
        linhaBotoes(botao("Montar mensagens", () => rodar(() => cobrarMontar(ta)))),
        el(
          "details",
          { class: "nomes-box" },
          el("summary", { text: "Nomes dos entregadores" }),
          el("p", { class: "nota", text: "Como chamar cada entregador na mensagem. Fica só neste navegador. Sem nome aqui, vai o primeiro nome do JMS." }),
          nomes,
          botao(
            "Salvar nomes",
            () => {
              salvo("nomes", R.lerNomes(nomes.value));
              nomes.value = R.textoNomes(salvo("nomes") || {});
              toast("Nomes salvos");
            },
            "bt s"
          )
        ),
        ...blocoProgresso()
      ),
      el("div", { class: "saida" })
    );
  }

  async function cobrarMontar(ta) {
    const lista = R.codigos(ta.value);
    if (!lista.length) return status("Nenhum código.");
    const res = await rastrearLista(lista, "Cobrar entregadores", "Rastreando", true);
    const { grupos, resolvidos, naoConsultados } = R.gruposCobrar(lista, res);
    const tot = Object.values(grupos).flat().length;
    let i = 0;
    for (const g of Object.values(grupos))
      for (const p of g) {
        progressoBarra(++i, tot, "Dados da cliente");
        p.cli = await cliente(p.c);
      }
    const nomes = salvo("nomes") || {};
    const msgs = Object.entries(grupos).map(([staff, g]) => [staff, R.montarMsg(staff, g, nomes)]);
    status(`${msgs.length} mensagens prontas`);
    const res2 = el("div", { class: "resultado" });
    encher(
      res2,
      msgs.length || resolvidos.length ? campoBusca(res2, "Buscar entregador ou código") : null,
      msgs.length
        ? secao(
            "",
            "Mensagens",
            msgs.length,
            true,
            msgs.map(([s, m]) => el("div", { class: "item msg-item" }, el("div", { class: "msg-tit" }, el("b", { text: R.semF(s) || "(sem entregador)" }), botaoCopiar("Copiar", () => m)), el("div", { class: "msg", text: m })))
          )
        : null,
      naoConsultados.length ? fita(el("b", { text: `${naoConsultados.length} não foram consultados (erro ou bloqueio):` }), listaMono(naoConsultados)) : null,
      resolvidos.length ? secao("apagada", "Não precisa cobrar", resolvidos.length, false, tabela(null, resolvidos)) : null
    );
    encher(saida(), res2);
  }

  // ===================== Histórico =====================
  function abaHistorico() {
    corpo.append(
      cartao(
        "entrada",
        tituloCartao("Histórico", `guardado por ${CFG.historicoDias} dias`),
        el("p", { class: "nota" }, "Tudo que foi consultado fica salvo neste navegador. Cole na planilha ", el("b", { text: "Rastreios JMS – histórico salvo" }), " (na primeira linha vazia da coluna A)."),
        linhaBotoes(
          botao("Copiar de hoje", async (e) => {
            const b = e.currentTarget;
            const d = new Date();
            d.setHours(0, 0, 0, 0);
            exportar(R.ultimas(await DB.desde(d.getTime())), true, b);
          }),
          botao(
            "Copiar ainda não exportado",
            async (e) => {
              const b = e.currentTarget;
              exportar(R.ultimas(await DB.desde((Number(salvo("exportadoAte")) || 0) + 1)), true, b);
            },
            "bt s"
          ),
          botao(
            "Limpar histórico",
            async () => {
              if (confirm("Apagar todo o histórico salvo no navegador?")) {
                await DB.limpar();
                status("Histórico apagado");
              }
            },
            "bt s"
          )
        ),
        el("div", { class: "status", "aria-live": "polite" })
      )
    );
  }
  async function exportar(lista, marcar, botaoEl) {
    const linhas = R.linhasHistorico(lista);
    if (!linhas.length) return status("Nada para copiar");
    await copiar(linhas.join("\n"), botaoEl);
    if (marcar) salvo("exportadoAte", Date.now());
    status(`${linhas.length} linhas de ${lista.length} consultas copiadas`);
  }

  // ===================== Liga/desliga =====================
  function conferirLigado() {
    chrome.storage.local.get(["painel_jms", "permissao_extensao"], (r) => {
      const ligado = !!r && r.painel_jms === true && r.permissao_extensao !== false;
      if (ligado) montar();
      else desmontar();
    });
  }
  chrome.storage.onChanged.addListener((m, area) => {
    if (area !== "local") return;
    if (m.painel_jms || m.permissao_extensao) conferirLigado();
    if (m.tema) aplicarTema(m.tema.newValue);
  });
  conferirLigado();
})();
